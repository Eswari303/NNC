"""

 *
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc, and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 * 
 @author: ganisetti.raju
"""
from __future__ import unicode_literals
from django.db import connection,connections
from django.db import models
import json
from NNCPortal.commonMethodsNEOS import CommonMethods
import logging
logger = logging.getLogger(__name__)

#insert record into database
class CommonModelMethods(object):
    def insertRecord(self,info,tableName,dbname):
            logger.info('In insertRecordMethod in commonModels file')
            
            try :
                count = 0
                #print "inside insert record"
                placeholders = ', '.join(['%s'] * len(info))
                columns = ', '.join(info.keys())
                sql = "INSERT INTO "+str(tableName)+" ( %s ) VALUES ( %s )" % (columns, placeholders)
                print sql
                cur = connections[dbname].cursor()
                cur.execute(sql, info.values())
                count = int(cur.rowcount)
                #print count
                if not count:
                    print "Record not inserted"
                    logger.error('Record not inserted')
                id = cur.lastrowid
                cur.close()
                logger.info("id for last records to be inserted"+str(id))
                return count
            except Exception as e:
                # handle all your exceptions... this is just an example
                logger.info("Caught Exception:"+str(e))
                print str(e)
                return None
         
            
    def selectRecord(self,tableName,selectFields,queryString,dbname):
         logger.info('In selectRecord in commonModel file')
         try :
                count = 0
                #print "inside insert record"
                sql = 'SELECT '+selectFields+' from '+tableName+queryString
                logger.info('select query is '+str(sql))
                cur = connections[dbname].cursor()
                cur.execute(sql)
                commMM = CommonMethods()
                res = commMM.dictfetchall(cur)
                #res = cur.fetchall() 
                cur.close()
                return res
         except Exception as e:
            # handle all your exceptions... this is just an example
            logger.error("Caught Exception:"+str(e))
            return "Exception raised"
        
    def recordCount(self,tableName,queryString,dbname):
         logger.info('In selectRecord in commonmodels file')
         try :
                count = 0
                #print "inside insert record"
                sql = 'SELECT count(*)'+' from '+tableName+queryString
                
                logger.info('select query is '+str(sql))
                cur = connections[dbname].cursor()
                cur.execute(sql)
                res = cur.fetchone()
                print res
                #res = cur.fetchall() 
                cur.close()
                return res
         except Exception as e:
            # handle all your exceptions... this is just an example
            logger.error("Caught Exception:"+str(e))
            print "Caught Exception:"+str(e)
            return "Exception raised"
        
    def brchTkts(self, staffId):
        commMM = CommonMethods()
        sql = "SELECT ticketid,fieldvalue FROM incident_data ic,swcustomfieldvalues scv WHERE statusid = 16 AND staffid IN ("+str(staffId)+") AND scv.typeid = ic.ticketid AND scv.customfieldid=12 AND fieldvalue between now() AND date_add(now(),INTERVAL 30 MINUTE)";
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        return result
    
    def currentTime(self):
        logger.info("In get current time method")
        commMM = CommonMethods()
        cursor = connections['ticketRead'].cursor()
        sql = "select unix_timestamp(now()) as curr_time"
        print sql
        logger.info(sql)
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        return result
