"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from ConfigParser import ConfigParser
import os

class ConfigManager(object):
    #configuration file
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    _conf_file = BASE_DIR+'/NNCPortal/params.cfg'
    #get param
    VALUE='message'
    saltmsg = 'SALT'
    ldapHost = 'LDAP_HOST'
    ldapDomain = 'LDAP_Domain'
    userDomain = 'USERDOMAIN'
    redisKey = 'REDISKEY'
    redisSecret = 'REDISSECRET'
    redisAuthurl = 'REDISAUTHURL'
    apiurl = 'APIURL'
    ticketKey = 'TICKETKEY'
    ticketSecret = 'TICKETSECRET'
    ticketAuthurl = 'TICKETAUTHURL'
    ticketurl = 'TICKETURL'
    relVer = 'RELEASEVER'
    loginurl = 'LOGINURL'
    homeurl = 'HOMEURL'
    mhurl = 'MHURL'
    SHomeUrl = 'SHOMEURL'
    masterDB = 'MASTERDB'
    slaveDB = 'SLAVEDB'
    threshold ='THRESHOLD'
    TB = "TB"
    AB = "AB"
    V = "V"
    ST = "ST"
    NESPID = "NESPID"
    emailCount = "EMAILCOUNT"
    slamResLocation = "slamResLocation"
    defaultTimeZone = "defaultTimeZone"
    logType = "logType"
    apiPointing = "APIPOINTING"
    HUBOTURL = 'HUBOTURL'
    attUrl = 'ATTURL'
    defaultTimeZone = 'defaultTimeZone'
    RequirementFormToEmail = 'RequirementFormToEmail'
    RequestFormSponsorEmail = 'RequestFormSponsorEmail'
    RequestFormCategories = 'RequestFormCategories'
    ReviewMetric = "ReviewMetric"
    QualityRating = "QualityRating"
    colorArray = "colorArray"
    DjnagoAppsApiUrl = "DjnagoAppsApiUrl"
    HrDataToEmail = "HrDataToEmail"
    Monitoringurl = "MONITORINGURL"
    MonitoringAPIValues = "MONITORING_APIVALUES"
    OBValidationCheckTeam = "OBValidationCheckTeam"
    NEOSDivaMapping = "NEOSDivaMapping"
    Statuses = "Statuses"
    Priorities = "Priorities"
    maxFileSize = 'maxFileSize'
    app_env = "APP_ENV"
    mspid_checks = "MSPID_checks"
    blockstatus_msps = "BLOCKSTATUS_MSPS"
    blockstatus_clients = "BLOCKSTATUS_CLIENTS"
    FileUploadPath = "fileUploadPath"

    def __init__(self):
        self.cfg = ConfigParser()
        self.cfg.read(self._conf_file)
    #get config parameters for login dictionary
    def getConfigValue(self, key):
        try:
            return self.cfg.get("Login", key)
        except:
            raise Exception('not found')
    #get config parameters for common dictionary
    def getCommConfigValue(self,key):
        try:
            return self.cfg.get("Common", key)
        except:
            raise Exception('not found')
    def getRepTypeConfigValue(self, key):
        try:
            return self.cfg.get("REPORT_TYPES",key)
        except:
            raise Exception('not found')
