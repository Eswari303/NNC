
import logging
logger = logging.getLogger(__name__)
from django.db import connection,connections
from NNCPortal import AutoClosureConfig
from NNCPortal import nebotConfig
import json,requests,urllib,math
from collections import OrderedDict

class CommonMethods(object):
    #convert cursor date into dictionary
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
        
    def orderDictFetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                OrderedDict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
        
    def processDictData(self,data):
        for index in data:
            if index["priorityid"] == 8 :
                index['priority'] = "critical"
                
            if index["priorityid"] == 9 :
                index['priority'] = "High"
                
            if index["priorityid"] == 10 :
                index['priority'] = "Medium"
                    
            if index["priorityid"] == 11 :
                index['priority'] = "Low"
        return data
    #insert record into database
    def insertRecord(self,info,tableName,cur):
        print "----------------------------------------->"
        try :
            count = 0
            #print "inside insert record"
            placeholders = ', '.join(['%s'] * len(info))
            columns = ', '.join(info.keys())
            
            sql = "INSERT INTO "+str(tableName)+" ( %s ) VALUES ( %s )" % (columns, placeholders)
            #print sql
            print ".............................."
            print sql 
            cur.execute(sql, info.values())
            count = int(cur.rowcount)
            #print count
            if not count:
                print "Record not inserted"
            return count
        except Exception as e:
            # handle all your exceptions... this is just an example
            print sql
            logger.info('Caught Exception: %s' % e)
            
            
    def updateRecord(self,Info,tableName,condition,dbname):
        try :    
            sql = 'UPDATE '+str(tableName)+' SET {}'.format(', '.join('{}=%s'.format(key) for key in Info))
            sql = sql + " where "+str(condition)
            #print sql
            cur = connections[dbname].cursor()
            cur.execute(sql, Info.values())
            count = int(cur.rowcount)
            if count == 0 :
                print "details did not found"
            cur.close()
            return count
        except Exception as e:
            # handle all your exceptions... this is just an example
            print sql
            print('Caught Exception: %s' % e)
           
    
    def preparingQueryString(self,queryString): 
        "preparing filter query from querystring" 
        #qry  ="where "
        logger.info('In preparingQueryString method in commonMthods file')
        count = 0
        if len(queryString) > 0 :
            qry = " where "
        else:
            qry = ''
            
        for key, value in queryString.iteritems():
            count +=1  
            key = key.strip()
            value = value.strip()
            
            if(value.startswith("(")) :
                value = value.replace("(","( "+key+"=").replace(","," OR "+key+"=")
                qry += str(value)
                
            elif(value.startswith("[")):
                value= value.replace("["," BETWEEN '").replace(",","' AND '").replace("]","'")
                qry += str(key)+str(value)
                
            elif(value.startswith(">")):
                if(value.startswith(">=")):
                    value = value.replace(">="," >= ")
                else:
                    value = value.replace(">"," > ")
                qry += str(key)+str(value)
                
            elif(value.startswith("NULL")):
                 #value = value.replace("NULL"," is NULL")
                 qry += str(key)+" is NULL"
                    
            elif(value.startswith("<")):
                if(value.startswith("<=")):
                    value = value.replace("<="," <= ")
                else:
                    value = value.replace("<"," < ")
                qry += str(key)+str(value)
            
            elif(value.startswith("~")):
                value = value.replace("~","")
                qry += str(key)+" NOT IN('"+ str(value)+"')"
            
            elif(value.startswith("%")):
                #value = value.replace("%","")
                qry += str(key)+" LIKE '"+str(value)+"'"
            elif(value.startswith("*")):
                value = value.replace("*","")
                qry += str(key)+" "+str(value)
           
            else:
                qry += "%s='%s'"%(key,value) 
                
            if count < len(queryString):
                qry += " AND "
        logger.error('Filter querysting is'+qry)      
        return qry    
          
    def createJsonData(self,queryString):
        ''' This method will convert the requested queryString into Json format'''
        logger.info('In createJsonData method in views.py')
        str = []
        str = queryString.split('+')
        querySting_json = {}
        for var in str:
            data = var.split(':',1)
            querySting_json[data[0]] = data[1]
       
        return querySting_json 

    def prparingSelectFields(self,tableName,dbname):
         try :
                count = 0
                #print "inside insert record"
                selectFields = ''
                sql = 'SHOW columns FROM '+tableName
                cur = connections[dbname].cursor()
                cur.execute(sql)
                commMM = CommonMethods()
                res = commMM.dictfetchall(cur)
                for var in res:
                     count += 1
                     selectFields += var['Field'] +" as "+ var['Field']
                     if count < len(res):
                         selectFields += ","
                
                #res = cur.fetchall() 
                cur.close()
                return selectFields
         except Exception as e:
            # handle all your exceptions... this is just an example
            print('Caught Exception: %s' % e)  
          
            
    def paginationMethod(self,request):
        extentionQuery =''
        finalResponse= {}
        totalRecordsCount = 0
        if('orderBy' in request.query_params):
            finalResponse['orderBy']= request.query_params['orderBy']
            extentionQuery += " order by "+str(request.query_params['orderBy'])+" DESC "
        else:
            finalResponse['orderBy']= nebotConfig.defaultOrderBy
            extentionQuery += " order by "+str(nebotConfig.defaultOrderBy)+" DESC "

        if('pageSize' in request.query_params):
            finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(request.query_params['pageSize'])))
            finalResponse['pageSize']= request.query_params['pageSize']
            extentionQuery += " LIMIT  "+str(request.query_params['pageSize'])
        else:
            finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(nebotConfig.defaultPageSize)))
            finalResponse['pageSize']= nebotConfig.defaultPageSize
            extentionQuery += " LIMIT "+str(nebotConfig.defaultPageSize)
            
        if('pageNo' in request.query_params):
            pageNo = int(request.query_params['pageNo'])
            OFFSET = ((pageNo-1)*int(finalResponse['pageSize']))
            extentionQuery += " OFFSET "+OFFSET
        else:
            pageNo = int(nebotConfig.defaultPageNo)
            OFFSET = (pageNo-1)*int(finalResponse['pageSize'])
            extentionQuery += " OFFSET "+str(OFFSET)
    
        return extentionQuery    
    
    def createJsonData1(self,queryString):
        ''' This method will convert the requested queryString into Json format'''
        logger.info('In createJsonData  method in commonmethods.py')
        str = []
        str = queryString.split('+')
        querySting_json = {}
        for var in str:
            data = var.split(':')
            querySting_json[data[0]] = data[1]
        return querySting_json
    
    def postRequest(self,body,filename):
        try:  
            postUrl=str(AutoClosureConfig.sendMailUrl)
            postDict = {}
            postDict['to']="ganisetti.raju@netenrich.com"
            postDict['subject']="Exception in Autoclosure functionality, FileName is :"+str(filename)
            postDict['cc']='suresh.patimeeda@netenrich.com,pavan.konduri@netenrich.com,mastan.shaik@netenrich.com'
            postDict['body']=str(body)
            header = {"content-type":"application/json"}
            print "post dict :",postDict
            print "1"
            ResponseIs = requests.post(postUrl,headers = header,data=json.dumps(postDict)) 
            print 'Update Table Status : ',ResponseIs.content
            if int(ResponseIs.status_code) == 200:
                return True
            else:
                return False
        except Exception as msg:
            print "Exception in post Request",msg
    
    