"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from __future__ import unicode_literals
from django.db import models, connections
from django.core.cache import caches
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)

class NtsMimeTypes(models.Model):
    ext = models.CharField(max_length=20)
    mime_type = models.CharField(max_length=50, blank=True, null=True)

    class Meta:
        db_table = 'nts_mime_types'
        app_label = 'ticket'
    
    def getNtsmimetypes(self):
        ntsMimes = mem_cache.get('ntsMimes'+env)
        if not ntsMimes:
            cursor = connections['ticketRead'].cursor()
            sql = 'select * from nts_mime_types'
            cursor.execute(sql)
            ntsMimes = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('ntsMimes'+env, ntsMimes, 86400)
        return ntsMimes
    
    def dictfetchall(self,cursor):
        "Returns all rows from a cursor as a dict"
        desc = cursor.description
        return [dict(zip([col[0] for col in desc], row)) for row in cursor.fetchall()]
