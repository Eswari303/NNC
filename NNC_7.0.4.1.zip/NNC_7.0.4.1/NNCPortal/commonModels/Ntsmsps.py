"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from __future__ import unicode_literals
from django.db import models
from django.db import connections
from django.core.cache import caches
from operator import itemgetter
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)

class Ntsmsps(models.Model):
    mspid = models.BigIntegerField(primary_key=True)
    mspname = models.CharField(max_length=255, blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    mspcode = models.CharField(max_length=50, blank=True, null=True)
    updated_time = models.DateTimeField(blank=True, null=True)
    channel_id = models.IntegerField(blank=True, default=0)
    ticketing_module = models.IntegerField(blank=True, default=0)
    tcks_support = models.IntegerField(blank=True, default=0)
    ticketing_system_id = models.BigIntegerField(null=True, blank=True)
    
    def __unicode__(self):
        return unicode(self.mspid)
    
    class Meta:
        managed = True
        app_label = 'noiseDashboard'
        db_table = 'ntsmsps'
    
    """Returns MSP data"""
    def getMSPSdata(self):
        msps = mem_cache.get('msps'+env)
        if not msps:
            sql = 'select mspid, mspname from ntsmsps where status=1 order by mspname'
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            msps = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set("msps"+env, msps, 86000)
        return msps
    
    """ Returns msp details for concerned mspid """
    def getMspByID(self, mspid):
        msp_data = mem_cache.get('mspdata'+env)
        if not msp_data:
            sql = 'select mspid, mspname from ntsmsps'
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            msp_data = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set("mspdata"+env, msp_data, 86000)

        try:
            index = map(itemgetter('mspid'), msp_data).index(mspid)
            return msp_data[index]['mspname']
        except Exception as e:
            print ("msp error:", e.message)
    
    """ Returns partners based on noc """       
    def getpartners(self,nocid = 0):
        cursor = connections['ticketRead'].cursor()
        if nocid :
            partners = mem_cache.get('nocID-'+str(nocid)+'partner'+env)
            if not partners :         
                sql = 'select distinct t.mspid, t.mspname from ntsmsps t join ntsmspclients ntsc on t.mspid = ntsc.mspid where ntsc.status = 1 and ntsc.nocid = '+str(nocid)+' order by t.mspname'
                cursor.execute(sql)
                partners = self.dictfetchall(cursor)
                mem_cache.set('nocID-'+str(nocid)+'partner'+env, partners, 86400)
        else :
            partners = mem_cache.get('nocID-'+str(nocid)+'partner'+env)
            if not partners :         
                sql = 'select distinct t.mspid, t.mspname from ntsmsps t join ntsmspclients ntsc on t.mspid = ntsc.mspid where ntsc.status = 1 order by t.mspname'
                cursor.execute(sql)
                partners = self.dictfetchall(cursor)
                mem_cache.set('nocID-'+str(nocid)+'partner'+env, partners, 86400)
        cursor.close()
        return partners
    
    """ Returns partners related to channel """
    def getChannelPartners(self,channelId = 0):
        cursor = connections['ticketRead'].cursor()
        if channelId :
            partners = mem_cache.get('channelID-'+str(channelId)+'partners'+env)
            if not partners :         
                sql = 'select distinct t.mspid, t.mspname from ntsmsps t join ntsmspclients ntsc on t.mspid = ntsc.mspid where ntsc.status = 1 and ntsc.channel_id = '+str(channelId)+' order by t.mspname'
                cursor.execute(sql)
                partners = self.dictfetchall(cursor)
                mem_cache.set('channelID-'+str(channelId)+'partners'+env, partners, 86400)
        else :
            partners = mem_cache.get('channelID-'+str(channelId)+'partners'+env)
            if not partners :         
                sql = 'select distinct t.mspid, t.mspname from ntsmsps t join ntsmspclients ntsc on t.mspid = ntsc.mspid where ntsc.status = 1 order by t.mspname'
                cursor.execute(sql)
                partners = self.dictfetchall(cursor)
                mem_cache.set('channelID-'+str(channelId)+'partners'+env, partners, 86400)
        cursor.close()
        return partners
    
    """ Returns active partners """
    def partnerName(self):
        cursor = connections['ticketRead'].cursor()
        sql = 'select distinct t.mspid, t.mspname from  ntsmsps t JOIN ntsmspclients ntsc ON t.mspid=ntsc.mspid   where  ntsc.status=1  order by  t.mspname '
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        partnersList = {}
        for i in result:
            partnersList[i['mspid']] = i['mspname']
        return partnersList


    def partnerNewDatacenterDetails(self):
        partnersNewDC = mem_cache.get('partnersNewDC'+env)
        if not partnersNewDC:
            cursor = connections['ticketRead'].cursor()
            sql = 'select ntsm.datacenter_code, ntsm.mspid, dc.portal_url, ntsm.dc_msp_id from ntsmsps ntsm join datacenter dc on(ntsm.datacenter_code = dc.datacenter_code)'
            cursor.execute(sql)
            partnersNewDC = self.dictfetchall(cursor)
            cursor.close()
            partnersNewDC = dict([(record['mspid'], record) for record in partnersNewDC ])
            mem_cache.set('partnersNewDC'+env, partnersNewDC, 86400)
        return partnersNewDC

    def clientNewDatacenterDetails(self):
        clientsNewDC = mem_cache.get('clientsNewDC'+env)
        if not clientsNewDC:
            cursor = connections['ticketRead'].cursor()
            sql = 'select ntsm.datacenter_code, ntsm.mspclientid, dc.portal_url, ntsm.dc_mspclient_id from ntsmspclients ntsm join datacenter dc on(ntsm.datacenter_code = dc.datacenter_code)'
            cursor.execute(sql)
            clientsNewDC = self.dictfetchall(cursor)
            cursor.close()
            clientsNewDC = dict([(record['mspclientid'], record) for record in clientsNewDC ])
            mem_cache.set('clientsNewDC'+env, clientsNewDC, 86400)
        return clientsNewDC


    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
        
    def allPartnerName(self):
        partnersList = mem_cache.get('activeIactivePartners'+env)
        if not partnersList:
            cursor = connections['ticketRead'].cursor()
            sql = 'select distinct t.mspid, t.mspname from  ntsmsps t JOIN ntsmspclients ntsc ON t.mspid=ntsc.mspid    order by  t.mspname '
            cursor.execute(sql)
            result = self.dictfetchall(cursor)
            cursor.close()
            partnersList = {}
            for i in result:
                partnersList[i['mspid']] = i['mspname']
            mem_cache.set('activeIactivePartners'+env,partnersList,3600)
        return partnersList

        """ Returns msp details """
    def getMsps(self):
        msp_data = mem_cache.get('mspById'+env)
        if not msp_data:
            sql = 'select mspid, mspname from ntsmsps'
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            msp_dat = self.dictfetchall(cursor)
            cursor.close()
            msp_data ={}
            for msp in msp_dat:
                msp_data[msp['mspid']] = msp['mspname']
            mem_cache.set("mspById"+env, msp_data, 86000)
        return msp_data