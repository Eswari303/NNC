"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import models, connections
from django.core.cache import caches
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)

class Ntschannel(models.Model):
    version = models.BigIntegerField(blank=True, null=True)
    name = models.CharField(max_length=45)
    time_zone = models.CharField(max_length=64)

    class Meta:
        app_label = 'serviceManagement'
        db_table = 'ntschannel'
        
    def getChanneldata(self):
        channels = mem_cache.get('channels'+env)
        if not channels:
            sql = 'select name, id from ntschannel order by name'
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            channels = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('channels'+env, channels, 86000)
        return channels

    def dictfetchall(self, cursor):
        "Returns all rows from a cursor as a dict"
        desc = cursor.description
        return [
            dict(zip([col[0] for col in desc], row))
            for row in cursor.fetchall()
            ]
