"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from __future__ import unicode_literals
from django.db import models, connections
from django.template.defaultfilters import default
from django.core.cache import caches
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)

class Ntsmspclients(models.Model):
    mspclientid = models.BigIntegerField(primary_key=True)
    mspid = models.BigIntegerField(null = True)
    clientname = models.CharField(max_length=255, blank=True)
    status = models.IntegerField(blank=True, null=True)
    clientcode = models.CharField(max_length=50, blank=True, null=True)
    #updated_time = models.DateTimeField(blank=True, null=True)
    servicestageid = models.IntegerField(blank=True, default = 0)
    servicetypeid = models.IntegerField(blank=True, default = 0)
    channel_id = models.IntegerField(blank=True, default = 0, null = True)
    nocid = models.BigIntegerField(default = 0)
    nocname = models.CharField(max_length=100, blank=True)
    
    
    class Meta:
        managed = True
        app_label = 'serviceManagement'
        db_table = 'ntsmspclients'        
     
    """ Returns clients related to partner """   

    def showPartnerClients (self):
        cursor = connections['ticketRead'].cursor()
        patnerclients = mem_cache.get('patnerclients'+env)
        if not patnerclients:
            sql = 'select msp.mspname,cli.mspclientid,cli.clientname,cli.mspid from ntsmspclients cli JOIN ntsmsps msp ON (cli.mspid = msp.mspid) where cli.status = 1  order by clientname'
            cursor.execute(sql)
            patnerclients = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('patnerclients'+env,patnerclients,14400)
        return patnerclients
    
    """ Returns client details related to noc """
    def getClients(self, nocid=0):
        cursor = connections['ticketRead'].cursor()
        if nocid :
            clients = mem_cache.get('nocID-' + str(nocid) + 'clients'+env)
            if not clients :         
                sql = 'select mspclientid, clientname from ntsmspclients where status = 1 and nocid = '+str(nocid)+' order by clientname'
                cursor.execute(sql)
                clients = self.dictfetchall(cursor)
                mem_cache.set('nocID-' + str(nocid) + 'clients'+env, clients, 86400)
        else :         
            clients = mem_cache.get('nocID-' + str(nocid) + 'clients'+env)
            if not clients:         
                sql = 'select mspclientid, clientname from ntsmspclients where status = 1 order by clientname'
                cursor.execute(sql)
                clients = self.dictfetchall(cursor)
                mem_cache.set('nocID-' + str(nocid) + 'clients'+env, clients, 86400)
        cursor.close()
        return clients
    
    """ Returns Clients related to particular partner """
    def getClientsOfPartner(self,pid):
        cursor = connections['ticketRead'].cursor()
        clients =[]
        if pid :
            if pid.find(',') == -1:
                pid_cache = str(pid)+env
                clients = mem_cache.get(pid_cache)
            if not clients :     
                pid_cache = str(pid)+env
                sql = 'select msp.mspname,cli.clientname,cli.mspid,cli.mspclientid from ntsmspclients cli JOIN ntsmsps msp ON (cli.mspid = msp.mspid) where cli.status = 1 and  cli.mspid IN( '+str(pid)+') order by clientname';
                cursor.execute(sql)
                clients = self.dictfetchall(cursor)
                mem_cache.set(pid_cache, clients, 86400)
        else :
            clients = mem_cache.get('all'+env)
            if not clients :         
                sql = 'select msp.mspname,cli.clientname,cli.mspid,cli.mspclientid from ntsmspclients cli JOIN ntsmsps msp ON (cli.mspid = msp.mspid) where cli.status = 1 order by clientname';
                cursor.execute(sql)
                clients = self.dictfetchall(cursor)
                mem_cache.set('all'+env, clients, 86400)
        cursor.close()
        return clients
    
    """ Returns clients related to channel """
    def getChannelClients(self,channelId = 0):
        cursor = connections['ticketRead'].cursor()
        if channelId :
            clients = mem_cache.get('channelID-' + str(channelId) + 'clients'+env)
            if not clients :         
                sql = 'select mspclientid, clientname from ntsmspclients where status = 1 and nocid = '+str(channelId)+' order by clientname'
                cursor.execute(sql)
                clients = self.dictfetchall(cursor)
                mem_cache.set('channelID-' + str(channelId) + 'clients'+env, clients, 86400)
        else :         
            clients = mem_cache.get('channelID-' + str(channelId) + 'clients'+env)
            if not clients:         
                sql = 'select mspclientid, clientname from ntsmspclients where status = 1 order by clientname'
                cursor.execute(sql)
                clients = self.dictfetchall(cursor)
                mem_cache.set('channelID-' + str(channelId) + 'clients'+env, clients, 86400)
        cursor.close()
        return clients
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]

     
    
    def Allclients(self):
        cursor = connections['ticketRead'].cursor()
        patclients = mem_cache.get('activeIactiveClients'+env)
        if not patclients:
            sql = 'select msp.mspname,cli.mspclientid,cli.clientname,cli.mspid from ntsmspclients cli JOIN ntsmsps msp ON (cli.mspid = msp.mspid)  order by clientname'
            cursor.execute(sql)
            patclients = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('activeIactiveClients'+env,patclients,3600)
        return patclients
        
