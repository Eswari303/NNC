"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import models, connections

class StaffDeptMapping(models.Model):
    managerid = models.IntegerField()
    nrstaffid = models.IntegerField()
    swstaffid = models.IntegerField()
    kayako_deptid = models.IntegerField()  # Field name made lowercase.
    hr_calendar_day = models.IntegerField()

    class Meta:
        db_table = 'staff_dept_mapping'
        app_label = 'employeeDashboard'
        
    def getDepartments(self,nrstaffid):
        sql = "select kayako_deptId from staff_dept_mapping where nrstaffid = "+str(nrstaffid)
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        res = self.dictfetchall(cursor)
        cursor.close()
        return res

    
    def employeeKayakoDept(self, eNrStffId):
        sql =  "select  DISTINCT kayako_deptId from  staff_dept_mapping where  nrstaffid ="+str(eNrStffId);
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result
    
    '''   '''
    def employeeKayakoDeptStaging(self, eNrStffId):
        sql =  "select  DISTINCT kayako_deptId from  staff_dept_mapping where  nrstaffid ="+str(eNrStffId);
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result
    
    '''   Method used for Department mapping functionlaity   '''
    def deletingRecordOfstaff(self, eNrStffId):
        sql = "delete from staff_dept_mapping where nrstaffid ="+str(eNrStffId)
        cursor = connections['rosterWrite'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result
    
    '''   '''
    def staffDeptMappingStatus(self, eNrStffId):
        sql = "select count(*) as count from staff_dept_mapping where nrstaffid ="+str(eNrStffId)
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result[0]['count']
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]