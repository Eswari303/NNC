"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import models, connections
from django.core.cache import caches
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)

class NrDepartments(models.Model):
    dept_name = models.CharField(unique=True, max_length=50)
    dept_desc = models.CharField(max_length=45, blank=True, null=True)
    nocid = models.IntegerField()
    is_roster = models.IntegerField(blank=True, null=True)
    class Meta:
        db_table = 'nr_departments'
        app_label = 'managerDashboard'


class NrGroups(models.Model):
    grp_name = models.CharField(unique=True, max_length=10)
    grp_desc = models.CharField(max_length=50)
    nocid = models.IntegerField()

    class Meta:
        db_table = 'nr_groups'
        app_label = 'managerDashboard'


class NrStaff(models.Model):
    employee_number = models.SmallIntegerField(blank=True, null=True)
    employee_id = models.CharField(max_length=10, blank=True, null=True)
    user_name = models.CharField(unique=True, max_length=150, blank=True, null=True)
    pwd = models.CharField(max_length=100, blank=True, null=True)
    staff_fname = models.CharField(max_length=25)
    staff_lname = models.CharField(max_length=25)
    staff_email = models.CharField(unique=True, max_length=82)
    staff_alternate_email = models.CharField(max_length=82, blank=True, null=True)
    dept = models.ForeignKey(NrDepartments, models.DO_NOTHING)
    roster_id = models.IntegerField(blank=True, null=True)
    grp = models.ForeignKey(NrGroups, models.DO_NOTHING)
    desig_id = models.IntegerField(blank=True, null=True)
    swstaff_id = models.IntegerField(blank=True, null=True)
    staff_resource_type = models.IntegerField()
    is_admin = models.IntegerField()
    is_ad_admin = models.IntegerField(blank=True, null=True)
    nocid = models.IntegerField()
    manupulate_staff_roster = models.IntegerField(blank=True, null=True)
    alltickets_acess = models.IntegerField(blank=True, null=True)
    is_active = models.SmallIntegerField(blank=True, null=True)
    is_found = models.SmallIntegerField(blank=True, null=True)
    reporting_manager_id = models.IntegerField(blank=True, null=True)
    date_of_join = models.DateField(blank=True, null=True)
    phone_number = models.CharField(max_length=15, blank=True, null=True)
    skype_id = models.CharField(max_length=50, blank=True, null=True)
    escalation_adm = models.IntegerField(blank=True, null=True)
    is_tb_admin = models.IntegerField(blank=True, null=True)
    is_ic_admin = models.IntegerField(blank=True, null=True)
    total_exp = models.FloatField(blank=True, null=True)
    is_mngr_dboard_access = models.IntegerField(blank=True, null=True)
    sdmtracker_access = models.IntegerField(blank=True, null=True)
    hrdata_access = models.IntegerField(blank=True, null=True)
    class Meta:
        db_table = 'nr_staff'
        app_label = 'managerDashboard'       
    def getSwStaffByRoster(self):
        SwStaffByRoster = mem_cache.get('SwStaffByRoster'+env)
        if not SwStaffByRoster:
            sql = "SELECT DISTINCT(staff.id), staff.staff_fname, staff.staff_lname, concat(staff.staff_fname,' ', staff.staff_lname) as staff_fullname, staff.employee_id, addept.dept_name, rosterdept.dept_name AS roster, staff.user_name as samaccountname, staff.staff_email, staff.swstaff_id FROM nr_staff staff LEFT JOIN nr_departments addept ON (addept.id = staff.dept_id) LEFT JOIN nr_departments rosterdept ON (rosterdept.id = staff.roster_id) WHERE staff.is_active = 1 AND staff.is_found = 1 AND swstaff_id > 0 ORDER BY roster,staff.staff_fname, staff.staff_lname"
            cursor = connections['rosterRead'].cursor()
            cursor.execute(sql)
            SwStaffByRoster = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('SwStaffByRoster'+env,SwStaffByRoster,86400)
        return SwStaffByRoster
    
    def getStaffInfo(self):
        sql = "select user_name as label,staff_email as value from nr_staff where is_active = 1"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        finResult = self.dictfetchall(cursor)
        cursor.close()
        return finResult
    
    
    '''   Method to bring employee designation for Team details pane.   '''
    def getEmpDesig(self,nrstaffids):
        sql = 'select nr.id,nd.desig_name,concat(staff_fname," ",staff_lname) as empname from nr_staff nr join nr_designations nd on nd.id = nr.desig_id and nr.id in ('+str(nrstaffids)+') order by empname'
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        empDesig = self.dictfetchall(cursor)
        cursor.close()
        return empDesig
    
    '''   Method to bring employee details for Department mapping.   '''
    def employeeDetails(self, eId):
        sql = "SELECT reporting_manager_id,swstaff_id,id FROM nr_staff WHERE id ="+str(eId)+" and  reporting_manager_id > 0 AND swstaff_id > 0 AND is_active = 1 AND is_found = 1 "
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        empDtails = self.dictfetchall(cursor)
        cursor.close()
        return empDtails
    
    '''   Method to bring emp details using swstaffid   '''
    def getStaffInformation(self, swstaffId):
        sql = "select concat(staff_fname,' ',staff_lname) as empname from nr_staff where swstaff_id = "+str(swstaffId)
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        finResult = self.dictfetchall(cursor)
        cursor.close()
        return finResult
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
    
    def getStaffData(self):
        staff_data = mem_cache.get("staffdata")
        if not staff_data:
            cursor = connections['rosterRead'].cursor()
            sql = "select swstaff_id, staff_fname, staff_lname from nr_staff"
            cursor.execute(sql)
            staff_dat = self.dictfetchall(cursor)
            staff_data= {}
            for stf in staff_dat:
                staff_data[stf['swstaff_id']] = str(stf['staff_fname']) +' ' +str(stf['staff_lname'])
            mem_cache.set("staffdata", staff_data, 86000)
            cursor.close()
        return staff_data
    
    def staffDataByCache(self):
        final = mem_cache.get("staffCacheData"+env)
        if not final:
            cursor = connections['rosterRead'].cursor()
            sql = "SELECT id,swstaff_id,staff_email,staff_fname, staff_lname FROM nr_staff WHERE is_active = 1 AND is_found = 1 AND swstaff_id > 0"
            cursor.execute(sql)
            staff_data = self.dictfetchall(cursor)
            cursor.close()
            nrstaffIdBasedData = {}
            swstaffIdBasedData = {}
            for staff in staff_data:
                set1 ={}
                set2={}
                nrstaffIdBasedData.setdefault(staff['id'],{})
                swstaffIdBasedData.setdefault(staff['swstaff_id'],{})
                fullname = str(staff['staff_lname'])+' '+str(staff['staff_fname'])
                set1['swstaffid']= staff['swstaff_id']
                set1['fullname']= fullname
                set1['email']=str(staff['staff_email'])
                nrstaffIdBasedData[staff['id']] = set1
                
                set2['nrstaffid']= staff['id']
                set2['fullname']= fullname
                set2['email']=str(staff['staff_email'])
                swstaffIdBasedData[staff['swstaff_id']] = set2
            final = {}
            final['nrstaffId'] = nrstaffIdBasedData
            final['swstaffId'] = swstaffIdBasedData
            mem_cache.set("staffCacheData"+env, final, 86000)
        return final    
