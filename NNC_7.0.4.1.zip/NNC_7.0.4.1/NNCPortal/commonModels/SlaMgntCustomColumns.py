"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import models
from django.db import connections
from django.core.cache import caches
from _collections import defaultdict
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)

class SlaMgntCustomColumns(object):

    def getCustomCoulmnFields(self, parent_id = 0, columns = defaultdict(dict), parent_column=''):
        cursor = connections['rosterRead'].cursor()
        sql = "SELECT * FROM sla_mgnt_custom_columns WHERE parent_id= "+str(parent_id)+" AND  is_default_field= 0  AND is_display = 1"
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        for res in result:
            sql = "SELECT COUNT(*) as count FROM sla_mgnt_custom_columns WHERE parent_id="+str(res['id'])+" AND  is_default_field= 0"
            cursor.execute(sql)
            count = self.dictfetchall(cursor)
            for cnt in count:
                childColumnsCount = cnt['count']
            if childColumnsCount > 0:
                columns = self.getCustomCoulmnFields(res['id'], columns, res['column_name'])
                
            else:
                if parent_column != '':
                    columns[parent_column][res['column_name']] = res['column_name'];
                else:
                    columns = res['column_name']
        cursor.close()
        return columns    
    
    def getDefaultCustomFields(self, columns = defaultdict(dict)):
        defaultCustomFields = mem_cache.get('defaultCustomFields'+env)
        if not defaultCustomFields:
            sql = "SELECT * FROM sla_mgnt_custom_columns_old WHERE is_default_field= 1 and is_display = 1 ORDER BY display_order"
            cursor = connections['rosterRead'].cursor()
            cursor.execute(sql)
            defaultCustomFields = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('defaultCustomFields'+env, defaultCustomFields, 86400)
        return defaultCustomFields
    
    def getSlamCustomColumns(self):
        #columns = mem_cache.get('slamCustomColumns')
        columns = mem_cache.get('finalCustomFields'+env)
        if not columns:
            columns = {}
            cursor = connections['rosterRead'].cursor()
            sql = "SELECT id,column_name FROM sla_mgnt_custom_columns WHERE parent_id= 0 AND is_display = 1"
            cursor.execute(sql)
            parentColumnsResult = self.dictfetchall(cursor)
            for parentColumns in parentColumnsResult:
                sql = "SELECT SQL_CALC_FOUND_ROWS column_name FROM sla_mgnt_custom_columns WHERE parent_id= "+str(parentColumns['id'])+" AND  is_default_field= 0  AND is_display = 1"
                cursor.execute(sql)
                childColumnsResult = self.dictfetchall(cursor)
                childColumnsDict = {}
                for childColumns in childColumnsResult:
                    childColumnsDict[childColumns['column_name']] = childColumns['column_name']
                
                if childColumnsDict:
                    columns[parentColumns['column_name']] = childColumnsDict                
            
            dbCustomFields = self.getCustomFields()
            for customField in dbCustomFields:
                if columns.has_key(customField['custom_field_group']):
                    columns[str(customField['custom_field_group'])]['cust_fld_'+str(customField['customfieldid'])] = customField['title']
                else:
                    columns[customField['custom_field_group']] = {}
                    columns[str(customField['custom_field_group'])]['cust_fld_'+str(customField['customfieldid'])] = customField['title']  
            mem_cache.set('finalCustomFields'+env, columns, 86400)
            #mem_cache.set('slamCustomColumns', columns, 86400)
        return columns
     
    def getCustomFields(self):
        result = mem_cache.get('customFields'+env)
        if not result:
            sql = "SELECT swcustfldgrp.title as custom_field_group, swcustfld.customfieldid, swcustfld.title FROM swcustomfields AS swcustfld JOIN swcustomfieldgroups AS swcustfldgrp ON swcustfldgrp.customfieldgroupid=swcustfld.customfieldgroupid WHERE swcustfld.title != 'LPI Ticket ID' ORDER BY swcustfldgrp.title, swcustfld.title"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('customFields'+env,result,86400)
        return result 
    
    def getDefaultCustomOrderBy(self):
        columns ={}
        sql = "SELECT * FROM sla_mgnt_custom_columns_old WHERE is_default_field= 1 and is_display = 1 order by display_order Asc"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        for res in result:
            columns[res['display_order']] = res['column_name']
        return columns   
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
     

