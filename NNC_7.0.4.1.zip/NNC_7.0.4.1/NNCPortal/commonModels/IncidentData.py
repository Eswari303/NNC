"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import models, connections
from _collections import defaultdict
from NNCPortal.commonModels.Swticketstatus import Swticketstatus
swtktstatus_obj = Swticketstatus()
from NNCPortal.commonModels.Swdepartments import Swdepartments
swdepts_obj = Swdepartments()
from django.core.cache import caches
mem_cache = caches['memcached']
class IncidentData(models.Model):
    ticketid = models.BigIntegerField(primary_key=True)
    created_dt = models.IntegerField()
    cid = models.BigIntegerField()
    client = models.CharField(max_length=255)
    mid = models.BigIntegerField()
    msp = models.CharField(max_length=255)
    nid = models.BigIntegerField()
    noc = models.CharField(max_length=100)
    channelid = models.IntegerField()
    channel = models.CharField(max_length=100, blank=True, null=True)
    did = models.BigIntegerField()
    device = models.CharField(max_length=255)
    package = models.CharField(max_length=255)
    sla_tooltip = models.CharField(max_length=300, blank=True, null=True)
    resol_sla = models.CharField(max_length=10)
    resp_sla = models.CharField(max_length=10)
    resol_due = models.IntegerField()
    resp_due = models.IntegerField()
    resp_slamet = models.SmallIntegerField(blank=True, null=True)
    resol_slamet = models.SmallIntegerField(blank=True, null=True)
    priorityid = models.IntegerField()
    priority = models.CharField(max_length=62, blank=True, null=True)
    resol_sec = models.BigIntegerField(blank=True, null=True)
    resp_sec = models.BigIntegerField(blank=True, null=True)
    statusid = models.IntegerField(blank=True, null=True)
    deptid = models.IntegerField(blank=True, null=True)
    sccalertid = models.BigIntegerField()
    sla_due = models.IntegerField(blank=True, null=True)
    record_updated_dt = models.IntegerField(blank=True, null=True)
    update_index = models.IntegerField(blank=True, null=True)
    devicetypeid = models.IntegerField(blank=True, null=True)
    devicetype = models.CharField(max_length=45, blank=True, null=True)
    lastactivity = models.IntegerField(blank=True, null=True)
    subject = models.CharField(max_length=175, blank=True, null=True)
    service_type = models.CharField(max_length=255, blank=True, null=True)
    service_level = models.CharField(max_length=255, blank=True, null=True)
    hmsp_count = models.IntegerField(blank=True, null=True)
    wfci_count = models.IntegerField(blank=True, null=True)
    fromp0tobelow = models.IntegerField(blank=True, null=True)
    fromp1tobelow = models.IntegerField(blank=True, null=True)
    fromp2tobelow = models.IntegerField(blank=True, null=True)
    fromp3toabove = models.IntegerField(blank=True, null=True)
    fromp2toabove = models.IntegerField(blank=True, null=True)
    fromp1toabove = models.IntegerField(blank=True, null=True)
    staffid = models.IntegerField(blank=True, null=True)
    totalreplies = models.IntegerField(blank=True, null=True)
    userreplies = models.IntegerField(blank=True, null=True)
    statuschanged_date = models.IntegerField(blank=True, null=True)
    duration = models.IntegerField(blank=True, null=True)
    lastreplier = models.CharField(max_length=255, blank=True, null=True)
    closed_time = models.IntegerField(blank=True, null=True)
    resolved_time = models.IntegerField(blank=True, null=True)
    lastpost = models.TextField(blank=True, null=True)
    businesshours = models.CharField(max_length=25, blank=True, null=True)
    second_responce_date = models.IntegerField(blank=True, null=True)
    first_responce_content = models.CharField(max_length=255, blank=True, null=True)
    second_responce_content = models.CharField(max_length=255, blank=True, null=True)
    status_changed_by = models.CharField(max_length=100, blank=True, null=True)
    timebillable = models.IntegerField(blank=True, null=True)
    business_hrs_start = models.TimeField(blank=True, null=True)
    business_hrs_end = models.TimeField(blank=True, null=True)
    timeworked = models.IntegerField(blank=True, null=True)
    hasattachments = models.SmallIntegerField(blank=True, null=True)
    devicegroupid = models.BigIntegerField(blank=True, null=True)
    devicegroup = models.CharField(max_length=255, blank=True, null=True)
    devicesite = models.CharField(max_length=255, blank=True, null=True)
    fullname = models.CharField(max_length=100, blank=True, null=True)
    devicecatid = models.IntegerField(blank=True, null=True)
    devicecategory = models.CharField(max_length=45, blank=True, null=True)
    email = models.CharField(max_length=180, blank=True, null=True)
    servicecatid = models.IntegerField(blank=True, null=True)
    servicecategory = models.CharField(max_length=45, blank=True, null=True)
    sku = models.CharField(max_length=100, blank=True, null=True)
    alertscount = models.IntegerField(blank=True, null=True)
    healedalertscount = models.IntegerField(blank=True, null=True)
    technology = models.CharField(max_length=45, blank=True, null=True)
    ab_ticketstatus = models.IntegerField(blank=True, null=True)
    psa_lastactivity_date = models.CharField(max_length=100, blank=True, null=True)
    psadata_as_on = models.IntegerField(blank=True, null=True)
    psa_post_count = models.IntegerField(blank=True, null=True)
    ticketing_system_type = models.CharField(max_length=255, blank=True, null=True)
    kyk_serviceboard = models.CharField(max_length=255, blank=True, null=True)
    is_status_matched = models.CharField(max_length=10, blank=True, null=True)
    is_board_matched = models.CharField(max_length=10, blank=True, null=True)
    primarymailid = models.CharField(max_length=255, blank=True, null=True)
    varnotificationtime = models.IntegerField(blank=True, null=True)
    csatrequest = models.CharField(max_length=5, blank=True, null=True)
    csatresponce = models.CharField(max_length=255, blank=True, null=True)
    client_timezone = models.TextField(blank=True, null=True)
    automation_flag = models.SmallIntegerField(blank=True, null=True)

    class Meta:
        app_label = 'noiseDashboard'
        db_table = 'incident_data'
        
    def getWidgetTickets_SM(self,searchAttribute,dept,wdg):
        if wdg == 1:
            sql = "select ticketid from incident_data where priorityid = 8 and resol_due >= 0 and resol_due <= 1800 and statusid not in (5 ,3,17,20,32 ,41) and  deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 2:
            sql = "select ticketid from incident_data where statusid in (1,7,12,18,19,21,22,23) and priorityid = 8 and unix_timestamp(now())-lastactivity > 1800 and  deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 3:
            sql = 'SELECT ticketid as count from incident_data i Join swcustomfieldvalues scfv where i.ticketid = scfv.typeid and scfv.customfieldid=12 and scfv.fieldvalue like "%-%-% %:%:%" and CONVERT_TZ(scfv.fieldvalue,"US/Pacific","UTC") between now() and date_add(now(), interval 30 minute)  and i.statusid not in (5 ,3 ,17 ,20 ,32 ,41) and i.deptid ' + searchAttribute + ' (' + dept + ')';
        elif wdg == 4:
            sql = "select i.ticketid  from incident_data i join swcustomfieldvalues scfv on i.ticketid = scfv.typeid where i.statusid = 9  and scfv.customfieldid = 3 and fieldvalue = ' ' and i.deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 5:
            sql = "select i.ticketid from incident_data i join swtickets st on st.ticketid=i.ticketid where unix_timestamp(now())-i.lastactivity>1800 and i.statusid not in  (5 ,3,17 ,20,32,41) and st.ownerstaffid=0 and i.deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 6:
            sql = "select ticketid from incident_data where statusid=1 and unix_timestamp(now())-lastactivity>3600 and deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 7:
            sql = "select ticketid from incident_data where statusid=19 and unix_timestamp(now())-lastactivity>1800 and deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 8:
            sql = "select ticketid from incident_data where priorityid = 9 and resol_due >= 0 and resol_due <= 1800 and statusid not in (5 ,3,17,20,32 ,41) and  deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 9:
            sql = "select ticketid from incident_data where statusid in (1,7,12,18,19,21,22,23) and priorityid = 9 and unix_timestamp(now())-lastactivity > 1800 and  deptid " + searchAttribute + " (" + dept + ")"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        tickets = cursor.fetchall()
        cursor.close()
        return tickets
    
    def getIdealTickets1(self,swtaffIds):
        sql = "select ticketid ,statusid,staffid,priorityid from incident_data where staffid in("+str(swtaffIds)+") and  priorityid in (8,9,10,11) and statusid not in (20,3,17,5,41,32) and lastactivity <= unix_timestamp(NOW() - INTERVAL 2 DAY) and deptid not in (0,1,2)"
        cursorIdealTick = connections['ticketRead'].cursor()
        cursorIdealTick.execute(sql)
        result = self.dictfetchall(cursorIdealTick)
        cursorIdealTick.close()
        return result
    
    def getSdRdtickets(self,staffInfo,stStamp,etStamp):
        sql = 'SELECT ic.priorityid,ic.ticketid,ic.statusid as sid,getntsstatussladue(ic.ticketid,ic.statusid) as sladue FROM  incident_data ic WHERE ic.staffid IN ('+str(staffInfo)+') AND (ic.statusid = 16 OR ic.statusid = 19) AND ((ic.created_dt >= '+str(stStamp)+' AND ic.created_dt <= '+str(etStamp)+') OR (ic.lastactivity >= '+str(stStamp)+' AND ic.lastactivity <= '+str(etStamp)+'))'
        tikcur = connections['ticketRead'].cursor()
        tikcur.execute(sql)
        res = self.dictfetchall(tikcur)
        tikcur.close()
        return res
    
    def getSdRdticketsDept(self,deptInfo,stStamp,etStamp):
        sql = 'SELECT ic.priorityid,ic.ticketid,ic.statusid as sid,getntsstatussladue(ic.ticketid,ic.statusid) as sladue FROM  incident_data ic WHERE ic.deptid IN ('+str(deptInfo)+') AND (ic.statusid = 16 OR ic.statusid = 19) AND ((ic.created_dt >= '+str(stStamp)+' AND ic.created_dt <= '+str(etStamp)+') OR (ic.lastactivity >= '+str(stStamp)+' AND ic.lastactivity <= '+str(etStamp)+'))'
        print sql
        tikcur = connections['ticketRead'].cursor()
        tikcur.execute(sql)
        res = self.dictfetchall(tikcur)
        tikcur.close()
        return res
    
    '''Below methods regarding Devices informatin in Cache data'''
    def getIncidentMspClientTicketQuery(self,clients,partner):       
        cursor = connections['ticketRead'].cursor()
        mspCond = ''
        sql =''
        ClientCond = ''
        ClientCond = " and cid in ("+ str(clients) +")" if (clients and clients !='' and clients != None) else ''
        mspCond = " and mid = ("+partner+") " if (partner and  partner!='' and partner!=None) else ''
        sql = "select count(ticketid) as count,sws.statustype,sws.title as status,sws.ticketstatusid,incident.deptid,swd.title as dept from incident_data incident join swdepartments swd on (swd.departmentid = incident.deptid) join swticketstatus sws on(sws.ticketstatusid = incident.statusid) where 1=1 "+mspCond + ClientCond+" and incident.deptid not in (0,1,2) group by incident.statusid,incident.deptid order by swd.title,sws.statustype";
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        return result
    
    "tickets counts based on msp,client "
    def getMspClientTicketsData(self,partner,clients):
        newStatues = swtktstatus_obj.getNewStatus()
        StatusTypes = swtktstatus_obj.getGroupStausName()
        Query = ''; result = {}; data= {};k=0;
        Query = self.getIncidentMspClientTicketQuery(clients, partner)
        if(Query != ''):
            for res in Query:
                if not data.has_key(res['deptid']):
                    data.setdefault(res['deptid'],{})
                data[res['deptid']]['title'] = res['dept'];
                if res['statustype'] != 3:
                    if data[res['deptid']].has_key('TotalCount'):
                        data[res['deptid']]['TotalCount'] += res['count']
                    else:
                        data[res['deptid']].setdefault('TotalCount', defaultdict(int))
                        data[res['deptid']]['TotalCount'] = res['count']
                res['statustype'] = StatusTypes[res['ticketstatusid']];
                if not data[res['deptid']].has_key('statusType'):
                    data[res['deptid']].setdefault('statusType',{})
                if not data[res['deptid']]['statusType'].has_key(res['statustype']):
                    data[res['deptid']]['statusType'].setdefault(res['statustype'],{})
                if data[res['deptid']]['statusType'][res['statustype']].has_key('statusCount'):
                    data[res['deptid']]['statusType'][res['statustype']]['statusCount'] += res['count'];
                else:
                    data[res['deptid']]['statusType'][res['statustype']].setdefault('statusCount',defaultdict(int));
                    data[res['deptid']]['statusType'][res['statustype']]['statusCount'] = res['count'];
                if  not data[res['deptid']]['statusType'][res['statustype']].has_key('status'):
                    data[res['deptid']]['statusType'][res['statustype']].setdefault('status',{})
                data[res['deptid']]['statusType'][res['statustype']]['status'].setdefault(k,{})
                data[res['deptid']]['statusType'][res['statustype']]['status'][k]['statusid'] = res['ticketstatusid'];
                data[res['deptid']]['statusType'][res['statustype']]['status'][k]['statusname'] = newStatues[res['ticketstatusid']];
                data[res['deptid']]['statusType'][res['statustype']]['status'][k]['count'] = res['count'];
                k = k+1
        return data
    
    "Ticket counts for all devices"   
    def getIncidentDeviceTypedata(self):
        nocCond =''
        nocCond = 'where devicetypeid != 0 and incident.deptid not in (0,1,2) group by devicetype,incident.statusid'
        sql = "select count(incident.ticketid) as count,devicetype,devicetypeid,sws.title as status,sws.ticketstatusid,sws.statustype "
        sql += "from incident_data incident join swticketstatus sws on(sws.ticketstatusid = incident.statusid) "
        sql += ""+nocCond+" order by devicetype,sws.statustype"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result
    
    "Ticket counts based on ticket type for all devices"
    def getByTicketTypeDeviceCountQuery(self):
        nocCond =''
        nocCond = 'where devicetypeid != 0 and incident.deptid not in (0,1,2)  group by nts.typeid,incident.statusid,devicetype'
        sql = "select count(incident.ticketid) as count,nts.typeid,devicetype,devicetypeid,sws.title as status,sws.ticketstatusid,sws.statustype "
        sql += "from incident_data incident join swticketstatus sws on(sws.ticketstatusid = incident.statusid) "
        sql += "join ntsclienttickets nts on (nts.ticketid = incident.ticketid) "+nocCond+" order by nts.typeid,devicetype,sws.statustype"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result
    
    "Ticket counts for all departments"
    def getPrepareNocDeptQuery(self):
        deptList = swdepts_obj.departments()
        statuses = swtktstatus_obj.getNewStatus()
        statusTypes = swtktstatus_obj.getSwticketstatus()
        cursor = connections['ticketRead'].cursor()
        closed = swtktstatus_obj.getClosedStatus()
        closed_statuses = ','.join(str(e) for e in closed.keys())
        sql = 'select count(ticketid) as count, statusid as ticketstatusid, deptid '
        sql += 'from incident_data incident '
        sql += 'where 1=1 and incident.statusid not in ('+closed_statuses+') '
        sql += 'group by incident.statusid, incident.deptid'   
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        fin_res = []
        statusTypes_tt=[]
        pvt_depts = [0, 1, 2, 11, 48, 181, 322, 40, 30, 113]
        ignore_statuses = [27]
        for res in result:
            flag=0
            if res['deptid'] not in pvt_depts and res['ticketstatusid'] not in ignore_statuses:
                if res['deptid'] not in deptList.keys():
                    print 'Entered for wrong Dept:---->', res['deptid']
                temp_res = res
                for dep_id, dep_title in deptList.iteritems():
                    if dep_id == res['deptid']:
                        temp_res.setdefault('dept', dep_title)
                for status_id, status_title in statuses.iteritems():
                    if status_id == res['ticketstatusid']:
                        temp_res.setdefault('status', status_title)
                for status in statusTypes:
                    if status['ticketstatusid'] == res['ticketstatusid']:
                        flag =1
                        temp_res.setdefault('statustype', status['statustype'])
                if flag == 0:
                    statusTypes_tt.append(res['ticketstatusid'])
                fin_res.append(temp_res)
        return fin_res
    
    " ticket counts for all departments based on each tickettype"
    def getByTicketTypeDeptCountQuery(self):
        print 'getByTicketTypeDeptCountQuery'
        deptList = swdepts_obj.departments()
        statuses = swtktstatus_obj.getNewStatus()
        statusTypes = swtktstatus_obj.getSwticketstatus()
        closed = swtktstatus_obj.getClosedStatus()
        closed_statuses = ','.join(str(e) for e in closed.keys())
        cursor = connections['ticketRead'].cursor()
        sql = "select count(incident.ticketid) as count,nts.typeid,statusid as ticketstatusid, deptid "  
        sql += "from incident_data incident "
        sql += "join ntsclienttickets nts on (nts.ticketid = incident.ticketid) "  
        sql += "where 1=1 and incident.statusid not in ("+closed_statuses+") group by nts.typeid, incident.statusid, incident.deptid  " 
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        fin_res = []
        statusTypes_tt=[]
        pvt_depts = [0, 1, 2, 11, 48, 181, 322, 40, 30, 113]
        ignore_statuses = [27]
        for res in result:
            flag=0
            if res['deptid'] not in pvt_depts and res['ticketstatusid'] not in ignore_statuses:
                temp_res = res
                for dep_id, dep_title in deptList.iteritems():
                    if dep_id == res['deptid']:
                        temp_res.setdefault('dept', dep_title)
                for status_id, status_title in statuses.iteritems():
                    if status_id == res['ticketstatusid']:
                        temp_res.setdefault('status', status_title)
                for status in statusTypes:
                    if status['ticketstatusid'] == res['ticketstatusid']:
                        temp_res.setdefault('statustype', status['statustype'])
                if flag == 0:
                    statusTypes_tt.append(res['ticketstatusid'])
                fin_res.append(temp_res)
        return fin_res
    
        "ticket counts for all departments based on nocid"
    def getByNocTypeDeptQuery(self):
        print 'getByNocTypeDeptQuery'
        deptList = swdepts_obj.departments()
        statuses = swtktstatus_obj.getNewStatus()
        statusTypes = swtktstatus_obj.getSwticketstatus()
        closed = swtktstatus_obj.getClosedStatus()
        closed_statuses = ','.join(str(e) for e in closed.keys())
        cursor = connections['ticketRead'].cursor()
        sql = 'select count(ticketid) as count,nid as nocid,statusid as ticketstatusid,deptid '
        sql += 'from incident_data incident '
        sql += 'where 1=1 and incident.statusid not in ('+closed_statuses+')'
        sql += 'group by nid, incident.statusid, incident.deptid'        
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        fin_res = []
        statusTypes_tt=[]
        pvt_depts = [0, 1, 2, 11, 48, 181, 322, 40, 30, 113]
        ignore_statuses = [27]
        for res in result:
            flag=0
            if res['deptid'] not in pvt_depts and res['ticketstatusid'] not in ignore_statuses:
                temp_res = res
                for dep_id, dep_title in deptList.iteritems():
                    if dep_id == res['deptid']:
                        temp_res.setdefault('dept', dep_title)
                for status_id, status_title in statuses.iteritems():
                    if status_id == res['ticketstatusid']:
                        temp_res.setdefault('status', status_title)
                for status in statusTypes:
                    if status['ticketstatusid'] == res['ticketstatusid']:
                        temp_res.setdefault('statustype', status['statustype'])
                if flag == 0:
                    statusTypes_tt.append(res['ticketstatusid'])
                fin_res.append(temp_res)
        return fin_res
    
    def getCountOfIncidentTicketsBySLA(self,prepareIncidentConditions,rsla,myticketFlag):       
        global IncidentResolutionSla                     
        sql = 'SELECT SQL_CALC_FOUND_ROWS DISTINCT(id.ticketid) FROM incident_data id  %s ' % (prepareIncidentConditions)     
        flag = False
        countresutl = {}
        countresutl[1] = countresutl[2] = countresutl[3] ="0"
        rslacount = 0 if myticketFlag == 0 else len(rsla)        
        sqlForSLACount = sql           
        if (rslacount == 0):
            if (flag == False):                
                sql = ' %s and  (id.resol_due between 0 AND 3600)  limit 1 ' % (sqlForSLACount)
                count1 = self.executeQueryGetCount(sql)
                flag = True          
                countresutl[1] = int(count1)                
            if (flag):
                sql = ' %s and  id.resol_due > 3600  limit 1 ' % (sqlForSLACount)
                count2 = self.executeQueryGetCount(sql)
                flag = True
                countresutl[2] = int(count2)               
                
            if (flag):
                sql = ' %s and  id.resol_due < 0  limit 1 ' % (sqlForSLACount)
                count3 = self.executeQueryGetCount(sql)                
                countresutl[3] = int(count3)        
        else:             
            for i in rsla:                             
                if (i == "1"):
                    sql = ' %s  and  (id.resol_due between 0 AND 3600)  limit 1 ' % (sqlForSLACount)
                    count1 = self.executeQueryGetCount(sql)           
                    countresutl[1] = int(count1)                    
                elif (i == "2"):
                    sql = ' %s and  id.resol_due > 3600  limit 1 ' % (sqlForSLACount)
                    count2 = self.executeQueryGetCount(sql)
                    countresutl[2] = int(count2)                                    
                elif (i == "3"):
                    sql = ' %s and  id.resol_due < 0  limit 1 ' % (sqlForSLACount)
                    count3 = self.executeQueryGetCount(sql)
                    countresutl[3] = int(count3)
        return countresutl
    
    def executeQueryGetCount(self, query): #TODO
        cursor = connections['ticketRead'].cursor()
        cursor.execute(query)
        count1 = self.dictfetchall(cursor)                
        cursor.close()  
        cursor = connections['ticketRead'].cursor()
        sql = 'select found_rows() as cnt'
        cursor.execute(sql)
        count1 = self.dictfetchall(cursor)                    
        cursor.close()            
        return count1[0]['cnt']

    def getAlertsCount(self, ticketid):
        cursor = connections['ticketRead'].cursor()
        sql = 'select if(alertscount=healedalertscount, 1, 0) from incident_data where ticketid='+str(ticketid)
        cursor.execute(sql)
        alertsResult = cursor.fetchall()
        for s in alertsResult:
            alertsResult = s[0]
        return alertsResult


    def getMappedTicketsDataAjax(self, ticketid, typeid):
        cursor = connections['ticketRead'].cursor()
        sql = "select ticketid, subject, priority, status, deptid, created_dt, lastactivity, staffid  from incident_data where parent_incident_id="+str(ticketid)+" and typeid="+str(typeid)
        print sql
        cursor.execute(sql)
        mappedData = self.dictfetchall(cursor)
        return mappedData

    def getTicketdetails(self, ticketid):
        cursor = connections['ticketRead'].cursor()
        sql = "select ticketid, subject, typeid  from incident_data where ticketid="+str(ticketid)
        cursor.execute(sql)
        detailsTicket = self.dictfetchall(cursor)
        return detailsTicket

    def unMapAjax(self, ticketid):
        cursor = connections['ticketWrite'].cursor()
        sql = "update incident_data set parent_incident_id=null where ticketid in ("+str(ticketid)+")"
        cursor.execute(sql)
        return sql

    def getOtherTicketsToMap(self):
        cursor = connections['ticketRead'].cursor()
        sql = "select ticketid, subject, priority, status, deptid, created_dt, lastactivity, staffid, typeid, parent_incident_id from incident_data where typeid in (1, 2, 3, 4, 5, 7, 10, 12, 13, 14) and deptid=231 limit 500;"
        cursor.execute(sql)
        totalDetailsTicket = self.dictfetchall(cursor)
        return totalDetailsTicket

    def mapTicketsToParent(self, pTicket, cTicket):
        cursor = connections['ticketWrite'].cursor()
        sql = "update incident_data set parent_incident_id="+str(pTicket)+" where ticketid in ("+str(cTicket)+")"
        cursor.execute(sql)
        return sql

    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
    
    def vistarUrls(self,params):
        data ={'partners':'/partnerPage.do?id=',
               'client':'/clientPage.do?id=',
               'device':'/devicePage.do?id='
               }
                
        return data[params]
