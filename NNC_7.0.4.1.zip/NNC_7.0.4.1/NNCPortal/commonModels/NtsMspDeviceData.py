"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import connections
from django.core.cache import caches
mem_cache = caches['memcached']


class NtsMspDeviceData(object):
    
    def getDevices(self, client_id=''):
        mem_key = 'getDevices_'+str(client_id)
        result = mem_cache.get(mem_key)
        condition = ''
        if not result:
            if client_id != '' and client_id != 0 and client_id != None :
                condition = " AND client_id IN ("+str(client_id)+") "
                cursor = connections['ticketRead'].cursor() 
                sql = "select id, device_name from ntsmspdevicedata where (state IS NULL OR state IN('','active','deleted-active')) "+condition+" order by device_name"
                cursor.execute(sql)
                result = self.dictfetchall(cursor)
                cursor.close()
                mem_cache.set(mem_key, result, 86400)
            else:
                result = {}
        return result
    
    def getDeviceById(self, deviceid, client_id=0):
        try:
            if int(deviceid) == 0:
                return None
            elif client_id != 0 and client_id != None and client_id != '':
                mem_key = 'getDeviceById_'+str(client_id)
                result = mem_cache.get(mem_key)
                if not result:
                    result = {}
                    device_data = self.getDevices(client_id)
                    for device in device_data:
                        result[device['id']] = device['device_name']
                    mem_cache.set(mem_key, result, 86400)
                    return result[deviceid]
            else:
                cursor = connections['ticketRead'].cursor()
                sql = "select id, device_name from ntsmspdevicedata where id =%s" %deviceid
                cursor.execute(sql)
                device_data = self.dictfetchall(cursor)
                cursor.close()
                result = {}
                for device in device_data:
                    result[device['id']] = device['device_name']
                if deviceid in result.keys():
                    return result[deviceid]
                else:
                    return None
        except Exception as e:
            print e
            return None
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
               dict(zip([col[0] for col in desc], row)) 
               for row in cursor.fetchall() 
       ]