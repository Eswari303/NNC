"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import models
from django.core.cache import caches
mem_cache = caches['memcached']
from django.db import connections
from operator import itemgetter
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
env = configobj.getCommConfigValue(configobj.app_env)

class Swticketpriorities(models.Model):
    priorityid = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    displayorder = models.IntegerField()
    type = models.CharField(max_length=7)
    frcolorcode = models.CharField(max_length=100)
    bgcolorcode = models.CharField(max_length=100)
    iscustom = models.SmallIntegerField()
    display_text = models.CharField(max_length=255)

    class Meta:
        app_label = 'serviceManagement'
        db_table = 'swticketpriorities'
        
    '''
    Function is used to return the matching priority name.
    Args:
        priority id (int).
    Returns:
        returns display name for priority id.
    '''
    def PriorityById(self, pid):
        try:
            priority_data = mem_cache.get('priorities_data'+env)
            if not priority_data:
                cursor = connections['ticketRead'].cursor()
                sql = "Select priorityid, display_text from swticketpriorities"
                cursor.execute(sql)
                priority_data = self.dictfetchall(cursor)
                cursor.close()
                mem_cache.set('priorities_data'+env, priority_data, 86400)
            try:
                index = map(itemgetter("priorityid"), priority_data).index(pid)
                priority = priority_data[index]['display_text']
                return priority
            except Exception as e:
                return None
        except Exception as e:
            print ("p error:", e.message)
            return "None"
        
    def getSlaEffectivePriorities(self):
        slaEffectivePriorities = mem_cache.get('slaEffectivePriorities'+env)
        if not slaEffectivePriorities:
            sql = "SELECT * FROM swticketpriorities WHERE frcolorcode !='' ORDER BY displayorder"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            slaEffectivePriorities = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('slaEffectivePriorities'+env, slaEffectivePriorities, 86400)
        return slaEffectivePriorities
    
    def priorty(self):
        prioritybytitle = mem_cache.get('prioritybytitle'+env)
        if not prioritybytitle:
            cursor = connections['ticketRead'].cursor()
            sql = "select priorityid, display_text as title from swticketpriorities order by title"
            cursor.execute(sql)
            result = self.dictfetchall(cursor)
            cursor.close()
            prioritybytitle={}
            for i in result:
                prioritybytitle[i['priorityid']] = i['title']
            mem_cache.set('prioritybytitle'+env,prioritybytitle,86400)
        return prioritybytitle
    
    def getPriority(self):
        priorities = mem_cache.get('priorities'+env)
        if not priorities:
            cursor = connections['ticketRead'].cursor()
            sql = "select display_text, priorityid from swticketpriorities order by displayorder"
            cursor.execute(sql)
            priorities = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('priorities'+env, priorities, 86400)
        return priorities
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
