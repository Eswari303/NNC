"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import connections
from django.core.cache import caches
mem_cache = caches['memcached']

class SwcustomFieldValues(object):
    def __init__(self):
        '''
        Constructor
        '''
    def getCustomFieldData(self, ticketId, custFieldId):
        cursor = connections['ticketRead'].cursor()
        sql = "SELECT swcustfld.title, swcustfldval.fieldvalue \
        FROM swcustomfieldvalues swcustfldval \
        JOIN swcustomfields AS swcustfld \
        ON swcustfld.customfieldid = swcustfldval.customfieldid \
        WHERE swcustfldval.typeid="+str(ticketId)+" \
        AND swcustfldval.customfieldid="+str(custFieldId)        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        customColumnData  = self.dictfetchall(cursor)
        cursor.close()
        return customColumnData
    
    def getScheduledTime(self,ticketid):
        sql = "select fieldvalue as scheduledTime from swcustomfieldvalues where customfieldid=12 and typeid='"+str(ticketid)+"'"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        scheduledTime = ''
        for res in result:
            scheduledTime = res['scheduledTime']
        return scheduledTime
    
    def  getCustomFieldValue(self,customFieldId, ticketId):        
        sql = "SELECT fieldvalue FROM swcustomfieldvalues WHERE customfieldid='"+str(customFieldId)+"' AND typeid='"+str(ticketId)+"'";
        result = self.executeQuery(sql)
        data =''
        if len(result)>0:
            data =result[0]['fieldvalue']            
        return data
    
    def executeQuery(self, query): #TODO
        cursor = connections['ticketRead'].cursor()
        cursor.execute(query)
        result = self.dictfetchall(cursor)
        cursor.close()  
        return result
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
        