"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import connection,connections


class CommonModelMethods(object):
    def updateRecord(self,Info,tableName,condition,dbname):
        try :    
            sql = 'UPDATE '+str(tableName)+' SET {}'.format(', '.join('{}=%s'.format(key) for key in Info))
            sql = sql + " where "+str(condition)
            cur = connections[dbname].cursor()
            cur.execute(sql, Info.values())
            count = int(cur.rowcount)
            if count == 0 :
                print "details did not found"
            cur.close()
            return sql
        except Exception as e:
            # handle all your exceptions... this is just an example
            print('Caught Exception: %s' % e)
    #insert record into database
    def insertRecord(self,info,tableName,dbname):
        try :
            count = 0
            placeholders = ', '.join(['%s'] * len(info))
            columns = ', '.join(info.keys())
            sql = "INSERT INTO "+str(tableName)+" ( %s ) VALUES ( %s )" % (columns, placeholders)
            cur = connections[dbname].cursor()
            cur.execute(sql, info.values())
            count = int(cur.rowcount)
            if not count:
                print "Record not inserted"
            id = cur.lastrowid
            cur.close()
            return id
        except Exception as e:
            # handle all your exceptions... this is just an example
            print sql
            print('Caught Exception: %s' % e)
            
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
    