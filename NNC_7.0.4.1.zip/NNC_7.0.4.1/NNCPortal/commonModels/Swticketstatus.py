"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import connections
from django.core.cache import caches
from django.db import models
from operator import itemgetter
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)

class Swticketstatus(models.Model):
    ticketstatusid = models.AutoField(primary_key=True)
    title = models.CharField(max_length=255)
    displayorder = models.IntegerField()
    iscustom = models.SmallIntegerField()
    displayinmainlist = models.SmallIntegerField()
    ismaster = models.SmallIntegerField()
    statustype = models.SmallIntegerField()
    displaycount = models.SmallIntegerField()
    statuscolor = models.CharField(max_length=50)
    departmentid = models.IntegerField()
    type = models.CharField(max_length=7)
    resetduetime = models.SmallIntegerField()
    display_text = models.CharField(max_length=255)

    class Meta:
        app_label = 'serviceManagement'
        db_table = 'swticketstatus'

    """ Return Status details from master table """

    def getSwticketstatus(self):
        Swticketstatus = mem_cache.get('Swticketstatus'+env)
        if not Swticketstatus:
            sql = "select ticketstatusid,title,display_text,parent_id, statustype from swticketstatus order by displayorder"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            Swticketstatus = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('Swticketstatus'+env, Swticketstatus, 86400)
        return Swticketstatus

    """ Returns newstatus list """

    def getNewStatus(self):
        newStatus = mem_cache.get('newStatus'+env)
        if not newStatus:
            newStatus = {}
            status = self.getSwticketstatus()
            oldStatus = {}
            for stat in status:
                oldStatus[stat['ticketstatusid']] = stat['display_text']
                if int(stat['parent_id']) == 0:
                    newStatus[stat['ticketstatusid']] = stat['display_text']
            for stat in status:
                if int(stat['parent_id']) == 18:
                    newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']]) + ' - ' + str(
                        stat['display_text'])
                elif int(stat['parent_id']) == 2:
                    newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']]) + ' - ' + str(
                        stat['display_text'])
                elif int(stat['parent_id']) == 3:
                    newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']]) + ' - ' + str(
                        stat['display_text'])
                elif int(stat['parent_id']) == 5:
                    newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']]) + ' - ' + str(
                        stat['display_text'])
                elif int(stat['parent_id']) == 19:
                    newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']]) + ' - ' + str(
                        stat['display_text'])
                elif int(stat['parent_id']) == 1:
                    newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']]) + ' - ' + str(
                        stat['display_text'])
                mem_cache.set('newStatus'+env, newStatus, 86400)
        return newStatus


    '''function to sort the ticket status list as per requirement'''
    def newOrderStatus(self):
        Ordered = mem_cache.get('ordered'+env)
        updated_child = {}
        if not Ordered:
            updated_child = self.getNewStatus()
            custom_order = [1,18,7,12,22,23,19,21,2,9,46,16,11,5,3,20,17,32,41]
            Ordered = sorted(updated_child.items(), key=lambda i:custom_order.index(i[0]))
            mem_cache.set('ordered'+env, Ordered, 86400)
        return Ordered

    """ Returns Active statuses """

    def getActiveStatus(self):
        ActiveStatus = mem_cache.get('activeStatus'+env)
        if not ActiveStatus:
            ActiveStatus = {}
            cursor = connections['ticketRead'].cursor()
            sql = "select ticketstatusid,title from swticketstatus where title not in (select statusname from ntsignorablestates) order by displayorder";
            cursor.execute(sql)
            result = self.dictfetchall(cursor)
            cursor.close()
            for value in result:
                ActiveStatus[value['ticketstatusid']] = value['title']
            mem_cache.set('activeStatus'+env, ActiveStatus, 86400)
        return ActiveStatus

    """  Returns inactive statuses """

    def getInActiveStatus(self):
        InActiveStatus = mem_cache.get('inactiveStatus'+env)
        if not InActiveStatus:
            InActiveStatus = {}
            cursor = connections['ticketRead'].cursor()
            sql = "select statusid,statusname from ntsignorablestates where statusname not in (select title from swticketstatus where statustype=3) order by statusname"
            cursor.execute(sql)
            result = self.dictfetchall(cursor)
            cursor.close()
            for value in result:
                InActiveStatus[value['statusid']] = value['statusname']
            mem_cache.set('inactiveStatus'+env, InActiveStatus, 86400)
        return InActiveStatus

    """ Returns closed statuses """

    def getClosedStatus(self):
        closed = mem_cache.get('closedStatus'+env)
        if not closed:
            closed = {}
            cursor = connections['ticketRead'].cursor()
            sql = "select ticketstatusid,title from swticketstatus where statustype=3 order by title";
            cursor.execute(sql)
            result = self.dictfetchall(cursor)
            cursor.close()
            for value in result:
                closed[value['ticketstatusid']] = value['title']
            mem_cache.set('closedStatus'+env, closed, 86400)
        return closed

    """ Returns ticket status along with ids """

    def getTicketStatusById(self, statusid):
        ticket_status = mem_cache.get("ticketstatus"+env)
        if not ticket_status:
            sql = "SELECT title, ticketstatusid FROM swticketstatus"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            ticket_status = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set("ticketstatus"+env, ticket_status, 86000)
        try:
            index = map(itemgetter('ticketstatusid'), ticket_status).index(statusid)
            return ticket_status[index]['title']
        except Exception as e:
            return None

    """ Returns the concated string which contains closed status ids used for empdashboard counts """

    def getClosedStatuses_emp(self):
        status = mem_cache.get('closedstatus_emp'+env)
        if not status:
            tikcur = connections['ticketRead'].cursor()
            sql = 'select group_concat(ticketstatusid) as closed_statuses from swticketstatus where statustype=3 order by title'
            tikcur.execute(sql)
            status = self.dictfetchall(tikcur)
            tikcur.close()
            mem_cache.set('closedstatus_emp'+env, status, 86400)
        return status

    def getGroupStausName(self):
        Allstatuses = []
        result = {}
        result = mem_cache.get('statusTypes'+env)
        if not result:
            result = {}
            Activestatusnames = self.getActiveStatus()
            Inactivestatusnames = self.getInActiveStatus()
            Closedstatusnames = self.getClosedStatus()
            Allstatuses = Activestatusnames.keys() + Inactivestatusnames.keys() + Closedstatusnames.keys()
            for statusid in Allstatuses:
                if statusid in Activestatusnames.keys():
                    result[statusid] = "Active"
                if statusid in Inactivestatusnames.keys():
                    result[statusid] = "InActive"
                if statusid in Closedstatusnames.keys():
                    result[statusid] = "Closed"
            mem_cache.set('statusTypes'+env, result, 604800)
        return result
    
    """ Returns the list of statuses which are needs to be disable in UI for the partner"""
    def getPartnerBlockedStatuses(self,mspid):
        blockedstatuses = []
        blockedstatuses = mem_cache.get('partnerblockedstatuses_'+mspid+env)
        if not blockedstatuses:
            tikcur = connections['ticketRead'].cursor()
            sql = 'select statusid from nts_block_ticket_status where entity_type="partner" and entity_id='+str(mspid)
            tikcur.execute(sql)
            statuses = self.dictfetchall(tikcur)
            tikcur.close()
            blockedstatuses = [stat['statusid'] for stat in statuses]
            mem_cache.set('partnerblockedstatuses_'+mspid+env, blockedstatuses, 86400)
        return blockedstatuses
    
    """ Returns the list of statuses  which are needs to be disable in UI for the client"""
    def getClientBlockedStatuses(self,clientid):
        blockedstatuses = []
        blockedstatuses = mem_cache.get('clientblockedstatuses_'+clientid+env)
        if not blockedstatuses:
            tikcur = connections['ticketRead'].cursor()
            sql = 'select statusid from nts_block_ticket_status where entity_type="client" and entity_id='+str(clientid)
            tikcur.execute(sql)
            statuses = self.dictfetchall(tikcur)
            tikcur.close()
            blockedstatuses = [stat['statusid'] for stat in statuses]
            mem_cache.set('clientblockedstatuses_'+clientid+env, blockedstatuses, 86400)
        return blockedstatuses
            

    def dictfetchall(self, cursor):
        "Returns all rows from a cursor as a dict"
        desc = cursor.description
        return [
            dict(zip([col[0] for col in desc], row))
            for row in cursor.fetchall()
            ]
