"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import models
from django.db import connections
from django.core.cache import caches
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
from _collections import defaultdict
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)


class swcustomFields(object):


    def getCustomFields(self):
            result = mem_cache.get('customFields'+env)
            if not result:
                sql = "SELECT swcustfldgrp.title as custom_field_group, swcustfld.customfieldid, swcustfld.title FROM swcustomfields AS swcustfld JOIN swcustomfieldgroups AS swcustfldgrp ON swcustfldgrp.customfieldgroupid=swcustfld.customfieldgroupid WHERE swcustfld.title != 'LPI Ticket ID' ORDER BY swcustfldgrp.title, swcustfld.title"
                cursor = connections['ticketRead'].cursor()
                cursor.execute(sql)
                result = self.dictfetchall(cursor)
                cursor.close()
                mem_cache.set('customFields'+env,result,86400)
            return result    
        
    def getCustomFields_SM(self):
        swCustomFields = mem_cache.get('swCustomFields'+env)
        if not swCustomFields:
            cursor = connections['ticketRead'].cursor()
            sql = "SELECT \
                               swcustfld.customfieldid, \
                               swcustfld.title   \
                        FROM swcustomfields AS swcustfld \
                        JOIN swcustomfieldgroups AS swcustfldgrp ON swcustfldgrp.customfieldgroupid=swcustfld.customfieldgroupid \
                        WHERE swcustfld.title != 'LPI Ticket ID'    \
                        ORDER BY swcustfldgrp.title,  \
                                 swcustfld.title"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            customColuns  = self.dictfetchall(cursor)
            cursor.close()
            swCustomFields ={}
            for i  in customColuns:
                swCustomFields[i['customfieldid']] = i['title']
            mem_cache.set('swCustomFields'+env, swCustomFields, 86400)
        
        return swCustomFields
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
     
