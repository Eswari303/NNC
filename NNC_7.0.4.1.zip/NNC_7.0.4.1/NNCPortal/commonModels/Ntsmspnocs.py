"""
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 *
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""

from __future__ import unicode_literals
from django.db import models, connections
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
from django.core.cache import caches
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)

class Ntsmspnocs(models.Model):
    id=models.AutoField(primary_key=True)
    version=models.IntegerField(max_length=100)
    name=models.CharField(max_length=100)

    class Meta:
        managed = True
        app_label = 'ticket'
        db_table = 'ntsmspnocs'

    """Returns Noc data"""

    def getNocdata(self):
        nocs = mem_cache.get('nocs'+env)
        if not nocs:
            cursor = connections['ticketRead'].cursor()
            sql = "select * from ntsmspnocs order by name"
            cursor.execute(sql)
            nocs = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('nocs'+env, nocs, 86400)
        return nocs

    def dictfetchall(self,cursor):
        "Returns all rows from a cursor as a dict"
        desc = cursor.description
        return [
                dict(zip([col[0] for col in desc], row))
                for row in cursor.fetchall()
        ]



