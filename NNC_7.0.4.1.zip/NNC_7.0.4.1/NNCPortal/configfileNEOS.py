from ConfigParser import ConfigParser
import os
#import dateutils, datetime

class ConfigManager(object):
    #configuration file
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    _conf_file = BASE_DIR+'/NEOSAPI/globalVariables.cfg'
    #get param
    ip = "ip"
    port = "port"
    username = 'username'
    password = 'password'
    database = 'database'
    url = 'url'
    driver = 'driver'
    tablename = 'tablename'

    def __init__(self):
        self.cfg = ConfigParser()
        self.cfg.read(self._conf_file)
    #get config parameters for common dictionary
    def getCommConfigValue(self,key):
        try:
            return self.cfg.get("Common",key)
        except :
            raise Exception('not found')
    #get config parameters of mysql 
    def getMysqlConfigValue(self,key):
        try:
            return self.cfg.get("mysql",key)
        except :
            raise Exception('not found')
    #get config parameters of cassandra
    def getCassandraConfigValue(self,key):
        try:
            return self.cfg.get("cassandra",key)
        except :
            raise Exception('not found')