"""
This computer program is the confidential information and proprietary trade
secret of NetEnrich, Inc. Possessions and use of this program must
conform strictly to the license agreement between the user and
NetEnrich, Inc., and receipt or possession does not convey any rights
to divulge, reproduce, or allow others to use this program without specific
written authorization of NetEnrich, Inc.

Copyright  2016 NetEnrich, Inc. All Rights Reserved.



The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import url, patterns,include
from django.contrib import admin
from django.conf.urls import include
import noiseDashboard.views.noiseDashboardView
import managerDashboard.views.managerDashboardView
import employeeDashboard.views.employeeDashboardView
import serviceManagement.views.serviceManagementView
import login.views.loginView
import sdmDashboard.views.sdmDashboardView
from django.conf import settings


urlpatterns = [
    url(r'^$', login.views.loginView.checkCredentials),
    url(r'^admin/', include(admin.site.urls)),
    url(r'^NNCPortal/', include('login.urls')),
    url(r'^Login', login.views.loginView.checkCredentials),
    url(r'^noiseDashboard/', include('noiseDashboard.urls')),
    url(r'^noiseDashboard/$', noiseDashboard.views.noiseDashboardView.loadMockup),
    url(r'^managerDashboard/', include('managerDashboard.urls')),
    url(r'^managerDashboard/$', managerDashboard.views.managerDashboardView.loadManagersMockup),
    url(r'^employeeDashboard/', include('employeeDashboard.urls')),
    url(r'^employeeDashboard/$', employeeDashboard.views.employeeDashboardView.loademployeesMockup),
    url(r'^serviceManagement/$', serviceManagement.views.serviceManagementView.loadMockup),
    url(r'^serviceManagement/', include('serviceManagement.urls')),
    url(r'^sdmDashboard/', include('sdmDashboard.urls')),
    url(r'^sdmDashboard/$', sdmDashboard.views.sdmDashboardView.loadSdmMockup),
    url(r'^ticket/', include('ticket.urls')),
    url(r'^qualityMetric/', include('apps.qualityMetrics.urls')),
    url(r'^ciscoUC/', include('apps.ciscoUC.urls')),
    url(r'^NEBOT/', include('apps.NEBOT.urls')),
    url(r'^requestForm/', include('apps.requestForm.urls')),
    url(r'^SDMTracker/', include('apps.SDMTracker.urls')),
    url(r'^escalationContacts/', include('apps.EscalationContacts.urls')),
    url(r'^hrData/', include('apps.HRData.urls')),
    url(r'^OBValidationCheck/', include('apps.OBValidationCheck.urls')),
    url(r'^static/(?P<path>.*)$', 'django.views.static.serve', {'document_root': settings.STATIC_ROOT, 'show_indexes': settings.DEBUG}),
    url(r'^nncCache/', include('apps.CacheManagement.urls')),
    url(r'^v1/ticket/', include('apps.ticketing.urls')),
]

if settings.DEBUG and 'debug_toolbar' in settings.INSTALLED_APPS:
    import debug_toolbar
    urlpatterns += patterns('',
        url(r'^__debug__/', include(debug_toolbar.urls)),
    )
