"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.http import HttpResponse, HttpResponseRedirect
from django.core.cache import caches
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.db import connections
from datetime import datetime, timedelta
from operator import itemgetter
from NNCPortal.commonModels.Swticketstatus import Swticketstatus
swticket_obj = Swticketstatus
from NNCPortal.configfile import ConfigManager
from NNCPortal.commonModels.NrStaff import NrStaff
from serviceManagement.models.SwStaff import Swstaff
import xlsxwriter,StringIO
import requests, json, os
import datetime as dt
import random,ast
import string
import json as simplejson
from NNCPortal.commonModels.Ntsmsps import Ntsmsps
msps_obj = Ntsmsps()

configobj = ConfigManager()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)
'''This class contains all the methods which is used by the entire project.'''
class commonMethods(object):

    def generateVistaraPartnerUrl(self, mspid=0):
        '''
        newDataCenterDetailsOfPartner = msps_obj.partnerNewDatacenterDetails()
        pData = newDataCenterDetailsOfPartner.get(mspid, {})
        partnerUrl = str(pData['portal_url'])+'/partnerPage.do?id='+str(pData['dc_msp_id']) if pData else ''
        return partnerUrl'''
        euurl = "https://app.vistaraeu.com/partnerPage.do?id="
        mspurl = "https://mspnocsupport.com/partnerPage.do?id="
        if int(mspid) < 10000000:
            partnerUrl = mspurl+str(mspid)
        else:
            pid = int(mspid) - 10000000
            partnerUrl = euurl+str(pid)

        return partnerUrl

    def generateVistaraClientUrl(self, clientid=0):
        '''
        newDataCenterDetailsOfClient = msps_obj.clientNewDatacenterDetails()
        cData = newDataCenterDetailsOfClient.get(clientid, {})
        clientUrl = str(cData['portal_url'])+'/clientPage.do?id='+str(cData['dc_mspclient_id']) if cData else ''
        return clientUrl
        '''
        euurl = "https://app.vistaraeu.com/clientPage.do?id="
        mspurl = "https://mspnocsupport.com/clientPage.do?id="
        #qubicClientIds = [10000053,10000058,10000048]

        if int(clientid) < 10000000:
            clientUrl = mspurl+str(clientid)
        else:
            cid = int(clientid) - 10000000
            clientUrl = euurl+str(cid)
        return  clientUrl


    def generateVistaraDeviceUrl(self, clientid=0, deviceid=0):
        '''
        newDataCenterDetailsOfClient = msps_obj.clientNewDatacenterDetails()
        dData = newDataCenterDetailsOfClient.get(clientid, {})
        deviceUrl = str(dData['portal_url'])+'/devicePage.do?id='+str(deviceid) if dData else ''
        return deviceUrl
        '''
        euurl = "https://app.vistaraeu.com/devicePage.do?id="
        mspurl = "https://mspnocsupport.com/devicePage.do?id="
        #qubicClientIds = [10000053,10000058,10000048]
        if int(clientid) < 10000000:
            deviceUrl = mspurl+str(deviceid)
        else:
            did = int(deviceid) - 10000000
            deviceUrl = euurl+str(did)
        return deviceUrl

    def generateVistaraAlertUrl(self, clientid=0, alertid=0):
        '''
        newDataCenterDetailsOfClient = msps_obj.clientNewDatacenterDetails()
        aData = newDataCenterDetailsOfClient.get(clientid, {})
        alertUrl = str(aData['portal_url'])+'/alert.do?action=monitoringAlerts&cId='+str(alertid) if aData else ''
        return alertUrl
        '''
        euurl = "https://app.vistaraeu.com/alert.do?action=monitoringAlerts&cId="
        mspurl = "https://mspnocsupport.com/alert.do?action=monitoringAlerts&cId="
        #qubicClientIds = [10000053,10000058,10000048]
        if int(clientid) < 10000000:
            alertUrl = mspurl+str(alertid)
        else:
            alertUrl = euurl+str(alertid)
        return alertUrl

    def random_password(self,length):
        key = ''
        for i in range(length):
            key += random.choice(string.lowercase +
                                 string.uppercase + string.digits)
        return key

    #Method check weather user session exist or not of exist return true else redirect to login page
    def checkAuthentication(self,request):
        if 'uName' in request.session :
            return True
        else :
            logURL = configobj.getConfigValue(configobj.loginurl)
            return HttpResponseRedirect(logURL)
    #Method gives week start date and end date.
    def getWeekStartAndEndDate(self):
        os.environ["TZ"]="Asia/Kolkata"
        curdate = datetime.now()
        curdate = curdate.strftime('%Y-%m-%d')
        curDate = datetime.strptime(curdate, '%Y-%m-%d')
        wseDates = {}
        wseDates['startDatetime'] = curDate - timedelta(days=curDate.weekday())
        wseDates['endDatetime'] =  wseDates['startDatetime'] + timedelta(days = 6)
        wseDates['startD'] = wseDates['startDatetime'].strftime('%Y-%m-%d')
        wseDates['endD'] = wseDates['endDatetime'].strftime('%Y-%m-%d')
        return wseDates
    #Method gives dates for week start and end dates and today date and seven days back date.
    def getCurWeekandlastsevDaysDates(self,inFlag):
        os.environ["TZ"]="Asia/Kolkata"
        curdate = datetime.now()
        curdate = curdate.strftime('%Y-%m-%d')
        curDate = datetime.strptime(curdate, '%Y-%m-%d')
        wselsDates = {}
        if inFlag == 1 :
            wselsDates['startDatetime'] = curDate - timedelta(days = 6)
            wselsDates['endDatetime'] = curDate
            wselsDates['startD'] = wselsDates['startDatetime'].strftime('%Y-%m-%d')
            wselsDates['endD'] = wselsDates['endDatetime'].strftime('%Y-%m-%d')    
        else :
            wselsDates['startDatetime'] = curDate - timedelta(days=curDate.weekday())
            wselsDates['endDatetime'] = wselsDates['startDatetime'] + timedelta(days = 6)
            wselsDates['startD'] = wselsDates['startDatetime'].strftime('%Y-%m-%d')
            wselsDates['endD'] = wselsDates['endDatetime'].strftime('%Y-%m-%d')
        return wselsDates
    #Method prepare work sheet to write into excel   
    def WriteToExcel(self,titles,data):
        output = StringIO.StringIO()
        workbook = xlsxwriter.Workbook(output)
        worksheet = workbook.add_worksheet()
        # Some data we want to write to the worksheet.
        # Start from the first cell. Rows and columns are zero indexed.
        row = 0
        col = 0
        for k,v in titles.iteritems():
            worksheet.write(row, col, v)
            col +=1
        # Iterate over the data and write it out row by row.
        row = 1
        col = 0
        for key,eachrow in data.iteritems():
            for key,title in titles.iteritems():
                worksheet.write(row, col, eachrow[title])
                col +=1
            row += 1
            col = 0
        workbook.close()
        xlsx_data = output.getvalue()
        return xlsx_data
    
    def WriteToExcelSheet(self,data,email=0):
        output = StringIO.StringIO()
        if not email :
            workbook = xlsxwriter.Workbook(output)
        else :
            slamFileLocation = configobj.getCommConfigValue(configobj.slamResLocation)
            workbook = xlsxwriter.Workbook(slamFileLocation)
        worksheet = workbook.add_worksheet()
        format = workbook.add_format()
        format.set_bg_color('cyan')
        # Some data we want to write to the worksheet.
        # Start from the first cell. Rows and columns are zero indexed.
        row = 0
        col = 0
        for key,info in data.iteritems() :
            for k,v in info.iteritems():
                worksheet.write(row, col, k, format)
                col +=1
            break
        # Iterate over the data and write it out row by row.
        row = 1
        col = 0
        for key,eachrow in data.iteritems():
            for key,val in eachrow.iteritems():
                worksheet.write(row, col, val['display'])
                col +=1
            row += 1
            col = 0
        workbook.close()
        if not email :
            xlsx_data = output.getvalue()
            return xlsx_data
        else :
            return slamFileLocation
    #Method prepares date into required format for pulling into excel
    def prepareExcelData(self,titles,data):
        finRes = {}
        for k, v in data.items():
            if k in titles.keys():
                finRes[titles[k]] = v
        return finRes
    #Method get result from the GET api url
    def getAPIResponce(self,url,apiType=None):
        
        if apiType == 'ticket' :
            token = self.getAuthToken('ticket')
            resHed = {'TOKEN' : token,'content-type': 'application/json'}
            finalRes = requests.get(url, headers=resHed, verify = False)
            return finalRes.json()
        else :
            token = self.getAuthToken('redis')
            resHed = {'TOKEN' : token,'generateToken':1, 'orgId':844, 'content-type': 'application/json'}
            finalRes = requests.get(url, headers=resHed).json()
            return finalRes
    #Method get result from POST api url.
    def getPostResponce(self,url='',params={},apiType = None):

        if apiType == 'ticket' :
            token = self.getAuthToken('ticket')
            resHed = {'TOKEN' : token}
            finalPostRes = requests.post(url, data=params, headers=resHed, verify = False).json()
            return finalPostRes 
        else :
            token = self.getAuthToken('redis')
            resHed = {'TOKEN' : token,'generateToken':1, 'orgId':844}
            finalPostRes = requests.post(url, data=json.dumps(params), headers=resHed).json()
            for key,value in finalPostRes.iteritems() :
                finalRes = value
                break
            return finalRes
    def getPutResponce(self,url,params,apiType = None):
        if apiType == 'ticket' :
            token = self.getAuthToken('ticket')
            resHed = {'TOKEN' : token}
            
            finalPostRes = requests.put(url, data=json.dumps(params), headers=resHed, verify = False).json()
            for key,value in finalPostRes.iteritems():
                finalRes = value
                break
            return finalRes 
        else :
            token = self.getAuthToken('redis')
            resHed = {'TOKEN' : token,'generateToken':1, 'orgId':844}
            finalPostRes = requests.put(url, data=json.dumps(params), headers=resHed).json()
            for key,value in finalPostRes.iteritems() :
                finalRes = value
                break
            return finalRes
    def getAuthToken(self,apiType):
        configobj = ConfigManager()
        if apiType == "redis":
            redisKey = configobj.getCommConfigValue(configobj.redisKey)
            redisSecret = configobj.getCommConfigValue(configobj.redisSecret)
            redisAuthurl = configobj.getCommConfigValue(configobj.redisAuthurl)
            tokenHed = {'KEY': redisKey, 'SECRET': redisSecret}
            getTokenResponseIs = requests.get(redisAuthurl, headers=tokenHed).json()
            for key,value in getTokenResponseIs.iteritems() :
                token = value[0]['token']
                break
        elif apiType == "ticket":
            apipointsto = configobj.getCommConfigValue(configobj.apiPointing)
            authUrl =  configobj.getCommConfigValue(configobj.ticketAuthurl)
            Apiurl =authUrl.split(',')
            ticketKey = configobj.getCommConfigValue(configobj.ticketKey)
            ticketSecret = configobj.getCommConfigValue(configobj.ticketSecret)
            ticketAuthurl = Apiurl[int(apipointsto)]
            tokenHed = {'KEY': ticketKey, 'SECRET': ticketSecret}
            getTokenResponseIs = requests.get(ticketAuthurl, headers=tokenHed, verify=False).json()
            for key,value in getTokenResponseIs.iteritems():
                token = value[0]['token']
                break
        elif apiType == "monitoring":
            APIvalues = configobj.getCommConfigValue(configobj.MonitoringAPIValues)
            APIvalues = json.loads(APIvalues)
            Authurl = str(APIvalues["BaseUrl"])+"auth/oauth/token"  
            data = {'client_secret' : APIvalues["secret"],'grant_type': 'client_credentials','client_id':APIvalues["key"]}
            headers={'ContentType': 'application/x-www-form-urlencoded'}
            tokenResponse = requests.post(Authurl,data=data,headers=headers,verify=False)
            tokenData = json.loads(tokenResponse.content) 
            token = str(tokenData['token_type'])+' '+str(tokenData['access_token'])  
        return token
    #Method converts time stamp to hours, minutes, seconds
    def getHours(self,total):
        total = int(total)
        if total >= 0:
            finalRes = "TL "
        else :
            finalRes = "OD "
        if total == 0 :
            return '-'
        s = int(total%60)
        m = int(total/60)%60
        h = int(total/3600)%24
        d = int(total/86400)
        d = '' if d == 0 else str(d)+'d'
        h = '' if h == 0 else str(h)+'h'
        m = '' if m == 0 else str(m)+'d'
        s = '' if s == 0 else str(s)+'s'
        finalRes = finalRes+d+h+m+s
        return finalRes
    #Method converts time stamp to hours, minutes, seconds
    def getHourMins(self,total):
        if total == '' or total == None :
            return '-'
        if int(total)<60:
            return str(total)+'s'
        s = int(total%60);
        m = int(total/60)%60;
        h = int(total/3600)%24;
        d = int(total/86400);
        if (d+h+m) != 0 :
            d = '' if d == 0 else str(d)+'d ';
            h = '' if h == 0 else str(h)+'h ';
            m = '' if m == 0 else str(m)+'m ';
            s = '' if s == 0 else str(s)+'s';
            showtime = d+h+m+s;
        else:
            showtime=""
        return showtime
    #Set Basic user information into session when logged in
    def setSessionValues(self,request,username = '',uId = 0):
        try :
            OBValidationCheckTeam = configobj.getCommConfigValue(configobj.OBValidationCheckTeam)
            OBValidationCheckTeam = ast.literal_eval(OBValidationCheckTeam)
            flag=0
            nrInfo = NrStaff()
            if username :
                from django.db.models import Q
                nrInfo = NrStaff.objects.using('rosterRead').get((Q(staff_email=username) | Q(user_name=username.split('@')[0])| Q(staff_alternate_email=username)), is_active=1, is_found=1)
                flag =1
            else :
                nrInfo = NrStaff.objects.using('rosterRead').get(id = uId)
                flag=1
            if flag == 1:
                request.session['uName'] = nrInfo.staff_email
                request.session['uId'] = nrInfo.id
                request.session['isAdmin'] = nrInfo.is_admin
                request.session['fullName'] = str(nrInfo.staff_fname)+' '+str(nrInfo.staff_lname)
                request.session['swstaffId'] = nrInfo.swstaff_id
                request.session['isadAdmin'] = nrInfo.is_ad_admin
                request.session['repMangId'] = nrInfo.reporting_manager_id
                request.session['isMBaccess'] = nrInfo.is_mngr_dboard_access
                request.session['tb_admin'] = nrInfo.is_tb_admin
                request.session['sdm_access'] = nrInfo.sdmtracker_access
                request.session['hrdata_access'] = nrInfo.hrdata_access
                request.session['empDeptMap'] =  self.staffDeptMappingStatus(nrInfo.id)
                res = NrStaff.objects.using('rosterRead').only('id').filter(reporting_manager_id = request.session['uId']).count()
                if res > 0:
                    request.session['isManager'] = 1
                else :
                    request.session['isManager'] = 0
                request.session['proVersion'] = self.getCurrentVersion()
                if nrInfo.id in OBValidationCheckTeam:
                    request.session['OBValidationCheck_access'] = 1
                else:
                    request.session['OBValidationCheck_access'] = 0
                    
                self.checkSwStaffIdByEmail(nrInfo.staff_email, request)        
            return request
        except Exception as e: 
            import logging
            log  = logging.getLogger('NNCPortal')
            log.info('')
            log.exception(' Exception in setSessionValues is -> %s'%str(e))
        return request
    #convert given time to UTC
    def convertDateUTC(self,inputDates,inputFor):
        for key,val in inputDates.iteritems() :
            if type('') == type(val) :
                inputDates[key] = datetime.strptime(val,'%Y-%m-%d %H:%M:%S')
        for key,val in inputDates.iteritems() :
            if inputFor == 'IST' :
                inputDates[key] = val - dt.timedelta(minutes=330)
                inputDates[key] = inputDates[key].strftime('%Y-%m-%d %H:%M:%S')
            if inputFor == 'PDT' :
                inputDates[key] = val + dt.timedelta(minutes=420)
                inputDates[key] = inputDates[key].strftime('%Y-%m-%d %H:%M:%S')
        return inputDates
    #convert given time specified format like IST or PDT
    def convertDateReq(self,inputDates,reqFor):
        for key,val in inputDates.iteritems() :
            if type('') == type(val) :
                inputDates[key] = datetime.strptime(val,'%Y-%m-%d %H:%M:%S')
        for key,val in inputDates.iteritems() :
            if reqFor == 'IST':
                inputDates[key] = val + dt.timedelta(minutes=330)
                inputDates[key] = inputDates[key].strftime('%Y-%m-%d %H:%M:%S')
            if reqFor == 'PDT':
                inputDates[key] = val - dt.timedelta(minutes=420)
                inputDates[key] = inputDates[key].strftime('%Y-%m-%d %H:%M:%S')
        return inputDates
    #convert cursor date into dictionary
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]


    def getCurrentVersion(self):
        sql = "SELECT db_version FROM dbversion order by id DESC LIMIT 1"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        if 'db_version' in result[0]:
            return result[0]['db_version']
        else:
            return configobj.getConfigValue(configobj.relVer)
    
    def getGroupStausName(self):
        Allstatuses = []
        result = mem_cache.get('statusTypes'+env)
        if not result:
            result={}
            Activestatusnames = swticket_obj.getActiveStatus()
            Inactivestatusnames = swticket_obj.getInActiveStatus()
            Closedstatusnames = swticket_obj.getClosedStatus()
            Allstatuses = Activestatusnames.keys()+Inactivestatusnames.keys()+Closedstatusnames.keys()
            for statusid in Allstatuses:
                if statusid in Activestatusnames.keys() :
                    result[statusid]="Active"
                if statusid in Inactivestatusnames.keys() :
                    result[statusid]="InActive"
                if statusid in Closedstatusnames.keys() :
                    result[statusid]="Closed"
            mem_cache.set('statusTypes'+env, result, 604800)
        return result
    
    def getDepatmentIs(self,managerId):
        sql = "select DISTINCT kayako_deptid from staff_dept_mapping  where managerid = "+str(managerId)
        cursorStaff = connections['rosterRead'].cursor()
        cursorStaff.execute(sql)
        result = self.dictfetchall(cursorStaff)
        cursorStaff.close()
        return result
    
    ''' Department wise staff list '''
    def getSwStaffByRoster(self):
        sql = "SELECT DISTINCT(staff.id), staff.staff_fname, staff.staff_lname, concat(staff.staff_fname,' ', staff.staff_lname) as staff_fullname, staff.employee_id, addept.dept_name, rosterdept.dept_name AS roster, staff.user_name as samaccountname, staff.staff_email, staff.swstaff_id FROM nr_staff staff LEFT JOIN nr_departments addept ON (addept.id = staff.dept_id) LEFT JOIN nr_departments rosterdept ON (rosterdept.id = staff.roster_id) WHERE staff.is_active = 1 AND staff.is_found = 1 AND swstaff_id > 0 ORDER BY roster,staff.staff_fname, staff.staff_lname"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result
    
    def getAllServiceTypes (self):
        serviceTypes = mem_cache.get('serviceTypes'+env)
        if not serviceTypes:
            cursor = connections['ticketRead'].cursor()
            sql = 'SELECT DISTINCT name as service_type FROM ntsviewdevice_service_map ORDER BY name ASC'
            cursor.execute(sql)
            serviceTypes = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('serviceTypes'+env, serviceTypes, 86400)
        return serviceTypes
    
    def getAllServiceLevels (self):
        cursor = connections['mspDB'].cursor()
        sql = 'select DISTINCT service_level from sku ORDER BY service_level ASC'
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result
    
    def getDeviceTypes (self):
        cursor = connections['ticketRead'].cursor()
        sql = 'select id, path from ntsdevice_type order by path'
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result
    
    def getTimeZonevalue(self,scheduledTime,timezone):
        if timezone.find('Greenwich') != False:
            timeDiff = "+00:00";
        else:
            res = timezone[4:10]
            timeDiff = res;
            timeDiff = res[0:1]
            if timeDiff == '-':
                timeDiff = str(res + 1)+":00";
            else:
                timeDiff = res;
        scheduledQ = "select CONVERT_TZ('"+str(scheduledTime)+"','"+str(timeDiff)+"','America/Los_Angeles') as scheduledtime";
        cursor = connections['rosterRead'].cursor()
        cursor.execute(scheduledQ)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result
    
    def getTimezones(self):
        result = mem_cache.get('timezones'+env)
        if not result:
            result = {}
            timeZonequery = "SELECT label,timezone_code,name FROM nts_cfg_timezones GROUP BY timezone_code order by id";
            cursor = connections['ticketRead'].cursor()
            cursor.execute(timeZonequery)
            timeZoneres = self.dictfetchall(cursor)
            i=0
            for timeZonere in timeZoneres:
                result.setdefault(i,timeZonere)
                i = i+1
            mem_cache.set('timezones'+env, result, 86400)
        return result
    
    def getTemplatenames(self):   
        cursor = connections['rosterRead'].cursor()
        sql = "SELECT  templatename FROM ticketbrowser_templates WHERE reportType = 'TB' AND display_template = 1";
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result  
       
    def ticketingUrls(self):
        configobj = ConfigManager()
        apipointsto = configobj.getCommConfigValue(configobj.apiPointing)
        authUrl =  configobj.getCommConfigValue(configobj.ticketurl)
        Apiurl =authUrl.split(',')
        return Apiurl[int(apipointsto)]
    
    ''' toTime zone value need to provide as input like -06:00 '''   
    def getCurrentTimeandDay(self,fromTimeZoneValue,toTimeZoneValue):
        result = {}
        sql = "SELECT DATE_FORMAT(CONVERT_TZ(now(),'"+str(fromTimeZoneValue)+"','"+str(toTimeZoneValue)+"'),'%H:%i:%s | %a') as currenttime , convert_tz(now(),'"+str(fromTimeZoneValue)+"', '"+str(toTimeZoneValue)+"') as currentdate from dual";
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        results = self.dictfetchall(cursor)
        cursor.close()
        CurrentTimeresults = results[0]['currenttime'].split('|')
        result['time'] = str(CurrentTimeresults[0])
        result['day'] = str(CurrentTimeresults[1])
        result['currentDate'] = results[0]['currentdate']
        return result;    
    
    def getEscalationUsers(self,shiftid):
        shiftUsersInfo = {}
        ShiftUsersQ = "select ntscon.first_name,ntscon.last_name,ntscon.email,ntscon.mobile_number,ntscon.phone_number,ntscon.time_zone "
        ShiftUsersQ += "from  nts_escalation_shift_users esu left join ntscontactmappings ntscon on (ntscon.id = esu.user_id) "
        ShiftUsersQ += "where escalation_shift_details_id="+str(shiftid)+" order by esu.id asc"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(ShiftUsersQ)
        shiftUsersRes = self.dictfetchall(cursor)
        cursor.close()
        usersi = 0;
        for shiftUser in shiftUsersRes : 
            shiftUsersInfo.setdefault(usersi,{})
            import re
            shiftUsersInfo[usersi]['User']= re.sub(u"(\u2013|\u2014)", "'",shiftUser['first_name'])+re.sub(u"(\u2013|\u2014)", "'",shiftUser['last_name'])
            shiftUsersInfo[usersi]['Email']= str(shiftUser['email'])
            shiftUsersInfo[usersi]['phone_number']= str(shiftUser['phone_number'])
            shiftUsersInfo[usersi]['mobile_number']= str(shiftUser['mobile_number'])
            shiftUsersInfo[usersi]['time_zone']= str(shiftUser['time_zone'])
            usersi = usersi+1
        return shiftUsersInfo;
    
    def sendEmail(self,myhtml='',inputAR={}):
        from django.core.mail import EmailMessage
        from django.template import Context
        from django.template.loader import get_template
        from django.template import loader
        t = loader.get_template(inputAR['templateName'])
        c = Context({'myhtml':myhtml})
        emailMessage = t.render(c)
        subject = inputAR['subject']
        fromMailID = 'noreply@netenrich.com'
        toMailList = inputAR['to']
        bccMailList = inputAR['bcc']
        finalMessasge=EmailMessage(subject=subject,body=emailMessage,from_email=fromMailID,to=toMailList,bcc=bccMailList,headers={'Cc': ','.join(bccMailList)})
        finalMessasge.content_subtype = 'html'
        if inputAR.has_key('fileLocation'):
            finalMessasge.attach_file(inputAR['fileLocation'], "application/pgp-encrypted")
        finalMessasge.send()
        return HttpResponse("email sent succussfully")
    
    def convertTemplateFieldsToString(self,inputData):
        if inputData in [None,'','NULL']:
            return ''
        else:
            return str(inputData)
        
    ''' CSAT information for custom columns '''
    def getCSAT(self, ticketId):
        cSatInfo = {}
        sql = "SELECT user_id,user_fullname,user_email,useremail_form,ticketid,survey_id,server_info "
        sql += "FROM csat_users " 
        sql += "WHERE user_status = 0 AND user_id NOT IN (1) AND ticketid = "+str(ticketId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        userStatResults = self.dictfetchall(cursor)
        
        if userStatResults:
            cSatInfo['full_name'] = userStatResults[0]['user_fullname']
            cSatInfo['user_email'] = userStatResults[0]['user_email']
            cSatInfo['entered_email'] = userStatResults[0]['useremail_form']
            sql = "SELECT m.mspname AS msp,c.clientname AS client "
            sql += "FROM ntsclienttickets t,ntsmsps m,ntsmspclients c " 
            sql += "WHERE m.mspid = t.mspid AND c.mspclientid = t.clientid AND t.ticketid = "+str(ticketId)
            cursor.execute(sql)
            mspInfo = self.dictfetchall(cursor)
            cSatInfo['msp'] = mspInfo[0]['msp']
            cSatInfo['msp'] = mspInfo[0]['msp']
            user_id =  str(userStatResults[0]['user_id'])
            survey_id = str(userStatResults[0]['survey_id'])
            sql = "SELECT uq.fb_question AS qtn ,fo.fbop_value AS ans,ut.fbop_text AS textans "
            sql += "FROM `csat_user_feedback` uf "
            sql += "LEFT JOIN csat_feedback_questions uq ON (uf.fb_id = uq.fb_id) "
            sql += "LEFT JOIN `csat_feedback_options` fo ON (fo.fbop_id = uf.fbop_id) "
            sql += "LEFT JOIN csat_userfeedback_text ut ON (uf.ufb_id = ut.ufb_id) "
            sql += "LEFT JOIN csat_users cu ON (cu.user_id = uf.user_id) "
            sql += "WHERE uf.user_id = "+user_id+" AND uf.survey_id = "+survey_id
            cursor.execute(sql)
            surveyInfo = self.dictfetchall(cursor)
            for survey in surveyInfo:
                if survey['qtn'].startswith('Your case has been closed'):
                    cSatInfo['resolution_address'] = survey['ans']
                elif survey['qtn'].startswith(' How do you rate your satisfaction'):
                    cSatInfo['satisfaction'] = survey['ans']
                elif survey['qtn'] == 'Other Comments':
                    cSatInfo['other_comments'] = survey['textans']
        cursor.close()
        return cSatInfo
    
    def getSlaEffectivePriorities(self):
        sql = "SELECT * FROM swticketpriorities WHERE frcolorcode !='' ORDER BY displayorder"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        return result

    def getTicketStatusById(self, statusid):
        ticket_status = mem_cache.get("ticketstatus")
        if not ticket_status:
            sql = "SELECT title, ticketstatusid FROM swticketstatus"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            ticket_status = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set("ticketstatus", ticket_status, 86000)

        try:
            index = map(itemgetter('ticketstatusid'), ticket_status).index(statusid)
            return ticket_status[index]['title']
        except Exception as e:
            return None
        
    """ Scheduled time conversion to PST"""
    def getScheduledTimeZoneConversion(self,scheduleTime,timeZoneValue):
        sql = "select CONVERT_TZ('"+str(scheduleTime)+"','"+str(timeZoneValue)+"','America/Los_Angeles') as scheduledtime"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        ticket_scheduledTime = self.dictfetchall(cursor)
        cursor.close()
        return ticket_scheduledTime
    
    def checkSwStaffIdByEmail(self, email, request):
        if email.__contains__("@"):
                email_list = email.split("@")
                fullname = email_list[0]
        try:
            sw_obj = Swstaff.objects.using('ticketRead').filter(email=email)[0]
            try:
                userobj = User.objects.get(email=email)
                user = authenticate(username=fullname, password="Pa55Word@123")
                request.session['_auth_user_id'] = user
                return True
            except Exception as e:
                user = User.objects.using('rosterWrite').create(username=fullname)
                user.email = email
                user.password = "Pa55Word@123"
                user.save()
                user_obj = authenticate(username=fullname, password="Pa55Word@123")
                request.session['_auth_user_id'] = user_obj
                return True
            return True
        except Exception as e:
            sw_obj = Swstaff.objects.using('ticketRead').get(staffid = 24)
            staff_new_obj = Swstaff.objects.using('ticketWrite').create(fullname=fullname, 
                                                                        username = fullname,
                                                                        email = email,
                                                                        password = self.random_password(9),
                                                                        staffgroupid = 16,
                                                                        mobilenumber = 9999999999,
                                                                        lastvisit = sw_obj.lastvisit,
                                                                        lastvisit2 = sw_obj.lastvisit2,
                                                                        enabledst = sw_obj.enabledst,
                                                                        startofweek = sw_obj.startofweek,
                                                                        pmunread = sw_obj.pmunread,
                                                                        groupassigns = sw_obj.groupassigns,
                                                                        enablepmalerts = sw_obj.enablepmalerts,
                                                                        enablepmjsalerts = sw_obj.enablepmjsalerts,
                                                                        ticketviewid = sw_obj.ticketviewid,
                                                                        timezonephp = sw_obj.timezonephp,
                                                                        lastactivity = sw_obj.lastactivity
                                                                        )
    
            staff_new_obj.save()
            nrobj = NrStaff.objects.using("rosterWrite").get(staff_email =  email)
            nrobj.swstaff_id = staff_new_obj.staffid
            nrobj.save()
            return True
        
        
        
    def apiForPostJsonData(self,url='',params={},apiType = None):

        if apiType == 'ticket' :
            token = self.getAuthToken('ticket')
            resHed = {'TOKEN' : token,'content-type':'application/json'}
            jsonData = simplejson.dumps(params)
            finalPostRes = requests.post(url, data=jsonData, headers=resHed, verify = False).json()
            return finalPostRes 
        else :
            token = self.getAuthToken('redis')
            resHed = {'TOKEN' : token,'generateToken':1, 'orgId':844}
            finalPostRes = requests.post(url, data=json.dumps(params), headers=resHed).json()
            for key,value in finalPostRes.iteritems() :
                finalRes = value
                break
            return finalRes
        
    def getDeviceByClientIds(self,clientIds):
        sql =" select id, device_name from ntsmspdevicedata  where (state IS NULL OR state IN('','active','deleted-active')) AND client_id IN (%s)  order by device_name" % (clientIds)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        return result
    def getAllTicketType(self):
        sql = "select typeid, typename from ntstickettype"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        return result
    
    def serviceCatory(self):
        sql = "select servicecatid, servicecatname  from ntsservicecategories order by servicecatname "
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        return result
    
    def deviceCategory(self):
        sql = "select devicecatid,devicecatname   from ntsdevicecategories order by devicecatname "
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        return result
    
    def staffDataByCache(self):
        final = mem_cache.get("staffCacheData")
        if not final:
            cursor = connections['rosterRead'].cursor()
            sql = "SELECT id,swstaff_id,staff_email,staff_fname, staff_lname FROM nr_staff WHERE is_active = 1 AND is_found = 1 AND swstaff_id > 0"
            cursor.execute(sql)
            staff_data = self.dictfetchall(cursor)
            cursor.close()
            nrstaffIdBasedData = {}
            swstaffIdBasedData = {}
            for staff in staff_data:
                set1 ={}
                set2={}
                nrstaffIdBasedData.setdefault(staff['id'],{})
                swstaffIdBasedData.setdefault(staff['swstaff_id'],{})
                fullname = str(staff['staff_lname'])+' '+str(staff['staff_fname'])
                set1['swstaffid']= staff['swstaff_id']
                set1['fullname']= fullname
                set1['email']=str(staff['staff_email'])
                nrstaffIdBasedData[staff['id']] = set1
                
                set2['nrstaffid']= staff['id']
                set2['fullname']= fullname
                set2['email']=str(staff['staff_email'])
                swstaffIdBasedData[staff['swstaff_id']] = set2
            final = {}
            final['nrstaffId'] = nrstaffIdBasedData
            final['swstaffId'] = swstaffIdBasedData
            mem_cache.set("staffCacheData", final, 86000)
        return final    
   
    
    def mspNamesByCache(self):
        from NNCPortal.commonModels.Ntsmsps import Ntsmsps
        msps = mem_cache.get('mspNames')
        final ={}
        if not msps:
            msps = Ntsmsps.objects.using('ticketRead').only('mspname', 'mspid').filter(status=1).order_by('mspname')
            for msp in msps:
                final[msp.mspid] = msp.mspname
            mem_cache.set('mspNames', final, 86400)
        return final
    
    def staffDeptMappingStatus(self,id):
        sql = "select count(*) as count from staff_dept_mapping where nrstaffid ="+str(id)
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        value = result[0]['count']
        data = 0
        if value > 0:
            data = 1
        return data
    
    """ if unixtimestamp exist then return equal PST date """
    def timeStampToPST(self,unixTimeStamp):
        if unixTimeStamp:
            sql = "SELECT CONVERT_TZ(FROM_UNIXTIME("+str(unixTimeStamp)+"),'UTC','US/Pacific') as pstdate FROM dual"
        else:
            return ''
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        pstDate = self.dictfetchall(cursor)
        cursor.close()
        return pstDate
    
        """ return current,yesterday PST date"""
    def currentAndYesterDayInPST(self):
        sql = "SELECT CONVERT_TZ(now(),'UTC','US/Pacific') as currentTimeInPST, CONVERT_TZ(now() - interval 1 day,'UTC','US/Pacific') as yesterDayPST FROM dual"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        pstDate = self.dictfetchall(cursor)
        cursor.close()
        return pstDate
    
    def ExcelDwdFor500Below(self,titles,contentData):
        output = StringIO.StringIO()
        workbook = xlsxwriter.Workbook(output)
        worksheet = workbook.add_worksheet()
        # Some data we want to write to the worksheet.
        # Start from the first cell. Rows and columns are zero indexed.
        row = 0
        col = 0
        for v in titles:
            worksheet.write(row, col, v)
            col +=1
        
        contentRow = 1
        ContentCol = 0
        for k,v in contentData.iteritems():
            grouping = {}
            for l in  titles:
                
                if isinstance(v[l],dict):
                    if v[l].has_key('display'):
                        worksheet.write(contentRow, ContentCol,v[l]['display'])
                    else:
                        worksheet.write(contentRow, ContentCol,'null')
                else:
                    worksheet.write(contentRow, ContentCol,'null')
                ContentCol =1 + ContentCol
            ContentCol = 0
            contentRow = 1 + contentRow
        
        # Iterate over the data and write it out row by row.
        workbook.close()
        xlsx_data = output.getvalue()
        return xlsx_data
        
            
        """ PST date to Unixtimestamp """
    def pstToUTCStamp(self,PstDate):
        if PstDate:
            sql = "SELECT UNIX_TIMESTAMP(CONVERT_TZ('"+str(PstDate)+"','US/Pacific','UTC')) as pstdate FROM dual"
        else:
            return ''
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        pstDate = self.dictfetchall(cursor)
        cursor.close()
        return pstDate

    def utcToDate(self,utcDate):
        if utcDate:
            sql = "select from_unixtime("+str(utcDate)+") as utc from dual"
        else:
            return ''
        print sql
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        utcDate_result = self.dictfetchall(cursor)
        cursor.close()
        return utcDate_result