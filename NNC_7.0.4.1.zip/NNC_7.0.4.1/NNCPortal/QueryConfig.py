clientTickets =  {
    'clientCurrentMonthTickets'  :  '''select sum(case when statusid in (1,7,12,18,19,21,22,23) then 1 else 0 end) as active,
sum(case when statusid in (9,2,11,16,46) then 1 else 0 end) as inactive,
sum(case when statusid in (16) then 1 else 0 end) as scheduled,
sum(case when statusid in (3,5,17,20,32,41) then 1 else 0 end) as closed,
sum(case when created_dt > unix_timestamp((now()) - interval 1 month) then 1 else 0 end) as created 
from incident_data where created_dt> unix_timestamp((now()) - interval 1 month) and cid =''',
    'activeCurrentMonthTickets' : '''select msp as mspName, client as clientName,priority as priority,status as status, ticketid as ticketId from incident_data where created_dt> unix_timestamp((now()) - interval 1 month) and deptid NOT IN (0,1) and statusid in (1,7,12,18,19,21,22,23) and cid = ''',
    'inactiveCurrentMonthTickets' : '''select msp as mspName, client as clientName,priority as priority,status as status, ticketid as ticketId from incident_data where created_dt> unix_timestamp((now()) - interval 1 month) and deptid NOT IN (0,1) and statusid in (2,9,11,16,46) and cid = ''',
    'scheduledCurrentMonthTickets' : '''select msp as mspName, client as clientName,priority as priority,status as status, ticketid as ticketId from incident_data where created_dt> unix_timestamp((now()) - interval 1 month) and deptid NOT IN (0,1) and statusid in (16) and cid = ''',
    'closedCurrentMonthTickets' : '''select msp as mspName, client as clientName,priority as priority,status as status, ticketid as ticketId from incident_data where created_dt> unix_timestamp((now()) - interval 1 month) and statusid in (3,5,17,20,32,41) and deptid NOT IN (0,1)  and cid = ''',
    'createdCurrentMonthTickets' : '''select msp as mspName, client as clientName,priority as priority,status as status, ticketid as ticketId from incident_data where created_dt> unix_timestamp((now()) - interval 1 month)  and deptid NOT IN (0,1) and cid = ''',
    'todayCreatedTickets' : '''SELECT count(ticketid) AS count, priority FROM incident_data WHERE cid = '%s' AND priorityid IN (8,9,10,11) AND deptid not in (0,1) AND 
created_dt > unix_timestamp((now()) - interval 1 day) group by priorityid''',
    'todayClosedTickets' : '''SELECT count(ticketid) AS count, priority FROM incident_data WHERE cid = '%s' AND priorityid IN (8,9,10,11) AND deptid not in (0,1) AND 
created_dt > unix_timestamp((now()) - interval 1 day) AND statusid in (3) group by priorityid''',
    'todayhmspwfciTickets' : '''SELECT count(ticketid) AS count, priority FROM incident_data WHERE cid = '%s' AND priorityid IN (8,9,10,11) AND deptid not in (0,1) AND 
created_dt > unix_timestamp((now()) - interval 1 day) AND statusid in (7,9) group by priorityid''',
    'deviceCount' : '''select count(*) as count from ntsmspdevicedata where client_id = '%s' and state = "active"''',
    'scheduledStatus':16
}