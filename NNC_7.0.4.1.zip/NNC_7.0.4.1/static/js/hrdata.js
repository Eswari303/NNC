/*
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
*/
var d = new Date();
currentDate = $.datepicker.formatDate('dd-M-yy', d);
var dataTable;
var defaultOrderForColumn = 1
var dataTableOptions = {
    paging: false,
    info: false,
    dom: 'Bfrtip',
    processing: true,
    buttons: [
	{
	    text: 'Import from Excel <i class="fa fa-download"></i>',
	    action: function ( e, dt, node, config ) {
	    	$('#uploadPostReplyFile').trigger('click');
	    },
	    className: 'btn btn-primary'
	},
    {
        extend: 'excel',
        filename: 'HRData_'+currentDate,
        text: 'Export to Excel <i class="fa fa-upload"></i>',
        exportOptions: {
            modifier: {
                page: 'current'
            }
        },
        className: 'btn btn-success',
    },
    {
	    text: 'Delete <i class="fa fa-times"></i>',
	    className:'btn btn-danger myClass'
	}],
    "order": [[ defaultOrderForColumn, "asc" ]],
    "columnDefs": [ {
    	"targets": 0,
    	"orderable": false
    } ]
};


$(document).ready(function() {
	$('input#staffidAll').prop('checked', false);
});

$('body').on('click', '.closethis', function(){
	$(this).parent().slideUp('slow');
});

$('body').on('change', '#staffidAll', function(){
	checkStatus = $(this).is(':checked');
	$('input#staffid').prop('checked', checkStatus);
	if(checkStatus)
		$('.btn-danger').show()
	else
		$('.btn-danger').hide()
});

$('body').on('change', '#staffid', function(){
	if($('input#staffid:checked').length == $('input#staffid').length){
		$('input#staffidAll').prop('checked', true);
	}else{
		$('input#staffidAll').prop('checked', false);
	}
	if($('input#staffid:checked').length > 0)
		$('.btn-danger').show()
	else
		$('.btn-danger').hide()
});

$('body').on('click', '.btn-danger', function(){
	if(confirm('Do you want to remove selected?'))
		deleteStaff();
});

$(window).bind("load", function(e) {
	loadStaffInfo();
})

$('body').on('change', '#uploadPostReplyFile', function(){
	$("span.dataTables_processing").show();
	$("#frmUploadFile").ajaxForm({
		success: function (data){
			displayNotification(data);			
			loadStaffInfo();
			$("span.dataTables_processing").hide();
		}
	}).submit();
	
});

function applyDataTable(dataTableId, html){
	$('#'+dataTableId+' tfoot td').each( function () {
		var title = $(this).attr('data-name')
		if($.trim(title) != '#' &&  $.trim(title) != 'Search')
        	$(this).html( '<input type="text" placeholder="'+title+'"/>' );
		else
			$(this).html( 'Search' );
    } );
	
	if(dataTable)
		dataTable.destroy();
	
	$('#datatable #qmInfo').html(html);
	
    dataTable = $('#'+dataTableId).DataTable(dataTableOptions);
    applyMultiLevelSearchForDataTable(dataTableId, dataTable);
    $('div.dt-buttons').append('<span class="dataTables_processing"><img src="/static/images/loading.gif"></span>');
}

function applyMultiLevelSearchForDataTable(dataTableId, dataTableObj){
	dataTable.columns().every( function () {
        var that = this;
 
        $( 'input', this.footer() ).on( 'keyup change', function () {
            if ( that.search() !== this.value ) {
                that
                    .search( this.value )
                    .draw();
            }
        } );
    } );
	
	//Filtering results for existing query 
	colNo=0;
	$('#'+dataTableId+' tfoot input').each(function (i,v){
		val = $.trim($(this).val());
		if(val != ''){
			dataTable.columns(colNo).search(val).draw();
		}
		colNo++;
	})
}

function loadStaffInfo(){
	$("span.dataTables_processing").show();
	$.ajax({
		type: 'GET',
		url: '/hrData/getStaffInfo',
		data:{},
		success: function(data){
			html = '';
			rowNum = 1;
			$(data).each(function (i,staffInfo){
				style = (staffInfo.employee_status == 0) ? 'background-color:#ffdee9;':'';
				html += '<tr style="'+style+'">';
				$(staffInfo).each(function (i,row){
					employeeNumber = row.employee_id.replace('E ', '');
					html += '<td><input type="checkbox" id="staffid" name="staffid" value="'+row.id+'" /> '+rowNum+'</td>';
					html += '<td data-order="'+employeeNumber+'">'+row.employee_id+'</td>';
					html += '<td>'+row.staff_name+'</td>';
					html += '<td data-order="'+row.doj_unixtime+'">'+((row.date_of_join !== null) ? row.date_of_join : '-')+'</td>';
					html += '<td>'+((row.prior_exp !== null) ? row.prior_exp : '0')+'</td>';
					html += '<td>'+((row.ne_exp !== null) ? row.ne_exp : '0')+'</td>';
					totalExp = parseInt(row.prior_exp)+parseInt(row.ne_exp)
					html += '<td>'+((totalExp > 0) ? totalExp : '0')+'</td>';
					html += '<td>'+((row.qualification !== null) ? row.qualification : '-')+'</td>';
					html += '<td>'+((row.grade !== null) ? row.grade : '-')+'</td>';
					html += '<td>'+((row.current_title !== null) ? row.current_title : '-')+'</td>';
					html += '<td>'+((row.reporting_manager !== null) ? row.reporting_manager : '-')+'</td>';
					html += '<td>'+((row.functional_owner !== null) ? row.functional_owner : '-')+'</td>';
					
					html += '<td>'+((row.business_divison !== null) ? row.business_divison : '-')+'</td>';
					html += '<td>'+((row.business_group !== null) ? row.business_group : '-')+'</td>';
					
					html += '<td>'+((row.employee_status == 1) ? 'Active' : 'Inactive')+'</td>';
					html += '<td>'+((row.employee_type == 0) ? 'FTE' : 'Contractor')+'</td>';
					html += '<td>'+((row.contracting_company !== null) ? row.contracting_company : '-')+'</td>';
					
					
					html += '<td>'+((row.geography !== null) ? row.geography : '-')+'</td>';
					html += '<td>'+((row.work_localtion !== null) ? row.work_localtion : '-')+'</td>';
					html += '<td>'+((row.functional_unit !== null) ? row.functional_unit : '-')+'</td>';
					html += '<td>'+((row.skill_one !== null) ? row.skill_one : '-')+'</td>';
					html += '<td>'+((row.skill_one_level !== null) ? row.skill_one_level : '-')+'</td>';					
					html += '<td>'+((row.skill_two !== null) ? row.skill_two : '-')+'</td>';
					html += '<td>'+((row.skill_two_level !== null) ? row.skill_two_level : '-')+'</td>';
					html += '<td>'+((row.shared !== null) ? row.shared : '-')+'</td>';
					html += '<td>'+((row.shared_percent !== null) ? row.shared_percent : '-')+'</td>';
					html += '<td>'+((row.direct_one !== null) ? row.direct_one : '-')+'</td>';
					html += '<td>'+((row.direct_one_percent !== null) ? row.direct_one_percent : '-')+'</td>';
					html += '<td>'+((row.direct_two !== null) ? row.direct_two : '-')+'</td>';
					html += '<td>'+((row.direct_two_percent !== null) ? row.direct_two_percent : '-')+'</td>';
					
					html += '<td data-order="'+row.doresig_unixtime+'">'+((row.date_of_resignation !== null) ? row.date_of_resignation : '-')+'</td>';
					html += '<td data-order="'+row.dorelieve_unixtime+'">'+((row.date_of_relieve !== null) ? row.date_of_relieve : '-')+'</td>';
					
				});
				html += '</tr>';
				rowNum++;
			});			
			applyDataTable('datatable', html);
			$("span.dataTables_processing").hide();			
		}		
	});
	
}

function deleteStaff(){
	$("span.dataTables_processing").show();
	$.ajax({
		type: "POST",
		url: '/hrData/deleteStaff',
		data: $('#frmStaffInfo').serialize(),
		success: function (data){
			if(data){
				displayNotification(data);
				loadStaffInfo();
				$("span.dataTables_processing").hide();
			}
		}
	});
	$('input#staffidAll').prop('checked', false);
	
}

function displayNotification(data){
	if(data.status == 'success'){
		$('#myAlert').slideUp();
		$('#mySuccessNotify #divErrorMsg').text(data.message);
		if(data.message)
			$('#mySuccessNotify').slideDown('slow');
		actionDiv = '#mySuccessNotify';
	}else{
		$('#mySuccessNotify').slideUp();
		$('#myAlert #divErrorMsg').text(data.message);
		if(data.message)
			$('#myAlert').slideDown('slow');
		actionDiv = '#myAlert';
	}
	
	setTimeout('$(".alert-success #divErrorMsg").html(""); $("'+actionDiv+'").slideUp();', 5000);
}