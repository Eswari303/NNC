/*
 This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 */
var IncidentPostLimit = 10;
var IncidentPostOffset = 0;
var file_c = 0;
var belowExpectation = ' <span class="fa fa-star fullstar" data-toggle="tooltip" title="Below Expection"></span><span class="star" data-toggle="tooltip" title="Below Expection"></span><span class="star" data-toggle="tooltip" title="Below Expection"></span>';
var meetsExpectation = ' <span class="fa fa-star fullstar" data-toggle="tooltip" title="Meets Expection"></span><span class="fa fa-star fullstar" data-toggle="tooltip" title="Meets Expection"></span><span class="star" data-toggle="tooltip" title="Meets Expection"></span>';
var exceedsExpection = ' <span class="fa fa-star fullstar" data-toggle="tooltip" title="Exceeds Expection"></span><span class="fa fa-star fullstar" data-toggle="tooltip" title="Exceeds Expection"></span><span class="fa fa-star fullstar" data-toggle="tooltip" title="Exceeds Expection"></span>';
var idleTime = 0;
var cdi_supportmail = ",CDI-support@netenrich.com "
/*var Electro_Switch_Corp_mail = ",pip@bemisworldwide.com"*/
$(document).ready(function() {
    var utc = moment.utc(new Date());
    var pst = moment(utc).zone('-0800');
    var currentPstTime = pst.format('YYYY-MM-DD HH:mm:ss');
    var scheduleTime = $('#gnschPost').val();
    var idleInterval = setInterval(timerIncrement, 60000); /* 1 minute */
    var existed_mails = cceList;

    /*Zero the idle timer on mouse movement. */
    $(this).mousemove(function(e) {
        idleTime = 0;
    });
    $(this).keypress(function(e) {
        idleTime = 0;
    });

    setInterval(function() {
        watchUserTrack_update();
    }, 30000);

    $('body').on('click', '#crePostRep', function() {
        $('#myAlert').hide();
        $('#divErrorMsg').html("");
        var ticketstatus = $('#statusPost').val();
        var regExNum = /^[0-9]+$/;
        var tomail = $('#toEmailId').val();

        /*Validations for NEinternal as it was not allowed the change in statuses like WFPI/WFCI... */
        if ($('#Internal').data('clicked')) { /*If NEINternal clicked this condition will pass */
            if (tomail == '' || tomail == 'undefined') { /*To mail is mandatory for NEinternal post...*/
                $('#myAlert').slideDown('slow');
                $('#divErrorMsg').html("Please enter to mail ID");
                return false;
            }
            if (ticketstatus == 9 || ticketstatus == 46) {
                $('#myAlert').slideDown('slow');
                $('#divErrorMsg').html("Please use Post Reply tab to change the status to WFPI/WFCI");
                return false;
            }
            if (ticketstatus == 3 || ticketstatus == 5) {
                $('#myAlert').slideDown('slow');
                $('#divErrorMsg').html("Please specify notes by using post reply tab before the ticket status change to Resolved/Closed");
                return false;
            }
        }

        if(CKEDITOR.instances['ticketContent'].getData() =='' || CKEDITOR.instances['ticketContent'].getData() == null || CKEDITOR.instances['ticketContent'].getData() == undefined){
            $('#myAlert').slideDown('slow');
            $('#divErrorMsg').html("Content should not be empty");
            return false;
        }

        /*HMSP Reason validation*/
        if ($('#statusPost').val() == 9 || $('#statusPost').val() == 46) {
            if ($('#hmspReason').val() == '' || $('#hmspReason').val() == "14661") {
                $('#myAlert').slideDown('slow');
                $('#divErrorMsg').html("Please enter Reason for WFPI/WFCI");
                return false;
            }
            if ($('#hmspReason').val() == 'Miscellaneous' && $('#hmspmisReason').val() == '') {
                $('#myAlert').slideDown('slow');
                $('#divErrorMsg').html("Please enter the Custom reason for WFPI/WFCI.");
                return false;
            }
            if ($('#hmspReason').val() == 'Miscellaneous' && $('#hmspmisReason').val().length < 20) {

                $('#myAlert').slideDown('slow');
                $('#divErrorMsg').html("Custom reason must be 20 characters");
                return false;
            }
        }

        if ($("#timeWorked").val() == '' || $("#timeWorked").val() == null) {
            $('#myAlert').slideDown('slow');
            $('#divErrorMsg').html("Please enter Time Worked");
            document.getElementById('timeWorked').value = '1';
            return false;
        } else {
            if (!(regExNum.test($("#timeWorked").val()))) {
                $('#myAlert').slideDown('slow');
                $('#divErrorMsg').html("Please enter valid Time Worked");
                return false;
            }
        }

        if ($("#billable").val() != '' || $("#billable").val() != null) {
            if ((regExNum.test($("#timeWorked").val())) && (regExNum.test($("#billable").val()))) {
                if (parseInt($("#timeWorked").val()) < parseInt($("#billable").val())) {
                    $('#myAlert').slideDown('slow');
                    $('#divErrorMsg').html("Time Billable should be lessthan Time Worked");
                    return false;
                }
            }
        }

        /*If ticket in Scheduled */
        if ($("#statusPost").val() == '16') {
            var tags = [];
            tagsVal = $('#postRepTags').val();
            tagsValArr = tagsVal.split(",");
            $.each(tagsValArr, function(key, val) {
                tags.push(val.trim());
            });
            tagArr = tags;
            if (($.inArray('Scheduled - Task', tagArr) != -1) || ($.inArray('Scheduled - Observation', tagArr) != -1)) {} else {
                $('#myAlert').slideDown('slow');
                $('#divErrorMsg').html("Please select the Tag, Scheduled-Task or Scheduled-Observation tag");
                return false;
            }
            if (($.inArray('Scheduled - Task', tagArr) != -1) && ($.inArray('Scheduled - Observation', tagArr) != -1)) {
                $('#myAlert').slideDown('slow');
                $('#divErrorMsg').html("Please select either 'Scheduled-Task' or 'Scheduled-Observation' ");
                return false;
            }
            var utc = moment.utc(new Date());
            var pst = moment(utc).zone('-0800');
            var currentPstTime = pst.format('YYYY-MM-DD HH:mm:ss');
            var scheduleTimeOnClick = $('#gnschPost').val();
            var scheduledFalse = scheuledTimeValidation(scheduleTimeOnClick, currentPstTime);
            if (scheduledFalse == false) {
                return false;
            }

        }
        
        /* Below is for Green Pages Partner */
        if('mspId' == 107521){
        	var validate = confirm("a. NetEnrich email address or phone numbers should not be added/pasted \nb. Customer email address should not be used for any communication");
		    if(validate == false){
		    	return false;
		    }
        }

        closeList = [3, 20, 17, 32, 41];
        var changedStatus =  $("#statusPost").val();
        function getAlertsCountStatus(){
            $.ajax({
                type: 'GET',
                url: '/ticket/getMSPID/?_ajax=true',
                data: {
                    ticketId: $('#ticketIds').val(),
                    csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
            },
            success: function (data) {
                console.log(data.getalertsCount);
                if (data.getalertsCount === 0){
                    bootbox.confirm({
                        message: "All alerts are not healed for this ticket. Do you want to continue ?",
                        buttons: {
                        confirm: {
                            label: 'Force close',
                            className: 'btn-success'
                        },
                        cancel: {
                            label: 'No',
                            className: 'btn-danger'
                            }
                        },
                        callback: function (result) {
                            if (result == true)
                                createTicketPost();
                         }
                     });
                } else {
                    createTicketPost();
                }
            }
            });
        }
        /*CreatePost	
        if (!($.inArray(changedStatus, closeList) === -1)) { */
        if ( changedStatus == 5 || changedStatus == 3 || changedStatus == 20 || changedStatus == 17 ){
            getAlertsCountStatus();
        } else {
            createTicketPost();
        }
    });

    $('body').on('click', '#createAtt', function() {
        $('#uploadPostReplyFile').trigger('click');
    });

    $('body').on('change', '#uploadPostReplyFile', function() {
        $('span#atload').show();
        $("#frmUploadFile").ajaxForm({
            success: function(data) {
            	if(data.indexOf("RestrictedToUpload:") >= 0){
            		var FileFailedReason = data.split("RestrictedToUpload:");
		        	$('#myAlert').slideDown('slow');
		            $('#divErrorMsg').html(FileFailedReason[1]);
                    $('span#atload').hide();
            	}else{
            	    display_file(data, file_c++);
                    $('span#atload').hide();
            	}
            }
        }).submit();
    });

    function display_file(data, file_c) {
        if (data) {
            $('#attach_div').append('<span id="fobj_' + file_c + '" data="' + data + '"class="btn btn-primary btn-small space">' + data + '<i class="fa fa-close"></i></span>');
        }
    }

    $(document).on('click', '#attach_div span .fa-close', function() {
        var nam = $(this)[0];
        $.ajax({
            type: "POST",
            url: '/ticket/delattachment',
            data: {
                'attDynamic': $('#attDynamic').val(),
                'fname': $(nam.parentElement).attr('data'),
                'csrfmiddlewaretoken': $('input[name=csrfmiddlewaretoken]').val()
            },
            beforeSend: function() {
                $('span#atload').show();
            },
            complete: function() {
                $('span#atload').hide();
            },
            success: function(response) {
                $(nam.parentElement).remove();
            }
        });

    });

    /* Quick Edit  */
    $('body').on('click', '#QuickUpdates', function(e) {
        e.preventDefault();

        if ($("#gnStatusEdit").val() == '16') {
        	var tags = [];
            tagsVal = $('#quickTags').val();
            tagsValArr = tagsVal.split(",");
            $.each(tagsValArr, function(key, val) {
                tags.push(val.trim());
            });
            tagArr = tags;
            if (($.inArray('Scheduled - Task', tagArr) != -1) || ($.inArray('Scheduled - Observation', tagArr) != -1)) {} else {
                $('#myAlert').slideDown('slow');
                $('#divErrorMsg').html("Please select the Tag, Scheduled-Task or Scheduled-Observation tag");
                return false;
            }
            if (($.inArray('Scheduled - Task', tagArr) != -1) && ($.inArray('Scheduled - Observation', tagArr) != -1)) {
                $('#myAlert').slideDown('slow');
                $('#divErrorMsg').html("Please select either 'Scheduled-Task' or 'Scheduled-Observation' ");
                return false;
            }
            var scheduleTimeOnClick = $('#upDateScheduledTime').val();
            var scheduledFalse = scheuledTimeValidation(scheduleTimeOnClick, currentPstTime);
            if (scheduledFalse == false) {
                return false;
            }
        }

        $.ajax({
            type: "POST",
            url: "/ticket/quickEdit/?_ajax=true",
            data: $('#quickUpdateForm').serialize(),
            beforeSend: function() {
                $('span#quickUpdateLoading').show();
                $('#QuickUpdates').attr('disabled', true);
                $('#myAlert').slideUp();
                $('#divErrorMsg').html('');
		        $('body').addClass('waiting');
                $.notification({
                    class: 'processing_notify',
                    notification: 'processing_notify',
                    autohide: true
                });
            },
            complete: function() {
                $('span#quickUpdateLoading').hide();
                $('#QuickUpdates').attr('disabled', false);
		$('body').removeClass('waiting');    
            },
            success: function(data) {
                if (data.Result == 1) {
                    $.notification({
                        class: 'success_notify',
                        notification: 'quickupdate_success',
                        time: 5000,
                        autohide: true
                    });
                    var statusname = $("#gnStatusEdit option:selected").text();
                    var priortyname = $("#quick_gnPriEdit option:selected").text();
                    $('#gnStatusEdit').selectpicker('val', data.tsId);
                    $("#statusname").text(statusname);
                    $("#priortyname").text(priortyname);

                    $('select[id=deptPost]').val(data.deptId);
                    $('#deptPost').selectpicker('refresh');

                    $('select[id=ownerPost]').val(data.osId);
                    $('#ownerPost').selectpicker('refresh');

                    $('select[id=statusPost]').val(data.tsId);
                    $('#statusPost').selectpicker('refresh');

                    $('select[id=priPost]').val(data.pId);
                    $('#lastUpdated').text(data.lastUpdated);
                    $('span#qTagId').text(data.incidenttags);
                    $('#priPost').selectpicker('refresh');
                    if (parseInt(data.tsId) == 16) {
                        var schDateTime1 = {
                            icons: {
                                time: "fa fa-clock-o",
                                date: 'fa fa-calendar',
                                up: 'fa fa-arrow-up',
                                down: 'fa fa-arrow-down',
                            },
                            minDate: '{{datePicker.yesDate}}',
                            defaultDate: data.schT,
                        }
                        $('input#gnschPost').datetimepicker(schDateTime1);
                        $("#gnschPost").data('DateTimePicker').setDate(data.schT);
                        $('#schStatus').show();
                        $('#tktInfo_scheduledTime').text(data.schT);
                    } else {
                        $('#schStatus').hide();
                    }
                } else {
                    $('#QuickUpdates').attr('disabled', false);
                    $.notification({
                        class: 'error_notify',
                        notification: 'quick_update_validation_failled',
                        time: 5000,
                        autohide: true,
	                    replaceKeys: {
	                        errorMsg: data.errorMessage
	                    }
                    });
                }
                slaResloution();
            },
            error: function() {
                $('#QuickUpdates').attr('disabled', false);
                $.notification({
                    class: 'error_notify',
                    notification: 'quickupdate_failled',
                    time: 5000,
                    autohide: true
                });
            }
        });
    });

    

    $('body').on('change', '#gnStatusEdit', function(e) {
        e.preventDefault();
        var val = $('#gnStatusEdit option:selected').val();
        if (val == 16) {
            $("tr#generalSchedule").show();
        } else {
            $("tr#generalSchedule").hide();
        }

    });

    $('body').on('click', '#showMatrix', function(e) {
        e.preventDefault();
        $('#matrixTable').show();
    });

    /* QuickLinks: For client or device Open tickets to be viewed in Slam page... */
    $('body').on('click', '#clientopentkts_btn, #deviceopentkts_btn', function() {
        var all = [];
        var template_name = '';
        var clientId = $(this).attr('data-cId');
        var deviceId = $(this).attr('data-dId');
        var cltid = $(this).attr('data-cltid');
        var active_status = active.split(",");
        var inactive_status = inactive.split(",");

        for (i = 0; i < active_status.length; i++)
            all.push(active_status[i]);

        for (i = 0; i < inactive_status.length; i++)
            all.push(inactive_status[i]);

        $('#template_hide input[name = "ticket-status"]').remove();
        $('#template_hide input[name = "selectedStatuses"]').remove();
        $('#template_hide input[name = "templatename"]').remove();
        $('#template_hide input[name = "statusType"]').remove();
        $('#template_hide input[name = "clients"]').remove();
        $('#template_hide input[name = "devices"]').remove();
        $('#template_hide input[name = "custom"]').remove();

        if (typeof clientId !== typeof undefined && clientId !== false) {
            template_name = "Client Open Tickets (" + ($(this).attr('data-cName')) + ")";
            $('#template_hide').append('<input type="text" name="clients" value="' + clientId + '">');
        } else if (typeof deviceId !== typeof undefined && deviceId !== false) {
            template_name = "Device Open Tickets (" + ($(this).attr('data-dName')) + ")";
            $('#template_hide').append('<input type="hidden" name="clients" value="' + cltid + '">');
            $('#template_hide').append('<input type="hidden" name="devices" value="' + deviceId + '">');
        }
        original = $('#slamform').html();
        for (i = 0; i < all.length; i++)
            $('#template_hide').append('<input id="st_typ" type="hidden" name="selectedStatuses" value="' + all[i] + '">');

        custom = ['SLA Resolution', 'Ticket Id', 'Priority', 'Department', 'Owner', 'Status', 'Created Date (PDT)', 'Subject', 'Requester', 'Last Update (PDT)', 'Time Worked (Min)', 'Partner Name', 'Client Name', 'Device Name'];
        for (i = 0; i < custom.length; i++)
            $('#template_hide').append('<input  type="hidden" name="custom" id="st_type" value="' + custom[i] + '">');

        $('#template_hide').append('<input id="st_typ" type=text name="ticket-status" value="active">');
        $('#template_hide').append('<input type="hidden" name="statusType" value="current">');
        $('#template_hide').append('<input type="hidden" name="templatename" value="' + template_name + '">');
        $('#template_hide').submit();
        $('#slamform').html(original);
    });

    /* QuickLink: For TICKET related ALERTS to be viewed in Slam page...  */
    $('body').on('click', '#showalerts', function() {
        var clientId = $(this).attr('data-cId');
        var incidentId = $(this).attr('data-incId');
        var ticketId = $(this).attr('data-tId');
        url = "/ticket/showAlertsData/?&tId=" + ticketId + "&cId=" + clientId + "&incId=" + incidentId;
        $.colorbox({
            href: url,
            width: '950px',
            height: '550px',
            iframe: true
        });
    });
    /* Custom Feature for CDI in partner level:: CDI support mail will be added to cc list whenever the status changed to WFCI/WFPI */
    $('body').on('change', '#statusPost', function() {
    	var status = $('#statusPost').val();
    	var maillist = '';
    	if(('mspId' == 109612 || 'mspId' == 590253) && (status == 9 || status == 46)){
    		if(typeof(existed_mails) != 'undefined' && existed_mails != ''){
    			if(existed_mails.includes(cdi_supportmail) == false){
    				maillist = existed_mails+" ,"+cdi_supportmail
    				$('#ccEmailId').tokenfield('setTokens', maillist);
    			}
    		}else{    			
    			$('#ccEmailId').tokenfield('setTokens', cdi_supportmail);
    		}
    	}/*else{  
    		$('#ccEmailId').tokenfield('setTokens', existed_mails);
    	}*/
    });
    /* removing this feature as per request*/
    /*Custom feature for one of the clients of the partner Alternative technology group :: 
     * Support mail should be added to cc list whenever the ticket was in Critical state*/
    /*$('body').on('change', '#priPost', function() {
    	var prioirty = $('#priPost').val();
    	var maillist = $('#ccEmailId').val();
    	if(clientId == 558536 && prioirty == 8){
    		if(typeof(existed_mails) != 'undefined' && existed_mails != ''){
    			if(existed_mails.includes(Electro_Switch_Corp_mail) == false){
    				maillist = existed_mails+" ,"+Electro_Switch_Corp_mail
    				$('#ccEmailId').tokenfield('setTokens', maillist);
    			}else{    			
        			$('#ccEmailId').tokenfield('setTokens', Electro_Switch_Corp_mail);
        		}
    		}
    	}else{
    		$('#ccEmailId').tokenfield('setTokens', existed_mails);
    	}
    });*/
    
});
var slaResloution = function() {
    $.ajax({
        type: 'POST',
        data: {
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val(),
            ticketId: $('#ticketIds').val()
        },
        url: '/ticket/slaResloutions',
        success: function(data) {
            $('span#resolutionSLA').text('SLA Resolution (' + data.sampleRes.resolutionSLA + ' ) ');
            $('span#responceSLA').text('SLA Response (' + data.sampleRes.responseTimeSLA + ' )');

            $('span#slamId').text(data.sampleRes.resolutionDueText);
            $('span#slamResponce').text(data.sampleRes.responseTimeDue);

            $('span#statusname').text(data.sampleRes.status);
            $('span#priortyname').text(data.sampleRes.prioritys);
	if (data.sampleRes.af > 0){
                $('span#robo_img').show();
            } else {
                $('span#robo_img').hide();
            }    
			setTimeout('slaResloution(true)', 180000);
        }
    });
};

$(window).bind("load", function(e) {
    e.preventDefault();
    watchUserTrack_update();
    postReplies(IncidentPostLimit, IncidentPostOffset,recentTime=0);
    esclationMatrix();
    resultsReview();   
    postreplyNotifications();
    slaResloution();
});

function postReplies(IncidentPostLimit, IncidentPostOffset,recentTime) {
    $('span#loadingPosts').show();
    
    $.ajax({
        type: "POST",
        url: "/ticket/postReplies/?_ajax=true",
        data: {
            limit: IncidentPostLimit,
            offset: IncidentPostOffset,
            ticketId: $('#ticketIds').val(),
            attDynamic: $('#attDynamic').val(),
            recentTime:recentTime,
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
        },
        success: function(data) {
        	
            html = '';
            count = 0;
            if (data != '') {
                if (data.stopPagination == 1) {
                    $('#post_scroll').hide();
                }
                $.each(data.postReplies, function(index, value) {
                    count = count + 1;
                    var content = value.content;
                    content.replace(/(\r\n|\n\r|\r|\n)/g, "<br>");
                    html += '<li class="comment">'
                    html += '<div>'
                    html += '<div class="comment-author">'
                    html += '<div id="userReply">'
                    html += '<div class="avatar-container">'
                    html += '<div class="' + value.clas + '"></div>'
                    html += '</div>'

                    html += '<div class="data-container">'
                    html += '<h5> '
                    html += '<a href="#" title="' + value.email + '"> ' + value.fName + ' </a>'
                    html += '<span class="date">' + value.dateLine + ' PST (' + value.days + ' ago)'+'<span id="tid_'+value.tId+'" style="display:none">'+value.utcTimeStampDateLine+'</span>'
                    html += '<a data-toggle="collapse" data-parent="#accordion" href="#comment1" class="collapse">'
                    html += '<i class="icon-large toggle-arrow"></i>'
                    html += '</a>'
                    html += '</span>'

                    html += '</h5>'
                    html += '<div style="background-color:#FFFFFF !important">'
                    html += '<div style="clear:both"></div>'
                    messageData = content.replace(/(\r\n|\n\r|\r|\n)/g, "<br>");
                    html += '<p>' + messageData + '</p>'

                    html += ''
                    if (value.attInfo != 'undefined') {
                        $.each(value.attInfo, function(key, val) {
                            html += '<div><span> <i class="attachment"></i></span><a class="attachment_text" id = "attDownload" attDownload_id = "' + val.attId + '" attDownload_name = "' + val.flName + '" href = "javascript:void(0)">' + val.flName + '</a></div>'
                        });
                    }
                    html += '</div>'

                    if (adminUser == 1) {
                        html += '<div class="comment-reply">'
                        html += '<div style="float:right;">'
                        html += '<button class="btn btn-success btn-sm buttons" id="postreView" data-toggle="tooltip" title="Review" style="float:right;" data-postid= ' + value.tpId + ' data-ticketId= ' + value.tId + '><i class="fa fa-star">&nbsp;&nbsp;Review on post</i></button>'
                        html += '</div>'
                    }
                    html += '<div id="reviewResults" data-ticketid=' + value.tId + ' data-postid=' + value.tpId + '>'
                    html += '</div>'

                    html += '<div class="auditlog_data" id="reviewInfo"   data-ticketid=' + value.tId + ' data-postid=' + value.tpId + '>'
                    html += '</div>'

                    html += '</div>'
                    html += '<div class="comment-reply">'
                    if (value.emailTo != "") {
                        html += 'Forwarded To: ' + value.emailTo + ',   E-mail: ' + value.email + ' '
                    } else {
                        html += 'E-mail: ' + value.email + ' '
                    }
                    html += '<div class="auditlog_date">&nbsp;&nbsp; <a class="btn btngrey btn-sm" > '
                    html += '<i class="fa fa-chain-broken"></i>'
                    html += '<span class="btnfont"></span> '
                    html += '</a> '
                    html += '</div> '
                    html += '<span class="auditlog_date">'
                    if (value.sTime != null) {
                        html += 'Time Spent: ' + value.sTime + ' Min(s),'
                    }
                    if (value.bTime != null) {
                        html += 'Billable Time: ' + value.bTime + ' Min(s)'
                    }

                    html += '</span> '
                    html += '</div>'
                    html += '</div>'
                    html += '</div>'
                    html += '<div style="clear:both;"></div>'
                    html += '</div>'

                    html += '</div>'
                    html += '</li>'
                    html += '<span style="display:none" id="repliesCount">none</span>'
                });
            } else  {
                $('#post_scroll').hide();
            }
            if (data.notifcation !='false'){
            	
            	if (html != ''){
            		
            		$('#postReplies').prepend(html);
            		$.notification({class:'info_notify', notification:'ticketPostNotification',time: 5000, autohide: true});
            		
            	}
            }else{
            	$('#postReplies').append(html);
            }
            
            $('span#loadingPosts').hide();
            var tpId = [];
            $.each(data.ticketPostId, function(index, value) {
                tpId.push(value);
            });
            var tpIds = tpId.join(',');
            if (tpIds == '') {
                $('span#repliesCount:last').text('none')
            }
            $('#repliesCount').text(data.countPReplies);
            ticketId = $('#ticketIds').val();
            ticketPostReviewData(tpIds, ticketId);
            isActive = false;
            scrollPagination(isActive, data.stopPagination);
        },
    });
}

function scrollPagination(isActive, stopPagination) {
    var isActive = false;
    $(window).scroll(function() {
        if (!isActive && $(window).scrollTop() == $(document).height() - $(window).height()) {
            isActive = true;
            rowcount = $('span#repliesCount:last').text();
            limit = 20;
            if (stopPagination != 1) {
                offset = $('div#userReply').length;
                postReplies(limit, offset,notifcation=false,recentTime=0);
            } else {}
        }
    });
}



function ticketPostReviewData(ticketPostId, ticketId) {
    var content = '';
    jQuery.ajax({
        type: 'POST',
        data: {
            tpIds: ticketPostId,
            ticketId: ticketId,
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
        },
        url: "/ticket/ticketPostDetails/?_ajax=true",
        success: function(html) {
            jQuery.each(html.ticketDetails, function(index, value) {
                content = "<span><strong>Review on Post: </strong></span>Process:<span class=\"rating\">";

                switch (value.proc_rating) {
                    case 1:
                        {
                            content += belowExpectation;
                            break;
                        }
                    case 2:
                        {
                            content += meetsExpectation;
                            break;
                        }
                    case 3:
                        {
                            content += exceedsExpection;
                            break;
                        }
                }
                content += "</span>, Communication:<span class=\"rating\">";
                switch (value.comm_rating) {
                    case 1:
                        {
                            content += belowExpectation;
                            break;
                        }
                    case 2:
                        {
                            content += meetsExpectation;
                            break;
                        }
                    case 3:
                        {
                            content += exceedsExpection;
                            break;
                        }
                }
                content += "</span>, Technical:<span class=\"rating\">";
                switch (value.tech_rating) {
                    case 1:
                        {
                            content += belowExpectation;
                            break;
                        }
                    case 2:
                        {
                            content += meetsExpectation;
                            break;
                        }
                    case 3:
                        {
                            content += exceedsExpection;
                            break;
                        }
                }
                content += "</span>, Time:<span class=\"rating\">";

                switch (value.time_rating) {
                    case 1:
                        {
                            content += belowExpectation;
                            break;
                        }
                    case 2:
                        {
                            content += meetsExpectation;
                            break;
                        }
                    case 3:
                        {
                            content += exceedsExpection;
                            break;
                        }
                }
                content += "</span>, Customer Value:<span class=\"rating\">";
                switch (value.customer_value_rating) {
                    case 1:
                        {
                            content += belowExpectation;
                            break;
                        }
                    case 2:
                        {
                            content += meetsExpectation;

                            break;
                        }
                    case 3:
                        {
                            content += exceedsExpection;
                            break;
                        }
                }
                content += "<span class=\"see_more\"><a href=\"javascript:void(0)\" id = \"reviewForPopst\" data-ticketid='" + value.ticket_id + "' data-postid='" + index + "'\"> See more...</a></span>";
                if (content != '') {
                    $('div#reviewResults[data-postid=\"' + index + '\"][data-ticketid=\"' + value.ticket_id + '\"]').html(content);
                }
            });
        }
    });

}

$('body').on('click', 'a#reviewForPopst', function() {
    ticketId = $(this).attr('data-ticketid');
    postid = $(this).attr('data-postid');
    url = "/ticket/urlGetReviewsForPost?&tktId=" + ticketId + "&tktPstId=" + postid;
    $.colorbox({
        href: url,
        width: '950px',
        height: '550px',
        iframe: true
    });
});

$('body').on('click', 'button#postreView', function() {
    ticketId = $(this).attr('data-ticketid');
    postId = $(this).attr('data-postid');
    $.ajax({
        type: "POST",
        url: "/ticket/ticketPostView/?_ajax=true",
        data: {
            ticketId: ticketId,
            postId: postId,
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
        },
        success: function(data) {
            $('div#reviewInfo[data-postid=\"' + postId + '\"][data-ticketid=\"' + ticketId + '\"]').html(data);
            $('button#postreView[data-postid=\"' + postId + '\"][data-ticketid=\"' + ticketId + '\"]').hide();
            $('div#reviewResults[data-postid=\"' + postId + '\"][data-ticketid=\"' + ticketId + '\"]').hide();
        }
    });
});

$('body').on('click', '#btnReviewSubmit', function(e) {
    postId = $(this).attr('data-postid');
    ticketId = $(this).attr('data-ticketid');
    formId = "post_reviews_form_" + postId + "_" + ticketId;
    $.ajax({
        type: 'POST',
        url: "/ticket/ticketPostSave/?_ajax=true",
        data: {
            postId: postId,
            ticketId: ticketId,
            'PostReviews_proc_rating': $("input[name=PostReviews_proc_rating]:checked").val(),
            'PostReviews_tech_rating': $("input[name=PostReviews_tech_rating]:checked").val(),
            'PostReviews_comm_rating': $("input[name=PostReviews_comm_rating]:checked").val(),
            'PostReviews_time_rating': $("input[name=PostReviews_time_rating]:checked").val(),
            'PostReviews_customer_value_rating': $("input[name=PostReviews_customer_value_rating]:checked").val(),
            'PostReviews_comments': $('#PostReviews_comments').val(),
            'PostReviews_review_time': $('#PostReviews_review_time').val(),
            'PostReviews_reviewMails': $('#reviewMails').val(),
            'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val(),
        },
        beforeSend: function() {
            $('#btnReviewSubmit').attr('disabled', true);
            $('span#loadingtktrvw').show();
        },
        complete: function() {
            $('#btnReviewSubmit').attr('disabled', false);
            $('span#loadingtktrvw').hide();

        },
        success: function(data) {
            html = (postId != '') ? '<hr style=\"border: none 0; border-top: 1px dashed #c2c2c2; height: 1px; margin: 2px 0 1px 0;\">' : '';
            if (data.status == 'Success') {
                $.notification({
                    class: 'success_notify',
                    notification: 'review_success',
                    time: 5000,
                    autohide: true
                });
                if (postId != '') {
                    $('div#reviewInfo[data-postid=\"' + postId + '\"][data-ticketid=\"' + ticketId + '\"]').html(html);
                    $('button#postreView[data-postid=\"' + postId + '\"][data-ticketid=\"' + ticketId + '\"]').show();
                    $('div#reviewResults[data-postid=\"' + postId + '\"][data-ticketid=\"' + ticketId + '\"]').show();
                    ticketPostReviewData(postId, ticketId);
                } else {

                }
            } else {
                $.notification({
                    class: 'error_notify',
                    notification: 'review_fail',
                    time: 5000,
                    autohide: true
                });
            }

        },
        error: function() {
            $.notification({
                class: 'error_notify',
                notification: 'review_fail',
                time: 5000,
                autohide: true
            });
        }
    });
});

$('body').on('click', '#btnReviewCancel', function() {
    postId = $(this).attr('data-postid');
    ticketId = $(this).attr('data-ticketid');
    $('div#reviewInfo[data-postid=\"' + postId + '\"][data-ticketid=\"' + ticketId + '\"]').html('');
    $('button#postreView[data-postid=\"' + postId + '\"][data-ticketid=\"' + ticketId + '\"]').show();
    $('div#reviewResults[data-postid=\"' + postId + '\"][data-ticketid=\"' + ticketId + '\"]').show();
});

function createTicketPost() {
    document.getElementById("crePostRep").disabled = true;
    var attachments = new Array();
    var qos = '';
    var qos_feedback = $('input[name=qos_feedback]:checked').val();
    var neinternal = 0;
    var emailtoclientsub = '';
    var emailToClient = 0;

    if (qos_feedback != 'undefined' && qos_feedback != '') {
        qos = qos_feedback;
    }

    for (i = 0; i < file_c; i++) {
        attachments.push($('#fobj_' + i).text());
    }
    if ($('#sendMail').is(":checked")) {
        var sendMail = 1
    } else {
        var sendMail = 0
    }
    if ($('#emailToClient').prop("checked")) {
        emailToClient = 1;
        emailtoclientsub = $('#postSub').val();
    } else {
        emailToClient = 0;
    }
    if ($('#Internal').data('clicked')) {
        neinternal = 1;
    }
    $.ajax({
        type: "POST",
        url: "/ticket/createPost/?_ajax=true",
        data: {
        	'mspId' : mspId,
        	'clientId' : clientId,
            'department': $('#deptPost').val(),
            'selectedPriority': $('#priPost').val(),
            'status': $('#statusPost').val(),
            'ownerPost': $('#ownerPost').val(),
            'toEmailId': $('#toEmailId').val(),
            'ccEmailId': $('#ccEmailId').val(),
            'attachments': attachments,
            'ticketId': ticketId,
            'emailToClient': emailToClient,
            'gnschPost': $('#gnschPost').val(),
            'tzone': $('#tzone').val(),
            'hmspReason': $('#hmspReason').val(),
            'hmspmisReason': $('#hmspmisReason').val(),
            'postSub': $('#postSub').val(),
            'tags': $('#postRepTags').val(),
            'ticketContent': CKEDITOR.instances['ticketContent'].getData(),
            'timeWorked': $('#timeWorked').val(),
            'billable': $('#billable').val(),
            'attDynamic': $('#attDynamic').val(),
            'sendMail': sendMail,
            'qos_feedback': qos,
            'neinternal': neinternal,
            'integrationcheck': $('input[name=integration_check]:checked').val(),
            'mailtoclientsub': emailtoclientsub,
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val(),
            'billableType': $('#billableType').val(),
            'workType': $('#workType').val(),
        },
        beforeSend: function() {
            $('span#postLoading').show();
	        $('body').addClass('waiting');
            $.notification({
                    class: 'processing_notify',
                    notification: 'processing_notify',
                    autohide: true
                });
        },
        complete: function() {
            $('span#postLoading').hide();
	        $('body').removeClass('waiting');
        },
        success: function(data) {
            if (data.resURL != '') {
                $('#divErrorMsg').html('');
                /* if(data.resMsg != ''){
                    $.notification({
                        class: 'warning_notify',
                        notification: 'updated_with_attachment_failed',
                        time: 5000,
                        autohide: true,
                        replaceKeys: {
                            errorMsg: data.resMsg
                        }
                    });
                }else{
                    $.notification({
                        class: 'success_notify',
                        notification: 'post_updated_successfully',
                        time: 5000,
                        autohide: true
                    });
                }*/
                document.getElementById("crePostRep").disabled = false;
                window.location.href = data.resURL;
            }else {
                $.notification({
                    class: 'error_notify',
                    notification: 'postreply_failled',
                    time: 5000,
                    autohide: true,
                    replaceKeys: {
                        errorMsg: data.resMsg
                    }
                });  
                document.getElementById("crePostRep").disabled = false;
              /*  window.location.href = "/ticket/view/"+ticketId; */
            } 
        },
        error: function(jqXHR, textStatus, errorThrown) {
            document.getElementById("crePostRep").disabled = false;
            var resMsg = jqXHR.status + ' - ' + errorThrown; /* ' : '+ jqXHR.responseText; */
            $.notification({
                class: 'error_notify',
                notification: 'postreply_failled',
                time: 5000,
                autohide: true,
                replaceKeys: {
                    errorMsg: resMsg
                }
            });            
        }
    });

}

$('body').on('click', '#attDownload', function() {
    url = "/ticket/downloadAttachment?" + "&attId=" + encodeURIComponent($(this).attr('attDownload_id')) + "&attDynamic=" + encodeURIComponent($('#attDynamic').val()) + "&attName=" + encodeURIComponent($(this).attr('attDownload_name'));
    open(url);
});

function esclationMatrix() {
    var clientIds = $('#clientId_matrix').val();
    var mspIds = $('#mspId_matrix').val();
    var diviceIds = $('#deviceId_matrix').val();
    var escHtml = ''
    var oldSchName = ''
        /*var globalLevel = innerLevel = finalLevel = 0 */
    $.ajax({
        type: "POST",
        data: {
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val(),
            mspId: mspIds,
            clientId: clientIds,
            diviceId: diviceIds,
        },
        url: "/ticket/esclation/?_ajax=true",
        success: function(EscalationInfo) {
            var scheduleCount = 0
            var users = 0
            if (!(jQuery.isEmptyObject(EscalationInfo.html))) {
                $.each(EscalationInfo.html, function(key, value) {
                    $.each(value, function(ind, newdata_escui) {
                        escName = '';
                        escHtml += 'Escalation Time Zone&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: ' + newdata_escui.tz_name;
                        escHtml += '<br>Escalation Current Time&nbsp;: ' + newdata_escui.ticktime;
                        escHtml += '<br>Escalation Current Day&nbsp;&nbsp;: ' + newdata_escui.tickday + '<br>';
                        if (key == 'device') {
                            escHtml += '<b>' + newdata_escui.Name + '</b><br><div class="pane collapsed">';
                            escHtml += newdata_escui.Description + ' | Device level Matrix';
                            escName = 'deviceArray';
                        } else if (key == 'devicegroup') {
                            escHtml += '<b>' + newdata_escui.Name + '</b><br><div class="pane collapsed">';
                            escHtml += newdata_escui.Description + ' | Device Group level Matrix ';
                            escName = 'devicegroupArray';
                        } else if (key == 'location') {
                            escHtml += '<b>' + newdata_escui.Name + '</b><br><div class="pane collapsed">';
                            escHtml += newdata_escui.Description + ' | Site level Matrix ';
                            escName = 'locationArray';
                        } else if (key == 'client') {
                            escHtml += '<b>' + newdata_escui.Name + '</b><br><div class="pane collapsed">';
                            escHtml += newdata_escui.Description + ' | Client level Matrix ';
                            escName = 'clientArray';
                        } else if (key == 'msp') {
                            escHtml += '<b>' + newdata_escui.Name + '</b><br><div class="pane collapsed">';
                            escHtml += newdata_escui.Description + ' | VAR level Matrix ';
                            escName = 'mspArray';
                        }
                        escHtml += '<span class="Matheader"><a href="javascript:void(0)"><i class=" fa fa-arrow-down toggle-arrow"></i></a></span><div class="Matcontent">'
                        var s = 1
                        $.each(newdata_escui, function(escInd, escTabRes) {
                            if (typeof escTabRes == 'object') {
                                $.each(escTabRes, function(ind, tableObjs) {
                                    if (typeof tableObjs == 'object') {
                                        schName = tableObjs.ScheduleName;
                                        globalMails = tableObjs[escName]
                                        escHtml += '<table class="table  table-bordered"><thead>'
                                        escHtml += '<tr><th>Level</th><th>Schedule Name</th><th>Shift Name</th><th>Days</th><th>Time</th><th>User</th><th>Email</th></tr></thead><tbody>'
                                        var shift = 1
                                        $.each(tableObjs, function(res, tableData) {
                                            if (typeof tableData == 'object') {
                                                if (tableData.inShift) {
                                                    escHtml += '<tr class="RowToClick shiftlevelbg">'
                                                } else {
                                                    escHtml += '<tr class="RowToClick">'
                                                }
                                                if (schName != oldSchName)
                                                    escHtml += '<td>' + s + '&nbsp;<input id="scheduleid' + scheduleCount + '" type="checkbox" value="' + globalMails + '" name="scheduleid' + scheduleCount + '" selected="" onclick="javascript:checkShiftAll(' + scheduleCount + ')"><span class="lbl padding-8"></span></td><td>' + schName + '</td>'
                                                else
                                                    escHtml += '<td colspan="2"></td>'
                                                oldSchName = tableObjs.ScheduleName;
                                                escHtml += '<td>' + tableData.ShiftName + '<a href="javascript:void(0)"><i class=" fa fa-arrow-down"></i></a></td><td>' + tableData.days + '</td><td>' + tableData.datetime + '</td><td>' + tableData.userDetails + '<br></td><td>' + tableData.emailDetails + '<br></td></tr>'
                                                var innerLevel = scheduleCount.toString() + shift.toString()
                                                escHtml += '<tr style="display: none;"><td colspan="2"></td><td colspan="5"><table class="table table-bordered"><thead><tr class="shiftlevelbg"><th><input type="checkbox" value = "' + tableData.shiftEmails + '" name="shiftall' + scheduleCount + '[]" selected="selected" id = "shiftall' + innerLevel + '" onclick="javascript:return checkAll(\'shift\',' + scheduleCount + ',' + shift + ')"><span class="lbl padding-8"></span></th>'
                                                escHtml += '<th>User</th><th>Email</th><th>Phone</th><th>Mobile</th><th>Time Zone</th></tr></thead><tbody>'
                                                $.each(tableData, function(userKey, userInfo) {
                                                    if (typeof userInfo == 'object') {
                                                        if (tableData.inShift) {
                                                            escHtml += '<tr class="shiftlevelbg">'
                                                        } else {
                                                            escHtml += '<tr>'
                                                        }
                                                        var finalLevel = scheduleCount.toString() + shift.toString()
                                                        escHtml += '<td><input type="checkbox" data-esc-single-contact = "true" id = "newesaEmail' + users + '" name="shift' + finalLevel + '[]" value = "' + userInfo.EMail + '" onclick="javascript:addEmailsTo(' + users + ')"><span class="lbl padding-8"></span></td><td>' + userInfo.User + '</td>'
                                                        escHtml += '<td>' + userInfo.EMail + '</td><td>' + userInfo.phone_number + '</td><td>' + userInfo.mobile_number + '</td><td>' + userInfo.time_zone + '</td></tr>'
                                                        users++
                                                    }
                                                });
                                                escHtml += '</tbody></table>'
                                                shift++
                                                schName = ''
                                                oldSchName = ''
                                            }
                                        });
                                        s++
                                        escHtml += '</td></tr></tbody></table>'
                                        scheduleCount++
                                    }
                                });
                            }
                        });
                        escHtml += '</div></div>'
                    });
                });
            } else {
                escHtml = '<table><tr><td colspan="20" align="center">No Matrices found</td></tr></table>'
            }
            $('#esc_matrix').html(escHtml);
            $(".pane .Matheader").click(function() {
                $(this).parent().toggleClass("collapsed");
            });
            $('.RowToClick').click(function() {
                $(this).nextAll('tr').each(function() {
                    if ($(this).is('.RowToClick')) {
                        return false;
                    }
                    $(this).toggle();
                });
            });
        },
    });
}
$(document).ready(function(){
    $('#rvwTkt').hide();
    if (adminUser == 1){
        $('#rvwTkt').show();
        $('body').on('click', '#rvwTkt', function() {
            ticketId = $('#ticketIds').val();
            url = "/ticket/ticketPostView?&ticketId=" + ticketId;
        $.colorbox({
            href: url,
            width: '950px',
            height: '550px',
            iframe: true
        });
        });
    }
}); 

function resultsReview() {
    ticketId = $('#ticketIds').val();
    $.ajax({
        type: "POST",
        url: "/ticket/ticketReviews/?&ticketId=" + ticketId,
        data: {
            ticketId: ticketId,
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
        },
        success: function(html) {
            if (html.ticketDetails.proc_rating != null) {
                content = "<span><a href=\"javascript:void(0)\" id = \"reviewForTicket\" data-ticketid='" + html.ticketDetails.ticket_id + "'> Process:<span class=\"rating\">";
                switch (html.ticketDetails.proc_rating) {
                    case 1:
                        {
                            content += belowExpectation;
                            break;
                        }
                    case 2:
                        {
                            content += meetsExpectation;
                            break;
                        }
                    case 3:
                        {
                            content += exceedsExpection;
                            break;
                        }
                }
                content += "</span>, Communication:<span class=\"rating\">";
                switch (html.ticketDetails.comm_rating) {
                    case 1:
                        {
                            content += belowExpectation;
                            break;
                        }
                    case 2:
                        {
                            content += meetsExpectation;
                            break;
                        }
                    case 3:
                        {
                            content += exceedsExpection;
                            break;
                        }
                }
                content += "</span>, Technical:<span class=\"rating\">";
                switch (html.ticketDetails.tech_rating) {
                    case 1:
                        {
                            content += belowExpectation;
                            break;
                        }
                    case 2:
                        {
                            content += meetsExpectation;
                            break;
                        }
                    case 3:
                        {
                            content += exceedsExpection;
                            break;
                        }
                }
                content += "</span>, Time:<span class=\"rating\">";

                switch (html.ticketDetails.time_rating) {
                    case 1:
                        {
                            content += belowExpectation;
                            break;
                        }
                    case 2:
                        {
                            content += meetsExpectation;
                            break;
                        }
                    case 3:
                        {
                            content += exceedsExpection;
                            break;
                        }
                }
                content += "</span>, Customer Value:<span class=\"rating\">";
                switch (html.ticketDetails.customer_value_rating) {
                    case 1:
                        {
                            content += belowExpectation;
                            break;
                        }
                    case 2:
                        {
                            content += meetsExpectation;

                            break;
                        }
                    case 3:
                        {
                            content += exceedsExpection;
                            break;
                        }
                }
                content += "</a></span>";
                if (content != '') {
                    $('#ticketReviewResults').html(content);
                }
            } else {
                content = '';
                $('#ticketReviewResults').html(content);
            }
        }
    });
}
$('body').on('click', 'a#reviewForTicket', function() {
    ticketId = $(this).attr('data-ticketid');
    url = "/ticket/urlGetReviewsForPost?&tktId=" + ticketId;
    $.colorbox({
        href: url,
        width: '950px',
        height: '550px',
        iframe: true
    });
});

$('body').on('click', 'button#TikId', function() {
    ticketId = $(this).attr('data-ticket');
    url = "/ticket/ticketEdit/?&tktId=" + ticketId;
    $.colorbox({
        href: url,
        width: '950px',
        height: '550px',
        iframe: true
    });
});



var useremailid = [];
var uuseremailid = [];

function addEmailsTo(userid) {
    var emailid = document.getElementById("newesaEmail" + userid).value,
        pos = -1,
        pos2 = -1;
    if (useremailid.length > 0) {
        pos = useremailid.indexOf(emailid);
    }
    if (!document.getElementById("newesaEmail" + userid).checked) { /*Remove the element */
        if (pos != -1) {
            useremailid.splice(pos, 1);
        }
        pos3 = useremailid.indexOf(emailid); /*Check again */
        if (pos3 == -1) {
            pos2 = uuseremailid.indexOf(emailid);
            if (pos2 != -1) {
                uuseremailid.splice(pos2, 1);
            }
        }
    } else { /*Add the element */
        useremailid.push(emailid);
        pos2 = uuseremailid.indexOf(emailid);
        if (pos2 == -1) {
            uuseremailid.push(emailid);
        }
    }
    $('#toEmailId').tokenfield('setTokens', []);
    for (z = 0; z < uuseremailid.length; z++) {
        $('#toEmailId').tokenfield('createToken', {
            value: uuseremailid[z]
        });
    }
}
var turn = [false];

function checkShiftAll(scheduleid) {
    var all2 = document.getElementsByName("shiftall" + scheduleid + "[]");
    var sn = all2.length;
    var shiftall;
    for (j = 0; j < sn; j++) {
        shiftall = all2[j];
        if (turn[scheduleid] == true) {
            if (shiftall.checked) shiftall.click();
            shiftall.checked = false;
        } else {
            if (!shiftall.checked) shiftall.click();
            shiftall.checked = true;
        }
    }
    if (turn[scheduleid] == true) {
        turn[scheduleid] = false;
    } else {
        turn[scheduleid] = true;
    }
    setToMailValues()
}

function checkAll(checktype, scheduleid, shiftid) {
    checktype = "";
    var all = document.getElementById("shiftall" + scheduleid + shiftid);
    shiftall = all;
    var group = document.getElementsByName("shift" + scheduleid + shiftid + "[]");
    var n = group.length;
    for (i = 0; i < n; i++) {
        if (shiftall.checked == true) {
            if (!group[i].checked) group[i].click();
            group[i].checked = true;
        } else {
            if (group[i].checked) group[i].click();
            group[i].checked = false;
        }
    }
    setToMailValues("shiftall" + scheduleid + shiftid);
}

function setToMailValues(reqId) {
    resEmails = new Array()
    $('input:checkbox[data-esc-single-contact="true"]:checked').each(function(i, v) {
        if ($.inArray($(this).val(), resEmails) == -1) {
            resEmails.push($(this).val());
        }
    });
    old = $('#toEmailId').tokenfield('getTokens');
    if (old) {
        oldEmail = []
        for (k = 0; k < old.length; k++) {
            oldEmail.push(old[k].value)
        }
        resEmails = union_arrays(resEmails, oldEmail)
    }
    $('#toEmailId').tokenfield('setTokens', []);
    $('#toEmailId').tokenfield('setTokens', resEmails);
}

function union_arrays(x, y) {
    var obj = {};
    for (var i = x.length - 1; i >= 0; --i)
        obj[x[i]] = x[i];
    for (var i = y.length - 1; i >= 0; --i)
        obj[y[i]] = y[i];
    var res = []
    for (var k in obj) {
        if (obj.hasOwnProperty(k)) /* <-- optional */
            res.push(obj[k]);
    }
    return res;
}


function scheuledTimeValidation(scheduleTimeOnClick, currentPstTime) {
	if(scheduleTimeOnClick == ''){
		$('#myAlert').slideDown('slow');
        $('#divErrorMsg').html("Please select the time");
        return false;
	}
    if (scheduleTimeOnClick < currentPstTime) {
        $('#myAlert').slideDown('slow');
        $('#divErrorMsg').html("Scheduled time should not be less then current date and time");
        return false;
    }
}

function watchUserTrack_update() {
    var startviewtime = new Date().getTime();
    var endTime = new Date().getTime();
    var timespent = endTime - startviewtime;
    var timespent_sec = new Date(timespent).getSeconds();
    var timespent_min = getTimeFromMilli(timespent);
    $.ajax({
        type: "POST",
        url: '/ticket/tktWatchingUsertrack',
        data: {
            'ticketid': ticketId,
            'userId': CurrentUserId,
            'userName': CurrentUserName,
            'timespent': timespent_min,
            'tkt_lastactivity': tkt_lastactivity,
            'csrfmiddlewaretoken': $('input[name=csrfmiddlewaretoken]').val()
        },
        success: function(response) {}
    });
}

function getTimeFromMilli(millisec) {
    var seconds = (millisec / 1000).toFixed(0);
    var minutes = Math.floor(seconds / 60);
    var hours = "";
    if (minutes > 59) {
        hours = Math.floor(minutes / 60);
        hours = (hours >= 10) ? hours : "0" + hours;
        minutes = minutes - (hours * 60);
        minutes = (minutes >= 10) ? minutes : "0" + minutes;
    }
    seconds = Math.floor(seconds % 60);
    seconds = (seconds >= 10) ? seconds : "0" + seconds;
    if (hours != "") {
        return hours + "h" + minutes + "m" + seconds + "s";
    }
    return minutes + "m" + seconds + "s";
}

function timerIncrement() {
    idleTime = idleTime + 1;
    if (idleTime > 9) { /* 10 minutes */
        clearInterval();
    }
}

function postreplyNotifications(){
	var recentTime = $('#tid_'+ticketId).text();
	if (recentTime >0){
		postReplies(0,0,recentTime);
	}
	setTimeout('postreplyNotifications();',30000);	
	
}
