/*
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
*/
$(document).ready(function(){ 
	var multiselectEnable = {
			maxHeight: 200,
			numberDisplayed: 1,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			includeFilterClearBtn: false,
	};

	$('body').on('click', 'a#hrefdt', function(){
		url = "/noiseDashboard/downloadTicketData?"+$('#ndform').serialize()+"&id="+$(this).attr("data-searchval")+"&data-source="+$(this).attr("data-source");
		open(url);
	});
	$('body').on('click', 'a#ticketedSubLine', function(){
        url = "/noiseDashboard/commonSubject?"+$('#ndform').serialize()+"&subId="+$(this).attr("data-id");
        $.colorbox({href:url,  width:'600px', height:'450px', iframe:true});   
    });
		
	$('#nocid').on('change',function(){
		$.ajax({
			type: "POST",
			url: "/noiseDashboard/nocAjax/",
			data: {
				'res_pat' : $('#nocid').val(),
				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
			},
			beforeSend: function (){
		       $('span#loadingNoc').show();
		       $('span#loadingClient').show();
		       },
		    complete: function(){
		       $('span#loadingNoc').hide();
		       $('span#loadingClient').hide();
		       },
			success: function(data){
				$('#partners').selectpicker('destroy');
			    $('#clients').selectpicker('destroy');
				var patData = new Array();
				var cliData = new Array();
				$.each(data.msps,function(key,val){
					patData.push("<option value = "+val.mspid+">"+val.mspname+"</option>");
				});
				$('#partners').html(patData);
				$.each(data.clients,function(key,val){
					cliData.push("<option value = "+val.mspclientid+">"+val.clientname+"</option>");
				});
				$('#clients').html(cliData);
				$('#partners').selectpicker(multiselectEnable);
				$('#clients').selectpicker(multiselectEnable);
			},
		});
	});
	
	$('#partners').on('change',function(){
		$.ajax({
			type: "POST",
			url: "/noiseDashboard/partnerAjax/",
			data: {
				'res_cli' : $('#partners').val(),
				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
			},
			beforeSend: function (){
		       $('span#loadingClient').show();
		       },
		    complete: function(){
		       $('span#loadingClient').hide();
		       },
			success: function(data){
				$('#clients').selectpicker('destroy');
				var datalist = new Array();
				$.each(data.clients,function(key,val){
					datalist.push("<option value = "+val.mspclientid+">"+val.clientname+"</option>");
				});
				$('#clients').html(datalist);
				$('#clients').selectpicker(multiselectEnable);
			},
		});
		
	});
	$("#btnRun").click(function(){
		var validation = true;
		var errorMessage = '';
        $('#loadingReports').show();
        var tdate = new Date($("#tdDate2").val());
        var fdate = new Date($("#fdDate2").val());
        if(tdate < fdate){
        	var validation = false;
        	errorMessage += "<li>Please select valid date range</li>";
        }
        if ($("#section-option").val() == null){
        	var validation = false;
        	errorMessage += "<li>Please select sections</li>";
        }
        if(validation){
        	$('#myAlert').hide();
	        var toDate = tdate.getFullYear()+'-'+(tdate.getMonth()+1)+'-'+tdate.getDate();
	        var fromDate = fdate.getFullYear()+'-'+(fdate.getMonth()+1)+'-'+fdate.getDate();
	        $.ajax({type: "POST",
	          url: "/noiseDashboard/noiseSubmit/",          
	          data: { toDate: toDate, fromDate: fromDate, nocid: $("#nocid").val(), partners: $("#partners").val(), clients: $("#clients").val(), departments: $("#departments").val(),section_option: $("#section-option").val(), csrfmiddlewaretoken : $("input[name=csrfmiddlewaretoken]").val()},
	          beforeSend: function (){
		       $('span#lodingRes').show();
		       },
		      complete: function(){
		       $('span#lodingRes').hide();
		       },
	          success:function(data){
	        	  $('#nosDevHide').show();
	        	  $('#nosCliHide').show();
	        	  $('#nosisuHide').show();
		          if(data.noiseDeviceData){
		        	  commonDeviceData(data.noiseDeviceData);
		          }
		          else{
		        	  $('#nosDevHide').hide();
		          }
	        	  if(data.noisyClientsData){
	        		  commonclientData(data.noisyClientsData);
	        	  }
	        	  else{
	        		  $('#nosCliHide').hide();
	        	  }
	        	  if(data.noisyticketedSubjectLineData){
	        		  commonSubjectData(data.noisyticketedSubjectLineData);
	        	  }
	        	  else{
	        		  $('#nosisuHide').hide();
	        	  }
		        },
	        });
        }
        else{
        	var errMsg = '<ul>'+errorMessage+'</ul>';
        	$('#myAlert').slideDown('slow');
        	$('#divErrorMsg').html(errMsg);
        	return false;
        }
	});
	$(window).bind('load',function(){
		selectOpt = [1,2,3];
		var today = new Date();
		var tDate = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
	    var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate() - 6);
		var lWeek = lastWeek.getFullYear()+'-'+(lastWeek.getMonth()+1)+'-'+lastWeek.getDate();
		$('#loadingReports').show();
        $.ajax({type: "POST",
          url: "/noiseDashboard/noiseSubmit/",
          data: { toDate: tDate , fromDate:lWeek,section_option: selectOpt , csrfmiddlewaretoken : $("input[name=csrfmiddlewaretoken]").val()},
          
          beforeSend: function (){
	       $('span#lodingRes').show();
	       },
		  complete: function(){
	       $('span#lodingRes').hide();
	       },

          success:function(data){
        	  $('#nosDevHide').show();
        	  $('#nosCliHide').show();
        	  $('#nosisuHide').show();
	          if(data.noiseDeviceData){
	        	  commonDeviceData(data.noiseDeviceData);
	          }
        	  if(data.noisyClientsData){
        		  commonclientData(data.noisyClientsData);
        	  }
        	  if(data.noisyticketedSubjectLineData){
        		  commonSubjectData(data.noisyticketedSubjectLineData);
        	  }
	        },
        });
	});
	
});
function commonDeviceData(noiseDeviceData){
	 var nosDeviceData;
	 if(noiseDeviceData == 0){
		  nosDeviceData = '<tr><td></td><td></td><td> No records found </td></tr>';
	  }
	  else{
		  $.each(noiseDeviceData,function(key,val){
				nosDeviceData += '<tr>';
				nosDeviceData +='<td>'+val.msp+'</td>';
				nosDeviceData +='<td>'+val.client+'</td>';
				nosDeviceData +='<td>'+val.device_name+'</td>';
				if (val.devicetype)
					nosDeviceData +='<td>'+val.devicetype+'</td>';
				else
					nosDeviceData +='<td>None</td>';
				nosDeviceData += '<td><a href="javascript:void(0)" id="hrefdt" data-source = "Devices" data-searchval= "'+val.device_id+'"><strong>'+val.count+'</strong></a></td>';
				nosDeviceData += '</tr>';
         });
	  }
	  $('#nosDevData').html(nosDeviceData);
}
function commonclientData(noisyClientsData){
	var nosClientsData;
	if(noisyClientsData == 0){
		  nosClientsData = '<tr><td></td><td><center> No records found </center></td></tr>';
	  }
	  else {
		  $.each(noisyClientsData,function(key,val){
      	  nosClientsData += '<tr>';
      	  nosClientsData +='<td>'+val.msp+'</td>';
      	  nosClientsData +='<td>'+val.client+'</td>';
      	  nosClientsData += '<td><a href="javascript:void(0)" id="hrefdt" data-source = "Clients" data-searchval= "'+val.clientid+'"><strong>'+val.count+'</strong></a></td>';
      	  nosClientsData += '</tr>';
        });
	  }
	  $('#nosCliData').html(nosClientsData);
}
function commonSubjectData(noisyticketedSubjectLineData){
	var nosticketedSubjectLineData;
	if(noisyticketedSubjectLineData == 0){
		  nosticketedSubjectLineData = '<tr><td></td><td> No records found </td></tr>';
	  }
	  else{
		  $.each(noisyticketedSubjectLineData,function(key,val){
      	  nosticketedSubjectLineData += '<tr>';
      	  nosticketedSubjectLineData +='<td>'+val.subjectinfo+'</td>';
      	  nosticketedSubjectLineData+='<td><a section="Top 20 Issues" data-id ="'+val.subjectinfo+'" id="ticketedSubLine" href="javascript:void(0)"><strong>'+val.totaltickets+'</strong></a></td>';
      	  nosticketedSubjectLineData += '</tr>';
        });
	  }
	  $('#nosIsuData').html(nosticketedSubjectLineData);
}