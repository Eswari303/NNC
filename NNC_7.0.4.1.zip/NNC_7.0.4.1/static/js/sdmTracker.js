/* * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
*/
var table;
var dataTableOptions = {
						'destroy': true,
						'paging': false,
					    'info': false,
					    "bFilter": false,
					    "aoColumns": [
					                  	{ "bSortable": false },
					                  	null
									],
					    "order": [[ 1, "desc" ]]
					};

$(document).ready(function() {
//Add partners color box
$('body').on('click', '#sdmtAddPartners', function(){
	url = "/SDMTracker/addPartners/";
	$.colorbox({href:url, width:'900px', height:'500px', iframe:true});
});

//Edit partner details on main page
$('body').on('click', '#patEdit', function(){
	var partnerId =  $("#partnerSummary").attr('data-id');
	url = "/SDMTracker/editPartners/?&pId="+partnerId;
	$.colorbox({href:url, width:'900px', height:'500px', iframe:true});
});

//Load forms on Partners change
$('#sdmPartners').on('change',function(){
	partnerId = $('#sdmPartners').val();
	partnersInfo(partnerId);
});

//Add week to weekly summary for particular partner
$('body').on('click', 'span#addWeek', function(){
	clientId = $(this).attr('data-cid');
	mspId = $("#clientName").attr('data-mspid');
	url = "/SDMTracker/addWeekPatSummary/?&cliId="+clientId+"&mspId="+mspId;
	$.colorbox({href:url, width:'900px', height:'450px', iframe:true});
});

//Edit week details in weekly summary
$('body').on('click', 'span#editWeek', function(){
	inputString = $(this).attr('data-cid');
	tmp = inputString.split(";");
	mspId = $("#clientName").attr('data-mspid');
	mspId = $("#clientName").attr('data-mspid');
	url = "/SDMTracker/addWeekPatSummary/?&cliId="+tmp[0]+"&mspId="+mspId+"&tmp="+tmp;
	$.colorbox({href:url, width:'900px', height:'450px', iframe:true});
});

// 1 Escalation tracker form loading
$('body').on('click', '#engEscTracker', function(){
	mspId = parent.$("span#engEscTrackerPId").text();
	frmId = $(this).attr('data-formId');
	url = "/SDMTracker/escalationTrackerResults/?&mspId="+mspId+"&frmId="+frmId;
	$.colorbox({href:url, width:'1100px', height:'600px', iframe:true});
});

// 1 Escalation tracker edit record
$('body').on('click', 'a#eetEditRecord', function(){
	mspId = parent.$("span#engEscTrackerPId").text();
	esctId = $(this).attr('data-escId');
	editId = 'editRecEet';
	url = "/SDMTracker/escalationTrackerResults/?&mspId="+mspId+"&escId="+esctId+"&editId="+editId;
	$.colorbox({href:url, width:'1100px', height:'600px', iframe:true});
});

// 2 Key engagements contacts Form loading
$('body').on('click', 'button#contactsSDM', function(){
	mspId = parent.$("span#contResId").text();
	frmId = $(this).attr('data-formId');
	url = "/SDMTracker/contactsResults/?&mspId="+mspId+"&frmId="+frmId;
	$.colorbox({href:url, width:'900px', height:'600px', iframe:true});
});

// 2 Key engagements contacts edit record
$('body').on('click', 'a#kecEditRecord', function(){
	mspId = parent.$("span#contResId").text();
	kecnId = $(this).attr('data-kecId');
	editId = 'editRecKec';
	url = "/SDMTracker/contactsResults/?&mspId="+mspId+"&kecnId="+kecnId+"&editId="+editId;
	$.colorbox({href:url, width:'900px', height:'600px', iframe:true});
});

// 3 Value adds Form loading
$('body').on('click', 'button#valAdds', function(){
	mspId = parent.$("span#vafPId").text();
	frmId = $(this).attr('data-formId');
	url = "/SDMTracker/valueAddsResults/?&mspId="+mspId+"&frmId="+frmId;
	$.colorbox({href:url, width:'900px', height:'580px', iframe:true});
});

// 3 Value adds edit record
$('body').on('click', 'a#vafEditRecord', function(){
	mspId = parent.$("span#vafPId").text();
	vafId = $(this).attr('data-vafId');
	editId = 'editVafKec';
	url = "/SDMTracker/valueAddsResults/?&mspId="+mspId+"&vafId="+vafId+"&editId="+editId;
	$.colorbox({href:url, width:'900px', height:'580px', iframe:true});
});

// 4 Planned Value Adds Form loading
$('body').on('click', 'button#plannedValAdds', function(){
	mspId = parent.$("span#pvaPId").text();
	frmId = $(this).attr('data-formId');
	url = "/SDMTracker/plannedValueAddsResults/?&mspId="+mspId+"&frmId="+frmId;
	$.colorbox({href:url, width:'900px', height:'600px', iframe:true});
});

// 4 Planned Value Adds edit record
$('body').on('click', 'a#pvaEditRecord', function(){
	mspId = parent.$("span#pvaPId").text();
	pvaId = $(this).attr('data-pvaId');
	editId = 'editPvaKec';
	url = "/SDMTracker/plannedValueAddsResults/?&mspId="+mspId+"&pvaId="+pvaId+"&editId="+editId;
	$.colorbox({href:url, width:'1100px', height:'600px', iframe:true});
});

// 5 Action Items Tracker Form loading
$('body').on('click', 'button#aitkrForm', function(){
	mspId = parent.$("span#aitPId").text();
	frmId = $(this).attr('data-formId');
	url = "/SDMTracker/actionItemsTrackerResults/?&mspId="+mspId+"&frmId="+frmId;
	$.colorbox({href:url, width:'900px', height:'540px', iframe:true});
});

// 5 Action Items Tracker edit record
$('body').on('click', 'a#aitEditRecord', function(){
	mspId = parent.$("span#aitPId").text();
	aitId = $(this).attr('data-aitId');
	editId = 'editAifRec';
	url = "/SDMTracker/actionItemsTrackerResults/?&mspId="+mspId+"&aitId="+aitId+"&editId="+editId;
	$.colorbox({href:url, width:'900px', height:'540px', iframe:true});
});

// 6 Pipeline Form loading
$('body').on('click', 'button#pipeLine', function(){
	mspId = parent.$("span#PplPId").text();
	frmId = $(this).attr('data-formId');
	url = "/SDMTracker/pipelineResults/?&mspId="+mspId+"&frmId="+frmId;
	$.colorbox({href:url, width:'900px', height:'580px', iframe:true});
});

// 6 Pipeline edit record
$('body').on('click', 'a#pplEditRecord', function(){
	mspId = parent.$("span#pplPId").text();
	pplId = $(this).attr('data-pplId');
	editId = 'editVafKec';
	url = "/SDMTracker/pipelineResults/?&mspId="+mspId+"&pplId="+pplId+"&editId="+editId;
	$.colorbox({href:url, width:'900px', height:'580px', iframe:true});
});

// 7 Cancellation Details Form loading
$('body').on('click', 'button#cancellationDetails', function(){
	mspId = parent.$("span#canPId").text();
	frmId = $(this).attr('data-formId');
	url = "/SDMTracker/cancellationDetResults/?&mspId="+mspId+"&frmId="+frmId;
	$.colorbox({href:url, width:'900px', height:'500px', iframe:true});
});

// 7 Cancellation Details edit record
$('body').on('click', 'a#canEditRecord', function(){
	mspId = parent.$("span#canPId").text();
	canId = $(this).attr('data-canId');
	editId = 'editCanKec';
	url = "/SDMTracker/cancellationDetResults/?&mspId="+mspId+"&canId="+canId+"&editId="+editId;
	$.colorbox({href:url, width:'900px', height:'500px', iframe:true});
});

// 8 Potential Cancellation Details loading
$('body').on('click', 'button#potCancellationDetails', function(){
	mspId = parent.$("span#ptcPId").text();
	frmId = $(this).attr('data-formId');
	url = "/SDMTracker/potCancelDetResults/?&mspId="+mspId+"&frmId="+frmId;
	$.colorbox({href:url, width:'900px', height:'500px', iframe:true});
});

// 8 Potential Cancellation Details edit record
$('body').on('click', 'a#ptcEditRecord', function(){
	mspId = parent.$("span#ptcPId").text();
	ptcId = $(this).attr('data-ptcId');
	editId = 'editPtcKec';
	url = "/SDMTracker/potCancelDetResults/?&mspId="+mspId+"&ptcId="+ptcId+"&editId="+editId;
	$.colorbox({href:url, width:'900px', height:'500px', iframe:true});
});

// 9 Commitments Tracker Form loading
$('body').on('click', 'button#commTracker', function(){
	mspId = parent.$("span#cmtPId").text();
	frmId = $(this).attr('data-formId');
	url = "/SDMTracker/commTrackerResults/?&mspId="+mspId+"&frmId="+frmId;
	$.colorbox({href:url, width:'900px', height:'600px', iframe:true});
});

// 9 Commitments Tracker edit record
$('body').on('click', 'a#cmtEditRecord', function(){
	mspId = parent.$("span#cmtPId").text();
	cmtId = $(this).attr('data-cmtId');
	editId = 'editCmtKec';
	url = "/SDMTracker/commTrackerResults/?&mspId="+mspId+"&cmtId="+cmtId+"&editId="+editId;
	$.colorbox({href:url, width:'1100px', height:'600px', iframe:true});
});

// 10 Review Tracker Form loading
$('body').on('click', 'button#reviewTracker', function(){
	mspId = parent.$("span#rvtPId").text();
	frmId = $(this).attr('data-formId');
	url = "/SDMTracker/reviewTrackerResults/?&mspId="+mspId+"&frmId="+frmId;
	$.colorbox({href:url, width:'800px', height:'500px', iframe:true});
});

// 10 Review Tracker edit record
$('body').on('click', 'a#rvtEditRecord', function(){
	mspId = parent.$("span#rvtPId").text();
	rvtId = $(this).attr('data-rvtId');
	editId = 'editRvtKec';
	url = "/SDMTracker/reviewTrackerResults/?&mspId="+mspId+"&rvtId="+rvtId+"&editId="+editId;
	$.colorbox({href:url, width:'800px', height:'500px', iframe:true});
});

// 11 Weekly Touch Point tracker Form loading
$('body').on('click', 'button#weekTouchptTracker', function(){
	mspId = parent.$("span#wtpPId").text();
	frmId = $(this).attr('data-formId');
	url = "/SDMTracker/weeklyTchPntTrkrResults/?&mspId="+mspId+"&frmId="+frmId;
	$.colorbox({href:url, width:'900px', height:'440px', iframe:true});
});

// 11 Weekly Touch Point tracker edit record
$('body').on('click', 'a#wtpEditRecord', function(){
	mspId = parent.$("span#wtpPId").text();
	wtpId = $(this).attr('data-wtpId');
	editId = 'editWtpKec';
	url = "/SDMTracker/weeklyTchPntTrkrResults/?&mspId="+mspId+"&wtpId="+wtpId+"&editId="+editId;
	$.colorbox({href:url, width:'900px', height:'440px', iframe:true});
});

//00 Partner Dashboard Form loading
$('body').on('click', 'button#partnerDashboard', function(){
	mspId = parent.$("span#plsPId").text();
	frmId = $(this).attr('data-formId');
	url = "/SDMTracker/patnerLevelSummary/?&mspId="+mspId+"&frmId="+frmId;
	$.colorbox({href:url, width:'900px', height:'600px', iframe:true});
});

// 00 Partner Dashboard edit record
$('body').on('click', 'a#plsEditRecord', function(){
	mspId = parent.$("span#plsPId").text();
	wtpId = $(this).attr('data-wtpId');
	editId = 'editPlsKec';
	url = "/SDMTracker/patnerLevelSummary/?&mspId="+mspId+"&wtpId="+wtpId+"&editId="+editId;
	$.colorbox({href:url, width:'1100px', height:'600px', iframe:true});
});



//Refresh button on Main page for refreshing last updated dates
$('body').on('click', 'a#refPatDetails', function(){
	partnerId = $('#sdmPartners').val(); //Value which is already selected in partners dropdown on main page left panel
	partnersInfo(partnerId);
});


	partnerId = $('#sdmPartners').val(); //Value which is already selected in partners dropdown on main page left panel
	if(partnerId != '' || partnerId != undefined){
		partnersInfo(partnerId);
	}
});

//To refresh Partner details on Main page
function partnersInfo(patId){
	$.ajax({
		type: 'POST',
		url: "/SDMTracker/showPartners/?_ajax=true",
		data:{
			'patId' : patId,
			csrfmiddlewaretoken : $("input[name=csrfmiddlewaretoken]").val(),
		},
		beforeSend: function (){
        		$('span#loadingMspData').show();    
        		$('a#refPatDetails').hide();
		},
		complete: function(){
				$('span#loadingMspData').hide();
				$('a#refPatDetails').show();
		},
		success:function(data){
			if(data.partnerDetails != undefined){
				$("#sdmPartnerDetails").show();
				//	counts of breach inata-id=p1unasgt 60 mins
				$("a[id=patNameLP]").html(data.partnerDetails.msp_name);
				$("a[id=accMngrNameLP]").html(data.partnerDetails.acc_mngr);
				$("a[id=accMngrEmailLP]").html(data.partnerDetails.acc_mngr_email);
				$("#accMngrPhoneLP").html(data.partnerDetails.acc_mngr_phone);
				$("#accMngrAddrLP").html(data.partnerDetails.acc_mngr_address);
				
				//Display Right panel
				$("#sdmPatRightPanel").show('slow');
				
				//Links for Forms 
				html0 = '<a id="patnerSummary" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/patnerLevelSummary/?&partnerId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Weekly Summary</a>'
				html = '<a id="partnerSummary" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/partnerSummary/?&patId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Partner Summary</a>'
				html1 = '<a id="escTracker" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/escalationTrackerResults/?&partnerId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Escalation Tracker</a>'
				html2 = '<a id="contactsSdm" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/contactsResults/?&partnerId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Key Engagement Contacts</a>'
				html3 = '<a id="valAdds" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/valueAddsResults/?&partnerId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Value Adds</a>'
				html4 = '<a id="plannedValAdds" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/plannedValueAddsResults/?&partnerId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Planned Value Adds</a>'
				html5 = '<a id="actionItemsTracker" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/actionItemsTrackerResults/?&partnerId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Action Items Tracker</a>'
				html6 = '<a id="pipeLine" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/pipelineResults/?&partnerId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Pipeline</a>'
				html7 = '<a id="cancellationDetails" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/cancellationDetResults/?&partnerId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Cancellation Details</a>'
				html8 = '<a id="potCancellationDetails" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/potCancelDetResults/?&partnerId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Potential Cancellation Details</a>'
				html9 = '<a id="commTracker" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/commTrackerResults/?&partnerId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Commitments Tracker</a>'
				html10 = '<a id="reviewTracker" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/reviewTrackerResults/?&partnerId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Review Tracker</a>'
				html11 = '<a id="weekTouchptTracker" data-id="'+data.partnerDetails.msp_id+'" href="/SDMTracker/weeklyTchPntTrkrResults/?&partnerId='+data.partnerDetails.msp_id+'" target="_blank"><i class="icon-key"></i>Weekly Touch Point tracker</a>'
				
				//Links for SDM tracker forms
				$("td[id=patnerSummary]").html(html0);
				$("td[id=patSummary]").html(html);
				$("td[id=escTrackerLink]").html(html1);
				$("td[id=contactsSdmLink]").html(html2);
				$("td[id=valAddsSdmLink]").html(html3);
				$("td[id=plannedValAddsSdmLink]").html(html4);
				$("td[id=actionItemsTkrSdmLink]").html(html5);
				$("td[id=pipeLineSdmLink]").html(html6);
				$("td[id=canDetailsSdmLink]").html(html7);
				$("td[id=potCanDetailsSdmLink]").html(html8);
				$("td[id=commTkrSdmLink]").html(html9);
				$("td[id=reviewTkrSdmLink]").html(html10);
				$("td[id=weekTouchptTrackerSdmLink]").html(html11);
				
				//Partner details for Weekly summary page
				$("span[id=patNameRP]").html(data.partnerDetails.msp_name);
				$("span[id=accMngrNameRP]").html(data.partnerDetails.acc_mngr);
				$("span[id=mspID]").html(data.partnerDetails.msp_id);

				$('#sdmPartners').selectpicker('val', data.partnerDetails.msp_id);
				$("span[id=patSumLastUpdtd], span[id=patnerSumLastUpdtd], span[id=escTrackerUpdtd], span[id=contactsUpdtd], span[id=valAddsUpdtd], span[id=plannedValAddsUpdtd], span[id=actionItemsTkrUpdtd], span[id=pipeLineUpdtd], span[id=canDetailsUpdtd], span[id=potCanDetailsUpdtd], span[id=commTkrUpdtd], span[id=reviewTkrUpdtd], span[id=weekTouchptTrackerUpdtd]").html('');
				//Last updated date on main page
				if(data.lasUpdtdDetails.lastModfd != '' || data.lasUpdtdDetails.lastModfd != undefined){
					$("td[id=patSumLastUpdtd]").html(data.lasUpdtdDetails.lastModfd);
				}
				if(data.lasUpdtdDetails.plsLastModfd != ''  || data.lasUpdtdDetails.plsLastModfd != undefined){
					$("td[id=patnerSumLastUpdtd]").html(data.lasUpdtdDetails.plsLastModfd);
				}
				if(data.lasUpdtdDetails.escLastModfd != ''  || data.lasUpdtdDetails.escLastModfd != undefined){
					$("td[id=escTrackerUpdtd]").html(data.lasUpdtdDetails.escLastModfd);
				}
				if(data.lasUpdtdDetails.kecLastModfd != ''  || data.lasUpdtdDetails.kecLastModfd != undefined){
					$("td[id=contactsUpdtd]").html(data.lasUpdtdDetails.kecLastModfd);
				}
				if(data.lasUpdtdDetails.valLastModfd != ''  || data.lasUpdtdDetails.valLastModfd != undefined){
					$("td[id=valAddsUpdtd]").html(data.lasUpdtdDetails.valLastModfd);
				}
				if(data.lasUpdtdDetails.pvaLastModfd != ''  || data.lasUpdtdDetails.pvaLastModfd != undefined){
					$("td[id=plannedValAddsUpdtd]").html(data.lasUpdtdDetails.pvaLastModfd);
				}
				if(data.lasUpdtdDetails.aitLastModfd != ''  || data.lasUpdtdDetails.aitLastModfd != undefined){
					$("td[id=actionItemsTkrUpdtd]").html(data.lasUpdtdDetails.aitLastModfd);
				}
				if(data.lasUpdtdDetails.pplLastModfd != ''  || data.lasUpdtdDetails.pplLastModfd != undefined){
					$("td[id=pipeLineUpdtd]").html(data.lasUpdtdDetails.pplLastModfd);
				}
				if(data.lasUpdtdDetails.canLastModfd != ''  || data.lasUpdtdDetails.canLastModfd != undefined){
					$("td[id=canDetailsUpdtd]").html(data.lasUpdtdDetails.canLastModfd);
				}
				if(data.lasUpdtdDetails.pcaLastModfd != ''  || data.lasUpdtdDetails.pcaLastModfd != undefined){
					$("td[id=potCanDetailsUpdtd]").html(data.lasUpdtdDetails.pcaLastModfd);
				}
				if(data.lasUpdtdDetails.comLastModfd != ''  || data.lasUpdtdDetails.comLastModfd != undefined){
					$("td[id=commTkrUpdtd]").html(data.lasUpdtdDetails.comLastModfd);
				}
				if(data.lasUpdtdDetails.rvwLastModfd != ''  || data.lasUpdtdDetails.rvwLastModfd != undefined){
					$("td[id=reviewTkrUpdtd]").html(data.lasUpdtdDetails.rvwLastModfd);
				}
				if(data.lasUpdtdDetails.wtpLastModfd != ''  || data.lasUpdtdDetails.wtpLastModfd != undefined){
					$("td[id=weekTouchptTrackerUpdtd]").html(data.lasUpdtdDetails.wtpLastModfd);
				}
				
				table = $('#dataTable').DataTable(dataTableOptions);
			}
		},
	}); 
}