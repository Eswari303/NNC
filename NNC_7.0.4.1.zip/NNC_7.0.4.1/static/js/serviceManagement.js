/* * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 *
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 */
var loading = $('#loadingDept1').html();
var errorMsgs = '';
$('[data-toggle="tooltip"]').tooltip();
$(window).bind('load', function() {
    deptCount();
    deptNocCount();
    /*deviceCount();*/
});

function applyTooltipForTree(obj) {
    treeText = obj.text();
    treeText = treeText.replace(/[0-9]/g, "");
    obj.attr('data-title', treeText);
    obj.attr('data-toggle', 'tooltip');
    $('[data-toggle="tooltip"]').tooltip();
}

$('#btnSubmit').click(function(e) {
    e.preventDefault();
    validationStatus = formValidations();
    if (validationStatus == true) {
        $.ajax({
            url: '/serviceManagement/saveOrUpdTmp/',
            type: 'post',
            data: $('#template0').serialize(),
            beforeSend: function() {
                $('span#load_template').show();
            },
            complete: function() {
                $('span#load_template').hide();
                $.ajax({
                    url: "/serviceManagement/TemplateList/",
                    type: 'post',
                    data: {
                        'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
                    },
                    beforeSend: function() {
                        $('span#load_template').show();
                    },
                    complete: function() {
                        $('span#load_template').hide();
                    },
                    success: function(data) {
                        $('#tab_5').html(data);
                    }
                });
            },
            success: function() {
                $.notification({
                    class: 'success_notify',
                    notification: 'template_saved_successfully',
                    time: 5000,
                    autohide: true,
                    replaceKeys: {
                        TEMPLATE_NAME: $('#templateName1').val()
                    }
                });
            },
            error: function() {
                $.notification({
                    class: 'error_notify',
                    notification: 'error_template_not_saved',
                    time: 5000,
                    autohide: true,
                    replaceKeys: {
                        TEMPLATE_NAME: $('#templateName1').val()
                    }
                });
            }
        });
    }
});
$('#btnUpdate').click(function(e) {
    e.preventDefault();
    validationStatus = formValidationupdate();
    if (validationStatus == true) {
        $.ajax({
            url: '/serviceManagement/saveOrUpdTmp/',
            type: 'post',
            data: $('#template0').serialize(),
            beforeSend: function() {
                $('span#load_template').show();
            },
            complete: function() {
                $('span#load_template').hide();
                $.ajax({
                    url: "/serviceManagement/TemplateList/",
                    type: 'post',
                    data: {
                        'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
                    },
                    beforeSend: function() {
                        $('span#load_template').show();
                    },
                    complete: function() {
                        $('span#load_template').hide();
                    },
                    success: function(data) {
                        $('#tab_5').html(data);
                    }
                });

            },
            success: function() {
                $.notification({
                    class: 'success_notify',
                    notification: 'template_updated_successfully',
                    time: 5000,
                    autohide: true,
                    replaceKeys: {
                        TEMPLATE_NAME: $('#templateName1').val()
                    }
                });
            },
            error: function() {
                $.notification({
                    class: 'error_notify',
                    notification: 'error_template_not_saved',
                    time: 5000,
                    autohide: true,
                    replaceKeys: {
                        TEMPLATE_NAME: $('#templateName1').val()
                    }
                });
            }
        });
    }
});

var multiselectEnable = {
    maxHeight: 200,
    numberDisplayed: 1,
    enableFiltering: true,
    enableCaseInsensitiveFiltering: true,
    includeFilterClearBtn: false,
};
$(document).ready(function() {
    /*Reset template filters on page refresh. */
    $("#template0")[0].reset();

    var is_tb_admin = $("#tbAdmin").val();
    $("input#dateselection_0").prop('checked', true);
    $('#date').hide();
    $('#others').hide();
    $('#days').show();

    if (is_tb_admin == 1) {
        $("#public").show();
        $("#private").show();
        $("#btnSubmit").show();
        $("#btnUpdate").hide();
        $("#templatType_1").prop('checked', true);
    } else {
        $("#public").hide();
        $("#private").show();
        $("#btnSubmit").show();
        $("#btnUpdate").hide();
        $("#templatType_1").prop('checked', true);
    }
    $('#channel, #noc, #partners, #clients, #departments, #ticketType, #staff, #serviceType, #serviceLevel, #devices, #deviceType, #resSla, #customColumns1').selectpicker('deselectAll');
    /*Quick option for showing all schedule templates */
    $('body').on('click', '#scheduleTmp', function() {
        url = "/serviceManagement/showSchTemp/"
        $.colorbox({
            href: url,
            width: '1000px',
            height: '600px',
            iframe: true
        });
    });
    /* Option for showing all schedule templates */

    $('body').on('click', '#loadSchedule', function() {
        url = "/serviceManagement/showSchTemp/"
        $.colorbox({
            href: url,
            width: '1000px',
            height: '600px',
            iframe: true
        });
    });

    $('#channel').on('change', function() {
        $('#nocid').selectpicker('val', false);
        channelChange();
    });

    $('#nocid').on('change', function() {
        $('#channel').selectpicker('val', false);
        nocChange();
    });

    $('#partners').on('change', function() {
        partnerChange();
    });

    $('#clients').on('change', function() {
        clientChange();
    });

    $('#partnersTab3').on('change', function() {
        $.ajax({
            type: "POST",
            url: "/serviceManagement/partnerAjax?_ajax=true",
            data: {
                'res_cli[]': $('#partnersTab3').val(),
                'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
            },
            beforeSend: function() {
                $('#mspClientRF').html('<img border="0" align="right" src="/static/images/loading.gif">');
            },
            complete: function() {
                $('#mspClientRF').html('<i class="fa fa-refresh"></i>');
            },
            success: function(data) {
                $('#clientsTab3').selectpicker('destroy');
                var datalist = new Array();
                $.each(data.clients, function(key, val) {
                    datalist.push("<option value = " + val.mspclientid + ">" + val.clientname + "</option>");
                });
                $('#clientsTab3').html(datalist);
                $('#clientsTab3').selectpicker(multiselectEnable);
                /*msp_clients_counts();*/
            },
        });

    });

    $('#pcGo').on('click', function() {
        msp_clients_counts();
    });
    $("body").on('click', 'input#dateselection_0', function() {
        $("#dateselection_1").prop('checked', false);
        $("#dateselection_2").prop('checked', false);
        $('#date').hide();
        $('#others').hide();
        $('#days').show();
    });
    $("body").on('click', 'input#dateselection_1', function() {
        $("#dateselection_0").prop('checked', false);
        $("#dateselection_2").prop('checked', false);
        $('#days').hide();
        $('#others').hide();
        $('#date').show();
    });
    $("body").on('click', 'input#dateselection_2', function() {
        $("#dateselection_0").prop('checked', false);
        $("#dateselection_1").prop('checked', false);
        $('#days').hide();
        $('#date').hide();
        $('#others').show();
    });
    $('#tckDeptRF').on('click', function() {
        deptCount();
    });
    $('#nocDeptRF').on('click', function() {
        deptNocCount();
    });
    $('#deviceRF').on('click', function() {
        deviceCount();
    });
    $('#mspClientRF').on('click', function() {
        msp_clients_counts();
    });

    var active = JSON.parse("[" + active1 + "]");
    $.each(active, function(i, ac) {
        $("#s_" + ac).prop('checked', true);
    });

    if (defltCustmCol != null) {
        displayColumns = defltCustmCol.split(",");
        $('#customColumns1').selectpicker('val', displayColumns);
    }

    $('#tkType').on('change', function() {
        deviceCount();
    });
    $('#ticketT').on('change', function() {
        deptCount();
    });

    $("body").on('click', '#t3', function() {
        $('.tab-content > .tab-pane').removeClass('active');
        $('#tab_3').addClass('tab-pane active');
    });
    $("body").on('click', '#t1', function() {
        $('.tab-content > .tab-pane').removeClass('active');
        $('#tab_1').addClass('active')
    });
    $("body").on('click', '#t2', function() {
        $('.tab-content > .tab-pane').removeClass('active');
        $('#tab_2').addClass('tab-pane active');
    });
    $("body").on('click', '#t4', function() {
        $('.tab-content > .tab-pane').removeClass('active');
        $('#tab_4').addClass('active')
    });
    $("body").on('click', '#t5', function() {
        $('.tab-content > .tab-pane').removeClass('active');
        $('#tab_5').addClass('active')
    });
    $("#nocT").on('change', function() {
        deptNocCount();
    });
    $('#grpStatus').on('change', function() {
        updateStatusArea();
    });
    $('#grpPriorities').on('change', function() {
        updatePriorityArea();
    });

    /*Left Pane Scroll*/
    var treeViewHeight = $('.tab-content').height();
    var windowHeight = $(window).height();
    treeViewHeight = windowHeight - 165;
    $('div.tab-content').attr('style', 'overflow-y: scroll !important; height:' + treeViewHeight + 'px !important;')

});

function formValidations() {
    var errorMsgs = '';
    var isFormValidated = true;
    var templateName = '';
    templateName = $('#templateName1').val();
    templateName = $.trim(templateName);
    if (templateName == '') {
        errorMsgs += "<li> Please enter the template name. </li>";
        isFormValidated = false;
    }

    var tempNames = new Array();
    if ($('#btnSubmit').is(':focus')) {
        $('#templatename_validation :checked').each(function() {
            tempNameList = $(this).val();
            if (templateName == tempNameList) {
                errorMsgs += "<li> Template name already existed </li>";
                isFormValidated = false;
            }
        });
    }


    if ($('input#dateselection_1').is(':checked')) {
        if ($.trim($('#fdDate1').val()) == '' || $.trim($('#tdDate1').val()) == '') {
            $('#fdDate1').addClass('errorMessage');
            $('#tdDate1').addClass('errorMessage');
            errorMsgs += "<li> Invalid date range. </li>";
            isFormValidated = false;
        } else {
            var dt1 = $('#fdDate1').val();
            dt1 = dt1.split('/');
            dt1Month = dt1[0];
            dt11 = dt1[1].split(' ');
            dt1Year = dt1[2];
            dt1Year = dt1Year.split(' ');
            dt1Year = dt1Year[0];
            dt1Date = dt11[0];

            var dt2 = $('#tdDate1').val();
            dt2 = dt2.split('/');
            dt2Month = dt2[0];
            dt22 = dt2[1].split(' ');
            dt2Year = dt2[2];
            dt2Year = dt2Year.split(' ');
            dt2Year = dt2Year[0];
            dt2Date = dt22[0];

            var date1 = new Date(dt1Year, (dt1Month) - 1, dt1Date, 0, 0); /*2014-06-01 */
            var date2 = new Date(dt2Year, (dt2Month) - 1, dt2Date, 0, 0); /*2014-05-31 */
            var diff = date2 - date1;

            if (diff < 0) {
                $('#fdDate1').addClass('errorMessage');
                $('#tdDate1').addClass('errorMessage');
                errorMsgs += "<li> Invalid date range. </li>";
                isFormValidated = false;
            }
        }
    }




    var _priority_From = $('#priority_from :checked').val();
    var _priority_To = $('#grpPriorities :checked').val();

    if (typeof(_priority_From) != 'undefined' && typeof(_priority_To) === 'undefined') {
        errorMsgs += "<li> Please select changed priority from the listed \"TO\" option. </li>";
        isFormValidated = false;
    } else {
        var priority_To = new Array();
        $('#grpPriorities :checked').each(function() {
            priority_To.push($(this).val());
        });

        var priority_From = $('#priority_from :checked').val();

        if (jQuery.inArray(priority_From, priority_To) !== -1) {
            errorMsgs += "<li> Please make sure selected priority \"FROM\"  and  \"TO\" should not be equal. </li>";
            isFormValidated = false;
        }
    }

    if (!$('#is_modified_tickets_0').is(":checked") && !$('#is_modified_tickets_1').is(":checked")) {
        errorMsgs += "<li> Please select atleast one option from Created and Modified </li>";
        isFormValidated = false;
    }

    if (!isFormValidated) {
        var html = '';
        var errMsg = '<ul>' + errorMsgs + '</ul>';
        $('#myAlert').slideDown('slow');
        $('#divErrorMsg').html(errMsg);
        return false;
    } else {
        $('#myAlert').hide();
    }
    return true;

}

function formValidationupdate() {
    var isFormValidated = true;
    var errorMsgs = '';
    var _priority_From = $('#priority_from :checked').val();
    var _priority_To = $('#grpPriorities :checked').val();

    if (typeof(_priority_From) != 'undefined' && typeof(_priority_To) === 'undefined') {
        errorMsgs += "<li> Please select changed priority from the listed \"TO\" option. </li>";
        isFormValidated = false;
    } else {
        var priority_To = new Array();
        $('#grpPriorities :checked').each(function() {
            priority_To.push($(this).val());
        });

        var priority_From = $('#priority_from :checked').val();

        if (jQuery.inArray(priority_From, priority_To) !== -1) {
            errorMsgs += "<li> Please make sure selected priority \"FROM\"  and  \"TO\" should not be equal. </li>";
            isFormValidated = false;
        }
    }

    if (!$('#is_modified_tickets_0').is(":checked") && !$('#is_modified_tickets_1').is(":checked")) {
        errorMsgs += "<li> Please select atleast one option from Created and Modified </li>";
        isFormValidated = false;
    }

    if (!isFormValidated) {
        var html = '';
        var errMsg = '<ul>' + errorMsgs + '</ul>';
        $('#myAlert').slideDown('slow');
        $('#divErrorMsg').html(errMsg);
        return false;
    } else {
        $('#myAlert').hide();
    }
    return true;

}
jQuery('#btnRun').on('click', function(e) {

    isFormValidated = formValidations();
    if (!isFormValidated) {
        var html = '';
        var errMsg = '<ul>' + errorMsgs + '</ul>';
        $('#myAlert').slideDown('slow');
        $('#divErrorMsg').html(errMsg);
        return false;
    } else {
        $('#myAlert').hide();
        return true;
    }


});

function deletetemp(id, tempname) {
    if (confirm("Do you want to delete " + tempname + "?")) {
        id1 = parseInt(id);
        $.ajax({
            type: "GET",
            url: "/serviceManagement/delete",
            data: {
                'id': id1,
                'templatename': tempname
            },
            success: function(data) {
                $.ajax({
                    url: "/serviceManagement/TemplateList/",
                    type: 'post',
                    data: {
                        'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
                    },
                    beforeSend: function() {
                        $('span#load_template').show();
                    },
                    complete: function() {
                        $('span#load_template').hide();
                    },
                    success: function(data) {
                        $('#mySuccessNotify #divErrorMsg').append("Template \"" + tempname + "\" deleted successfully");
                        $('#mySuccessNotify').slideDown();
                        setTimeout('$("#mySuccessNotify #divErrorMsg").html(""); $("#mySuccessNotify").slideUp();', 5000);
                        $('#tab_5').html(data);
                    }
                });
            },
        });
    }
}

function email(tmpId) {
    var encodedData = window.btoa(tmpId);
    url = $(location).attr('href') + "slamResults?view=" + encodedData;
    window.location.href = "mailto:?body= Copy and paste in the browser to execute %0D%0A " + url + "%20%20";
}

function updateStatusArea() {
    var active = JSON.parse("[" + active1 + "]");
    var inactive = JSON.parse("[" + inactive1 + "]");
    var closed = JSON.parse("[" + closed1 + "]");
    var all = JSON.parse("[" + all1 + "]");
    var allVals = [];
    var allFlag = acFlag = inacFlag = cFlag = 0;

    $('#grpStatus :checked').each(function() {
        allVals.push($(this).val());
    });
    $.each(allVals, function(i, temp) {

        if (temp == 'all') {
            allFlag = 1;
            $.each(all, function(i, ac) {
                $("#s_" + ac).prop('checked', true);
            });
        }
        if (temp == 'active') {
            acFlag = 1;
            $.each(active, function(i, ac) {
                $("#s_" + ac).prop('checked', true);
            });
        }
        if (temp == 'inactive') {
            inacFlag = 1;
            $.each(inactive, function(i, iac) {
                $("#s_" + iac).prop('checked', true);
            });
        }
        if (temp == 'closed') {
            cFlag = 1;
            $.each(closed, function(i, c) {
                $("#s_" + c).prop('checked', true);
            });
        }

    });

    if ((allFlag != 1 && (acFlag == 1 || inacFlag == 1 || cFlag == 1) || (allFlag != 1 && acFlag != 1 && inacFlag != 1 && cFlag != 1))) {

        if (!$('#cls').is(":checked")) {
            $.each(closed, function(i, c) {
                $("#s_" + c).prop('checked', false);
            });
        }
        if (!$('#ac').is(":checked")) {
            $.each(active, function(i, ac) {
                $("#s_" + ac).prop('checked', false);
            });
        }
        if (!$('#inac').is(":checked")) {
            $.each(inactive, function(i, iac) {
                $("#s_" + iac).prop('checked', false);
            });
        }
    }
}

function updatePriorityArea() {
    var allVals = [];
    var p1, p2, p3;
    p1 = p2 = p3 = 0;
    $('#grpPriorities :checked').each(function() {
        allVals.push($(this).val());
    });

    $.each(allVals, function(i, temp) {
        if (temp == '8') {
            p0 = 1;
            $("#p_" + 8).prop('checked', true);
        }
        if (temp == '9') {
            p1 = 1;
            $("#p_" + 9).prop('checked', true);
        }
        if (temp == '10') {
            p2 = 1;
            $("#p_" + 10).prop('checked', true);
        }
        if (temp == '11') {
            p3 = 1;
            $("#p_" + 11).prop('checked', true);
        }

    });

    if ((p1 == 1 || p2 == 1 || p3 == 1 || p0 == 1) || (p0 != 1 && p1 != 1 && p2 != 1 && p3 != 1)) {

        if (!$('#p0').is(":checked")) {
            $("#p_" + 8).prop('checked', false);
        }
        if (!$('#p1').is(":checked")) {
            $("#p_" + 9).prop('checked', false);
        }
        if (!$('#p2').is(":checked")) {
            $("#p_" + 10).prop('checked', false);
        }
        if (!$('#p3').is(":checked")) {
            $("#p_" + 11).prop('checked', false);
        }
    }
}

/*actual addTab function: adds new tab using the input from the form above */
function addSlamTab(templateid) {
    /*Clearing Search values */
    $('#idTypeVal').val('');

    /*Clearing priorites */
    $(".selectedPriorities").removeAttr("checked");

    /*Clearing statuses */
    $('#grpStatus').selectpicker('deselectAll');
    $(".selectedStatuses").removeAttr("checked");

    /*Default search selected */
    $("#inlineRadio1").prop('checked', true);

    /*Clearing Tickettypes */
    $('#ticketType').selectpicker('deselectAll');

    /*Clearing Departments */
    $('#departments').selectpicker('deselectAll');

    /*Clearing Service type, Service levels, devices, devicetypes */
    $('#serviceType').selectpicker('deselectAll');
    $('#serviceLevel').selectpicker('deselectAll');
    $('#devices').selectpicker('deselectAll');
    $('#deviceType').selectpicker('deselectAll');

    /*clear is modified or created values */
    $("#is_modified_tickets_0").prop('checked', false);
    $("#is_modified_tickets_1").prop('checked', false);

    /*clear From and To option in priorities and setting default values to statuses  */
    $('#priority_from').selectpicker('deselectAll');
    $('#grpPriorities').selectpicker('deselectAll');
    $('#statusType').selectpicker('val', 'current');
    $('#grpStatus').selectpicker('val', 'active');

    /*clear Channels  */

    $('#resSla').selectpicker('deselectAll');
    /*clear tags  */
    $('#tags').selectpicker('deselectAll');

    /*clearing custom columns  */
    $('#customColumns1').selectpicker('deselectAll');

    var statuses = [];
    $.ajax({
        type: "POST",
        url: "/serviceManagement/loadTemplate?" + "&id=" + templateid,
        data: {
            'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
        },
        beforeSend: function() {
            $('span#load_template').show();
        },
        complete: function() {
            $('span#load_template').hide();
        },
        success: function(data) {
            templateName = data.templatename;
            $("#templateName1").val(templateName);

            templateType = data.templateType.split(",");
            tb_admin = data.tb_admin;
            $("input#templatType_0").prop('checked', false);
            $("input#templatType_1").prop('checked', false);

            $.each(templateType, function(index, value) {
                $("input#templatType_" + value).prop('checked', true);
                if (tb_admin == 0) {
                    if (value == 0) {
                        $("#public").show();
                        $("#private").hide();
                        $("#btnUpdate").hide();
                        $("#btnSubmit").hide();
                        $("#btnSubmit").hide();
                    } else {
                        $("#public").hide();
                        $("#private").show();
                        $("#btnUpdate").show();
                        $("#btnSubmit").hide();
                    }
                } else if (tb_admin == 1) {
                    if (value == 0) {
                        $("#public").show();
                        $("#private").show();
                        $("#btnUpdate").show();
                        $("#btnSubmit").hide();
                    } else {
                        $("#public").show();
                        $("#private").show();
                        $("#btnUpdate").show();
                        $("#btnSubmit").hide();
                    }
                }

            });
            optDateSelection = data.optDateSelection.split(",");
            $("input#dateselection_0").prop('checked', false);
            $("input#dateselection_1").prop('checked', false);
            $("input#dateselection_2").prop('checked', false);
            if (optDateSelection == "DAYS") {
                $("input#dateselection_0").prop('checked', true);
                $('#date').hide();
                $('#others').hide();
                $('#days').show();
                $('#daysSelected1').selectpicker('val', data.days);

                if (data.days == null) {

                    days = 0;
                    $('#daysSelected1').selectpicker('val', days);
                } else {

                    $('#daysSelected1').selectpicker('val', data.days);
                }
            } else if (optDateSelection == "DATE") {
                $("input#dateselection_1").prop('checked', true);
                $('#days').hide();
                $('#others').hide();
                $('#date').show();
            } else if (optDateSelection == "OTHERS") {
                $("input#dateselection_2").prop('checked', true);
                $('#days').hide();
                $('#date').hide();
                $('#others').show();
                $('#otherOption').selectpicker('val', data.otherOption);
            }

            var fromDateValue = data.fDate
            var toDateValue = data.tDate
            var d = new Date();

            if ((fromDateValue != undefined) || (fromDateValue != null) || (!fromDateValue)) {

            	/*         var optionsFromDt = {
                    icons: {
                        time: "fa fa-clock-o",
                        date: 'fa fa-calendar',
                        up: 'fa fa-arrow-up',
                        down: 'fa fa-arrow-down',
                    },
                    sideBySide: true,
                    maxDate: toDateValue,
                    defaultDate: fromDateValue,
                    format: 'MM/DD/YYYY HH:mm'
                }
                var optionsToDt = {
                    icons: {
                        time: "fa fa-clock-o",
                        date: 'fa fa-calendar',
                        up: 'fa fa-arrow-up',
                        down: 'fa fa-arrow-down',
                    },
                    sideBySide: true,
                    format: 'MM/DD/YYYY HH:mm'
                }
                $('#tdDate1').datetimepicker(optionsToDt);
                $('#fdDate1').datetimepicker(optionsFromDt);
                $("#fdDate1").data('DateTimePicker').setDate(fromDateValue)
                $("#tdDate1").data('DateTimePicker').setDate(toDateValue)*/
        		var calanderFromDate = {
        				 defaultDate: fromDateValue,
        				 maxDate: toDateValue,
        				 htmlId: 'fdDate1',
        				 format: 'MM/DD/YYYY HH:mm',
        			};
        			var calanderToDate = {
        				 defaultDate: toDateValue,
        				 htmlId: 'tdDate1',
        				 format: 'MM/DD/YYYY HH:mm',
        			};
        			prepareCalendar(calanderFromDate);
        			prepareCalendar(calanderToDate);

            }

            $("#templateid1").val(data.templateId);

            if (data.is_modified_tickets == "0") {
                $("input#is_modified_tickets_0").prop('checked', true);
                $("input#is_modified_tickets_1").prop('checked', false);
            } else if (data.is_modified_tickets == "1") {
                $("input#is_modified_tickets_0").prop('checked', false);
                $("input#is_modified_tickets_1").prop('checked', true);
            } else if (data.is_modified_tickets == "0,1") {
                $("input#is_modified_tickets_0").prop('checked', true);
                $("input#is_modified_tickets_1").prop('checked', true);
            }

            if (data.channel != null) {
                channel = data.channel.split(",");
                $('#channel').selectpicker('val', channel);
            }

            nocs = data.nocs.split(",");
            $('#nocid').selectpicker('val', nocs);
            partners = data.partners.split(",");
            devices = data.devices.split(",");
            clients = data.clients.split(",");
            var temp = false;
            if (nocs.length > 0) {
                temp = nocChange(partners, clients);
            }
            if (partners.length > 0 || temp == true) {
                partnerChange(partners, clients);
            }
            if (clients.length > 0) {
                clientChange(clients, devices);
            }

            depts = data.departments.split(",");
            $('#departments').selectpicker('val', depts);

            if (data.ticketType != null) {
                ticketType = data.ticketType.split(",");
                $('#ticketType').selectpicker('val', ticketType);
            }

            staff = data.staff.split(",");
            $('#staff').selectpicker('val', staff);

            if (data.serviceType != null) {
                serviceType = data.serviceType.split(",");
                $('#serviceType').selectpicker('val', serviceType);
            }

            if (data.serviceLevel != null) {
                serviceLevel = data.serviceLevel.split(",");
                $('#serviceLevel').selectpicker('val', serviceLevel);
            }

            if (data.deviceType != null) {
                deviceType = data.deviceType.split(",");
                $('#deviceType').selectpicker('val', deviceType);
            }

            if (data.resSla != null) {
                resSla = data.resSla.split(",");
                $('#resSla').selectpicker('val', resSla);
            }


            if (data.displayColumns != null) {
                displayColumns = data.displayColumns.split(",");

                $('#customColumns1').selectpicker('val', displayColumns);
            }

            if (data.tags != null) {
                tags = data.tags.split(",");
                $('#tags').selectpicker('val', tags);
            }

            if (data.priorities != null) {
                priorities = data.priorities.split(",");
                $.each(priorities, function(index, value) {
                    $("#p_" + value).prop('checked', true);
                });
            }

            if (data.statuses != null) {
                statuses = data.statuses.split(",");
                $.each(statuses, function(index, value) {
                    $("#s_" + value).prop('checked', true);
                });
            }
            if (data.is_auditlog_status != null) {
                var isAudStatus = data.is_auditlog_status;
                if (isAudStatus == 1) {
                    var isAudStatusVal = 'auditlog';
                }
                $('#statusType').selectpicker('val', isAudStatusVal);
            }

            if (data.ticketid != '') {
                $("#inlineRadio1").prop('checked', true);
                $("#idTypeVal").val(data.ticketid);
            } else if (data.alertid != '') {
                $("#inlineRadio2").prop('checked', true);
                $("#idTypeVal").val(data.alertid);
            } else if (data.psaid != '') {
                $("#inlineRadio3").prop('checked', true);
                $("#idTypeVal").val(data.psaid);
            } else if (data.subject != '') {
                $("#inlineRadio4").prop('checked', true);
                $("#idTypeVal").val(data.subject);
            }

            if (templateid == 17974) { /*Related to reset template  */
                $("#btnUpdate").hide();
                $("#btnSubmit").show();
            }
            $('#partners').selectpicker('val', partners);
            $('#clients').selectpicker('val', clients);
            $('#devices').selectpicker('val', devices);
        }
    });
}

function deviceCount() {
    var tkType = $('select#tkType').val();
    if (tkType == null || tkType == undefined) {
        var tkType = ''
    }
    $.ajax({
        type: 'POST',
        url: "/serviceManagement/deviceCount/",
        data: {
            'tkType': tkType,
            'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val(),
        },
        beforeSend: function() {
            $('#deviceRF').html(loading);
        },
        complete: function() {
            $('#deviceRF').html('<i class="fa fa-refresh"></i>');
        },
        /*async: false,  */
        success: function(data) {
            $('#treeview3').treeview({
                levels: 1,
                showTags: true,
                data: data.finalTree
            });

            $('li.node-treeview3').each(function() {
                applyTooltipForTree($(this));
            });
        }
    });
}

function deptCount() {
    var typeid = $('select#ticketT').val();
    if (typeid == null || typeid == undefined) {
        var typeid = ''
    }
    $.ajax({
        type: 'POST',
        url: "/serviceManagement/deptCount/",
        data: {
            'ticketType': typeid,
            'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val(),
        },
        beforeSend: function() {
            $('#tckDeptRF').html(loading);
        },
        complete: function() {
            $('#tckDeptRF').html('<i class="fa fa-refresh"></i>');
        },
        /*async: false, */
        success: function(data) {
            $('#treeview1').treeview({
                levels: 1,
                showTags: true,
                data: data.finalTree
            });

            $('li.node-treeview1').each(function() {
                applyTooltipForTree($(this));
            });
        }
    });
}

function deptNocCount() {
    var nocT = $('select#nocT').val();
    if (nocT == null || nocT == undefined) {
        var nocT = ''
    }
    $.ajax({
        type: 'POST',
        url: "/serviceManagement/deptNocCount/",
        data: {
            'nocT': nocT,
            'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val(),
        },
        beforeSend: function() {
            $('#nocDeptRF').html(loading);
        },
        complete: function() {
            $('#nocDeptRF').html('<i class="fa fa-refresh"></i>');
        },
        /*async: false, */
        success: function(data) {
            $('#treeview2').treeview({
                levels: 1,
                showTags: true,
                data: data.finalTree
            });

            $('li.node-treeview2').each(function() {
                applyTooltipForTree($(this));
            });
        }
    });
}

function msp_clients_counts() {
    $.ajax({
        type: "POST",
        url: "/serviceManagement/pcCountAjax?_ajax=true",
        data: {
            'res_p': $('#partnersTab3').val(),
            'res_c[]': $('#clientsTab3').val(),
            'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
        },
        beforeSend: function() {
            $('#mspClientRF').html('<span><img border="0" align="right" src="/static/images/loading.gif"></span>');
        },
        complete: function() {
            $('#mspClientRF').html('<i class="fa fa-refresh"></i>');
        },
        success: function(data) {
            $('#treeview4').treeview({
                levels: 1,
                showTags: true,
                data: data.finalTree
            });

            $('li.node-treeview4').each(function() {
                applyTooltipForTree($(this));
            });
        },
    });
}
var load_data = ['', '', '']
$('#template_hide').append("<input type=text name='statusType' value='current'>")

chk_bxs = $("#template0 input[id^=s_]");
data_obj = {};
for (i = 0; i < chk_bxs.length; i++) {
    parnt = chk_bxs[i].parentElement;
    data_obj[parnt.nextElementSibling.textContent] = chk_bxs[i].value;
}

$(document).on('click', 'li.node-treeview1,li.node-treeview2,li.node-treeview3,li.node-treeview4', function(e) {
    target = e.target;
    var dev_flag = false;

    if ($(this).hasClass('node-treeview3')) { /*TO check whether devicetype tab selected or not. */
        dev_flag = true;
    }

    if ($(target).hasClass('expand-icon')) {
        if ($(target).hasClass('fa-plus')) {
            if (this.childNodes.item(2).textContent != '') {
                load_data[0] = this.childNodes.item(2).textContent;
                load_data[1] = '';
                load_data[2] = '';
            } else if (this.childNodes.item(3).textContent != '') {
                load_data[1] = this.childNodes.item(3).textContent;
            }
        } else {
            if (this.childNodes.item(2).textContent != '') {
                load_data[0] = '';
                load_data[1] = '';
                load_data[2] = '';
            } else if (this.childNodes.item(3).textContent != '') {
                load_data[1] = '';
                load_data[2] = '';
            }
        }
        $('li.list-group-item').each(function() {
            applyTooltipForTree($(this));
        });
    } else {
        $('#template_hide input[name = "partners"]').remove();
        $('#template_hide input[name = "clients"]').remove();
        $('#template_hide input[name = "ticket-status"]').remove();
        $('#template_hide input[name = "selectedStatuses"]').remove();
        $('#template_hide input[name = "deviceType"]').remove();
        $('#template_hide input[name = "templatename"]').remove();
        $('#template_hide input[name = "department"]').remove();
        $('#template_hide input[name = "ticketTypes"]').remove();
        $('#template_hide input[name = "nocs"]').remove();
        $('#template_hide input[name = "idTypeValue"]').val('');
        if (this.childNodes.item(2).textContent != '') {
            load_data[0] = this.childNodes.item(2).textContent;
            load_data[1] = '';
            load_data[2] = '';
        } else if (this.childNodes.item(3).textContent != '') {
            load_data[1] = this.childNodes.item(3).textContent;
        } else if (this.childNodes.item(4).textContent != '') {
            load_data[2] = this.childNodes.item(4).textContent;
        }
        original = $('#slamform').html();
        if ($(this).hasClass('node-treeview1') && $('#ticketT').val() != "") $('#template_hide').append('<input type="text" name="ticketTypes" value="' + $('#ticketT').val() + '">');
        else if ($(this).hasClass('node-treeview2') && $('#nocT').val() != "") $('#template_hide').append('<input type="text" name="nocs" value="' + $('#nocT').val() + '">');
        else if ($(this).hasClass('node-treeview3') && $('#tkType').val() != "") $('#template_hide').append('<input type="text" name="ticketTypes" value="' + $('#tkType').val() + '">');
        else if ($(this).hasClass('node-treeview4')) {
            $('#template_hide').append('<input type="text" name="partners" value="' + $('#partnersTab3').val() + '">');
            clnts = $('#clientsTab3').val();
            if (clnts != null) {
                $.each(clnts, function(ind, val) {
                    $('#template_hide').append('<input type="text" name="clients" value="' + val + '">');
                });
            }
        }
        ar = $('#departments option');
        c = 0;
        if (dev_flag == false) {
            for (i = 0; i < ar.length; i++) {
                if ((ar[i].innerHTML).search(load_data[0]) != -1) {
                    $('#template_hide').append("<input type='text' name='department' value='" + ar[i].value + "'>");
                    c++;
                    break;
                }
            }
        }
        if (dev_flag == true) {
            $('#deviceType option').each(function(num, val) {
                var deviceTypeFromOption = $(this).attr('data-deviceType').toLowerCase();
                var listValue = load_data[0].toLowerCase();
                if (deviceTypeFromOption == listValue) {
                    $('#template_hide').append("<input type='text' name='deviceType' value='" + $(this).val() + "'>");
                }
            });
        }
        if (load_data[2] == '') {
            if (load_data[1] == '') {
                var all = [];
                active = active1.split(",");
                inactive = inactive1.split(",");
                for (i = 0; i < active.length; i++)
                    all.push(active[i]);
                for (i = 0; i < inactive.length; i++)
                    all.push(inactive[i]);
                for (i = 0; i < all.length; i++)
                    $('#template_hide').append("<input id='st_typ' type=text name='selectedStatuses' value='" + all[i] + "'>")
            } else if (load_data[1] == 'Active') {
                active = active1.split(",");
                $('#template_hide').append("<input id='st_typ' type=text name='ticket-status' value='active'>")
                for (i = 0; i < active.length; i++)
                    $('#template_hide').append("<input id='st_typ' type=text name='selectedStatuses' value='" + active[i] + "'>")
            } else if (load_data[1] == 'InActive') {
                inactive = inactive1.split(",");
                $('#template_hide').append("<input id='st_typ' type=text name='ticket-status' value='inactive'>")
                for (i = 0; i < inactive.length; i++)
                    $('#template_hide').append("<input id='st_typ' type=text name='selectedStatuses' value='" + inactive[i] + "'>")
            } else if (load_data[1] == 'Closed') {
                closed1 = Array(32, 3, 5, 17, 20, 41);
                $('#template_hide').append("<input id='st_typ' type=text name='ticket-status' value='closed'>")
                for (i = 0; i < closed1.length; i++)
                    $('#template_hide').append("<input id='st_typ' type=text name='selectedStatuses' value='" + closed1[i] + "'>")
            }
        } else {
            $('#template_hide').append("<input id='st_typ' type=text name='selectedStatuses' value='" + data_obj[load_data[2]] + "'>")
        }
        /* setup for Template name for Service management Left panel count results.. */
        var template_name = "General Template"; /*Default name for Template	 */
        if (load_data[0] != 'undefined' && load_data[0] != '') {
            template_name = load_data[0];
            if (load_data[2] != 'undefined' && load_data[2] != '') {
                template_name += "_" + load_data[2] + "_" + "Tickets";
            } else if (load_data[1] != 'undefined' && load_data[1] != '') {
                template_name += "_" + load_data[1] + "_" + "Tickets";
            }
        }
        $('#template_hide').append("<input type='hidden' name='templatename' value='" + template_name + "'>")
        $('#template_hide').submit();
        $('#slamform').html(original);

    }
});

jQuery('#btnReset').on('click', function() {
    $('#channel').selectpicker('deselectAll');
    $('#nocid').selectpicker('deselectAll');
    /*templateId = 11935; */
    templateId = 17974; /* Production General template ID to reset the form in Service management */

    addSlamTab(templateId);
});

jQuery('body').on("keypress", '#template0', function(e) {
    if (e.keyCode == 13) {
        /* Cancel the default action on keypress event */
        e.preventDefault();
        $('#btnRun').trigger('click');
    }
});

function fromDateTodate(fromdate, todate) {

    $(function() {

        var fromdatelist = fromdate.split("/");
        var todatelist = todate.split("/");
        var newdate = new Date();
        var optionsFromDt = {
            icons: {
                time: "fa fa-clock-o",
                date: 'fa fa-calendar',
                up: 'fa fa-arrow-up',
                down: 'fa fa-arrow-down',
            },
        }
        var optionsToDt = {
            icons: {
                time: "fa fa-clock-o",
                date: 'fa fa-calendar',
                up: 'fa fa-arrow-up',
                down: 'fa fa-arrow-down',
            },
        }
        $('#fdDate1').datetimepicker(optionsFromDt);
        $('#tdDate1').datetimepicker(optionsToDt);
        $("#fdDate1").data('DateTimePicker').setDate(new Date(Number(fromdatelist[2]), Number(fromdatelist[0]) - 1, Number(fromdatelist[1]), newdate.getHours(), newdate.getMinutes()));
        $("#tdDate1").data('DateTimePicker').setDate(new Date(Number(todatelist[2]), Number(todatelist[0]) - 1, Number(todatelist[1]), newdate.getHours(), newdate.getMinutes()));
    });
}

function channelChange(partnerIds, clientIds) {
    $.ajax({
        type: "POST",
        url: "/serviceManagement/channelAjax?_ajax=true",
        data: {
            'res_pat': $('#channel').val(),
            'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
        },
        beforeSend: function() {
            $('span#loadingNoc').show();
            $('span#loadingClient').show();
        },
        complete: function() {
            $('span#loadingNoc').hide();
            $('span#loadingClient').hide();
        },
        success: function(data) {
            $('#partners').selectpicker('destroy');
            $('#clients').selectpicker('destroy');
            var patData = new Array();
            var cliData = new Array();
            $.each(data.msps, function(key, val) {
                patData.push("<option value = " + val.mspid + ">" + val.mspname + "</option>");
            });
            $('#partners').html(patData);
            $.each(data.clients, function(key, val) {
                cliData.push("<option value = " + val.mspclientid + ">" + val.clientname + "</option>");
            });
            $('#clients').html(cliData);
            $('#partners').selectpicker(multiselectEnable);
            $('#clients').selectpicker(multiselectEnable);
            if (partnerIds != '' && partnerIds != undefined) {
                $('#partners').selectpicker('val', partnerIds);
            }
            if (clientIds != '' && clientIds != undefined) {
                $('#clients').selectpicker('val', clientIds);
            }
            return true;
        },
        error: function() {
            return false;
        }
    });
}

function nocChange(partnerIds, clientIds) {
    $.ajax({
        type: "POST",
        url: "/serviceManagement/nocAjax?_ajax=true",
        data: {
            'res_pat[]': $('#nocid').val(),
            'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
        },
        beforeSend: function() {
            $('span#loadingNoc').show();
            $('span#loadingClient').show();
        },
        complete: function() {
            $('span#loadingNoc').hide();
            $('span#loadingClient').hide();
        },
        success: function(data) {
            $('#partners').selectpicker('destroy');
            $('#clients').selectpicker('destroy');
            var patData = new Array();
            var cliData = new Array();
            $.each(data.msps, function(key, val) {
                patData.push("<option value = " + val.mspid + ">" + val.mspname + "</option>");
            });
            $('#partners').html(patData);
            /*$.each(data.clients,function(key,val){
				cliData.push("<option value = "+val.mspclientid+">"+val.clientname+"</option>");
			});*/

            /*$('#clients').html(cliData); */
            $('#partners').selectpicker(multiselectEnable);
            $('#clients').selectpicker(multiselectEnable);
            if (partnerIds != '' && partnerIds != undefined) {
                $('#partners').selectpicker('val', partnerIds);
            }
            /*$('#clients').selectpicker('val', clientIds);*/
            return true;
        },
        error: function() {
            return false;
        }
    });
}

function partnerChange(partnerIds, clientIds) {
    if (partnerIds != null && partnerIds != '' && partnerIds != undefined) {
        var pIds = partnerIds;
    } else {
        var pIds = $('#partners').val();
    }
    $.ajax({
        type: "POST",
        url: "/serviceManagement/partnerAjax?_ajax=true",
        data: {
            'res_cli[]': pIds,
            'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
        },
        beforeSend: function() {
            $('span#loadingClient').show();
        },
        complete: function() {
            $('span#loadingClient').hide();
        },
        success: function(data) {
            $('#clients').selectpicker('destroy');
            var datalist = new Array();
            $.each(data.clients, function(key, val) {
                datalist.push("<option value = " + val.mspclientid + " data-subtext= " + val.mspname + ">" + val.clientname + "</option>");
            });
            $('#clients').html(datalist);
            $('#clients').selectpicker(multiselectEnable);
            $('#clients').selectpicker('val', clientIds);
            return true;
        },
        error: function() {
            return false;
        }
    });
}

function clientChange(clientIds, deviceIds) {
    if (clientIds != null && clientIds != '' && clientIds != undefined) {
        var cIds = clientIds;
    } else {
        var cIds = $('#clients').val();
    }
    $.ajax({
        type: "POST",
        url: "/serviceManagement/clientAjax?_ajax=true",
        data: {
            'res_devices[]': cIds,
            'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
        },
        beforeSend: function() {
            $('span#loadingDevices').show();
        },
        complete: function() {
            $('span#loadingDevices').hide();
        },
        success: function(data) {
            $('#devices').selectpicker('destroy');
            var datalist = new Array();
            $.each(data.devices, function(key, val) {
                datalist.push("<option value = " + val.id + ">" + val.device_name + "</option>");
            });
            $('#devices').html(datalist);
            $('#devices').selectpicker(multiselectEnable);
            $('#devices').selectpicker('val', deviceIds);
            return true;
        },
        error: function() {
            return false;
        }
    });
}
