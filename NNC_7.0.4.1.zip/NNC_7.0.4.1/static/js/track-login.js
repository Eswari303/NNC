/*
* This computer program is the confidential information and proprietary trade
* secret of NetEnrich, Inc. Possessions and use of this program must
* conform strictly to the license agreement between the user and
* NetEnrich, Inc., and receipt or possession does not convey any rights
* to divulge, reproduce, or allow others to use this program without specific
* written authorization of NetEnrich, Inc.
*
* Copyright  2016 NetEnrich, Inc. All Rights Reserved.
*/

function LoginTracking(){
    var url_hit_time =  new Date($.now());

    if ($.cookie("url_last_hit_time")){
        var cookie_time = $.cookie("url_last_hit_time");
        var cookie_date_time =  new Date(cookie_time);
    }
    else{
        var cookie_date_time = new Date($.now())
        $.cookie("url_last_hit_time", cookie_date_time);
    }

    var t2 = new Date(url_hit_time.getFullYear(),
                      url_hit_time.getMonth()+1,
                      url_hit_time.getDay(),
                      url_hit_time.getHours(),
                      url_hit_time.getMinutes(),
                      url_hit_time.getSeconds());

    var t1 = new Date(cookie_date_time.getFullYear(),
                      cookie_date_time.getMonth()+1,
                      cookie_date_time.getDay(),
                      cookie_date_time.getHours(),
                      cookie_date_time.getMinutes(),
                      cookie_date_time.getSeconds());
    var dif = t1.getTime() - t2.getTime();
    var Seconds_from_T1_to_T2 = dif / 1000;
    var Seconds_Between_Dates = Math.abs(Seconds_from_T1_to_T2);

    if (Number(Seconds_Between_Dates) < 10){
        console.log("");
    }
    else{
        var url_last_hit_time = new Date($.now())
        $.cookie("url_last_hit_time", url_last_hit_time);
        $.ajax({url: "/employeeDashboard/trackUserStatus/",
          type : "POST",
          dataType:"json",
          data :
          {
            'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
            "latest_date_time" :url_last_hit_time
          },success: function(response){

          },error : function(error){

          }
    });
    }
}

$(document).ready(function(){
    LoginTracking();
});
//setInterval(LoginTracking, 10000);