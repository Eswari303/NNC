/*---------------Moved below code from ticketView.html-----------------------------*/
$('#myTabbedModal').click(function () {
    url = "/ticket/mappedTicketView/"+ticketId;
    $.colorbox({
        href: url,
        width: '1200px',
        height: '700px',
        iframe: true,
        title: "Incident to Incident Mapping"
    });
});

$(document).ready(function(){
    var calanderFromDate = {
        defaultDate: dateTimePicker,
        htmlId: 'gnschPost',
        format: 'YYYY-MM-DD HH:mm'
    };
    var calanderToDate = {
        defaultDate: dateTimePicker,
        htmlId: 'upDateScheduledTime',
        format: 'YYYY-MM-DD HH:mm'
    };
    prepareCalendar(calanderFromDate);
    prepareCalendar(calanderToDate);
});

$(document).ready(function() {
    $('#toEmailId,#ccEmailId')
        .on('tokenfield:createtoken', function (e) {
            var data = e.attrs.value.split('|');
            e.attrs.value = data[1] || data[0];
            e.attrs.label = data[1] ? data[0] + ' (' + data[1] + ')' : data[0];
        })
        .on('tokenfield:createdtoken', function (e) {
            var re = /\S+@\S+\.\S+/;
            var valid = re.test(e.attrs.value);
            if (!valid) {
                $(e.relatedTarget).addClass('invalid').css('background-color', 'pink');
            }
        })
        .on('tokenfield:edittoken', function (e) {
            if (e.attrs.label !== e.attrs.value) {
                var label = e.attrs.label.split(' (');
                e.attrs.value = label[0] + '|' + e.attrs.value
            }
        })

        .on('tokenfield:removedtoken', function (e) {
            $('input:checkbox[data-esc-single-contact="true"][value="'+e.attrs.value+'"]').attr('checked',false)
        })

        .tokenfield({
            delimiter: [',',';'],
            minWidth: 160, /*pixels*/
            autocomplete: {
                source: emailList,
                delay: 100
            },
            createTokensOnBlur: true,
            inputType: 'email'
        });

    $('#tags,#postRepTags,#quickTags')
        .on('tokenfield:createtoken', function (e) {
            var data = e.attrs.value.split('|');
            e.attrs.value = data[1] || data[0];
            e.attrs.label = data[1] ? data[0] + ' (' + data[1] + ')' : data[0]
        })
        .on('tokenfield:edittoken', function (e) {
            if (e.attrs.label !== e.attrs.value) {
                var label = e.attrs.label.split(' (');
                e.attrs.value = label[0] + '|' + e.attrs.value
            }
        })
        .tokenfield({
            delimiter: [',',';'],
            minWidth: 160, 
            autocomplete: {
                source: searchTags,
                delay: 100
            },
            createTokensOnBlur: true
        });

});
$(window).bind('load',function(){
    /*quickStatusId = ticketStatus;*/
    $('#gnStatusEdit').selectpicker('val',[ticketStatus]);
    /* quickPId = priorty; */
    $('#quick_gnPriEdit').selectpicker('val',[priorty]);
    $('#quick_staff').selectpicker('val',[staffID]);
    $('#auditLogRF').hide();
    $('#notesRF').hide();
    $('#billingRF').hide();
    if($('#quick_department').val() == null || $('#quick_department').val() == ''){
        $('#quick_department').selectpicker('val',['']);
    }
    if($('#quick_timezone').val() == null || $('#quick_timezone').val() == ''){
        $('#quick_timezone').selectpicker('val',['']);
    }
});
$(document).ready(function(){
    $('body').on('click','#emailToClient',function(){
        if($(this).prop("checked") == true){
            var subjectpicker = '';
            var statusName = $('#statusPost option:selected').text();
            var priorityName = $('#priPost option:selected').text();
            var mspticketId = psaTID;
            var deviceId = deviceId;
            subjectpicker = "[#"+ticketId+"]";
            if(mspticketId && mspticketId !='None'){
                subjectpicker += "["+mspticketId+"]";
            }
            subjectpicker += "["+priorityName+"]["+ clientName +"]"
            if(deviceId>0){
                subjectpicker += "["+ deviceName +"]";
            }
            subjectpicker +="["+statusName+"] : "+ ticketSubject;
            $('#postSub').val(subjectpicker);
        }else{
            $('#postSub').val(ticketSubject);
        }
    });
});




/*===================================================================================*/
var config = {
	enterMode : CKEDITOR.ENTER_BR,
	removeButtons: 'Image,Anchor,Image,About,Maximize,NumberedList,BulletedList,Source',
	height : '400px',
	disableNativeSpellChecker : false,
	scayt_autoStartup : true,
	scayt_sLang : 'en_US',
};
var multiselectEnable = {
	    maxHeight: 200,
	    numberDisplayed: 1,
	    enableFiltering: true,
	    enableCaseInsensitiveFiltering: true,
	    includeFilterClearBtn: false,
	};
var mspid_checks = '{{ msp_flag }}';
CKEDITOR.replace('ticketContent',config);
$(document).ready(function() {
    if ($('#statusPost').val() == 16) {
        $('#schStatus').show(200);
    }
    if ($('#statusPost').val() == 9 || $('#statusPost').val() == 46) {
    	if (mspId == 107521){
        	if ($('#statusPost').val() == 46) {
        		$('#hmsporwfci').show(200);
                $('#hmspReason').selectpicker('destroy');
                var hmspreasonsForGP = new Array();
                var hmspreasons = {14661: "Select Reason", 14691: "Physical Examination", 14671: "Approval Required", 14681: "Information Required", 9990: "Maintenance window"};
                $.each(hmspreasons, function(key, val) {
                	hmspreasonsForGP.push("<option id = " + key + " value = '" + val + "'>" + val + "</option>");
                });
                $('#hmspReason').html(hmspreasonsForGP);
                $('#hmspReason').selectpicker(multiselectEnable);
        	}else if($('#statusPost').val() == 9){
        		$('#hmsporwfci').show(200);
                $('#hmspReason').selectpicker('destroy');
                var hmspreasonsForGP = new Array();
                var hmspreasons = {14661: "Select Reason", 14701: "Credentials are not available", 14711: "Credentials provided are invalid", 9991: "ISP Details", 9992: "Out of SCOPE"};
                $.each(hmspreasons, function(key, val) {
                	hmspreasonsForGP.push("<option id = " + key + " value = '" + val + "'>" + val + "</option>");
                });
                $('#hmspReason').html(hmspreasonsForGP);
                $('#hmspReason').selectpicker(multiselectEnable);
        	}
        }else if(($('#statusPost').val() == 9 || $('#statusPost').val() == 46)){
        	$('#hmsporwfci').show(200);
        }else{
        	$('#hmsporwfci').hide(200);
        }
    }


    $('.audit').click(function() {
        $('#displaynote').hide();
        $('#billingEntry').hide();
        $('#auditLog').show();
        $('a#auditLogRF').show();
        $('a#notesRF').hide();
        $('a#billingRF').hide();
        auditLog();
    });

    $('body').on('click', '.notes', function() {
        $('#auditLog').hide();
        $('#billingEntry').hide();
        $('#displaynote').show();
        $('a#auditLogRF').hide();
        $('a#notesRF').show();
        $('a#billingRF').hide();
        loadTicketNotes(true);
    });
    
    
    $('.billing').click(function() {
    	$('#auditLog').hide();
    	$('#displaynote').hide();
        $('#billingEntry').show();
        $('a#auditLogRF').hide();
        $('a#notesRF').hide();
        $('a#billingRF').show();
        loadBillingEntries(true);
        
    });
    
    /*auditLog */
    /*$('a#notesRF').click(function(e) {
        e.preventDefault();
        loadTicketNotes(true);
    });*/
    /*auditLog */
    $('#auditLogRF').click(function() {
        auditLog();
    });
    /*auditLog */
    $('a#billingRF').click(function() {
        loadBillingEntries(true)
    });

    $('#reply').click(function() {
        $('#Internal').data('clicked', false);
        $('.postR').show(200);
	    $('#ccField').show();
        $('#NInternal').show(200);
        $('#NInternal2').show(200);
        $('#ccEmailId').tokenfield('setTokens', []);
        $('#ccEmailId').tokenfield('setTokens', cceList);
        var toElist = $('#toEmailId').val();

    });

    $('#Internal').click(function() {
        $('.postR').show(200);
        $(this).data('clicked', true);
	    $('#ccField').hide();
        $('#NInternal').hide(100);
        $('#NInternal2').hide(100);  
        $('#ccEmailId').tokenfield('setTokens', []);
        $('#ccEmailId').tokenfield('setTokens', internaleList);
        $('#toEmailId').tokenfield('setTokens', []);
        $('.Matcontent table input').attr('checked', false);
    });

    $('#hidePostRep').click(function() {
        $('.postR').hide(200);
        $('#NInternal').hide(100);
        $('#NInternal2').hide(100);
    });

    $('#button2').click(function() {
        deviceNotes();
    });

    customFiledsData();
    /*loadTicketNotes(false);
    loadBillingEntries(false);
    auditLog();*/
    $('#addNotes').click(function() {
        url = "/ticket/notesForm/" + ticketId
        $.colorbox({
            href: url,
            width: '950px',
            height: '500px',
            iframe: true,
            onClosed: function() {
                $('.notes').trigger('click');
            }
        });

    });

    $('#billing').click(function() {
    	url = "/ticket/billing/" + ticketId
        $.colorbox({
            href: url,
            width: '950px',
            height: '500px',
            iframe: true,
            onClosed: function() {
                $('.billing').trigger('click')
            }
        });
    });

    $(".pane .Matheader").click(function() {
        $(this).parent().toggleClass("collapsed");
    });

    $('.RowToClick').click(function() {
        $(this).nextAll('tr').each(function() {
            if ($(this).is('.RowToClick')) {
                return false;
            }
            $(this).toggle();
        });
    });


    $('#tags,#postRepTags,#quickTags')
        .on('tokenfield:createtoken', function(e) {
            var data = e.attrs.value.split('|')
            e.attrs.value = data[1] || data[0]
            e.attrs.label = data[1] ? data[0] + ' (' + data[1] + ')' : data[0]
        })
        .on('tokenfield:edittoken', function(e) {
            if (e.attrs.label !== e.attrs.value) {
                var label = e.attrs.label.split(' (')
                e.attrs.value = label[0] + '|' + e.attrs.value
            }
        })
        .tokenfield({
            delimiter: [',', ';'],
            minWidth: 160, /*pixels */
            autocomplete: {
                source: searchTags,
                delay: 100
            },
        })

    $(window).bind('load', function() {
        /*slaResloution();*/
        $('.notes').trigger('click');
    });

    function deviceNotes() {
        url = "/ticket/devicenotesview?cId=" + clientId;
        $.colorbox({
            href: url,
            width: '950px',
            height: '550px',
            iframe: true
        });
    }

    /*Predefined Replies to be added to Editor.*/
    $('body').on('click', '#predef', function() {
        predefid = $(this).attr('predef_id');
        /*alert("predefid"+predefid)   	*/
        $.ajax({
            type: 'POST',
            url: "/ticket/predefinedReplyData/?_ajax=true",
            data: {
                'predefid': predefid,
                'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
            },
            success: function(data) {
            	var newContent = existingContent = '';				
				newContent = data.replace(/(\r\n|\n\r|\r|\n)/g, "<br>");  
				CKEDITOR.instances['ticketContent'].focus();
				existingContent = CKEDITOR.instances['ticketContent'].getData();
				CKEDITOR.instances['ticketContent'].setData(existingContent+newContent);
            }
        });
    });

    /*KnowledgeBase Replies to be added to Editor. */
    $('body').on('click', '#kba', function() {
        kbaid = $(this).attr('kba_id');
        $.ajax({
            type: 'POST',
            url: "/ticket/kbaReplyData/?_ajax=true",
            data: {
                'kbaid': kbaid,
                'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
            },
            success: function(data) {
				var newContent = existingContent = '';
				newContent = data.replace(/(\r\n|\n\r|\r|\n)/g, "<br>");  
				CKEDITOR.instances['ticketContent'].focus();
				existingContent = CKEDITOR.instances['ticketContent'].getData();
				CKEDITOR.instances['ticketContent'].setData(existingContent + newContent);
            }
        });
    });
    if ($('span.value').text().indexOf('Request is in queue') !== -1){
        $(".link1").hide()
    }
    if ($('.vistaraStatus').text() == "Request is in queue"){
        getMSPIDAJAX();
    }
});


/* for email check box	 */
$(function() {
    var $conditionalInput = $('#clientSub');
    var $subscribeInput = $('input[name="emailClient"]');
    $conditionalInput.hide();
    $subscribeInput.on('click', function() {
        if ($(this).is(':checked'))
            $conditionalInput.show();
        else
            $conditionalInput.hide();
    });

});
$('.dd').click(function() {
    /*remove class from previously active button */
    $('.btnactive').removeClass('btnactive');
    $(this).addClass('btnactive');
});
$('#hmspReason').on('change', function() {
    if ($('#hmspReason').val() == 'Miscellaneous') {
        $('#divEmpDates').show(200);
    } else {
        $('#divEmpDates').hide(200);
    }
});

$('body').on('change', '#statusPost', function(e) {
    if ($('#statusPost').val() == 16) {
        $('#schStatus').show(200);
        $('#hmsporwfci').hide(100);
    } else {
        $('#schStatus').hide();
    }
    /* Below is for Green Pages Partner */
    statusId = $('#statusPost').val();
    if (mspId != 107521){
    	if(($('#statusPost').val() == 9 || $('#statusPost').val() == 46)){
        	$('#hmsporwfci').show(200);
        }else{
        	$('#hmsporwfci').hide(200);
        }
    	
    }else{
    	if ($('#statusPost').val() == 46) {
    		$('#hmsporwfci').show(200);
            $('#hmspReason').selectpicker('destroy');
            var hmspreasonsForGP = new Array();
            var hmspreasons = {14661: "Select Reason", 14691: "Physical Examination", 14671: "Approval Required", 14681: "Information Required", 19990: "Maintenance window"};
            $.each(hmspreasons, function(key, val) {
            	hmspreasonsForGP.push("<option id = " + key + " value = '" + val + "'>" + val + "</option>");
            });
            $('#hmspReason').html(hmspreasonsForGP);
            $('#hmspReason').selectpicker(multiselectEnable);
    	}else if($('#statusPost').val() == 9){
    		$('#hmsporwfci').show(200);
            $('#hmspReason').selectpicker('destroy');
            var hmspreasonsForGP = new Array();
            var hmspreasons = {14661: "Select Reason", 14701: "Credentials are not available", 14711: "Credentials provided are invalid", 19991: "ISP Details", 19992: "Out of SCOPE"};
            $.each(hmspreasons, function(key, val) {
            	hmspreasonsForGP.push("<option id = " + key + " value = '" + val + "'>" + val + "</option>");
            });
            $('#hmspReason').html(hmspreasonsForGP);
            $('#hmspReason').selectpicker(multiselectEnable);
    	}else{
    		$('#hmsporwfci').hide(200);
    	}
    }

});

$('#btnSubmit').on('click', function() {
    setTimeout(parent.$.colorbox.close(), 10000);
});


$('#esclactionHide').on('click', function() {
    $('#esc_matrix').toggle();
});

$('input#customNofi').on('click', function() {
    var val = $(this).val();
    if (val == 'Notes') {
        $('select#customoptions').show();
    } else {
        $('select#customoptions').hide();
    }
});

$('body').on('click', '#psaIntegartions', function() {
    ticketStatusId = $(this).attr('data-ticketstatus');
    mspId = $(this).attr('data-msp');
    $.ajax({
        type: 'POST',
        url: "/ticket/pasIntegration/?_ajax=true",
        data: {
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val(),
            ticketId: $('#ticketIds').val(),
            ticktStId: ticketStatusId,
            priority: priorty
        },
        beforeSend: function() {
            $('span.value:contains("0000")').html('Request is in queue');
            $('.emptyStatus').parent('span.value').html('<span class="mspStatus">Request is in queue</span>');
            $(".mylink").hide()
        },
        complete: function() {
             var getMSP = $.ajax({
                            type: 'GET',
                            url: '/ticket/getMSPID/?_ajax=true',
                            data: {
                                ticketId: $('#ticketIds').val(),
                                csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
                            },
                            success: function(data) {
                                /* if (data.resultMSP[0][0] != null && data.resultMSP[0][0] != '0000') { */
                                if (!($.inArray(data.resultMSP[0][0][0], mspid_checks))) {
                                    $('.mspStatus').html('<span class="mspStatus">data.resultMSP[0][0]</span>');
                                    $(".myvaluecheck").attr("value", data.resultMSP[0][0][0]);
                                }
                            },
                            error: function(){
                                setInterval(getMSP, 30000);
                            },
                            complete: function(){
                                clearInterval(getMSP);
                            }
                        });
        },
        success: function(data) {
            console.log(data.resURL);
        }
    });
});

function getMSPIDAJAX() {
    $.ajax({
        type: "GET",
        url: '/ticket/getMSPID/?_ajax=true',
        data: {
            ticketId: $('#ticketIds').val(),
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
        },
        success: function (data) {
            console.log(data.resultMSP[0][0][0]);
            console.log(data.resultMSP[1][0].fieldvalue);
            console.log(alertStats);
            alertsStatus = data.getalertsCount;
            /* if (data.resultMSP[0][0] != null && data.resultMSP[0][0] != '0000') { */
            if (!($.inArray(data.resultMSP, mspid_checks))) {
                $('span.value:contains("0000")').html(data.resultMSP[0][0]);
                $('span.value:contains("Request is in queue")').html(data.resultMSP[0][0]);
                $('.mspStatus').html(data.resultMSP[0][0]);
                $("myvalue").hide();
                $('.vistaraStatus').html(data.resultMSP[1][0].fieldvalue);
            } else {
                setTimeout(getMSPIDAJAX, 30000);
            }
        }
    });
}

var checkValue = function(){
    if ($('span.value').text().indexOf('0000') !== -1) {
        getMSPIDAJAX();
    }
};

var checkValueafterTicketCreate = function(){
    if ($('span.value').text().indexOf('Request is in queue') !== -1){
        getMSPIDAJAX();
    }
};

var checkVistaraIncident = function(){
    if ($('.vistaraStatus').text() === "Request is in queue"){
        getMSPIDAJAX();
    }
};
$(window).load(function(){
    window.setTimeout(checkValue, 3000)
    window.setTimeout(checkValueafterTicketCreate, 5000)
    window.setTimeout(checkVistaraIncident, 5000)
});


function customFiledsData() {
    $.ajax({
        type: "POST",
        url: "/ticket/customFieldsView/",
        data: {
            'tktId': ticketId,
            'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
        },
        success: function(data) {
            $('#customfiedDetails').html(data.html);
        }
    });
}

function auditLog() {
    var tId = $('#tId').val();
    if (tId == undefined || tId == '' || tId == null) {
        tId = ticketId;
    }
    $.ajax({
        type: "GET",
        url: "/ticket/auditLog/" + tId + "/?_ajax=true",
        beforeSend: function() {
            /*$('a#auditLogRF').hide();*/
            $('span#loadAudit').show();
        },
        complete: function() {
            $('span#loadAudit').hide();
            /*$('a#auditLogRF').show();*/
        },
        success: function(data) {
            $('#auditLog').html(data.html);
            $('#auditLog').show();
        },
    });
}

function loadTicketNotes(loadStatus) {
    var tId = $('#tId').val();
    if (tId == undefined || tId == '' || tId == null) {
        tId = ticketId;
    }
    $.ajax({
        type: "GET",
        url: "/ticket/loadNotes/" + tId + "/?_ajax=true",
        beforeSend: function() {
            $('span#loadAudit').show();
        },
        complete: function() {
            $('span#loadAudit').hide();
        },
        success: function(data) {
        	/*if (loadStatus == true && data.notesINfo.length > 0 ){
        		$('.displaydevicenotes').slideUp();     
                $('.billingEntries').slideUp();
                $('.displaynotes').slideToggle();
        	}*/	
	            html = ''
	            flag = 0
	            html = '<table class="table table-hover table-bordered" id="tbl_auditlog">'
	            html += '<thead><tr><th>Description</th><th>Note By</th><th>Date</th></tr></thead>'
	            html += '<tbody>'
	            if (data.notesINfo.length >0 ){
	            	$.each(data.notesINfo, function(index, value) {
		                flag += 1
		                if (flag % 2 == 0)
		                    html += "<tr class='even'>"
		                else
		                    html += "<tr class='odd'>"
		                html += '<td>' + value.note + '</td>'
		                html += '<td>' + value.bStName + '</td>'
		                html += '<td>' + value.dLine + '</td>'
		            });
		            html += '</tbody>'
		            html += '</table>'
		            $('#notesContent').html(html);
		            $('#displaynote').show();	
	            }
	            
        	
        },
    });
}

/* Below function to display Billing entries */
function loadBillingEntries(loadStatus) {
    var tId = $('#tId').val();
    if (tId == undefined || tId == '' || tId == null) {
        tId = ticketId;
    }
    $.ajax({
        type: "GET",
        url: "/ticket/loadBillingEntries/" + tId + "/?_ajax=true",
        beforeSend: function() {
            $('span#loadAudit').show();
        },
        complete: function() {
            $('span#loadAudit').hide();
        },
        success: function(data) {
	        $('#billingContent').html(data.billingData);
            $('#billingEntry').show();
        },
    });
}