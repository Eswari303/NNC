$(document).ready(function() {
    $('[data-toggle="tooltip"]').tooltip();
    var flagHasFormValidation = true
    $('.error_text').find('a.closethis').on('click', function() {
        $('.error_text').slideUp('slow');
        flagHasFormValidation = true
    });

    $("div.desc").hide();
    $("input[name$='schType']").click(function() {
        var test = $(this).val();
        $("div.desc").hide();
        $("div.defdesc").hide();
        $("#" + test).show();
    });
    $('#btnSubmit').click(function() {
        if ($('#weeklyEvery').val() > 3) {
            $('#myAlert').slideDown('slow');
            $('#divErrorMsg').html('Week value should be between 1 and 3');
            flagHasFormValidation = false;
        }
        if ($('#endAfter').val() == 0) {
            $('#myAlert').slideDown('slow');
            $('#divErrorMsg').html('Please enter no of occurences');
            flagHasFormValidation = false;
        }
        return flagHasFormValidation
    });
});