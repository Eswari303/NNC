var config = {
	enterMode : CKEDITOR.ENTER_BR,
	removeButtons: 'Image,Anchor,Image,About,Maximize,NumberedList,BulletedList,Source',
	height : '400px',
	disableNativeSpellChecker : false,
	scayt_autoStartup : true,
	scayt_sLang : 'en_US',
};
CKEDITOR.replace('ticketContent',config); 
$(document).ready(function(){
	
	var file_c=0;
	
   	/* Predefined Replies to be added to Editor. */
    $('body').on('click','li#predef',function(){
    	predefid = $(this).attr('predef_id'); 
    	  	
		$.ajax({
			type: 'POST',
			url: "/serviceManagement/predefinedReplyData/?_ajax=true",
			data: {
				'predefid' :predefid,
				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
			},
			beforeSend: function (){
	            /*$('span#atload').show(); */
	        },
	        complete: function(){
	        	/*$('span#atload').hide(); */
	        },
			success: function (data){ 
				
				var newContent = existingContent = '';
				newContent = data.replace(/(\r\n|\n\r|\r|\n)/g, "<br>");  
				CKEDITOR.instances['ticketContent'].focus();
				existingContent = CKEDITOR.instances['ticketContent'].getData();
				CKEDITOR.instances['ticketContent'].setData(existingContent + newContent);	
			}
        });
	});
   	
   	
  /* KnowledgeBase Replies to be added to Editor. */
    $('body').on('click','#kba',function(){
    	kbaid = $(this).attr('kba_id');
		$.ajax({
			type: 'POST',
			url: "/serviceManagement/kbaReplyData/?_ajax=true",
			data: {
				'kbaid' :kbaid,
				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
			},
			
			success: function (data){
				
				var newContent = existingContent = '';
				newContent = data.replace(/(\r\n|\n\r|\r|\n)/g, "<br>");  
				CKEDITOR.instances['ticketContent'].focus();
				existingContent = CKEDITOR.instances['ticketContent'].getData();
				CKEDITOR.instances['ticketContent'].setData(existingContent + newContent);
	           	
			}
        });
	});

  
    $('body').on('click', '#createAtt', function(){
    	$('#uploadPostReplyFile').trigger('click');
    });

    $('body').on('change', '#uploadPostReplyFile', function(){
    	
    	$('span#attachmentload').show();
    	 $("form#frmUploadFile").ajaxForm({
    		 beforeSend: function (){
             	$('span#atload').show();
     	    },
     	    complete: function(){
     	    	$('span#atload').hide();
     	    },
    		success: function (data){	
    			
    			display_file(data,file_c++);
    			$('span#attachmentload').hide();
    		}
    	}).submit();
    });
    function display_file(data,file_c){
        if(data)
        {
        	
            $('div#attach_div').append('<span id="fobj_'+file_c+'" data="'+data+'"class="btn btn-primary btn-small space" style="color:blue" >'+data+'<i class="fa fa-close"></i></span>');
        }
    }
    $(document).on('click','#attach_div span .fa-close',function(){
        var nam = $(this)[0];
        console.log($(nam.parentElement).attr('data'));
        $.ajax({
            type: "POST",
            url: '/serviceManagement/delattachment',
            data: {'attDynamic':$('#attDynamic').val(),'fname':$(nam.parentElement).attr('data'),'csrfmiddlewaretoken':$('input[name=csrfmiddlewaretoken]').val()},
            beforeSend: function (){
            	$('span#atload').show();
    	    },
    	    complete: function(){
    	    	$('span#atload').hide();
    	    },
            success: function(response){
                $(nam.parentElement).remove();
            }
        });
    });


  $('#massUpdateSave').on('click',function(){
	  var attachments = new Array(); 
	  var regExNum = /^[0-9]+$/;
	  $('#myAlert').hide();
		for (i = 0; i < file_c; i++) {
			attachments.push($('#fobj_'+i).text());
		}
	
		ticketId  = $('#ticketIDs').val();
		priorty = $('#priortyId').val();
		deptments =$('#deptId').val();
		status = $('#status').val();
		owners = $('#ownersId').val();
		postContent = CKEDITOR.instances['ticketContent'].getData();
		timeworkedout = $('#timeworked').val();
		billabletime  = $('#billabe').val();
	
		
		if(timeworkedout =='' || timeworkedout == null ){
			$('#myAlert').slideDown('slow');
	    	$('#divErrorMsg').html("Please enter Time Worked");
	    	document.getElementById('timeworked').value = '1';
			return false;	
		}
		else{
			if(!(regExNum.test($("#timeworked").val())))
			{
				$('#myAlert').slideDown('slow');
		    	$('#divErrorMsg').html("Please enter valid Time Worked");
				return false;
			}
		}
		if($("#billabe").val()!='' || $("#billabe").val()!= null ){
			if ((regExNum.test($("#timeworked").val())) && (regExNum.test($("#billabe").val())))
			{
				if(parseInt($("#timeworked").val()) < parseInt($("#billabe").val())){
					$('#myAlert').slideDown('slow');
			    	$('#divErrorMsg').html("Time Billable should be lessthan Time Worked");
					return false;
				}
			}
		}
	 $.ajax({
         type: "POST",
         url: '/serviceManagement/massUpdate',
         data: {ticketId:ticketId,priorty:priorty,deptments:deptments,status:status,owners:owners,postContent:postContent,timeworkedout:timeworkedout,billabletime:billabletime,attDynamic:$('#attDynamic').val(),'csrfmiddlewaretoken':$('input[name=csrfmiddlewaretoken]').val(),'attachments':attachments},
         beforeSend: function (){
 			$('span#postLoading').show();
 	    },
 	    complete: function(){
 	    	$('span#postLoading').hide();
 	    },
         success: function(data){
        	parent.$.notification({class:'success_notify', notification:'massupdate_success', time: 5000, autohide: true}); 
        	parent.$.colorbox.close(); 
         },
 		error: function () {
 			parent.$.notification({class:'error_notify', notification:'massupdate_failed', time: 5000, autohide: true});
        }
     });
  });
  
  $('#hideMassUpdate').on('click',function(){
	  parent.$.colorbox.close();
  });
  
  $('.error_text').find('a.closethis').on('click', function(){
	$('.error_text').slideUp('slow');
  });
  
  
  
}); 