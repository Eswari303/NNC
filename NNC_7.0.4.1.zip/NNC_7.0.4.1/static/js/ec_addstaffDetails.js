$('.closethis').on('click', function() {

    $('.error_text').slideUp('slow');
});


$('body').on('click', '#esclationSave', function() {
    var isValidated = true
    subDepatment = $(this).attr('data-subdetp');
    flagmessage = false;
    staffidSaveId = $('#staffidSave').val();
    var errorMsgs = new Array();
    if (staffidSaveId == 1) {
        errorMsgs.push("Please select employee ");
        isValidated = false;
    }
    if (!isValidated) {
        var html = '';
        $.each(errorMsgs, function(i, message) {
            html += '<ul><i class="icon-warning-sign"></i> ' + message + '</ul>';
        });
        $('#alertwarning').html(html);
        $('#alert').show();
        return false;
    } else {

        $("#alert").hide();

    }


    if (!flagmessage) {

        $.ajax({
            type: 'POST',
            cache: false,
            data: {
                sdId: subDepatment,
                stId: staffidSaveId,
                csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
            },
            url: '/escalationContacts/saveStaffDetails/',
            success: function(data) {
                parent.$.notification({
                    class: 'success_notify',
                    notification: 'Record_is_updated',
                    time: 5000,
                    autohide: true
                });
                window.setTimeout(function() {
                    location.reload();
                }, 2000);
            },
            error: function() {
                parent.$.notification({
                    class: 'error_notify',
                    notification: 'Record_is_notupdated',
                    time: 5000,
                    autohide: true
                });
            }
        });
    }
});

$('body').on('click', '#delescalation', function() {
    var esccontactid = '';
    esccontactid = $('#escDeletecontacts option:selected').val();
    isValidated = true
    var errorMsgs = new Array();
    if (esccontactid == 1) {
        errorMsgs.push("Please select employee ");
        isValidated = false;
    }
    if (!isValidated) {
        var html = '';
        $.each(errorMsgs, function(i, message) {
            html += '<ul><i class="icon-warning-sign"></i> ' + message + '</ul>';
        });
        $('#alertwarning').html(html);
        $('#alert').show();
        return false;
    } else {

        $("#alert").hide();

    }
    $.ajax({
        type: 'POST',
        cache: false,
        data: {
            'contactid': esccontactid,
            datalist: $('#schform').serialize(),
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
        },
        url: '/escalationContacts/deleteEscContact/',
        success: function(data) {
            parent.$.notification({
                class: 'success_notify',
                notification: 'Record_delete',
                time: 5000,
                autohide: true
            });
            window.setTimeout(function() {
                location.reload();
            }, 2000);
        },
        error: function() {
            parent.$.notification({
                class: 'error_notify',
                notification: 'Record_delete_fail',
                time: 5000,
                autohide: true
            });
        }
    });
});


$('body').on('click', 'input#editid', function() {
    $('#saveButton').show();
    $('#CancelButton').show();
    $('#editid').hide();
    $('#displayAlertnum').show();
    $('span#hidedisplaydata').hide();
    $('#priortyIdhide').show();
});


$('body').on('click', '#saveButton', function() {
    var staffId = $(this).attr('data-id');
    var priorty = 0;
    var contactNum = $('#alternate').val();
    if ($('#priorty').is(":checked")) {
        priorty = $('#priorty').val();
    }

    isValidated = true
    var errorMsgs = new Array();

    $.ajax({
        type: 'POST',
        cache: false,
        data: {
            contactNum: contactNum,
            priorty: priorty,
            staffId: staffId,
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
        },
        url: '/escalationContacts/savealertnum/',
        success: function(data) {
            $('#mySuccessNotify').append("Alternative Number saved successfully");
            $('#mySuccessNotify').show();

            $('#editid').show();
            $('#CancelButton').hide();
            $('#saveButton').hide();
            $('#displayAlertnum').hide();
            $('#alternate').val();
            $('#hidedisplaydata').show();
            $('#priortyIdhide').hide();
            parent.eval('$.colorbox.close();');
            location.reload();
        },
    });

});


$('body').on('click', '#CancelButton', function() {
    $('#saveButton').hide();
    $('#CancelButton').hide();
    $('#editid').show();
    $('#displayAlertnum').hide();
    $('#hidedisplaydata').show();
    $('#priortyIdhide').hide();
});

$(document).ready(function() {

    if ($('tbody tr').length == 3) {
        $('#esclationSave').prop("disabled", true);
        $('#esclationSave').attr('title', 'Maximum you can add 3 persons only ');
    } else {
        $('#esclationSave').prop("disabled", false);
    }

    $("#escDeletecontacts > option").each(function() {
        if (this.value != 1) {
            $("#staffidSave option[value='" + this.value + "']").each(function() {
                $(this).remove();
            });
        }
    });




    /* Initialise the table */
    $("tbody").tableDnD({
        onDragClass: "selRow",
        onDrop: function(table, row) {
            count = $('td.countlist').length;
            var j = 1;
            for (i = 0; i <= 3; i++) {
                $($('span.countlist')[i]).text(j);
                $($('.loadPriorty')[i]).val(j);
                j = j + 1;
            }
            $.ajax({
                type: 'POST',
                cache: false,
                data: {
                    datalist: $('#schform').serialize(),
                    csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
                },
                url: '/escalationContacts/savepriortyorder/',
                success: function(data) {
                    parent.$.notification({
                        class: 'success_notify',
                        notification: 'Record_order_change',
                        time: 5000,
                        autohide: true
                    });
                },
                error: function() {
                    parent.$.notification({
                        class: 'error_notify',
                        notification: 'Record_order_fail',
                        time: 5000,
                        autohide: true
                    });
                }
            });

        },

    });
});



function phonenumber(inputtxt) {

    var phoneno = /^\d{10}$/;
    if ((phoneno.test(inputtxt))) {
        return true;
    } else {
        return false;
    }
}