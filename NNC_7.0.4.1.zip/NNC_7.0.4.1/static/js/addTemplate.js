$(document).ready(function() {

    var flagHasFormValidation = true
    $('.error_text').find('a.closethis').on('click', function() {
        $('.error_text').slideUp('slow');
        flagHasFormValidation = true
    });

    $('input[name="schType"]').on('change', function() {
        if ($('input[name="schType"]:checked').val() == 'Runnow') {
            $('#hideRunNow').hide();
        } else {
            $('#hideRunNow').show();
        }
    });


    $('[data-toggle="tooltip"]').tooltip();
    $('body').on('click', '#btnSubmit', function() {
        if ($('#weeklyEvery').val() > 3) {
            $('#myAlert').slideDown('slow');
            $('#divErrorMsg').html('Week value should be between 1 and 3');
            flagHasFormValidation = false;
        }
        if ($('#tokens').val() == '') {
            $('#myAlert').slideDown('slow');
            $('#divErrorMsg').html('Please select template');
            flagHasFormValidation = false;
        }
        if ($('#endAfter').val() == 0) {
            $('#myAlert').slideDown('slow');
            $('#divErrorMsg').html('Please enter no of occurences');
            flagHasFormValidation = false;
        }
        return flagHasFormValidation
    });

    $('#tokens').on('change', function() {
        var selected = $(':selected', this);
        if ('Public' == selected.closest('optgroup').attr('label')) {
            $("#hideemils").hide();
        } else if ('Private' == selected.closest('optgroup').attr('label')) {
            $("#hideemils").show();
        }
    });



    $("div.desc").hide();
    $("#Daily").show();
    $("input[name$='schType']").click(function() {
        var test = $(this).val();
        $("div.desc").hide();
        $("#" + test).show();
    });

});