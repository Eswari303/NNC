var config = {
	enterMode : CKEDITOR.ENTER_BR,
	removeButtons: 'Image,Anchor,Image,About,Maximize,NumberedList,BulletedList,Source',
	height : '400px',
	disableNativeSpellChecker : false,
	scayt_autoStartup : true,
	scayt_sLang : 'en_US'
};
CKEDITOR.replace('ticketContent',config);
var mspId = $('#partners').val();
var clientId = $('#clients').val();
/* Mails used by custom features for particular clients */
var cdi_supportmail = ",CDI-support@netenrich.com"
/*var Electro_Switch_Corp_mail = ",pip@bemisworldwide.com"*/
$(function(){
	var utc =  moment.utc(new Date());
	var pst = moment(utc).zone('-0700');
	var fromdate = pst.format('YYYY-MM-DD HH:mm');
	var optionsFromDt = {
  	icons: {
        time:"fa fa-clock-o",
           date: 'fa fa-calendar',
           up:'fa fa-arrow-up',
           down: 'fa fa-arrow-down'
       },
       sideBySide: true,
      defaultDate: fromdate
	};
    $('#alertInCOm').datetimepicker(optionsFromDt);
});


$(document).ready(function() {
	var multiselectOptions = {maxHeight: 200,
        			 		  numberDisplayed: 1,
        			 		  enableFiltering: true,
        			 		  enableCaseInsensitiveFiltering: true,
        			 		  includeFilterClearBtn: false,
        					};
	var selectedprior = $('#selectedPriorities option:selected').val(); 
	
   $('#partners').on('change',function(){	
	   mspId = $(this).val();
	   $.ajax({
    		type: "POST",
    		url: "/ticket/partnerAjax?_ajax=true",
    		data: {
    			'res_cli' : $('#partners').val(),
    			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
    		},
    		beforeSend: function (){
		       $('span#lodingClient').show();
		    },
		    complete: function(){
		       $('span#lodingClient').hide();
		       /* Custom Feature:: for the partner comm-works to disable the WFPI */
		       if(mspId == 619913 || mspId == 570823){
 				   $('#grpStatus option[value=9]').attr("disabled",true);
 				   $('#grpStatus').selectpicker('refresh');
    			}else{   
    			   $('#grpStatus option[value=9]').attr("disabled",false);
  				   $('#grpStatus').selectpicker('refresh');
    			}
		    },
    		success: function(data){
    			$('#clients').selectpicker('destroy');
    			var datalist = new Array();
    			$.each(data.clients,function(key,val){
    				datalist.push("<option value = "+val.mspclientid+">"+val.clientname+"</option>");
    			});
    			$('#clients').html(datalist);
    			$('#clients').selectpicker();
    		},
    	});
    });
    $('#clients').on('change',function(){   
    	clientId = $(this).val();
    	$.ajax({
    		type: "POST",
    		url: "/ticket/clientAjax?_ajax=true",
    		data: {
    			'res_devices' : $('#clients').val(),
    			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
    		},
    		beforeSend: function (){
 		       $('span#lodingDevice').show();
 		    },
 		    complete: function(){
 		       $('span#lodingDevice').hide();
 		      
 		    },
    		success: function(data){
    			$('#devices').selectpicker('destroy');
    			var datalist = new Array();
    			datalist.push("<option value = 0 selected>Others</option>");
    			$.each(data.devices,function(key,val){
    				datalist.push("<option value = "+val.id+">"+val.device_name+"</option>");
    			});
    			$('#devices').html(datalist);
    			$('#devices').selectpicker();
    			/* removing this feature as per request*/
    			/*Custom Feature: For the client of Alternative Technology group as mail 
    			 * need to be added to cc list when priority in critical while ticket creation placed this because of default value for priority is critical*/
    			/*if(clientId == 558536 && selectedprior == 8){    		    	 
    		    	 $('#ccEmailId').tokenfield('setTokens',Electro_Switch_Corp_mail); 
    		     }else{
    		    	$('#ccEmailId').tokenfield('setTokens',[]); 
    		    	$('#ccEmailId').val('');
    		     }*/
    		}
    	});
    });
    
    /*Predefined Replies to be added to Editor. */
    $('body').on('click','#predef',function(){
       	predefid = $(this).attr('predef_id');
    	$.ajax({
    		type: 'POST',
    		url: "/ticket/predefinedReplyData/?_ajax=true",
    		data: {
    			'predefid' :predefid,
    			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
    			},
    		beforeSend: function (){
    	           /*$('span#load_msg').show(); */
    	    },
    	    complete: function(){
    	      	/*$('span#load_msg').hide(); */
    	    },
    		success: function (data){   
    	       	var newContent = existingContent = '';				
    			newContent = data.replace(/(\r\n|\n\r|\r|\n)/g, "<br>");  
    			CKEDITOR.instances['ticketContent'].focus();
    			existingContent = CKEDITOR.instances['ticketContent'].getData();
    			CKEDITOR.instances['ticketContent'].setData(existingContent+newContent);
    		}
        });
    });

    /*KnowledgeBase Replies to be added to Editor. */
    $('body').on('click','#kba',function(){
      	kbaid = $(this).attr('kba_id');
    	$.ajax({
    		type: 'POST',
    		url: "/ticket/kbaReplyData/?_ajax=true",
    		data: {
    			'kbaid' :kbaid,
    			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
    		},    		
    		success: function (data){
    			var newContent = existingContent = '';
    			newContent = data.replace(/(\r\n|\n\r|\r|\n)/g, "<br>");  
    			CKEDITOR.instances['ticketContent'].focus();
    			existingContent = CKEDITOR.instances['ticketContent'].getData();
    			CKEDITOR.instances['ticketContent'].setData(existingContent + newContent);
    		}
        });
    });
      
    $('select#incidenttype').on('change',function(){
    	var type= $(this).val();
      	if(type == 14){
      		$('div#QOSDiv').show();
      	}else{
      		$('div#QOSDiv').hide();
      	}
      		
      	if(type == 10 || type == 12 || type == 13){
      		$('div#integrationDiv').show();
      	}else{
      		$('div#integrationDiv').hide();
      	}      	  
      });
        
    $('body').on('click','#checkalertId',function(){
    	var chek  = $(this).val();
        if (chek == 'system'){
        	$('#alertInput').hide();  
        }else{
        	$('#alertInput').show();  
        }	
     });
          
     $('#department').on('change',function(){
    	 detId = $(this).val();
         $.ajax({
        	 data:{deptId:detId,csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()},
        	 type:'POST',
        	 url:'/ticket/customfeildGroupids',
        	 success:function(data){
        		var deptId = data.deptId;        	
        		$.ajax({
        			type:'POST',
        			url:'/ticket/linkcustomfieldView/',
        			data:{view:deptId,
        				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
        			},
        			beforeSend: function (){
        				$('span#editCutomColumns').show();
        				$('div#linkedGroups').empty();
        			},
        			complete: function(){
        			   	$('span#editCutomColumns').hide();
        		    },
        			success:function(data){
        				$('div#linkedGroups').append(data.html);
        			},        						
        		}); 
        	},	 
        });	
     });
     /* custom feature:: For the partners CDI and Alternative Technology group 
      * CDI: CDI support mail should be added when status in WFCI/WFPI
      */
     $('body').on('change','#grpStatus',function(){
    	 var status = $('#grpStatus').val();    	 
    	 if((mspId == 109612 || mspId == 590253)&& (status == 9 || status == 46)){    		 
    		 $('#ccEmailId').tokenfield('setTokens',cdi_supportmail);
     	 }else{
     		 $('#ccEmailId').tokenfield('setTokens',[]);
     		 $('#ccEmailId').val('');
     	 }
    	     	 
     });
     /*removing this feature as per request*/
     /* For the client of Alternative Technology group: when priority in Critical client support mail should be added.*/
     /*$('body').on('change','#selectedPriorities',function(){    	 
    	 var prioirty = $('#selectedPriorities').val();    	 
    	 if((clientId == 558536) && prioirty == 8){    		
    		$('#ccEmailId').tokenfield('setTokens',Electro_Switch_Corp_mail);
    	 }else{
    		$('#ccEmailId').tokenfield('setTokens',[]); 
    		$('#ccEmailId').val('');
    	 }
    	 
     });*/
 });
        
function uploadFile(file) {
  	data = new FormData();
    data.append('file', file);
    data.append('csrfmiddlewaretoken', $("input[name=csrfmiddlewaretoken]").val());
    $.ajax({
         data: data,
         type: "POST",
         url: "/ticket/uploadImage",
         cache: false,
         contentType: false,
         processData: false,
         complete: function(){
    	      	$('#uploadImgStatus').remove();
    	 },
         success: function(url) {
          	/* $('#ticketContent').summernote('insertImage', url); */
         }
     });
 }      	