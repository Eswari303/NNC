/*
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
*/
var tickets;
/* bellow code from NNCGlobal.html*/
/*$('#template_hide').hide();
$('.hideSlamForm').hide();*/
$(function() {
	$(window).load(function(){
		loadWidgets();
		/*NEBOTemployeeInfo();*/
	});
	$('.error_text').find('a.closethis').on('click', function(){
		$('.error_text').slideUp('slow');
	});
});
$(function(){ 
	  $('#click-me').on("click", function(e) {
	    bootbox.alert("Close the bootbox", function() {
	        console.log("Alert Callback");
	    });
	  });
});
 
function maximizeFilterWindow() {
    $('.chat-history').css('height', '450px');
    $('#live-chat').css('width', '900px');    
}
 $(document).ready(function(){

	 /* to show quick edit for NEBOT */
	 $('body').on('click', '#NBticketUp', function(){
	    var ticketid =$(this).attr('data-ticket');
	    $("#NBtktUpd").show();
	 }); 
	 /* to clear chat history */
	 $("#NBclearChat").click(function(){
	  	$(".chat-history").empty();
	  	return false;
	 }); 
	 var draggableDiv = $('.drag2').draggable();
	 $('.chat', draggableDiv).mousedown(function(ev) {
	      draggableDiv.draggable('disable');
	 }).mouseup(function(ev) {
	      draggableDiv.draggable('enable');
	 });
	 /* minimize the size of NEBOT */
	 $('#min').on('click', function() {
         $('#operator_avatar').fadeIn(100, 'swing');
         $('#live-chat').fadeOut(100, 'swing');
	 });
     $('#chatOpen').on('click', function() {
         $('#live-chat').fadeIn(100, 'swing');
         $('#operator_avatar').fadeOut(100, 'swing');
     });  
	 /* to show quick edit */
     $('#NBticketUp').click(function() {
         $('#ticketD').toggle(200);    
     });
	 /* maximize the size of NEBOT  */
	 $('#max').click(function(){
	     maximizeFilterWindow();
	 });
	 function maximizeFilterWindow() {
	     $('.chat-history').css('height', '450px');
	     $('#live-chat').css('width', '900px');    
	 }
	  
     /*to show quick edit for NEBOT */
     $('body').on('click', '#NBticketUp', function(){
      var ticketid =$(this).attr('data-ticket');
      $("#NBtktUpd").show();
     }); 
	 /* to clear chat history */
	  $("#NBclearChat").click(function(){
	  	 	$(".chat-history").empty();
	  	 	return false;
	  }); 
	  
	/* popbox for new tickets */
 	$('.popupbox').delay(2000).slideDown();
 	$('.clickable').on('click',function(){
 	    var effect = $(this).data('effect');
 	        $(this).closest('.popupbox')[effect]();
 	});
	  
	 $('#NBsearch_chat').keypress(function (e) {

	  var key = e.which;
	  if(key == 13) 
	   {
	     e.preventDefault();
	     /*$('#btnRun').trigger('click');*/
	 	var sampleData =$('#NBsearch_chat').val();		
	     var date = new Date();		
	     var hours = date.getHours();		
	 	var minutes = date.getMinutes();		
	 	var ampm = hours >= 12 ? 'pm' : 'am';		
	 	hours = hours % 12;		
	 	hours = hours ? hours : 12; /* the hour '0' should be '12'		*/
	 	minutes = minutes < 10 ? '0'+minutes : minutes;		
	 	var strTime = hours + ':' + minutes + ' ' + ampm;
	     /*$('.chat-history').append("<p style='text-align:right;width:100%'>"+$('#NBsearch_chat').val()+"</p>");*/
	     $('.chat-history').append('<div class="chat-message clearfix"><div class="chat-message-content clearfix">');
	     /*$('.chat-history').append('<h5>'+$('#NBsearch_chat').val()+'</h5>');*/
	 	$('.chat-history').append('<html><h5><body><table width =100% ><tr><td align = "left">'+sampleData+'</td><td align="right">'+strTime+'</td></table></body></h5></html>');
	     $('.chat-history').append('</div></div>');
	     $.ajax({
		     type: "POST",
		     /* url: '/ticket/NBsearch_chat',*/
		     url: '/NEBOT/NBsearch_chat',
		     data:{'ele':$('#NBsearch_chat').val(),'csrfmiddlewaretoken':$('input[name=csrfmiddlewaretoken]').val()},
		     dataType : "text",
	         success: function(response){
	             $('.chat-history').append('<div class="chat-message clearfix">');
	             $('.chat-history').append('<p>'+response+'</p>');
	             $('.chat-history').append('</div>');
	             /* on successful response we are scrolling down chat history */
	             var elem = document.getElementById('NBid_chatbox');
	             elem.scrollTop = elem.scrollHeight;
	         }
	     });
	     $('#NBsearch_chat').val('');
	   }

	 }); 

	 
	$("Tooltip").tooltip({html:true});
  	$('[data-toggle="tooltip"]').tooltip();
  	$('[data-toggle=offcanvas]').click(function() {
	$('.row-offcanvas').toggleClass('active');
	$('.right-aside-container').stop().fadeToggle(750);
	$('#NBticketUpInfo').toggle();
  	});
  
  $('body').on('click', '#NBticketUpInfo', function(){
  	var status = ($(this).attr('data-Status'));
  	var TicketId = $(this).attr('data-ticketid');
  	var Department = ($(this).attr('data-Department'));
  	var Priority = ($(this).attr('data-Priority'));
  	var Owner = ($(this).attr('data-Owner'));
  	$.ajax({
    type: "POST",
    url: '/NEBOT/NBsearch_first',
    data:{TicketId:TicketId,status:status,Department:Department,Priority:Priority,Owner:Owner,csrfmiddlewaretoken:$('input[name=csrfmiddlewaretoken]').val()},
    dataType : "text",
        success: function(data){
            $('#quickeditinfo_'+TicketId+'op').html(data);
			$('#quickeditinfo_'+TicketId+'op').toggle();
        }
    });
  	
  });
});

$('body').on('click', '#quickUpdatebot', function(e){
		e.preventDefault();
		var ticketid = $(this).attr('data-TicketId');
		var form_id = "form_"+ticketid;
		$.ajax({
			type: "POST",
			url: "/NEBOT/NBsearch_updatebot?_ajax=true",
			data: {
				'ticketid':	ticketid,
				'priority':$('span#quickeditinfo_'+ticketid+'op #tokensPriority').val(),
				'status':$('span#quickeditinfo_'+ticketid+'op #tokensStatus').val(),
				'departmentid':$('span#quickeditinfo_'+ticketid+'op #tokensDept').val(),
				'ownerid':$('span#quickeditinfo_'+ticketid+'op #tokensOwner').val(),
				csrfmiddlewaretoken : $("input[name=csrfmiddlewaretoken]").val()
			},
			beforeSend: function (){
				$('span#quickUpdateLoadingbot').show();
				$('#quickUpdatebot').attr('disabled',true);
			},
		    complete: function(){		    	
		    	$('span#quickUpdateLoadingbot').hide();
		    	$('#quickUpdatebot').attr('disabled',false);
		    	$('#quickeditinfo_'+ticketid+'op').html('');
		    },
			success: function(data){				
				$('#mySuccessNotifybot #divErrorMsg').show();
				$('.chat-history').html(data);
			},
			
		});		
});
/* #############################  Default NEBOT Info    ############################## */
/*$(document).ready(function() {
	$('#operator_avatar').click(function() {
	NEBOTemployeeInfo();
	 });	
});*/
function NEBOTemployeeInfo(){
  var test = ''; 
  $.ajax({	
	    type: "POST",
  		url: "/NEBOT/NBprioritiesInfo?_ajax=true",
        data: {'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()},
        success: function (data) {
            $("#NBid_chatbox").html(data); /* this statment will fill `<p id="avg_rating">` with value you return from Django view */
        }
  });
  /* setTimeout('NEBOTemployeeInfo()',1,800,000);
	setInterval(function() {
		NEBOTemployeeInfo();
	},60000) */
}	

/* ########################   POPUP MEASSAGE   ################################### */
$(document).ready(function(){
	/* NEBOTpopupInfo(); */
});
function NEBOTpopupInfo(){
	  $.ajax({	
		    type: "POST",
    		url: "/NEBOT/NBpopupmeassage?_ajax=true",
	        data: {'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()},
		    success: function (data) {
			   if (data.flag == 1){
				    html = '';
				   	var ticketIDNB = (data.ticketid);
				   	$('#pop-upshowingNB').hide();
				 	html += '<a target="_blank" href="/ticket/view/'+ticketIDNB+'">'+ticketIDNB+'</a>';
				 	$('span#tickeiid_NB').html(html);					   	
		            $('span#subject_NB').text(data.subject);
		            usernameNB = 'New Ticket is assigned to you ('+(data.userName)+')';
		            $('span#usernameNB').text(usernameNB);
		            $('span#priority_NB').text(data.priority);
		        	console.log(data); /* response is value which you return from Django view */
		             /* $(".new-Ticket").html(data); this statment will fill `<p id="avg_rating">` with value you return from Django view */
		        	$('#pop-upshowingNB').show();
		        	
		       }else{
		    	   	 $('#pop-upshowingNB').hide();
		       	} 
		}
	        
	  });
	  setTimeout('NEBOTpopupInfo()',30000);
}	
	

$('body').on('click', '#closeBtn', function(){
	$('#pop-upshowingNB').hide();
});
/* above code from NNCGlobal.html*/
var Notifications = {
    "schedular_saved_successfully": "Scheduler saved successfully",
    "error_schedular_not_saved": "Scheduler does not saved successfully",
    "template_saved_successfully": "Template \'{TEMPLATE_NAME}\' saved successfully",
    "template_updated_successfully": "Template \'{TEMPLATE_NAME}\' updated successfully",
    "exceed_limit": "Sorry! You have exceeded maximum limit",
    "error_template_not_saved": "Template \'{TEMPLATE_NAME}\' does not saved successfully",
    "unsubscribe_success": "You have successfully unsubscribed from this report",
    "runnow_scheduled_successfully": "Report scheduled successfully. You will get report in mail shortly",
    "runnow_scheduled_fail": "Sorry! Unable to schedule report. Please try again",
    "review_success": "Your review has been submitted successfully",
    "review_fail": "Sorry! Unable to submit your review",
    "request_form_success": "Request form has been submitted successfully",
    "request_form_failed": "Sorry! Unable to submit your request form",
    "perosnal_data_updated": "Your personal information is updated",
    "invalid_data_updated": "Please provide valid data",
    "mapping_successfully": "Mappings updated successfully",
    "release_message": "Legacy NNC will be deactivated from 31st  of October 2016. Requesting to please use NNC Portal for the Ticketing Operations and for any challenges or concerns please email to nnc-tickets@netenrich.com",
    "postreply_failled": "Your post reply failed to send. Please try again.<br> {errorMsg}<a id='postReplyHrefMailTo' href=''></a>",
    'post_updated_successfully':'Transaction completed successfully',
    "quickupdate_failled": "Ticket update failed. Please try again",
    "quickupdate_success": "Ticket updated successfully",
    "data_added_success": "Data saved successfully", /* Used it for SDM Tracker forms */
    "data_added_failed": "Data not saved successfully", /* Used it for SDM Tracker forms */
    "data_updation_success": "Data updated successfully", /* Used it for SDM Tracker forms */
    "data_updation_failed": "Data not updated successfully", /* Used it for SDM Tracker forms */
    "data_removal_success": "Data removed successfully", /* Used it for SDM Tracker forms */
    "data_removal_failed": "Data not removed successfully", /* Used it for SDM Tracker forms */
    "notes_failed" : "Sorry! Failed to add your Note",
    "notes_success" : "Note added successfully",
    'scheduled_report_download' : 'Your requested report will send to {EMAIL}',
    'Record_save_fail':'Sorry! Unable to save contact',
	'Record_order_change':'Contact level is changed',
	'Record_order_fail':'Sorry! Unable to change contact level',
	'Record_delete':'Contact deleted successfully',
	'Record_delete_fail':'Sorry! Unable to delete contact',
	'Record_is_updated':'Contact saved successfully',
	'Record_is_notupdated':'Record is not updated',
	'subDepartmentUpdated':'Service level information is updated successfully',
	'subDepartmentNotUpdated':'Error: Unable to update service level',
	'subDepartmentSaved':'Service level information is saved successfully',
	'subDepartmentNotSaved':'Error: Unable to save service level',
	'subDepartmentDelete':'Service level deleted',
	'subDepartmentNotDelete':'Error: Unable to delete service level',
	'record':'You Can Not Add more Than Three Employees ',
	'massupdate_success':'Tickets updated successfully',
	'massupdate_failed':'Tickets not updated',
	'sdm_tracker_failed':'Oops! Something went wrong, Please try again',
	'unauthorized_access': 'Unauthorized access', /* Warning notification - Unauthorized access for SDM Tracker */
	'add_partner_success': 'Partner details saved successfully', /* Used in SDM Tracker for ADD Partner */
	'add_partner_failed': 'Partner details not saved successfully', /* Used in SDM Tracker for ADD Partner */
	'postreply_warning':'Oops! There are some exceptions while creating your post. Please check your post content',
	'ticketPostNotification':'New post added to this ticket. Please check',
	'add_billing_success': 'Billing entry saved successfully', /* Used in Ticket app for Billing entry Success case */
	'add_billing_failed': 'Billing entry not saved successfully', /* Used in Ticket app for Billing entry Failure case */
	'updated_with_attachment_failed':'Ticket updated with attachment failed.<br> {errorMsg}',
	'post_updated_fileupload_failed': 'Ticket updated with attachment failed',
	"quick_update_validation_failled": "Ticket update failed <br> {errorMsg}",
	'mspid_info': "MSP ID has been generated.",
	'processing_notify':'<i class=\"fa fa-spinner faa-spin animated\"></i> Processing ...',
};
var regExValidation = {
	    isEmailAddress:function(str) {
	        var pattern =/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
	        return pattern.test(str);  /* returns a boolean */
	    },
	    isNotEmpty:function (str) {
	        var pattern =/\S+/;
	        return pattern.test(str);  /* returns a boolean */
	    },
	    isNumber:function(str) {
	        var pattern = /^\d+$/;
	        return pattern.test(str);  /* returns a boolean */
	    },
	    isSame:function(str1,str2){
	        return str1 === str2;
	    }
};   

function getwidgettickets(val)
{
        cs = $('input[name=csrfmiddlewaretoken]').val();
        return  $.ajax({
	      		type: "POST",
	      		url: "/serviceManagement/getwidgetTickets/",
	      		data: {'csrfmiddlewaretoken':cs,'departments':val.deptid,'wdg_type':val.wdgtTyp},
	      		success: function(resultData){}
        	});
}

function loadWidgets(){
$('#slide1').attr('class','item active');
$('#slide2,#slide3,#slide4').attr('class','item');
	$.ajax({
		type: "POST",
		url: "/noiseDashboard/flashWidgets/",
		data: {
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
		},
		success: function(data){
			var widCount = 1;
			$('div.wid-priority').html('');
			$.each(data.widgetsRes,function(key,val){
				tickets=val.tickets;
				if(val.wdgtTyp == 1 && val.count > 0){
					w1html = '<a  href="javascript:void(0)"  data="'+tickets+'"><b class="label label-danger">P0</b><span class="badge badge-green blink_me" id="bin30minp0">'+val.count+'</span> <span class="wtext">Breach in 30m</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w1html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 2 && val.count > 0){
					w2html = '<a  href="javascript:void(0)"  data="'+tickets+'"><b class="label label-danger">P0</b><span class="badge badge-green blink_me" id="bin30minp0">'+val.count+'</span> <span class="wtext">No update from last 30 mins</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w2html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 8 && val.count > 0){
					w3html = '<a  href="javascript:void(0)"  data="'+tickets+'"><b class="label label-success">P1</b><span class="badge badge-red blink_me" id = "bin30minp1">'+val.count+'</span> <span class="wtext">Breach in 30m</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w3html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 9 && val.count > 0){
					w4html = '<a  href="javascript:void(0)"  data="'+tickets+'"><b class="label label-success">P1</b><span class="badge badge-red blink_me" id = "bin30minp1">'+val.count+'</span> <span class="wtext">No update from last 30 mins</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w4html);
					widCount = widCount+1;
				}
				/*if(val.wdgtTyp == 3 && val.count > 0){
					w5html = '<a  href="javascript:void(0)" data="'+tickets+'"><i class="fa fa-bell fa-fw fa-lg icon"></i><span class="badge badge-red blink_me" id="scheduled">'+val.count+'</span><span class="wtext">Scheduled Ticket(s) Starts in 60m</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w5html);
					widCount = widCount+1;
				}*/
				if(val.wdgtTyp == 4 && val.count > 0){
					w6html = '<a  href="javascript:void(0)"  data="'+tickets+'"><i class="fa fa-clock-o fa-lg icon"></i><span class="badge badge-green blink_me" id="hmsp">'+val.count+'</span> <span class="wtext">HMSP Ticket(s) wihtout PSA Ticket</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w6html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 5 && val.count > 0){
					w7html = '<a  href="javascript:void(0)" data="'+tickets+'"><i class="fa fa-bell fa-fw fa-lg icon"></i><span class="badge badge-red blink_me">'+val.count+'</span><span class="wtext">Un-assigned ticket(s) crossed 30 mins</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w7html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 6 && val.count > 0){
					w8html = '<a  href="javascript:void(0)"  data="'+tickets+'"><i class="fa fa-clock-o fa-lg icon"></i><span class="badge badge-green blink_me">'+val.count+'</span> <span class="wtext">New status ticket(s) crossed 60 mins</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w8html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 7 && val.count > 0){
					w9html = '<a  href="javascript:void(0)"  data="'+tickets+'"><b class="label label-danger">RD</b><span class="badge badge-green blink_me">'+val.count+'</span> <span class="wtext">RD status ticket(s) crossed 30 mins</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w9html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 10 && val.count > 0){
					w10html = '<a  href="javascript:void(0)"  data="'+tickets+'"><i class="fa fa-bell fa-fw fa-lg icon"></i><span class="badge badge-green blink_me" id="scheduled">'+val.count+'</span> <span class="wtext">Scheduled - Task Ticket(s) breach in 60 mins</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w10html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 11 && val.count > 0){
					w11html = '<a  href="javascript:void(0)"  data="'+tickets+'"><b class="fa fa-bell fa-fw fa-lg icon"></b><span class="badge badge-green blink_me" id="scheduled">'+val.count+'</span> <span class="wtext">Scheduled - Observation Ticket(s) breach in 60 mins</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w11html);
					widCount = widCount+1;
				}
			});
			if((widCount-1)>9){
				console.log(widCount);
			}
			else if((widCount-1)<=9){
				$('#slide4').removeAttr( "class" );
			}
			else if((widCount-1)<=6){
				$('#slide3').removeAttr( "class" );
				$('#slide4').removeAttr( "class" );
			}
			else if((widCount-1)<=3){
				$('#slide2').removeAttr( "class" );
				$('#slide3').removeAttr( "class" );
				$('#slide4').removeAttr( "class" );
			}
			else{
				$('#slide1').removeAttr( "class" );
				$('#slide2').removeAttr( "class" );
				$('#slide3').removeAttr( "class" );
				$('#slide4').removeAttr( "class" );
			}
		},
	});
setTimeout(function(){loadWidgets()}, 600000);
}

$('#aboutNNC').click(function() {
	$.ajax({
		type: "GET",
		url: "/employeeDashboard/showAppVersion/",
		success: function(data){
			$('#resultVer').html('Version '+data);
		},
	});
});



function slamResultsByTickets(data,templateName){
    $('#template_hide input[name = "idTypeValue"]').val('');
	$('#template_hide input[name = "selectedStatuses"]').remove();
	$('#template_hide input[name = "ticket-status"]').remove();
	$('#template_hide input[name = "templatename"]').val('');
	$('#template_hide input[name = "custom"]').remove();
	    
	original=$('#slamform').html();
	var url = $(location).attr('href');
	$('#template_hide #daysSelected').val('');
	custom = ['SLA Resolution','Ticket Id','Priority','Department','Owner','Status','Created Date (PDT)','Subject','Requester','Last Update (PDT)','Time Worked (Min)','Client Name','Partner Name','Device Name'];
	if(url.search('serviceManagement') == -1){
		for(i=0;i<custom.length;i++)
			$('#template_hide').append("<input  type='hidden' name='custom' id='st_type' value='"+custom[i]+"'>");
		$('#template_hide').append("<input type='hidden' id='st_type' name='statusType' value='current'>");
	}
	active=Array(1,7,12,18,19,21,22,23);
	$('#template_hide').append("<input id='st_typ' type='hidden' name='ticket-status' value='active'>");
    
    if(templateName == "Scheduled - Task Ticket(s) breach in 60 mins" || templateName == "Scheduled - Observation Ticket(s) breach in 60 mins"){
    	$('#template_hide').append("<input id='st_typ' type='hidden' name='selectedStatuses' value='16'>");
    }else{
    	for(i=0;i<active.length;i++)
        	$('#template_hide').append("<input id='st_typ' type='hidden' name='selectedStatuses' value='"+active[i]+"'>");
    }
	$('#template_hide input[name = "idTypeValue"]').val(data);
	$('#template_hide input[name = "templatename"]').val(templateName);
	$('#template_hide').submit();
	$('#slamform').html(original);
}

$(document).on('click','div.wid-priority a',function(){
        data=this.attributes.data.textContent;
        templateName= $(this).find('.wtext').text();
        slamResultsByTickets(data,templateName);
});

$('body').on('click', 'a#requestForm', function(){
	url = "/requestForm/showRequests/";
	$.colorbox({href:url, width:'1180px', height:'580px', iframe:true});	
});

$('body').on('click', '#submitRequest', function (e){
	 $.ajax({
		type: 'POST',
		url: "/requestForm/newRequest/?_ajax=true",
		data:{
			'sponsorEmail': $("input[name=sponsorEmail]:checked").val(),
			csrfmiddlewaretoken : $("input[name=csrfmiddlewaretoken]").val(),
		},
		beforeSend: function (){
			$('#submitRequest').attr('disabled',true);
		},
		complete: function(){
			$('#submitRequest').attr('disabled',false);
		},
		success: function(data){
			parent.eval("$.colorbox.close();");
		},
	}); 
});
$('body').on('keypress', '#openTicket[data-action="open_ticket"]', function (e) {
	var key = e.which;
	if(key == 13){
		var val = $.trim($(this).val());
		if(regExValidation.isNumber(val)){
			console.log('open '+val+' in new window');
			url = '/ticket/view/'+val;
			window.open(url, '_blank');
		}
	}
});

/* Validation for email ids to avoid email ids other than company and client mailids in post reply/Neinternal */
$('body').on('change', '#toEmailId,#reqEmailId,#ccEmailId', function(e){
	e.preventDefault();
	$('#myAlert').hide();
	$('#divErrorMsg').html("");	
	var tomailids = $('#toEmailId').val();
	var emailids = '';
	if($('#reqEmailId').val()){
		$('#toEmailId').val('');
		emailids = $('#reqEmailId').val();
	}
	if($('#ccEmailId').val()){
		if(emailids){
			emailids = emailids+","+$('#ccEmailId').val();
		}else{
			emailids = $('#ccEmailId').val();
		}
	}
	if(tomailids){
		if(emailids){
			emailids = emailids+","+tomailids;
		}else{
			emailids = tomailids;
		}
	}
	
	if(emailids){
		emailValidation(emailids);
	}
});


function emailValidation(emailids){
	var mspClient = mspId+","+clientId;
	
	$.ajax({
		type: "POST",
		url:  "/ticket/emailValidation?_ajax=true",
		data:{
			'emailids':emailids,
			'mspCleint':mspClient,
			'csrfmiddlewaretoken':$('input[name=csrfmiddlewaretoken]').val()
			
		},
		success: function(data){			
			if(data.externalmails != '' && data.externalmails != 'undefined'){
				$('#myAlert').slideDown('slow');
		    	$('#divErrorMsg').html("<b>"+data.externalmails+"</b>, Please check the email as the email(s) are not the user(s) of Partner or Client nor is in NetEnrich domain.");
		    	return false;
			}
		},
	});
}

$(document).ready(function(){
	var depMappingSession = "{{ request.session.empDeptMap }}";
	if (depMappingSession< 1){
		deptMappings();
	}
	$('body').on('click','#deptMappingId',function(){	
		deptMappings();
	});
	
	function deptMappings(){
		url = "/employeeDashboard/empMapping/";
		$.colorbox({href:url, width:'950px', height:'550px', iframe:true});
	}
});

function prepareCalendar(inputData){
	var options = {
			icons: {
				time:"fa fa-clock-o",
				date: 'fa fa-calendar',
				up:'fa fa-arrow-up',
				down: 'fa fa-arrow-down',
		    },
		    format: 'YYYY-MM-DD HH:mm',
		    /*changeMonth: true,
		    changeYear: true,
		   	pickTime: false,
		    showOtherMonths: true,
		    selectOtherMonths: true,
		    sideBySide: true,
		    */
	};
	if(inputData.defaultDate !='' && inputData.defaultDate != undefined ){
		options.defaultDate = inputData.defaultDate;
	}
	if(inputData.maxDate !='' && inputData.maxDate != undefined){
		options.maxDate = inputData.maxDate;
	}
	if(inputData.minDate !='' && inputData.minDate != undefined){
		options.minDate = inputData.minDate;
	}
	if(inputData.format !='' && inputData.format != undefined){
		if((inputData.format.indexOf(':') == -1)){
			options.pickTime = false;
		}else{
			options.sideBySide = true;
		}
		options.format = inputData.format;
	}
	if(inputData.htmlId !='' && inputData.htmlId != undefined ){
	    $('#'+inputData.htmlId).val(inputData.defaultDate);
	    $('#'+inputData.htmlId).datetimepicker(options);
	}
}

if($('.mytoggle1').find('li').hasClass('active')){
		$('.mytoggle1').addClass('active');
}
if($('.mytoggle2').find('li').hasClass('active')){
		$('.mytoggle2').addClass('active');
}
if($('.mytoggle3').find('li').hasClass('active')){
		$('.mytoggle3').addClass('active');
}
if($('.mytoggle4').find('li').hasClass('active')){
		$('.mytoggle4').addClass('active');
}

/*
jQuery.fn.simulateClick = function() {
    return this.each(function() {
        if('createEvent' in document) {
            var doc = this.ownerDocument,
                evt = doc.createEvent('MouseEvents');
            evt.initMouseEvent('click', true, true, doc.defaultView, 1, 0, 0, 0, 0, false, false, false, false, 0, null);
            this.dispatchEvent(evt);
        } else {
            this.click();  IE Boss!
        }
    });
}*/