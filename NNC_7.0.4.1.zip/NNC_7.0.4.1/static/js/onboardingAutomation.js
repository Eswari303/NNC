/* * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
*/
var refreshFlag = true;
var AutoDeviceTypeId = 0;
var AutoTimeInterval = 0;
var timerFlag = 0;
var tempTime;
$(document).ready(function() {
var d = new Date();
currentDate = $.datepicker.formatDate('dd-M-yy', d);
var dataTableOptions = {
    paging: true,
    info: false,
    dom: 'Bfrtip',
    processing: true,
    buttons: [    
	    {
/*	        extend: 'excel',
	        filename: 'OBValidationChek_partnerDeatils_'+currentDate,
	        text: 'Export to Excel',
	        extension: '.xlsx',
	        exportOptions: {
	            modifier: {
	                page: 'all'
	            }
	        },
	        className: 'btn btn-success',
	        title: 'PartnerDeatils'*/
	    } 
	],
}; 
var table = $('#partnerDatatable').DataTable(dataTableOptions);

$('body').on('click','button#repoExcelDownload',function (event) {
	var mspids = $("form#repo_form").serialize();
	console.log(mspids);
    url= "/OBValidationCheck/repoExcelDownload?id="+1+"&partnerIds="+encodeURIComponent(mspids);
    open(url);
});
autoRefresh();

$('#partners').on('change',function(){
	$.ajax({
			type: "POST",
			url: "/OBValidationCheck/partnerAjax?_ajax=true",
			async: true,
			data: {
				'partnerId' : $('#partners').val(),
				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
			},
			beforeSend: function (){
			       $('span#loadingClients').show();
			       $('#test').hide();
			       $('button#saveToRepository').hide();
			       $('#clientCheckpointsDownload').hide();
		       },
		    complete: function(){
		    	   $('span#loadingClients').hide();
		       },
			success: function(data){
					$('#clients').selectpicker('destroy');
					var datalist = new Array();
					$.each(data.clients,function(key,val){
						datalist.push("<option value = "+val.mspclientid+" data-subtext= "+val.mspname+">"+val.clientname+"</option>");
						
					});
					$('#clients').html(datalist);
					$('#clients').selectpicker('refresh');
			},
	});
		
});

$('#goForClientsDeviceData').on('click',function(){
	var isValidated = true;
	var errorMsgs = new Array();
	if ($('#clients').val() == ''){
		errorMsgs.push("Please select client name.");
		isValidated = false;	
	}
	if(!isValidated){				
		var html = '';
		$.each(errorMsgs, function(i, message){
			html += '<ul><i class="icon-warning-sign"></i> '+message+'</ul>';
		});
		$('#obv_alertwarning').html(html);
		$('#obv_alert').show();
		return false;
	}else{
		$('#obv_alertwarning').html('');
		$('#obv_alert').hide();
	}
	if(isValidated){
		$('#obv_mySuccessNotify').hide();
		var clientId = $('#clients').val();
		var partnerId = $('#partners').val();
		getDeviceTypeTabData(clientId,partnerId);	
	}
});

$('body').on('click','#btnSubmit',function(){
	deviceTypeId = $(this).attr('data-did');
	var reportLoading =  'span#loadingReportNow_'+deviceTypeId;
	$.ajax({
		type: "POST",
		url: "/OBValidationCheck/checkList?_ajax=true",
		async: true,
		data: {
			'clientId' : $('#clients').val(),
			'partnerId' : $('#partners').val(),
			'deviceTypeId' : $(this).attr('data-did'),
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
		},
		beforeSend: function (){
			$(reportLoading).show();
			var generateButtonNname = 'generateReport_'+deviceTypeId;
			$('button[name="'+generateButtonNname+'"]').attr('disabled',true);
			$('button[name="'+generateButtonNname+'"]').text("Populating Report");
		},	       
		complete: function(){
			/*$('span#loadingReportNow').hide();*/
			$(reportLoading).hide();
			AutoDeviceTypeId = deviceTypeId;
			getDeviceData(deviceTypeId);
		},
		success: function(data){
			console.log(data);
		},
	});
});

$('body').on('click', '.dummyTest a', function(){
	clearTimeout(tempTime);
	var clientId = $('#clients').val();
	var partnerId = $('#partners').val();
    var deviceTypeId = $(this).attr('data-dvtpId');
    AutoDeviceTypeId = deviceTypeId;
    if (deviceTypeId != null && deviceTypeId != undefined){
    	tabContent = $.trim($('#tabContent #tab_'+deviceTypeId+' .boxPanel').text());
    	if (tabContent == ''){
    		getDeviceData(deviceTypeId);
    	}
    }
});
$('body').on('click','#firstSetCountId,#secondSetCountId',function (event) {
	var clientId = $('#clients').val();
	var partnerId = $('#partners').val();
    var temp = $(this).attr("data-chekOption");
    dataArray = temp.split(';');
    console.log(dataArray);
    var url = "/OBValidationCheck/countsForm/?clientId="+clientId+"&partnerId="+partnerId+'&deviceTypeId='+dataArray[0]+'&clientCheckListId='+dataArray[2]+'&checklistId='+dataArray[3]+'&optionString='+encodeURIComponent(dataArray[1]); 	
    $.colorbox({href:url,  width:'1200px', height:'610px'});
});
$('body').on('click','#refButton',function (event) {
	var deviceTypeId = $(this).attr("data-refrsh");
	var clientId = $('#clients').val();
	var partnerId = $('#partners').val();
	AutoDeviceTypeId = deviceTypeId;
	var numberOfSelectedTab = $('#tabSett a[href="#tab_'+deviceTypeId+'"]').parent().index();
    if (deviceTypeId != null && deviceTypeId != undefined){
 	    getDeviceData(deviceTypeId);
    }
});

$('body').on('click','#btnSetInterval',function (event) {
	AutoRefresh = true;
	var interval = $('#refreshInterval').val(); 
	var deviceTypeId = $(this).attr("data-autoRefrsh");
	AutoDeviceTypeId = deviceTypeId;
	AutoTimeInterval = interval;
	var clientId = $('#clients').val();
	var partnerId = $('#partners').val();
    if (deviceTypeId != null && deviceTypeId != undefined){
 	    getDeviceData(deviceTypeId);
    }
});

$('body').on('click','#downloadReport',function (event) {
	var clientId = $('#clients').val();
	var partnerId = $('#partners').val();
    var temp = $(this).attr("data-chckId");
    dataArray = temp.split(';');
    console.log(dataArray);
    deviceTypeId = dataArray[0];
    clientCheckListId = dataArray[1];
    checklistId = dataArray[2];
    url= "/OBValidationCheck/excelDownload?id="+1+"&clientId="+clientId+"&partnerId="+partnerId+"&deviceTypeId="+deviceTypeId+"&clientCheckListId="+clientCheckListId+"&checklistId="+checklistId;
    open(url);
});	

$('body').on('click','button#clientCheckpointsDownload',function (event) {
	var clientId = $('#clients').val();
	var partnerId = $('#partners').val();
	var url= "/OBValidationCheck/clientCheckPointsExcelDownload?id="+1+"&clientId="+clientId+"&partnerId="+partnerId;
	open(url);
});

$('body').on('click','button#saveToRepository',function (event) {
	var clientId = $('#clients').val();
	var partnerId = $('#partners').val();
	 $('span#loadingRepo').show();
	console.log('testing in getCountFormData');
	$.ajax({
		type: "POST",
		url: "/OBValidationCheck/saveToRepo?_ajax=true",
		async: true,
		data: {
			'clientId' : clientId,
			'partnerId' : partnerId,
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
		},
		success: function(data){
			/* dataTable = $('#'+datatable).DataTable(dataTableOptions); */
			$('span#loadingRepo').hide();
			$('button#saveToRepository').attr('title', data.lastRepo);
		},
	});
	
});

}); /* end of Document Ready */

function getDeviceTypeTabData(clientId,partnerId,deviceTypeId,deviceTabIndex){
	var html = $('#loadingDeviceTypes').html();
	$.ajax({
		type: "POST",
		url: "/OBValidationCheck/getTabs?_ajax=true",
		async: true,
		data: {
			'clientId' : clientId,
			'partnerId' : partnerId,
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
		},
		beforeSend: function (){
	       if(typeof(deviceTypeId)!=='undefined' && typeof(deviceTabIndex) !=='undefined'){
	    	   $('#tabContent').html(html);
	       }else{
	    	   $('span#loadingDeviceTypes').show();
		       $('#goForClientsDeviceData').hide();
	       }
	    },	       
	    complete: function(){
	       $('#test').show();
	       $('#tabSett').show();
	       $('span#loadingDeviceTypes').hide();
	       $('#goForClientsDeviceData').show();
	    },
		success: function(data){
			$('#test').html(data.tabs);
			deviceTypeId = $('#tabSett .nav-tabs li').attr('data-dvtpId');
			if((deviceTypeId !='' || deviceTypeId != undefined) && data.tabFlag == 1){
				AutoDeviceTypeId = deviceTypeId;
				getDeviceData(deviceTypeId);
			}
			/* $('button#SKUReport').show(); */
			if(data.repoFlag == 1){
				$('button#saveToRepository').show();
				$('#clientCheckpointsDownload').show();
				$('button#saveToRepository').attr('title', data.lastRepo);
			}

		},
	});
}

function getExcelDownload(clientId,partnerId,deviceTypeId,clientCheckListId,checklistId){
	console.log('testing in getCountFormData');
	$.ajax({
		type: "POST",
		url: "/OBValidationCheck/excelDownload?_ajax=true",
		async: true,
		data: {
			'clientId' : clientId,
			'partnerId' : partnerId,
			'deviceTypeId' : deviceTypeId,
			'clientCheckListId': clientCheckListId,
			'checklistId': checklistId,
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
		},
		success: function(data){
			console.log(data);
		},
	});
}

function getDeviceData(deviceTypeId){
	var clientId = $('#clients').val();
	var partnerId = $('#partners').val();
	var refreshing  = false;
	var refreshButton = $('#refButton').html();
	/*$('#refButton').html('');*/
	var refButton="refButton_"+deviceTypeId;
	$('button[name="'+refButton+'"]').html('');
	if(refreshFlag == true && deviceTypeId == undefined ){
		deviceTypeId = AutoDeviceTypeId;
		refreshing = true;
		console.log('in refreshing block');
		console.log(deviceTypeId);
	}else{
		console.log('not in refreshing block');	
	}
	tabContent = $.trim($('#tabContent #tab_'+deviceTypeId+' .boxPanel').text());
	if (tabContent == '' || refreshFlag == true){
		if (tabContent == ''){
			$('#tabContent #tab_'+deviceTypeId+' .boxPanel').html($('#loadingDeviceTypes').html());
		}else{
			$('#dummyRefreshID_'+deviceTypeId).html($('#loadingDeviceTypes').html());
		}
		$.ajax({
			type: "POST",
			url: "/OBValidationCheck/getDeviceTypeData?_ajax=true",
			async: true,
			data: {
				'clientId' : clientId,
				'partnerId' : partnerId,
				'devicetypeId':deviceTypeId,
				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
			},
			success: function(data){
				$('#dummyRefreshID_'+deviceTypeId).html('');
				$('button[name="'+refButton+'"]').html(refreshButton);
				$('#tabContent #tab_'+deviceTypeId+' .boxPanel').html(data[deviceTypeId]);
				if(timerFlag == 0){
					timerFlag = 1;
					tempTime = setTimeout('getDeviceData()', 300000);
				}
			}
		});
	}
}

function autoRefresh(){
	$.ajax({
		type: "GET",
		url: "/OBValidationCheck/validateCounts?_ajax=true",
		success: function(data){
			$('#validateCounts').text(data);
			tempTime = setTimeout('autoRefresh()', 10000);
		},
	});
}