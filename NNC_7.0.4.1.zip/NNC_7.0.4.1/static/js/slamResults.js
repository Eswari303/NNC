/*
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 */
var table;
var defaultOrderForColumn = 1;
var dataTableOptions = {
    'paging': false,
    'info': false,
    "order": [
        [defaultOrderForColumn, "asc"]
    ],
    "columnDefs": [{
        "targets": 0,
        "orderable": false
    }],
    'colReorder': true,
    
};
$(document).ready(function() {
	$('input#checkbox3').attr('checked',false);
	$('input#seltChkBox').attr('checked',false);
	
    $('#lblLastUpdatedDt').text(getCurrentDateTime());
    $('body').on('click', '#radRefresh', function() {
        if ($(this).val() == 1) {
            $("#ticketBrowserRefreshTab").slideDown("slow", function() {});
        } else {
            $("#ticketBrowserRefreshTab").slideUp("slow", function() {});
            clearTimeout();
        }
        onLoadRecordsCount = parseInt($('#clistTbody tr').length);

        TotalTicketsCount = parseInt($('span#TotalTickets').text());
        if (TotalTicketsCount < 50) {
            $('#addMore').remove();
        }
        if (TotalTicketsCount == 0) {
            $('#addMore').remove();
        }


    });

    totalRecord();

    function totalRecord() {

        TotalTicketsCount = parseInt($('span#TotalTickets').text());

        if (TotalTicketsCount < 50) {

            $('#addMore').remove();

        }
        if (TotalTicketsCount == 0) {

            $('#addMore').remove();
        }
    }




    $('body').on('click', '#btnSetInterval', function() {
        $("#ticketBrowserRefreshTab").slideUp("slow", function() {});
        $('#massUpdateId').hide();
        $('#seltChkBox').attr('checked', false);
        updateListView(true);
        TicketCountRefresh(true);

        return false;
    });


    /* Setup - add a text input to each footer cell */
    $('#datatable tfoot td').each(function() {
        var title = $(this).text();
        $(this).html('<input type="text" placeholder="' + title + '"/>');
    });

   /* DataTable */
    table = $('#datatable').DataTable(dataTableOptions);

 
    applyMultiLevelSearchForDataTable();

    totalNoofrecords = parseInt($('#resultCounts').text());
    tableRowlist = $('#clistTbody tr').length;

    if (tableRowlist == totalNoofrecords) {
        $('#addMore').hide();
    } else {

        var i = totalNoofrecords - tableRowlist;
        $('#addMore').text('Show More Records ' + i);
    }

    $('body').on('click', '#addMore', function() {
        updateListView(false);
    });

    $('body').on('click', '#excelDownload', function() {
        var totalRecordDwd = $('span#TotalTickets').text();
        if (totalRecordDwd <= 500) {
            $('#slamform').attr('action', '/serviceManagement/slamResults/?excel=1');
            $('#slamform').attr('target', '_blank').submit();
            return false;

        } else {
            $('#loadingImgDownloadResults').show();
            $('#excelDownload').hide();
            sql = $('span#querySlam').text();
            customColumns = $('span#headersSlam').text();
            csrfmiddlewaretoken = $("input[name=csrfmiddlewaretoken]").val();
            $.ajax({
                type: 'POST',
                url: '/serviceManagement/excelDownload/',
                data: $('form.slamresults').serialize() + '&csrfmiddlewaretoken=' + csrfmiddlewaretoken,
                success: function(response) {
                    //response = $.parseJSON(data)
                    if (response.status == 'success') {
                        $.notification({
                            class: 'success_notify',
                            notification: 'runnow_scheduled_successfully',
                            time: 5000,
                            autohide: true
                        });
                        $('#loadingImgDownloadResults').hide();
                        $('#excelDownload').show();
                    } else {
                        $.notification({
                            class: 'error_notify',
                            notification: 'runnow_scheduled_fail',
                            time: 5000,
                            autohide: true
                        });
                    }
                },
                error: function() {
                    $.notification({
                        class: 'error_notify',
                        notification: 'runnow_scheduled_fail',
                        time: 5000,
                        autohide: true
                    });
                }
            });
        }
    });



    /*   ticket data   */

    $('#seltChkBox').on('click', function() {

        var isStatusCheked = $(this).is(':checked');
        if (isStatusCheked != false) {
            $('.ticketIds').prop('checked', true);
        } else {
            $('.ticketIds').prop('checked', false);

        }
    });



    $('button#massUpdateId').on('click', function() {
        var totCheckedTicket = $('.ticketIds:checked').length;
        var data = new Array();
        if (totCheckedTicket > 0) {

            $('.ticketIds:checked').each(function() {
                data.push($(this).val());
            });
        }
        url = "/serviceManagement/massUpdateView?tikIds=" + data;
        $.colorbox({
            href: url,
            width: '950px',
            height: '550px',
            iframe: true,
            onClosed: function() {
                $('#massUpdateId').hide();
                updateListView(true);
                TicketCountRefresh(true);
               
            }
        });

    });



  


    $('body').on('click', '.ticketIds,#seltChkBox', function() {
        var totlSelect = $('#seltChkBox:checked').length;
        if (totCheckedTicket > 0) {
            $('#massUpdateId').show();
        } else {

        }
        var totalcheckbox = $('.ticketIds').length;
        var totCheckedTicket = $('.ticketIds:checked').length;
        if (totCheckedTicket > 0) {
            $('#massUpdateId').show();
        } else {
            $('#massUpdateId').hide();
        }

        if (totalcheckbox != totCheckedTicket) {
            $('#seltChkBox').attr('checked', false);
        } else {

            $('#seltChkBox').prop('checked', true);
        }
    });




    /* ticket data */

    $($('tfoot tr td input')[0]).attr('style', 'display:none');
    
    
    $('body').on('click', '#closeBtn', function(){
    	$('#pop-upshowingNB').hide();
    });

});


$('body').on('click', '#breachIn_1', function() {
    $('#slamform').attr('action', '/serviceManagement/slamResults/?rals=1');
    $('#slamform').attr('target', '_blank').submit();
    return false;
});


$('body').on('click', '#breachIn_2', function() {
    $('#slamform').attr('action', '/serviceManagement/slamResults/?rals=2');
    $('#slamform').attr('target', '_blank').submit();
    return false;
});

$('body').on('click', '#breachIn_3', function() {
    $('#slamform').attr('action', '/serviceManagement/slamResults/?rals=3');

    $('#slamform').attr('target', '_blank').submit();
    return false;
});


function applyMultiLevelSearchForDataTable() {
    table.columns().every(function() {
        var that = this;

        $('input', this.footer()).on('keyup change', function() {
            if (that.search() !== this.value) {
                that
                    .search(this.value)
                    .draw();
            }
        });
    });

    /* Filtering results for existing query */ 
    colNo = 0;
    $('#datatable tfoot input').each(function(i, v) {
        var val = $.trim($(this).val());
        if (val != '') {
            table.columns(colNo).search(val).draw();
        }
        colNo++;
    })

    if (statusSlaFlag == 'True') {
        $('#datatable thead tr td').each(function() {
            text = $.trim($(this).text())
            hassortingClass = $(this).hasClass('sorting_asc')
            if (text == 'Status' && hassortingClass == false)
                $(this).trigger('click');
        });
    }

}


function updateListView(flagAutoRefresh) {

    offset = (flagAutoRefresh) ? 0 : $('#clistTbody tr').length;

    AutoRfreshCheck = parseInt($('input:radio[id="radRefresh"]:checked').val());
    if (AutoRfreshCheck > 0) {
        urldefined = "/serviceManagement/autoRefresh/"
    } else {
        urldefined = "/serviceManagement/pagination/"
    }

    $.ajax({
        type: 'POST',
        url: urldefined,
        data: {
            sql: $('span#querySlam').text(),
            offset: offset,
            customColums: $('span#headersSlam').text(),
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val()
        },
        beforeSend: function() {
            $('span#loadingNoc').show();
        },
        complete: function() {
            $('span#loadingNoc').hide();
        },

        success: function(data) {
            var tablecontant = ''
            $.each(data.finalData.results, function(key, val) {
                slaResolutionStyle = '';
                tdContent = '';

                $.each(val, function(key11, value21) {
                    if (key11 == 'Ticket Id') {

                        tdContent = '<td><input type="checkbox" value="' + value21.display + '" class="styled ticketIds" id="checkbox3"></td>'
                    }

                });


                $.each(data.finalData.HeaderField, function(keyCheck, valcheck) {

                    
                    $.each(val, function(key1, value2) {
                        
                        if (valcheck == key1) {
                            switch (key1) {
                                case 'Ticket Id':
                                    {
                                        classcode = (value2.classcode == undefined) ? '' : value2.classcode;
                                        display = (value2.display == undefined) ? '' : value2.display;

                                        tdContent += '<td data-toggle="tooltip" data-html="true" data-container="body" data-placement="top" title="Edit ticket in NNC" class="' + classcode + '">';
                                        tdContent += '<a href="/ticket/view/' + display + '" target="_blank"><strong>' + display + '</strong></a>';
                                        tdContent += '</td>';
                                        break;
                                    }
                                case 'SLA Resolution':
                                    {
                                        classcode = (value2.classcode == undefined) ? '' : value2.classcode;
                                        display = (value2.display == undefined) ? '' : value2.display;

                                        slaResolutionStyle = value2.style
                                        tdContent += '<td data-toggle="tooltip" data-html="true" data-container="body" data-placement="top" title="'+value2.Tooltip+'" data-order="' + value2.Order + '" class="' + classcode + '">';
                                        tdContent += '<strong>' + display + '</strong>';
                                        tdContent += '</td>';
                                        break;
                                    }
                                case 'Subject':
                                    {
                                        toopltip = (value2.Tooltip == undefined) ? '' : value2.Tooltip;
                                        classcode = (value2.classcode == undefined) ? '' : value2.classcode;
                                        display = (value2.display == undefined) ? '' : value2.display;

                                        tdContent += '<td data-toggle="tooltip" data-container="body" data-placement="top" data-trigger="hover"  title="' + toopltip + '" data-content="' + toopltip + '">';
                                        tdContent += display.substr(0,11);
                                        tdContent += '</td>';
                                        break;
                                    }
                                case 'Requester':
                                	{
                                	toopltip = (value2.Tooltip == undefined) ? '' : value2.Tooltip;
                                	display = (value2.display == undefined) ? '' : value2.display;
                                	 tdContent += '<td data-toggle="tooltip" data-container="body" data-placement="top" data-trigger="hover"  title="' + toopltip + '" data-content="">';
                                     tdContent += display.substr(0,11);
                                     tdContent += '</td>';
                                     break;
                                	}
                                case 'Device Name':
                                    {
                                        if (value2.deviceid != undefined) {
                                            tdContent += '<td data-toggle="tooltip" data-html="true" data-container="body" data-placement="top" title="Open in Vistara" class="' + value2.classcode + '"  >';
                                            tdContent += '<a href="https://www.mspnocsupport.com/devicePage.do?id=' + value2.deviceid + '" target="_blank"><strong>' + value2.display + '</strong></a>';
                                            tdContent += '</td>';
                                        } else {
                                            tdContent += '<td data-container="body" class="' + value2.classcode + '">';
                                            tdContent += value2.display
                                            tdContent += '</td>';
                                        }
                                        break;
                                    }
                                case 'Partner Name':
                                    {
                                        tdContent += '<td data-toggle="tooltip" data-html="true" data-container="body" data-placement="top" title="Open in Vistara" class="' + value2.classcode + '">';
                                        tdContent += '<a href="https://www.mspnocsupport.com/partnerPage.do?id=' + value2.partnerid + '" target="_blank"><strong>' + value2.display + '</strong></a>';
                                        tdContent += '</td>';
                                        break;
                                    }
                                case 'Client Name':
                                    {
                                        tdContent += '<td data-toggle="tooltip" data-html="true" data-container="body" data-placement="top" title="Open in Vistara" class="' + value2.classcode + '">';
                                        tdContent += '<a href="https://www.mspnocsupport.com/clientPage.do?id=' + value2.clientid + '" target="_blank"><strong>' + value2.display + '</strong></a>';
                                        tdContent += '</td>';
                                        break;
                                    }
                                default:
                                    {
                                        toopltip = (value2.Tooltip == undefined) ? '' : value2.Tooltip;
                                        classcode = (value2.classcode == undefined) ? '' : value2.classcode;
                                        display = (value2.display == undefined) ? '' : value2.display;
                                        tdContent += '<td ';
                                        if (value2.Order != undefined)
                                            tdContent += 'data-order="' + value2.Order + '"';

                                        if (value2.fieldType == 'sladue') {
                                            if (value2.Order < 0)
                                                tdContent += ' class="OD sorting_1"'
                                            else if (value2.Order > 0 && value2.Order < value2.slaTime)
                                                tdContent += 'class="spec-red sorting_1"'
                                            else
                                                tdContent += ' class="TL1 sorting_1"'
                                        }
                                        tdContent += ' style="' + value2.style + '"';

                                        tdContent += ' title ="' + toopltip + '">';
                                        tdContent += '<span class="' + classcode + '">' + display + '</span></td>';

                                        break;
                                    }
                            }
                        }

                    });

                });
                tablecontant += '<tr style="' + slaResolutionStyle + '">' + tdContent + '</tr>';

            });

            table.destroy();

            if (flagAutoRefresh) {
                $('#clistTbody').empty();
                $('#clistTbody').html(tablecontant);
                if ($(".tooltip").length > 0){
                    $(".tooltip").tooltip('destroy');
                }
            } else {
                $('#clistTbody').append(tablecontant);
                totalNoofrecords = parseInt($('span#resultCounts').text());

                tableRowlist = parseInt($('#clistTbody tr').length);
                if (tableRowlist == totalNoofrecords) {
                    $('#addMore').hide();
                } else {
                    var i = totalNoofrecords - tableRowlist
                    $('#addMore').text('Show More Records ' + i);

                }
            }



            totalNoofrecords = parseInt($('span#resultCounts').text());
            tableRowlist = parseInt($('#clistTbody tr').length);
            var i = totalNoofrecords - tableRowlist
            $('#addMore').text('Show More Records ' + i);

            table = $('#datatable').DataTable(dataTableOptions);
            applyMultiLevelSearchForDataTable();

            $('[data-toggle="tooltip"]').tooltip();
            $('[data-toggle="popover"]').popover({
                placement: 'right'
            });

            if (flagAutoRefresh) {
                isRequestRefresh = $('input:radio[id="radRefresh"]:checked').val();
                intervalTime = $('#refreshInterval').val();
                if (isRequestRefresh == 1 && intervalTime > 0) {
                    setTimeout('updateListView(true)', intervalTime * 60 * 1000);

                } else {
                    clearTimeout();
                }
            }

            $('input#checkbox3').attr('checked',false);
        	$('input#seltChkBox').attr('checked',false);
            $('#lblLastUpdatedDt').text(getCurrentDateTime());
        },


    });
}



function showing_all() {
    x = document.getElementById("datatable").rows;
    for (i = 0; i < x.length; i++) {
        $(x[i]).show();
    }
}
$('[data-toggle="tooltip"]').tooltip();
$('[data-toggle="popover"]').popover({
    placement: 'right'

});

function getCurrentDateTime() {
    var d = new Date();
    strTime = $.datepicker.formatDate('mm/dd/yy', d);
    var hours = d.getHours();
    var minutes = d.getMinutes();
    var ampm = hours >= 12 ? 'pm' : 'am';
    hours = hours % 12;
    hours = hours ? hours : 12; /* the hour '0' should be '12' */
    minutes = minutes < 10 ? '0' + minutes : minutes;
    strTime += ' ' + hours + ':' + minutes + ' ' + ampm;
    return strTime;
}


function TicketCountRefresh(AutoRfreshCheck) {
    CountQuerys = $('span#TicketsCOuntQuery').text();
    ticketSla = $('span#ticketsSla').text();
    myTicketsCount = $('span#myTicketsCount').text();
    var settimer;
    AutoRfreshCheck = parseInt($('input:radio[id="radRefresh"]:checked').val());
    if (AutoRfreshCheck > 0) {
        settimer = true;
    } else {
        settimer = false;
    }
    $.ajax({
        type: 'POST',
        url: '/serviceManagement/ticketCountRefresh/',
        data: {
            countQuerys: CountQuerys,
            ticketSla: ticketSla,
            myTicketsCount: myTicketsCount,
            csrfmiddlewaretoken: $("input[name=csrfmiddlewaretoken]").val(),
        },

        success: function(data) {

            totalCountResults = 0;
            $.each(data.results, function(k, v) {
                $('span#breachIn_' + k).text(v);
                totalCountResults = totalCountResults + parseInt(v);
            });
            $('span#TotalTickets').text(totalCountResults);

            intervalTime = $('#refreshInterval').val();
            if (AutoRfreshCheck == 1 && AutoRfreshCheck > 0) {
                setTimeout('TicketCountRefresh(true)', intervalTime * 60 * 1000);

            } else {
                clearTimeout();
            }
        },


    });


}
