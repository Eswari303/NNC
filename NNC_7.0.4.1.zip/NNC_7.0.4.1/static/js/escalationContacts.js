/*
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 */

// Triggers when the 'Manage Service levels' button clicked in Internal Escalation Matrix..
$(document).ready(function(){
	

	$('body').on('click', '#servicelevelIds', function(){
	        serviceurl = "/escalationContacts/service";
	        $.colorbox({href:serviceurl,width:'1000px', height:'600px', iframe:true,
	        	onClosed:function(){
					loadStaffdetails();
					}
	
	        });  
	 });
	
	loadStaffdetails();
	$('body').on('change','#DepartmentsId',function(){
		$('#loadingPartnersData').html('');
		loadStaffdetails();
	});
	
	$('body').on('click', '#subDepartment', function(){
		subDept= $(this).attr('data-id');
		url ="/escalationContacts/addContacts?&deptId="+subDept,
		$.colorbox({href:url,
			width:"1050px", 
			height:"550px", 
			iframe:true,
			onClosed:function(){
					loadStaffdetails();
					}
			});
	});
	
	
	var default_deptid = '';
	default_deptid = $('#DepartmentsId_inner option:selected').val();
	if (default_deptid != undefined){		
		$.ajax({
			type: 'POST',
			url: "/escalationContacts/getServicelevels/"+default_deptid+"/?_ajax=true",
			data: {				
					'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
			},
			beforeSend: function (){			
		    },
		    complete: function(){
		    	$('#loadingdata').hide();
		    },
			success: function (data){
				$('#subdeptlist').html(data);
			}
	    });
	}
	$('body').on('click','#btnedit',function(){
		servicelevelid = $(this).attr('data-id');
		servicename  = $(this).attr('data-name');				
       	details = getCurrentservice_details();       	
      	urlpopup = "/escalationContacts/edit_popup/"+details['departmentid']+"/"+details['departmentname']+"/"+servicelevelid+"/"+servicename;
       	$(location).prop('href',urlpopup);
       	
    });
	
	$('body').on('change', '#DepartmentsId_inner', function(){
		var departmentid = ''
		departmentid = $('#DepartmentsId_inner option:selected').val();
		$.ajax({
    		type: 'POST',
    		url: "/escalationContacts/getServicelevels/"+departmentid+"/?_ajax=true",
    		data: {				
    				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
    		},
    		beforeSend: function (){
    			$('#loadingdata').show();
    	    },
    	    complete: function(){
    	    	$('#loadingdata').hide();
    	    },
    		success: function (data){
    			$('#subdeptlist').html(data);
    		}
        });		
	});

	
    $('body').on('click','#btndelete',function(){    	
     	confirm("Do you really want to delete service?");      	
       	servicelevelid = $(this).attr('data-id');  
       	dept_details = getCurrentservice_details();
       	$.ajax({
    		type: 'POST',
    		url: "/escalationContacts/manipulateService_delete/?_ajax=true",
    		data: {
    				'servicelevelid' : servicelevelid,
    				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
    		},
    		beforeSend: function (){
    			$('#loadingdata').show();
    	    },
    	    complete: function(){
    	    	$('#loadingdata').hide();
    	    },
    		success: function (data){   
    			$('#mySuccessNotify').append("servicelevel deleted successfully");
				$('#mySuccessNotify').show();		
    	       	location.reload();
    		}
        });
       	
     });
    
     $('body').on('click','#btnaddlevel',function(){
       	details = Array();
       	details = getCurrentservice_details();        	
       	url = "/escalationContacts/addServiceLevelpopup/"+details['departmentid']+"/"+details['departmentname']
       	$(location).prop('href',url); 
     });
     
     
     
     
 		$('body').on('click','#btnsubmitservice',function(){
 			var isValidated = true;
 			var errorMsgs = new Array();
 			var servicelevelid = ''; var servicename = '';
 			var departmentid = ''; var servicename_old = '';
 			servicelevelid = $(this).attr('data-id');
 			servicename_old = $(this).attr('data-name');
 			servicename_old = $.trim(servicename_old);			
 			servicename = $('input#ServiceEscalation_service_name').val();
 			servicename = $.trim(servicename);
 			if(servicename_old === servicename){
 				errorMsgs.push("Please enter new service name.");
 				isValidated = false;
 			}
 			if(!isValidated){				
 				var html = '';
 				$.each(errorMsgs, function(i, message){
 					html += '<ul><i class="icon-warning-sign"></i> '+message+'</ul>';
 				});
 				$('#alertwarning').html(html);
 				$('#alert').show();
 				return false;
 			}else{
 				$('#alert').hide();
 			}
 			$.ajax({
 				type: 'POST',
 				url: "/escalationContacts/serviceName_edit/?ajax=true",
 				data: {	'servicename':servicename,
 						'servicelevelid':servicelevelid,
 						'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
 				},
 				beforeSend: function (){
 					$('span#loadingdata').show();
 			    },
 			    complete: function(){
 			    	$('span#loadingdata').hide();
 				},
 				success: function (data){
 				    parent.$.notification({class:'success_notify', notification:'subDepartmentUpdated',time: 5000, autohide: true}); 
 					window.history.go(-1);
 				},
 				error: function () {
 					parent.$.notification({class:'error_notify', notification:'subDepartmentNotUpdated',time: 5000, autohide: true}); 
 				}
 			});
 			
 		});
 		   		
 		$('body').on('click','#btncancel_service',function(){
 			confirm("Do you really want to exit?");   			
 		   	window.history.go(-1);
 		}); 
 		
 		$('body').on('click','#btnsubmit',function(){	
 			var isValidated = true;
 			var errorMsgs = new Array();
 			var servicelevelid = ''; var servicename = '';
 			var departmentid = ''; 			
 			departmentid = $(this).attr('data-deptid');
 			servicename = $('input#ServiceEscalation_service_name').val();					
 			servicename = $.trim(servicename);
 			
 			if(servicename.length == ''){
 				errorMsgs.push("Please enter service name.");
 				isValidated = false;				
 			}
 			if(!isValidated){				
 				var html = '';
 				$.each(errorMsgs, function(i, message){
 					html += '<ul><i class="icon-warning-sign"></i> '+message+'</ul>';
 				});
 				$('#alertwarning').html(html);
 				$('#alert').show();
 				return false;
 			}else{
 				$('#alert').hide();
 			}
 			$.ajax({
 				type: 'POST',
 				url: "/escalationContacts/servicelevel_add/?_ajax=true",
 				data: {	'servicename':servicename,				
 						'departmentid':departmentid,				
 						'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
 				},
 				beforeSend: function (){
 					$('span#loadingdata').show();
 			    },
 			    complete: function(){	
 			    	$('span#loadingdata').hide();
 			    },
 				success: function (data){	
 					parent.$.notification({class:'success_notify', notification:'subDepartmentSaved',time: 5000, autohide: true}); 
 					window.history.go(-1);
 				},
 				error: function () {
 					parent.$.notification({class:'error_notify', notification:'subDepartmentNotSaved',time: 5000, autohide: true}); 
 				}
 			});				
 			
 		}); 
 		
 		$('body').on('click', '.cancel', function(e){
 			e.preventDefault();
 			confirm("Do you really want to exit?");   			
 		   	window.history.go(-1);
 		});
 		
 		$('body').on('click', '.closethis', function(){
 			$('#alert').hide();
 		});
 
  });
	



function loadStaffdetails(){
	var dataList= $('#DepartmentsId').val();
	if (typeof (dataList) != "undefined" ){

		$.ajax({
			type:'GET',
			url:"/escalationContacts/staffDetails",
			data:{deptId:dataList},
			beforeSend: function (){
				   $('#loadingdata').show();
				 },

			complete: function() {
				$('#loadingdata').hide();
			},
			success:function(data){
				$('#loadingPartnersData').html(data.html);
			},
			
		});
	} 

			
}

function getCurrentservice_details(){
  	details = Array();
   	details['departmentname'] =  $('#DepartmentsId_inner option:selected').text();
   	details['departmentid'] = $('#DepartmentsId_inner option:selected').val();    	
   	return details;
  } 
