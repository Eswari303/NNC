/* * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
*/

var calnderType,fromDate,lastDate;
$(document).ready(function(){
   $('.flip').hover(
	 function () {
	   $(this).find('.card').addClass('flipped');
	 },
	 function () {
	    $(this).find('.card').removeClass('flipped');
	 }
	);
	$('[data-toggle="tooltip"]').tooltip();
	$('[data-toggle=offcanvas]').click(function() {
		$('.row-offcanvas').toggleClass('active');
		$('.right-container').stop().fadeToggle(750);
	});
	$('#manDateRange').on('change',function(){
		   if($('#manDateRange').val() == 1){
		    msg = "Tickets-7 Days Back";
		    $('span#dateRangeString').html(msg);
		     } 
		     if($('#manDateRange').val() == 2){
		     msg = "Tickets-CurrentWeek";
		     $('span#dateRangeString').html(msg);
		     } 
		    if($('#manDateRange').val() == 3){
		     msg = "Tickets-Date Range";	
		     $('span#dateRangeString').html(msg);
		     $('#customdates').show();
		     } else {
		      $('#customdates').hide();
		     }
		   });	
			
			$("#btnRun").click(function(){
				var isFormValidated = true;
				var errorMsgs = '';
				calnderType = $('#manDateRange').val();
				if (calnderType == 3){
					fromDate  = $('#fdDates').val();
					lastDate = $('#tdDates').val();
				    if(lastDate < fromDate){
				    	isFormValidated = false;
			        	errorMsgs += "<li>Please select valid date range</li>"
			        }
					if (fromDate >0 && lastDate >0 ){
						flagValue = true;
					}
					
					else {
						flagValue = false;
					}
					
				}
				
				if (flagValue = true){
					loadComplaince(calnderType,fromDate,lastDate);
					teamSlaComp(calnderType,fromDate,lastDate);
					
				}
				if(!isFormValidated){
					var html = '';
					var errMsg = '<ul>'+errorMsgs+'</ul>';
					$('#myAlert').slideDown('slow');
			    	$('#divErrorMsg').html(errMsg);
					return false;
				}else{
					$('#myAlert').hide();
				}
				return true;
				
				
		    });
			
			var dupcounter = 0;
			$('body').on('click', '#skillsedit', function(){
			url = "/managerDashboard/skillsMapping";	
			$.colorbox({href:url,  width:'900px', height:'610px', onClosed:function(){
				 location.reload();
				}
			});	
			});
	
			$('body').on('click', '.del', function(){
				$(this).parent().parent().remove();
			}); 

			$('body').on('click', '.add', function(){
				
				count = dupcounter;
				dupcounter = dupcounter+1;
				
				var dRoster = "ddroster"+dupcounter;
				var dupstaff = "dupstaff"+dupcounter;
				
				var dSkill = "ddskill"+dupcounter;
				var dupskill = "dupskill"+dupcounter;
				
				var dExp = "ddexp"+dupcounter;
				var dupexp = "dupexp"+dupcounter;
				
				var appendTxt2 = "<tr><td id='ddroster'>##RosterDropDown##</td> <td id='ddskill'>##SkillsDropDown##</td> <td id='ddexp'>##ExpTextBox##</td> <td><input type='button' class='btn btn-success add' value='Add' /></td></tr>";
				var appendTxt = "<tr class='detail-row'><td id='"+dRoster+"'>##RosterDropDown##</td> <td id='"+dSkill+"'>##SkillsDropDown##</td> <td id='"+dExp+"'>##ExpTextBox##</td> <td><input type='button' class='btn btn-success add' value='Add' id='add' /></td></tr>";
	
				appendTxt = appendTxt.replace('##RosterDropDown##', $('#ddroster').html());
				appendTxt = appendTxt.replace('##SkillsDropDown##', $('#ddskill').html());
				appendTxt = appendTxt.replace('##ExpTextBox##', $('#ddexp').html());
				
				appendTxt2 = appendTxt2.replace('##RosterDropDown##', $('#ddroster').html());
				appendTxt2 = appendTxt2.replace('##SkillsDropDown##', $('#ddskill').html());
				appendTxt2 = appendTxt2.replace('##ExpTextBox##', $('#ddexp').html());
				
				$('#tblMapping tr:last').remove();
				
				$('#tblMapping tr:last').after(appendTxt);
				$('#tblMapping tr:last').after(appendTxt2);
				
				$('.detail-row'+ ' #add').val('Remove');
				$('.detail-row'+ ' #add').attr('class','btn del');
				
				$("#"+dRoster+" #StaffMapping_staffid").attr('name',dupstaff);
				$("#"+dSkill+" #StaffMapping_skill_id").attr('name',dupskill);
				$("#"+dExp+" #StaffMapping_exp_yrs").attr('name',dupexp);
			
			}); 
			
			var errorMsgs = new Array();
			
			$('.error_text1').find('a.closethis').on('click', function(){
		    	$('.error_text1').slideUp('slow');
		 	});
				
			$('#divErrorMsg1').html('');
		 	$('.error_text1').slideUp('slow');
		
		 	$('#save1').on('click', function(){
		 		var exp = 0;
		 		$('td input[type="text"]').each(function(){
		 			if( $(this).val() != ''){
		 				exp++;
		 			}		 			   
		 		});
		 		
				var numRegExp = /^[0-9\.]+$/;
				var flagNumValidated = true;
				var match = '';
				var sti = $('select#StaffMapping_staffid option[value != \"\"]:selected').length;
				var ski = $('select#StaffMapping_skill_id option[value != \"\"]:selected').length;
				
				var dig,pos,rc;
				dig=pos=rc= 0;		
				$('td input[type="text"]').each(function(){
		 			if($(this).val() != 'Remove' && $(this).val() != '' && $(this).val() !='Add'){
					 	match = numRegExp.test($(this).val());
					  	if(!match && $(this).val()!=null){
							if(dig === 0){
								errorMsgs.push('Please enter valid digits');
								dig=1;
							}
							flagNumValidated = false;
						}
				
					  	if($(this).val() < 0 || $(this).val() === 0 || $(this).val()==''){
							if(pos === 0){
								errorMsgs.push('Experiance must have a value');
								errorMsgs.push('Experiance must be greater than Zero');
								pos=1;
							}
							flagNumValidated = false;
						}
				
						if(sti != ski || sti != exp){
							if(rc === 0){
								errorMsgs.push('Please select full record');
								rc=1;
							}
							flagNumValidated = false;
						}
						
						if(!flagNumValidated){
				    		var html = '<ul>';
				    		$.each(errorMsgs, function(j, message){
				    			html += '<li>'+message+'</li>';
					    	});
					    	html += '</ul>';
						    $('#divErrorMsg1').html(html);
						    $('.error_text1').slideDown('slow');
							errorMsgs = new Array();
						    return false;
						}
				
		 			}	
				});
				
				
				return flagNumValidated;
		 	});
			
					
		$('body').on('click', '#rm', function(){
			 $("body").unbind("click").click('#rm'); /* stop multiple event times firing */
			 skid = $(this).attr('data-skill');
			 stid = $(this).attr('data-staff');
			 $(this).parent().parent().remove();
			$.ajax({
					type: 'POST',
					url: "/managerDashboard/deleteRecord/",
					data:{ski:skid,sti:stid,'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()},
					
					success:function(data){			           				
						$(this).parent().parent().remove();
					},
				 });
		});
		getMdScheduledTickets();
	});
	
$(window).bind('load',function(){
	priorityWidgets();
	bioMeticdetails();
	currentDetails();
	  loadComplaince(calnderType,fromDate,lastDate);
	  hmspAndWficCount();
	  teamTicketInfoFistHeader();
	  teamSlaComp(calnderType,fromDate,lastDate);
	  getIdealsTicketsData();
	  scheduledAndRd();
	  
});

function loadComplaince(calnderType,fromDate,lastDate){
	
	var validation = true;
	var errorMessage = '';
  $('#lodingRes').show(); 
 
  $.ajax({
		type: "POST",
		url: "/managerDashboard/deptSlaComplaiance/",
		data: {
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
			'fromDate':fromDate,
			'toDate':lastDate,
			'calanderType':calnderType,
		},
		beforeSend: function (){
				$('span#lodingRes').show();
		       
		       },
		    complete: function(){
		       $('span#lodingRes').hide();
		       
		       },
		success: function(data){
				
				$.each(data.deptRes,function(emplId,loop1){
					
					$.each(loop1,function(key,loop2){
						$('#'+emplId+key).text(loop2);
					});
				});
				
				$.each(data.totlHeader,function(emplI,loop1){
					
					$('#'+'deptTotal'+emplI).text(loop1);
				});
				
				$("#idClosedP0Tickets").val(data.totalCloased.closedP0tickets);
				$("#idClosedP1Tickets").val(data.totalCloased.closedP1tickets);
				$("#idClosedP2Tickets").val(data.totalCloased.closedP2tickets);
				$("#idClosedP3Tickets").val(data.totalCloased.closedP3tickets);

				$.each(data.totalCloased,function(key,value){
					$('#'+key).text(value);
				});
				$('#tmWrked').text(data.totalWorked);
				$('#utPcent').text(data.utilzation);
				
				
				$('#datasdisaplay').text('( '+data.selectedDates+' )');
				
				setInterval(function() {
						loadComplaince(calnderType,fromDate,lastDate);
					}, 300000)
		},
		
		
  });
  $('#lodingRes').hide();	
  
}



function hmspAndWficCount(){
	
	
	$.ajax({
		type: "GET",
		url: "/managerDashboard/hmspWfci/",
		/*data: {
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
		},*/
		beforeSend: function (){
			$('span#lodingData').show();
	       
	       },
	    complete: function(){
	       $('span#lodingData').hide();
	       
	       },
		success: function(data){
			var ticketids_list = data.hmsp.ticketid;
			var hmspticketdata = "";
			for(var i = 0 ; i <= ticketids_list.length; i++)
			{	
				if (ticketids_list[i] == ticketids_list[ticketids_list.length-1]){
					if (ticketids_list[i] != undefined){
						hmspticketdata += String(ticketids_list[i]);
					}
					
				}
				else{
					if (ticketids_list[i] != undefined){
						hmspticketdata += String(ticketids_list[i]) + ",";
					}
					
				}
				
			}

			$("#idHmspVal").val(hmspticketdata);
			$('#hmspwfciCount').html(data.hmsp.count+' / '+data.wfci.count);
			
			setInterval(function() {
				hmspAndWficCount();
				}, 300000)
		}
	});
	
}
var apres;		
var unass;

function teamTicketInfoFistHeader(){
	
	$.ajax({
		type: "GET",
		url: "/managerDashboard/teamInfoFirstHeader/",
		
		beforeSend: function (){
			$('span#lodingData').show();
	       
	       },
	    complete: function(){
	       $('span#lodingData').hide();
	       
	       },
	
		success: function(data){
			unass = data.unass;					
			apres = data.apres;
			$.each(data.employee,function(emplyeeId,loop1){
				 $.each(loop1,function(headers,loop2){
					$.each(loop2,function(innerHeaders,endResult){
						$('#'+emplyeeId+headers+innerHeaders).text(endResult);
					});
				 });
			});
			
			var activeP0tickets = "";
			var activeP1tickets = "";
			var activeP2tickets = "";
			var activeP3tickets = "";			
			var inactiveP0tickets = "";
			var inactiveP1tickets = "";
			var inactiveP2tickets = "";
			var inactiveP3tickets = "";

			$.each(data.employee, function(employeeid, loop1){
				$.each(loop1, function(headers, loop2){
					if (headers == "Active"){
						$.each(loop2, function( innerHeaders, values){
							if(innerHeaders == "P0tkts"){
								if (values != ""){
									activeP0tickets += values + ",";
								}
							}else if(innerHeaders == "P1tkts"){
								if (values != ""){
									activeP1tickets += values + ",";
								}
							}else if(innerHeaders == "P2tkts"){
								if (values != ""){
									activeP2tickets += values + ",";
								}
							}else if(innerHeaders == "P3tkts"){
								if (values != ""){
									activeP3tickets += values + ",";
								}
							}
						});
					}
					else if(headers == "InActive"){
						$.each(loop2, function( innerHeaders, values){
							if(innerHeaders == "P0tkts"){
								if (values != ""){
									inactiveP0tickets += values + ",";
								}
							}else if(innerHeaders == "P1tkts"){
								if (values != ""){
									inactiveP1tickets += values + ",";
								}
								
							}else if(innerHeaders == "P2tkts"){
								if (values != ""){
									inactiveP2tickets += values + ",";
								}
								
							}else if(innerHeaders == "P3tkts"){
								if (values != ""){
									inactiveP3tickets += values + ",";
								}
							}
						});
					}
				});
			});

			$("#idActiveP0Tickets").val(activeP0tickets);
			$("#idActiveP1Tickets").val(activeP1tickets);
			$("#idActiveP2Tickets").val(activeP2tickets);
			$("#idActiveP3Tickets").val(activeP3tickets);

			$("#idInActiveP0Tickets").val(inactiveP0tickets);
			$("#idInActiveP1Tickets").val(inactiveP1tickets);
			$("#idInActiveP2Tickets").val(inactiveP2tickets);
			$("#idInActiveP3Tickets").val(inactiveP3tickets);


			$.each(data.employeeCounts,function(key,val){
				
				$.each(val,function(header,values){
					$("#"+key+header).text(values);
				});
			});
			
			$.each(data.fisrtHeader,function(key,val){
				$("#"+key).text(val);
			});
			
			$("#idUnAssignedP0Tickets").val(data.fisrtHeader.unassP0Tickets);
			$("#idUnAssignedP1Tickets").val(data.fisrtHeader.unassP1Tickets);
			$("#idUnAssignedP2Tickets").val(data.fisrtHeader.unassP2Tickets);
			$("#idUnAssignedP3Tickets").val(data.fisrtHeader.unassP3Tickets);

			$("span.Tooltip").tooltip({
				html: true
			});
			
			
			setInterval(function() {
		    	   teamTicketInfoFistHeader();
				}, 300000)
		}
	      
	       
	});
	
}


function teamSlaComp(calnderType,fromDate,lastDate){
	$.ajax({
		type: "POST",
		url: "/managerDashboard/teamsla/",
		data: {
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
			'fromDate':fromDate,
			'toDate':lastDate,
			'calanderType':calnderType,
		},
		beforeSend: function (){
			$('span#lodingRes').show();
	       
	       },
	    complete: function(){
	       $('span#lodingRes').hide();
	       
	       },

		success: function(data){
			$.each(data.teamSla,function(empId,lop1){
				$.each(lop1,function(key,val){
					$('#'+empId+'teamSla'+key).text(val);
				});
				
			});
			
			
			$.each(data.totalHeader,function(key,val){
				$('#'+'Total'+key).text(val);
				
			});
			
			setInterval(function() {
				teamSlaComp(calnderType,fromDate,lastDate);
			}, 300000)
		}
	});

}
var idealt;
function getIdealsTicketsData(){
	$.ajax({
		type: "GET",
		url: "/managerDashboard/ideal/",
		beforeSend: function (){
			$('span#lodingData').show();
	       
	       },
	    complete: function(){
	       $('span#lodingData').hide();
	       
	       },
		success: function(data){
			var totalIdetickets = 0;
			var tickets_str = "";
			$.each(data.idealticketslist, function(i){
				if(data.idealticketslist[i] == data.idealticketslist[data.idealticketslist.length -1]){
					tickets_str += data.idealticketslist[i]
				}else{
					tickets_str += data.idealticketslist[i] + ","
				}
			});
			$("#idIdeal").val(tickets_str);
			$.each(data.idealTickets,function(employeid,value){
					$('#'+employeid+'count').text(value.count);
					totalIdetickets = totalIdetickets + value.count;
				
			});
			$('#idealTickets').text(totalIdetickets);
			
			setInterval(function() {
				getIdealsTicketsData();
				}, 300000)
		},
	});
}

var schrd;
function scheduledAndRd(){
	var sd = Rd =0;
	$.ajax({
		type: "GET",
		url: "/managerDashboard/schedule/",
		beforeSend: function (){
			$('span#lodingData').show();
	       
	       },
	    complete: function(){
	       $('span#lodingData').hide();
	       
	       },

		success: function(data){
					schrd=data;

				var scheduled_sdtickets_data = data.schuandRd.sdTicketid;
				var scheduled_rdtickets_data = data.schuandRd.rdTicketid;
				
				var sdtickets_str = "";
				var rdtickets_str = "";

				$.each(scheduled_sdtickets_data, function(i){
					if (scheduled_sdtickets_data[i] == scheduled_sdtickets_data[scheduled_sdtickets_data.length-1]){
						sdtickets_str += String(scheduled_sdtickets_data[i]);
					}else{
						sdtickets_str += String(scheduled_sdtickets_data[i]) + ",";
					}
				});

				/*$("#idScheduled").val(sdtickets_str);*/

				$.each(scheduled_rdtickets_data, function(i){
					if (scheduled_rdtickets_data[i] == scheduled_rdtickets_data[scheduled_rdtickets_data.length-1]){
						rdtickets_str += String(scheduled_rdtickets_data[i]);
					}else{
						rdtickets_str += String(scheduled_rdtickets_data[i]) + ",";
					}
				});

				$("#idResponseDue").val(rdtickets_str);

				if (data.schuandRd.rdTicketid !=undefined ){
					Rd=data.schuandRd.rdTicketid.length;
				}
				   
				   if (data.schuandRd.sdTicketid !=undefined ){
					   sd = data.schuandRd.sdTicketid.length;   
				   }
				   
				   
				   if (Rd>0){
				 
				   }else {
					 Rd = 0;  
				   }
				   
				   if (sd>0){
					  
				   }else {
					   sd = 0;  
				   }
				$('#ResponseDue').text(Rd);
				/*$('#sche').text(sd);*/


				if (data.schuandRd.sdFlag > 0) {
					setInterval(function() {
						$('#sd-itemtoBlink').toggleClass("t-item-red");
					}, 800)
				}
			
		},
	});  
}

/*Priority widgets - P0, P1, P2, P3 assigned and unassigned tickets which breach in 60 minutes*/

function priorityWidgets(){
	$.ajax({
		type: "POST",
		url: "/managerDashboard/priorityWidgets/",
		data: {
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
		},
		success: function(data){
			if(data.assUnassBreachTickets.Total == 0){
    			$("#mngrDboardWidgets").hide('slow');
    		}else{
				$("#mngrDboardWidgets").show('slow');
				/*	counts of breach inata-id=p1unasgt 60 mins*/
				$("a[data-id=p0tkts60mins]").html(data.assUnassBreachTickets.P0_asgn);
				$("a[data-id=p1tkts60mins]").html(data.assUnassBreachTickets.P1_asgn);
				$("a[data-id=p2tkts60mins]").html(data.assUnassBreachTickets.P2_asgn);
				$("a[data-id=p3tkts60mins]").html(data.assUnassBreachTickets.P3_asgn);

				$("a[data-id=p0unasgtkts60mins]").html(data.assUnassBreachTickets.P0_unasgn);
				$("a[data-id=p1unasgtkts60mins]").html(data.assUnassBreachTickets.P1_unasgn);
				$("a[data-id=p2unasgtkts60mins]").html(data.assUnassBreachTickets.P2_unasgn);
				$("a[data-id=p3unasgtkts60mins]").html(data.assUnassBreachTickets.P3_unasgn);

				/* ticket data for breach in 60 mins*/	
				$("a[data-id=p0tkts60mins]").attr('data-searchval', data.assUnassBreachTickets.P0_asgntkts);
				$("a[data-id=p1tkts60mins]").attr('data-searchval', data.assUnassBreachTickets.P1_asgntkts);
				$("a[data-id=p2tkts60mins]").attr('data-searchval', data.assUnassBreachTickets.P2_asgntkts);
				$("a[data-id=p3tkts60mins]").attr('data-searchval', data.assUnassBreachTickets.P3_asgntkts);

				$("a[data-id=p0unasgtkts60mins]").attr('data-searchval', data.assUnassBreachTickets.P0_unasgntkts);
				$("a[data-id=p1unasgtkts60mins]").attr('data-searchval', data.assUnassBreachTickets.P1_unasgntkts);
				$("a[data-id=p2unasgtkts60mins]").attr('data-searchval', data.assUnassBreachTickets.P2_unasgntkts);
				$("a[data-id=p3unasgtkts60mins]").attr('data-searchval', data.assUnassBreachTickets.P3_unasgntkts);
    		
				setTimeout('priorityWidgets(true)', 300000);
    		}
		},
    });
}

function bioMeticdetails() {
	$.ajax({
		type: 'POST',
		url: '/managerDashboard/biometric/',
		data: {
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
		},
		success: function(data) {
			$('#biomerticData').empty();
			$('#biomerticData').html(data.html);
			$('#notTeamAvailable').text(data.teamAvailableCount.nav);
			$('#teamAvailable').text(data.teamAvailableCount.av);
			$("div.Tooltip").tooltip({
				html: true
			});
			setTimeout('bioMeticdetails()', 300000);
		},
	});
}

function currentDetails() {

	$.ajax({
		type: 'POST',
		url: '/managerDashboard/biometricMan/',
		data: {
			/*'uId' : '<%= Session["uId"] %>',*/
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
		},
		success: function(html) {
			var cuet = (html.currtLoc != null) ? html.currtLoc : '';
			var first = (html.firstPunch != null) ? html.firstPunch : '';
			var lst = (html.lastPunch != null) ? html.lastPunch : '';

			if (cuet != '') {
				$('#currtLoc').text(cuet);
				$('#currtLoc').show();
			} else {
				$('#currtLoc').hide();
			}

			if (first != '') {
				$('#fp span').text(first);
				$('#fp').show();
			} else {
				$('#lp').hide();
			}

			if (lst != '') {
				$('#lp span').text(lst);
				$('#lp').show();
			} else {
				$('#lp').hide();
			}
			setTimeout('currentDetails(true)', 300000);
		},

	});
}

$(document).on('click','.Emp_priority',function(){
	var id = $(this).attr('id');
	var st = id.slice(0,id.length-2);
	var pr=id.slice(id.length-2,id.length).toUpperCase();
	var tickets="";
	var map_pr ={'P0':8,'P1':9,'P2':10,'P3':11};
	if(id.search('active')!=-1 || id.search('inactive')!=-1)
	{
		if (id[0]=='t'){
			st=id.slice(1,id.length-2);
		}
		$.each(apres,function(ind,id){
			if(apres[ind][st][pr]>0)
				tickets+=","+apres[ind][st][pr+"tkts"]
		});
	}
	else if(id.search('unass')!=-1){
		$.each(unass,function(dept,val){
			if (val[pr]>0)	tickets+=","+val[pr+"tkts"]
		});
	}
	if(tickets!="")
		slamResultsByTickets(tickets);
});
$(document).on('click','.item-work',function(){
	var id = $(this).attr('id');
	var tickets="";
	var schrd="";
	if(id=="idealTickets"){
		$.each(idealt[id],function(sid,val){
			if(val.count>0) tickets+=","+val["ticketId"];
		});
	}
	else if(id=="sche"){
		if(schrd["schuandRd"]["sdTicketid"].length>0){
		$.each(schrd["schuandRd"]["sdTicketid"],function(ind,val){
			tickets+=","+val;
		});}
	}
	else if (id=="ResponseDue"){
		if(schrd["schuandRd"]["rdTicketid"].length>0){
		$.each(schrd["schuandRd"]["rdTicketid"],function(ind,val){
			tickets+=","+val;
		});}
	}
	if(tickets!="")
		slamResultsByTickets(tickets);
});


function GetResults(id){
	html = '';
	if(id == 'idSchtkt'){
		html += '<input type="hidden" name="selectedStatuses" value="16">';
		$("#statusDecMD").html(html);
	}else{
		html += '<input type="hidden" name="selectedStatuses" value="1">';
		$("#statusDecMD").html(html);
	}
    if (id == "idActiveP0Tickets"){
        $("#idTempName").val("Active P0 Tickets");
    }
    else if(id == "idActiveP1Tickets"){
        $("#idTempName").val("Active P1 Tickets");
    }
    else if(id == "idActiveP2Tickets"){
        $("#idTempName").val("Active P2 Tickets");
    }
    else if(id == "idActiveP3Tickets"){
        $("#idTempName").val("Active P3 Tickets");
    }
    else if(id == "idInActiveP0Tickets"){
        $("#idTempName").val("In Active P0 Tickets");
    }
    else if(id == "idInActiveP1Tickets"){
        $("#idTempName").val("In Active P1 Tickets");
    }
    else if(id == "idInActiveP2Tickets"){
        $("#idTempName").val("In Active P2 Tickets");
    }
    else if(id == "idInActiveP3Tickets"){
        $("#idTempName").val("In Active P3 Tickets");
    }
    else if(id=="idHmspVal"){
        $("#idTempName").val("HMSP / WFCI Tickets");
    }
    else if(id == "idIdeal"){
        $("#idTempName").val("Idle Tickets");
    }
    else if( id == "idSchtkt"){
          $("#idTempName").val("Scheduled Tickets");
    }
    else if(id == "idResponseDue"){
        $("#idTempName").val("Response Due Tickets");
    }
    else if(id == "idClosedP0Tickets"){
        $("#idTempName").val("Closed P0 Tickets ");
    }
    else if(id == "idClosedP1Tickets"){
        $("#idTempName").val("Closed P1 Tickets");
    }
    else if(id == "idClosedP2Tickets"){
        $("#idTempName").val("Closed P2 Tickets");
    }
    else if(id == "idClosedP3Tickets"){
        $("#idTempName").val("Closed P3 Tickets");
    }
    else {
        $("#idTempName").val("General Template");
    }

	var ticketsdata = $("#"+String(id)).val();
	$("#idTypeValue").val(ticketsdata);
	var tickets = $("#idTypeValue").val();
	document.getElementById("IdSlamResults").submit();
};

function getMdScheduledTickets(){
	$.ajax({
		  type: "POST",
		        url: "/managerDashboard/mdSchTickets/",
		        data: {'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()},
		        success: function (data) {
		        	var taskCount = 0;
		        	var obsCount = 0;
		        	var taskTktsList = '';
		        	var obsTktsList = '';
		        	$.each(data.Response,function(key,val){
		        		taskCount = taskCount + parseInt(val.scheduledTaskCount);
		        		obsCount = obsCount + parseInt(val.scheduledObservationCount);
		        		taskTktsList += ","+val.scheduledTaskTickets;
		        		obsTktsList += ","+val.scheduledObservationTickets;
		        	});
		        	var totalTktList = taskTktsList+obsTktsList;
		        	var counts = taskCount+" / "+obsCount;
	        		$("#sche").html(counts);
		        	$("#idSchtkt").val(totalTktList);
		        	if (taskCount > 0 || obsCount > 0) {
						setInterval(function() {
							$('#rd-itemtoBlink').toggleClass("t-item-red");
						}, 800)
					}
		        	setTimeout(function() {
		        		getMdScheduledTickets();
		        	}, 300000);
		        }
		 });
}