/*
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
*/

var file_c=0;
$(document).ready(function(){
	$('body').on('click', '#createTicket', function(){
		document.getElementById("createTicket").disabled = true;
		var formTicketResNotes =$('#cust_grp_31').serialize();
		var formMspQoss = $('#cust_grp_21').serialize();
		var formMspTools = $('#cust_grp_11').serialize();
		var formMsp = $('#cust_grp_2').serialize();
		var formOnboardingData = $('#cust_grp_5').serialize();
		var attachments = new Array(); 
		var qos = '';
		var qos_feedback = $('input[name=qos_feedback]:checked').val();	
		if(qos_feedback != 'undefined' && qos_feedback!= ''){			
			qos = qos_feedback;			
		}
		for (i = 0; i < file_c; i++) {
			attachments.push($('#fobj_'+i).text());
		}
		
		if ($('#sendMail').is(":checked")){
			var sendMail = 1
		}
		else {
			var sendMail = 0
		}
		var postContent = CKEDITOR.instances['ticketContent'].getData();
		$.ajax({
			type: "POST",
			url: "/ticket/createTicket/?_ajax=true",
			data: { 'partners':$('#partners').val(),'clients':$('#clients').val(),'deviceType':$('#deviceType').val(),'devices':$('#devices').val(),'department':$('#department').val(),
				'incidenttype':$('#incidenttype').val(),'selectedPriorities':$('#selectedPriorities').val(),'grpStatus':$('#grpStatus').val(),'staff':$('#staff').val(),'sendMail':sendMail,
				'fromMail': $('#frommail').val(),'subject': $('#subject').val(),'reqPhone': $('#reqPhone').val(),'reqEmailId': $('#reqEmailId').val(),'attachments':attachments ,'attDynamic':$('#attDynamic').val(),
				'tags': $('#tags').val(),'ticketContent':postContent ,'ticDue': $('#ticDue').val(),'timeWorked': $('#timeWorked').val(),'billable': $('#billable').val(),
				'workType': $('#workType').val(),'billableType': $('#billableType').val(),'ccEmailId': $('#ccEmailId').val(),'qos_feedback':qos,'integrationcheck':$('input[name=integration_check]:checked').val(),csrfmiddlewaretoken : $("input[name=csrfmiddlewaretoken]").val()
			},
			beforeSend: function (){
				$('span#createLoading').show();
				$('body').addClass('waiting');
				$.notification({
				   class: 'processing_notify',
				   notification: 'processing_notify',
				   autohide: true
			   	});
	       		},
	       		complete: function(){
			  	$('span#createLoading').hide();
		       	  	$('body').removeClass('waiting');
	       		},
			success: function(data){
				var errorMSg = data.resMsg;
				if (data.resURL !=''){
					var ticketingUrl = data.resURL; 
					if (data.ticketResult !=null && data.ticketResult != ''){
						var formTicketResNotes =$('#cust_grp_31').serialize();
						 var formMspQoss = $('#cust_grp_21').serialize();
						 var formMspTools = $('#cust_grp_11').serialize();
						 var formOnboardingData = $('#cust_grp_5').serialize();
						var formLPI = $('#cust_grp_1').serialize();
						/*  ticket View added  */
						
						$.ajax({
							 type:'POST',
							 url:'/ticket/ticketEditSave/',
							 data:{
								 ticketId:data.ticketResult,
								 ticketResNote:formTicketResNotes,
								 mspQos:formMspQoss,
								 mspTools:formMspTools,
								 onboardingData:formOnboardingData,
								 lpiData :formLPI,
								 'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
								 },
							 
							success:function(data){
								 if (data.html =='success') {
						                $('#divErrorMsg').html('');
						                /* if(errorMSg == ''){
							                $.notification({
							                    class: 'success_notify',
							                    notification: 'post_updated_successfully',
							                    time: 5000,
							                    autohide: true
							                });
						                }else{
							                $.notification({
							                    class: 'warning_notify',
							                    notification: 'updated_with_attachment_failed',
							                    time: 5000,
							                    autohide: true,
							                    replaceKeys: {
							                        errorMsg: errorMSg
							                    }
							                });
						                }*/
						                window.location.href = ticketingUrl;
						            } else {
						            	document.getElementById("createTicket").disabled = false;
						                $.notification({
						                    class: 'error_notify',
						                    notification: 'postreply_failled',
						                    time: 5000,
						                    autohide: true,
						                    replaceKeys: {
						                        errorMsg: data.resMsg
						                    }
						                });
						            }
							},
					        error: function(jqXHR, textStatus, errorThrown) {
					            document.getElementById("createTicket").disabled = false;
					            var resMsg = jqXHR.status + ' - ' + errorThrown; /* ' : '+ jqXHR.responseText; */
					            $.notification({
					                class: 'error_notify',
					                notification: 'postreply_failled',
					                time: 5000,
					                autohide: true,
					                replaceKeys: {
					                    errorMsg: resMsg
					                }
					            });
					            return false;
					        }
						
						
						});
					}
				}else {
					document.getElementById("createTicket").disabled = false;
	                $.notification({
	                    class: 'error_notify',
	                    notification: 'postreply_failled',
	                    time: 5000,
	                    autohide: true,
	                    replaceKeys: {
	                        errorMsg: data.resMsg
	                    }
	                });
					return false;
				}
			},
			error: function(jqXHR, textStatus, errorThrown) {
	            document.getElementById("createTicket").disabled = false;
	            var resMsg = jqXHR.status + ' - ' + errorThrown; /* ' : '+ jqXHR.responseText; */
	            $.notification({
	                class: 'error_notify',
	                notification: 'postreply_failled',
	                time: 5000,
	                autohide: true,
	                replaceKeys: {
	                    errorMsg: resMsg
	                }
	            });
	            return false;
	        }
		});
	});
});

$('#createTicket').click(function(){
	$('#myAlert').hide();
	$('#divErrorMsg').html("");
	
	if($("#partners").val()=='' || $("#partners").val()== null ){
		$('#myAlert').slideDown('slow');
    	$('#divErrorMsg').html("<ul><li>Please select Partner</li></ul>");
		return false;
	}
	if($("#clients").val()=='' || $("#clients").val()== null){
		$('#myAlert').slideDown('slow');
    	$('#divErrorMsg').html("Please select Client");
		return false;
	}
	if($("#deviceType").val()=='' || $("#deviceType").val()== null ){
		$('#myAlert').slideDown('slow');
    	$('#divErrorMsg').html("Please select Device Category");
		return false;
	}
	if($("#devices").val()=='' || $("#devices").val()== null ){	
		$('#myAlert').slideDown('slow');
    	$('#divErrorMsg').html("Please select Device");
		return false;
	}
	if($("#department").val()=='' || $("#department").val()== null ){
		$('#myAlert').slideDown('slow');
    	$('#divErrorMsg').html("Please select Department");
		return false;
	}
	if($("#grpStatus").val()==16){
		$('#myAlert').slideDown('slow');
    	$('#divErrorMsg').html("Unable to create ticket in Scheduled status");
		return false;
	}
	if($("#subject").val()==''|| $("#subject").val()== null ){
		$('#myAlert').slideDown('slow');
    	$('#divErrorMsg').html("Subject should not be empty");
		return false;
	}
	if(CKEDITOR.instances['ticketContent'].getData() =='' || CKEDITOR.instances['ticketContent'].getData() == null || CKEDITOR.instances['ticketContent'].getData() == undefined){
		$('#myAlert').slideDown('slow');
    	$('#divErrorMsg').html("Content should not be empty");
		return false;
	}
	if($("#reqEmailId").val()=='' || $("#reqEmailId").val()== null ){
		$('#myAlert').slideDown('slow');
    	$('#divErrorMsg').html("Requester Email ID should not be empty");
		return false;
	}
	if($("#reqEmailId").val().split(",").length > 1 ){
		$('#myAlert').slideDown('slow');
    	$('#divErrorMsg').html("More than one Requester Email ID not allowed");
		return false;
	}
	var regExNum = /^[0-9]+$/;
	if($("#timeWorked").val()=='' || $("#timeWorked").val()== null ){
		$('#myAlert').slideDown('slow');
    	$('#divErrorMsg').html("Please enter Time Worked");
    	document.getElementById('timeWorked').value = '1';
		return false;	
	}
	else{
		if(!(regExNum.test($("#timeWorked").val())))
		{
			$('#myAlert').slideDown('slow');
	    	$('#divErrorMsg').html("Please enter valid Time Worked");
			return false;
		}
	}
	if($("#billable").val()!='' || $("#billable").val()!= null ){
		if ((regExNum.test($("#timeWorked").val())) && (regExNum.test($("#billable").val())))
		{
			if(parseInt($("#timeWorked").val()) < parseInt($("#billable").val())){
				$('#myAlert').slideDown('slow');
		    	$('#divErrorMsg').html("Time Billable should be lessthan Time Worked");
				return false;
			}
		}
	}
});

$('body').on('click', '#createAtt', function(){
	$('#uploadPostReplyFile').trigger('click');
});

$('body').on('change', '#uploadPostReplyFile', function(){
	$('span#attachmentload').show();
	 $("#frmUploadFile").ajaxForm({
		success: function (data){			
			display_file(data,file_c++);
			$('span#attachmentload').hide();
		}
	}).submit();
});

function display_file(data,file_c){
    if(data)
    {
        $('#attach_div').append('<span id="fobj_'+file_c+'" data="'+data+'"class="btn btn-primary btn-small space">'+data+'<i class="fa fa-close"></i></span>');
    }
}

$(document).on('click','#attach_div span .fa-close',function(){
    var nam = $(this)[0];
    
    $.ajax({
        type: "POST",
        url: '/ticket/delattachment',
        data: {'attDynamic':$('#attDynamic').val(),'fname':$(nam.parentElement).attr('data'),'csrfmiddlewaretoken':$('input[name=csrfmiddlewaretoken]').val()},
        beforeSend: function (){
			$('span#attachmentload').show();
	    },
	    complete: function(){
	    	$('span#attachmentload').hide();
	    },
        success: function(response){
            $(nam.parentElement).remove();
        }
    });
});


$('#reqEmailId,#ccEmailId')
.on('tokenfield:createtoken', function (e) {
  var data = e.attrs.value.split('|')
  e.attrs.value = data[1] || data[0]
  e.attrs.label = data[1] ? data[0] + ' (' + data[1] + ')' : data[0]
})

.on('tokenfield:createdtoken', function (e) {
  /* Über-simplistic e-mail validation */
  var re = /\S+@\S+\.\S+/
  var valid = re.test(e.attrs.value)
  if (!valid) {
    $(e.relatedTarget).addClass('invalid')
  }
})

.on('tokenfield:edittoken', function (e) {
  if (e.attrs.label !== e.attrs.value) {
    var label = e.attrs.label.split(' (')
    e.attrs.value = label[0] + '|' + e.attrs.value
  }
})

.tokenfield({
	delimiter: [',',';'],
	minWidth: 160, 
	autocomplete: {
	    source: resMails,
	    delay: 100
	},
})

$('#reqPhone')

.on('tokenfield:createtoken', function (e) {
  var data = e.attrs.value.split('|')
  e.attrs.value = data[1] || data[0]
  e.attrs.label = data[1] ? data[0] + ' (' + data[1] + ')' : data[0]
})

.on('tokenfield:edittoken', function (e) {
  if (e.attrs.label !== e.attrs.value) {
    var label = e.attrs.label.split(' (')
    e.attrs.value = label[0] + '|' + e.attrs.value
  }
})

.tokenfield({
	delimiter: [',',';'],
	minWidth: 160, 
	autocomplete: {
	    source: clientContacts,
	    delay: 100
	},
})


$('#tags')

.on('tokenfield:createtoken', function (e) {
  var data = e.attrs.value.split('|')
  e.attrs.value = data[1] || data[0]
  e.attrs.label = data[1] ? data[0] + ' (' + data[1] + ')' : data[0]
})

.on('tokenfield:edittoken', function (e) {
  if (e.attrs.label !== e.attrs.value) {
    var label = e.attrs.label.split(' (')
    e.attrs.value = label[0] + '|' + e.attrs.value
  }
})

.tokenfield({
	delimiter: [',',';'],
	minWidth: 160, 
	autocomplete: {
	    source: searchTags,
	    delay: 100
	},
})
