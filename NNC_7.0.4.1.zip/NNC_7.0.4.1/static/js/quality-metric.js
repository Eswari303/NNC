/*
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
*/

function getQualityMetricInfo(){
    var formdata = $("#idQualityMetric").serializeArray();
    var selectedStaff = $("#idStaffData").val();
    var selectedPriority = $("#idPriorityData").val();
    var timeWorked = $('#idTimeWorked').val();
    $body = $("body");
    if (($('#idManage').is(':checked')) == true){
        var manage = "on";
    }
    else{
        var manage = "";
    }

    if (($('#idAid').is(':checked')) == true){
        var aid = "on";
    }
    else{
        var aid = "";
    }

    if (($('#idSmartEscalation').is(':checked')) == true){

        var smartescalate = "on";
    }
    else{
        var smartescalate = "";
    }

    if (selectedStaff == null){
        $("#myAlert").show()
        $("#divErrorMsg").text("Please select staff");
        return false;
    }


    if (selectedPriority == null){
        $("#myAlert").show()
        $("#divErrorMsg").text("Please select priority");
        return false;
    }
    
    if (timeWorked == null || timeWorked == ''){
    	$('#idTimeWorked').val(1);
    	
    }
    
    $.ajax({url: "/qualityMetric/",
          type : "POST",
          dataType:"json",
          data :
          {
            'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
            'staffdata' : JSON.stringify(selectedStaff),
            'prioritydata' : JSON.stringify(selectedPriority),
            "timespent" : $("#idTimeSpent").val(),
            'billabletime' : $("#idBillableTime").val(),
            'fromdate' : $("#idFromDate").val(),
            'todate' : $("#idToDate").val(),
            'manage' : manage,
            'aid' : aid,
            'smartescalate' : smartescalate,
            'timeworked' : $("#idTimeWorked").val(),
            'package' : $("#idPackage").val()
          },beforeSend: function (){
			    $("#load_template").show()
			    $("#IdSearch").prop('disabled', true);
			    $('#myTable tbody').remove();
			    $('#myTable').append("<tbody>...</tbody>");
			    var rowCount = $('#myTable >tbody >tr').length;
			    if (rowCount >= 0){
			        console.log("in count if condition");
			        var dataTable = $('#example').DataTable();
			        dataTable.clear();
			        var newcontent = '<tr class="odd"> <td valign="top" colspan="9" class="dataTables_empty">No data available in table</td></tr>'
			        $("#myTable tbody").append(newcontent);
			    }
	       },complete: function(){
	            $("#load_template").hide()
	            $("#IdSearch").prop('disabled', false);
	            $("#myAlert").hide()
	       },success: function(response){
                $('#myTable tbody').remove();
                finaldata = [];
                var i = 0;
                $.each(response, function(index, element){
                    data = [];
                    var i_in = i + 1;
                    if (parseInt(response[index]['tickets_closed']) == 0) {
                        var tickets_closed_href = 0;
                    }
                    else{
                        var tickets_closed_href =  '<b> <a target="_blank" href="/qualityMetric/getClosedTicketsInfo?'+ String(response[index]['closedTktParams']) +'">'+String(response[index]['tickets_closed'])+'</a></b>'
                    }

                    if (parseInt(response[index]['tickets_touched']) == 0){
                        var tickets_touched_href = 0;
                    }
                    else{
                        var tickets_touched_href =  '<b> <a target="_blank" href="/qualityMetric/getClosedTicketsInfo?'+ String(response[index]['touchedTktParams']) +'">'+String(response[index]['tickets_touched'])+'</a></b>'
                    }
                    data.push(String(i_in));
                    data.push(response[index]['fullname']);
                    data.push(tickets_closed_href);
                    data.push(tickets_touched_href);
                    data.push(response[index]['time_spent']);
                    data.push(response[index]['review_time']);
                    data.push(response[index]['time_billable']);
                    data.push(response[index]['working_days']);
                    data.push(response[index]['utilization']);
                    finaldata.push(data);
                    i = i_in;
                });
//                console.log("final data:", finaldata);
                var table = $("#myTable").DataTable();
                table.destroy();
                $('#myTable').DataTable( {
                    data: finaldata,
                    columns: [
                        { title: "#" },
                        { title: "Engineer Name" },
                        { title: "Tickets Closed"},
                        { title: "Tickets Touched" },
                        { title: "Time Spend (Mins)" },
                        { title: "Review Time (Mins)" },
                        { title : "Billable Time (Mins)" },
                        { title : "Working Days" },
                        { title : "Utilization"}
                    ],
                } );

          },error : function(error){
                console.log(error)
          }
    });
}
