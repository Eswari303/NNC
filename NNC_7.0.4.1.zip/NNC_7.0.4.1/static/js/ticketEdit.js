$(document).ready(function() {

    $('#linkcustomfieldSubmit').on('click', function() {
        viewValue = $('#linkcustomfieldDropDwon').val();

        $.ajax({
            type: 'POST',
            url: '/ticket/linkcustomfieldView/',
            data: {
                view: viewValue,
                'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val(),
            },
            beforeSend: function() {
                $('span#editCutomColumns').show();
                $('#linkcustomfieldSubmit').attr('disabled', 'disabled');
            },
            complete: function() {
                $('span#editCutomColumns').hide();

                $('#linkcustomfieldSubmit').removeAttr('disabled');
            },
            success: function(data) {

                $('div#appendCustomField').append(data.html);
                if (viewValue != 0) {
                    $('#linkcustomfieldDropDwon option[value="' + viewValue + '"]').remove();
                }

            }

        });
    });




    $('#ticketDetailsSave').on('click', function() {
        tickId = $(this).attr('data-ticket');
        $.ajax({
            type: 'POST',
            url: '/ticket/ticketEditSave/',
            data: {
                ticketId: tickId,
                ticketResNote: $('#cust_grp_31').serialize(),
                mspQos: $('#cust_grp_21').serialize(),
                mspTools: $('#cust_grp_11').serialize(),
                msp: $('#cust_grp_2').serialize(),
                onboardingData: $('#cust_grp_5').serialize(),
                ticketForm: $('#tickeDetailsForm').serialize(),
                'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val(),
            },
            beforeSend: function() {
                $('span#upDateCutomColumns').show();
                $('#ticketDetailsSave').attr('disabled', 'disabled');
            },
            complete: function() {
                $('span#upDateCutomColumns').hide();
                $('#ticketDetailsSave').removeAttr('disabled');
            },
            success: function(data) {
                if (data.html == 'success') {
                    parent.$.notification({
                        class: 'success_notify',
                        notification: 'quickupdate_success',
                        time: 5000,
                        autohide: true
                    });
                } else {
                    parent.$.notification({
                        class: 'error_notify',
                        notification: 'quickupdate_failled',
                        time: 5000,
                        autohide: true
                    });
                }
                parent.$.colorbox.close();
                parent.eval("customFiledsData();");
                parent.eval("window.location.reload();");
            },
            error: function() {
                parent.$.notification({
                    class: 'error_notify',
                    notification: 'quickupdate_failled',
                    time: 5000,
                    autohide: true
                });
            }
        });

    });




    $('#tpartners').on('change', function() {

        $.ajax({
            type: "POST",
            url: "/ticket/partnerAjax?_ajax=true",
            data: {
                'res_cli': $('#tpartners').val(),
                'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
            },
            beforeSend: function() {
                $('span#lodingClient').show();
            },
            complete: function() {
                $('span#lodingClient').hide();
            },
            success: function(data) {
                $('#tclients').selectpicker('destroy');
                var datalist = new Array();
                $.each(data.clients, function(key, val) {
                    datalist.push("<option value = " + val.mspclientid + ">" + val.clientname + "</option>");
                });
                $('#tclients').html(datalist);
                $('#tclients').selectpicker();
            },
        });

    });
    $('#tclients').on('change', function() {
        $.ajax({
            type: "POST",
            url: "/ticket/clientAjax?_ajax=true",
            data: {
                'res_devices': $('#tclients').val(),
                'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
            },
            beforeSend: function() {
                $('span#lodingDevice').show();
            },
            complete: function() {
                $('span#lodingDevice').hide();
            },
            success: function(data) {
                $('#tdevicname').selectpicker('destroy');
                var datalist = new Array();
                datalist.push("<option value = 0 selected>Others</option>");
                $.each(data.devices, function(key, val) {
                    datalist.push("<option value = " + val.id + ">" + val.device_name + "</option>");
                });
                $('#tdevicname').html(datalist);
                $('#tdevicname').selectpicker();
            }
        });
    });
    
    
  $('body').on('click', '#btnTktReviewSubmit', function (e){
		
		postId = $(this).attr('data-postid');
		ticketId = $(this).attr('data-ticketid');
		formId = "post_reviews_form_"+postId+"_"+ticketId;
		console.log("formId: "+formId);
		 $.ajax({
			type: 'POST',
			url: "/ticket/ticketPostSave/?_ajax=true",
			data:{
				postId: postId,
				ticketId: ticketId,
				'PostReviews_proc_rating': $("input[name=PostReviews_proc_rating]:checked").val(),
				'PostReviews_tech_rating': $("input[name=PostReviews_tech_rating]:checked").val(),
				'PostReviews_comm_rating': $("input[name=PostReviews_comm_rating]:checked").val(),
				'PostReviews_time_rating': $("input[name=PostReviews_time_rating]:checked").val(),
				'PostReviews_customer_value_rating': $("input[name=PostReviews_customer_value_rating]:checked").val(),
				'PostReviews_comments': $('#PostReviews_comments').val(),
				'PostReviews_review_time': $('#PostReviews_review_time').val(),
				'PostReviews_reviewMails': $('#reviewMails').val(),
				
				csrfmiddlewaretoken : parent.$("input[name=csrfmiddlewaretoken]").val(),
			},
			beforeSend: function (){
				$('#btnTktReviewSubmit').attr('disabled',true);
			    $('span#loadingtktrvw').show();
			},
			complete: function(){
				$('#btnTktReviewSubmit').attr('disabled',false);
			    $('span#loadingtktrvw').hide();
			},
			success: function(data){
				parent.eval("$.colorbox.close();");
				parent.eval("resultsReview();");
				parent.$.notification({class:'success_notify', notification:'review_success', time: 5000, autohide: true});
			},
			error: function () {
				parent.$.notification({class:'error_notify', notification:'review_fail', time: 5000, autohide: true});
	        }
		}); 
	});


});