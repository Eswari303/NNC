$(document).ready(function() {

    $('body').on('click', '#btnAddNew', function() {
        window.location.href = '/serviceManagement/addSchTemp/';
    });
    $('body').on('click', '#chkAllJobs', function() {
        checkStat = $(this).is(':checked');
        if (checkStat) {
            $("input#chkJobId").prop('checked', true);
        } else {
            $("input#chkJobId").prop('checked', false);
        }
        showOrHideUnsubscribe();
    });
    $('body').on('click', '#chkJobId', function() {
        showOrHideUnsubscribe();
        if ($('input:checkbox[id="chkJobId"]:checked').length == $('input:checkbox[id="chkJobId"]').length) {
            $("input#chkAllJobs").prop('checked', true);
        } else {
            $("input#chkAllJobs").prop('checked', false);
        }
    });
    $('body').on('click', '#btnUnsubscribe', function() {
        var jobIds = null;
        $('input[id="chkJobId"]:checked').each(function() {
            if (jobIds == null) {
                jobIds = $(this).val();
            } else {
                jobIds = jobIds + "," + $(this).val();
            }
        });
        window.location.href = "/serviceManagement/unsubscribeJob?_ajax=true&jobIds=" + jobIds;
    });
});

function showOrHideUnsubscribe() {
    if ($('input:checkbox[id="chkJobId"]:checked').length > 0) {
        $('#btnUnsubscribe').show('slow');
    } else {
        $('#btnUnsubscribe').hide('slow');
    }
}