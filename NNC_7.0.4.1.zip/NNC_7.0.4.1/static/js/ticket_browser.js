/*
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
*/

var baseUrl = 'static';
	var loadingImg = '<img border="0" align="absmiddle" src="'+baseUrl+'/images/loading.gif" class="loadingImg">'
	var reportflag = 'TicketBrowser';
	function validateCreated(templateid){		
		var isModifiedOrCreated = $("#template"+templateid+" input[name='"+reportflag+"Form[is_modified_tickets][]']").serializeArray(); 
		if(isModifiedOrCreated.length <= 0) return false;
		return true;
	}	
	function clearDateRanges(templateId){
		$('#TicketBrowserForm'+templateId+'_fromdate').val('');
		$('#TicketBrowserForm'+templateId+'_todate').val('');
	}	
	$(function() {
		jQuery('#TicketBrowserForm_nocs').live('change', function(e){
			$(e).preventDefault;
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			$('#template'+templateId+' #TicketBrowserForm_channel option').attr('selected', false);
			$('#template'+templateId+' #TicketBrowserForm_nocs  option:selected').each(function (key, list){
				if(list.value == '' && $('#template'+templateId+' #TicketBrowserForm_nocs  option:selected').length > 1){
					list.selected = false;
					return false;
				}
			});
			
			if($('#template'+templateId+' #TicketBrowserForm_nocs  option:selected').length > 0){
				jQuery.ajax({
					type:'POST',
					cache: false,
					//async: false,
					data: $('#template'+templateId+' #TicketBrowserForm_nocs').serialize(),
					url: urlGetPartners,
					beforeSend: function (){
					$('#template'+templateId+' #tdPartner, #template'+templateId+' #tdClient').append(loadingImg);
					},
					complete: function(){
						$('.loadingImg').remove();
					},
					success: function(html){
						jSon = $.parseJSON(html);
						$.each(jSon, function (index, value){
							jQuery('#template'+templateId+' #TicketBrowserForm_'+index).html(value);
						});
					}
				});
			}else{
				/*jQuery('#template'+templateId+' #TicketBrowserForm_partners').empty();
				jQuery('#template'+templateId+' #TicketBrowserForm_partners').append($('<option></option>').val('').html('Select Partner'));
				jQuery('#template'+templateId+' #TicketBrowserForm_clients').empty();
				jQuery('#template'+templateId+' #TicketBrowserForm_clients').append($('<option></option>').val('').html('Select Client'));
				jQuery('#template'+templateId+' #TicketBrowserForm_devices').empty();
				jQuery('#template'+templateId+' #TicketBrowserForm_devices').append($('<option></option>').val('').html('Select Device'));
				jQuery('#template'+templateId+' #TicketBrowserForm_device_groups').empty();
				jQuery('#template'+templateId+' #TicketBrowserForm_device_groups').append($('<option></option>').val('').html('Select Device Group'));
				jQuery('#template'+templateId+' #TicketBrowserForm_device_sites').empty();
				jQuery('#template'+templateId+' #TicketBrowserForm_device_sites').append($('<option></option>').val('').html('Select Device Site'));*/
			}
			return false;
		});
		
		
		jQuery('#TicketBrowserForm_channel').live('change', function(e){
			$(e).preventDefault;
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			$('#template'+templateId+' #TicketBrowserForm_nocs option').attr('selected', false);
			$('#template'+templateId+' #TicketBrowserForm_channel  option:selected').each(function (key, list){
				if(list.value == '' && $('#template'+templateId+' #TicketBrowserForm_channel  option:selected').length > 1){
					list.selected = false;
					return false;
				}
			});
			
			if($('#template'+templateId+' #TicketBrowserForm_channel  option:selected').length > 0){
				jQuery.ajax({
					type:'POST',
					cache: false,
					//async: false,
					data: $('#template'+templateId+' #TicketBrowserForm_channel').serialize(),
					url: urlGetPartners,
					beforeSend: function (){
						$('#template'+templateId+' #tdPartner, #template'+templateId+' #tdClient').append(loadingImg);
					},
					complete: function(){
						$('.loadingImg').remove();
					},
					success: function(html){
						jSon = $.parseJSON(html);
						$.each(jSon, function (index, value){
							jQuery('#template'+templateId+' #TicketBrowserForm_'+index).html(value);
						});
					}
				});
			}
			return false;
		 });
		
		
		 jQuery('#TicketBrowserForm_partners').live('change', function(e){
			$(e).preventDefault;
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			$('#template'+templateId+' #TicketBrowserForm_partners  option').each(function (key, list){
				if(list.value == '' && $('#template'+templateId+' #TicketBrowserForm_partners  option:selected').length > 1){
					list.selected = false;
					return false;
				}
			});
			if($('#template'+templateId+' #TicketBrowserForm_partners  option:selected').length > 0){
				jQuery.ajax({
					type:'POST',
					cache: false,
					//async: false,
					data: $('#template'+templateId+' #TicketBrowserForm_partners, #template'+templateId+' #TicketBrowserForm_nocs').serialize(),
					url: urlGetClients,
					beforeSend: function(){
						$('#template'+templateId+' #tdClient').append(loadingImg);
					},
					complete: function(){
						$('.loadingImg').remove();
					},
					success: function(html){
						jSon = $.parseJSON(html);
						$.each(jSon, function (index, value){
							jQuery('#template'+templateId+' #TicketBrowserForm_'+index).html(value);
						});
					}
				});
			}else{
				/*jQuery('#template'+templateId+' #TicketBrowserForm_clients').empty();
				jQuery('#template'+templateId+' #TicketBrowserForm_clients').append($('<option></option>').val('').html('Select Client'));
				jQuery('#template'+templateId+' #TicketBrowserForm_devices').empty()
				jQuery('#template'+templateId+' #TicketBrowserForm_devices').append($('<option></option>').val('').html('Select Device'));
				jQuery('#template'+templateId+' #TicketBrowserForm_device_groups').empty();
				jQuery('#template'+templateId+' #TicketBrowserForm_device_groups').append($('<option></option>').val('').html('Select Device Group'));
				jQuery('#template'+templateId+' #TicketBrowserForm_device_sites').empty();
				jQuery('#template'+templateId+' #TicketBrowserForm_device_sites').append($('<option></option>').val('').html('Select Device Site'));*/
			}
		});


		jQuery('#TicketBrowserForm_clients').live('change', function(){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			$('#template'+templateId+' #TicketBrowserForm_clients  option').each(function (key, list){
				if(list.value == '' && $('#template'+templateId+' #TicketBrowserForm_clients  option:selected').length > 1){
					list.selected = false;
					return false;
				}
			});
			if($('#template'+templateId+' #TicketBrowserForm_clients  option[value=""]:selected').length > 0){
				jQuery('#template'+templateId+' #TicketBrowserForm_devices').empty();
				jQuery('#template'+templateId+' #TicketBrowserForm_devices').append($('<option></option>').val('').html('Select Device'));
				jQuery('#template'+templateId+' #TicketBrowserForm_device_groups').empty();
				jQuery('#template'+templateId+' #TicketBrowserForm_device_groups').append($('<option></option>').val('').html('Select Device Group'));
				jQuery('#template'+templateId+' #TicketBrowserForm_device_sites').empty();
				jQuery('#template'+templateId+' #TicketBrowserForm_device_sites').append($('<option></option>').val('').html('Select Device Site'));
			}else{
				jQuery.ajax({
					type:'POST',
					cache: false,
					//async: false,
					data: $('#template'+templateId+' #TicketBrowserForm_clients').serialize(),
					url: urlGetDevices,
					beforeSend: function(){
						$('#template'+templateId+' #tdDevice, #template'+templateId+' #tdDeviceGroup, #template'+templateId+' #tdDeviceSite').append(loadingImg);
					},
					complete: function(){
						$('.loadingImg').remove();
					},
					success: function(html){
						jSon = $.parseJSON(html);
						$.each(jSon, function (index, value){
							jQuery('#template'+templateId+' #TicketBrowserForm_'+index).html(value);
						});
					}
				});
			}/*else{
				
			}*/
		});
		
		
		jQuery('#TicketBrowserForm_departments').live('change', function(){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			selectAllDropdownOptions('#template'+templateId+' #TicketBrowserForm_departments');
		});
		
		jQuery('#TicketBrowserForm_statuses').live('change', function(){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			selectAllDropdownOptions('#template'+templateId+' #TicketBrowserForm_statuses');
		});
		
		/* jQuery('body').live('change','#TicketBrowserForm_staff',function(){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			selectAllDropdownOptions('#template'+templateId+' #TicketBrowserForm_staff');
		}); */
		
		jQuery('#TicketBrowserForm_priorities').live('change', function(){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			$('#template'+templateId+' input:radio[name="TicketBrowserForm[opt_priority_from]"]').attr('checked', false);
			$('#template'+templateId+' input:radio[name="TicketBrowserForm[opt_priority_to]"]').attr('checked', false);
			selectAllDropdownOptions('#template'+templateId+' #TicketBrowserForm_priorities');
		});
		
		jQuery('#TicketBrowserForm_opt_priority_from').live('change', function(){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			$('#template'+templateId+' #TicketBrowserForm_priorities option').attr('selected', false);
		});
		
		jQuery('#TicketBrowserForm_opt_priority_to').live('change', function(){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			$('#template'+templateId+' #TicketBrowserForm_priorities option').attr('selected', false);
		});
			
		$('#openOrder').live('click', function(e){
		    $(e).preventDefault;
		    templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
		    
		    imgUp = baseUrl+'/images/arrow_up.gif';
		    imgDown = baseUrl+'/images/arrow_down.gif';
		    imgSrc = $(this).attr('src');
		    if(imgSrc == imgUp){
		        imgSrc = imgDown;
		        title = 'Hide Details';
		    }else{
		        imgSrc = imgUp;
		        title = 'Open Details';
		    }
		    $('#template'+templateId+' #trOrder').slideToggle("slow", function (){
		        $('#template'+templateId+' #openOrder').attr('src', imgSrc);
		        $('#template'+templateId+' #openOrder').attr('title', title);
		    });
		});
		
		
		
		$('#openOrderColumns').live('click', function(e){
		    $(e).preventDefault;
		    templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
		    
		    imgUp = baseUrl+'/images/arrow_up.gif';
		    imgDown = baseUrl+'/images/arrow_down.gif';
		    imgSrc = $(this).attr('src');
		    if(imgSrc == imgUp){
		        imgSrc = imgDown;
		        title = 'Hide Details';
		    }else{
		        imgSrc = imgUp;
		        title = 'Open Details';
		    }
		    $('#template'+templateId+' #trOrderColumns').slideToggle("slow", function (){
		        $('#template'+templateId+' #openOrderColumns').attr('src', imgSrc);
		        $('#template'+templateId+' #openOrderColumns').attr('title', title);
		    });
		});
		
		$('#addColumn').live('click', function(e){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			if($('#template'+templateId+' #defaultColumns option:selected').length > 0){
				$('#template'+templateId+' #removeColumn').show('slow');
				$('#template'+templateId+' #moveColumnUp').show('slow');
				$('#template'+templateId+' #moveColumnDown').show('slow');
			}
			$('#template'+templateId+' #defaultColumns option:selected').each(function (i,v){
				$('#template'+templateId+' #TicketBrowserForm_display_columns').append($('<option></option>').val($(this).val()).html($(this).text()));
				$(this).remove();
			});
			if($('#template'+templateId+' #defaultColumns option').length == 0){
				$('#template'+templateId+' #addColumn').hide('slow');
			}
		});
		$('#removeColumn').live('click', function(e){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			$('#template'+templateId+' #TicketBrowserForm_display_columns option:selected').each(function (i,v){
				$('#template'+templateId+' #defaultColumns').append($('<option></option>').val($(this).val()).html($(this).text()));
				$(this).remove();
			});
			if($('#template'+templateId+' #TicketBrowserForm_display_columns option').length == 0){
				$('#template'+templateId+' #addColumn').show('slow');
				$('#template'+templateId+' #removeColumn').hide('slow');
				$('#template'+templateId+' #moveColumnUp').hide('slow');
				$('#template'+templateId+' #moveColumnDown').hide('slow');
			}
		});
		$('#moveColumnUp').live('click', function(){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
		    var selected = $('#template'+templateId+' #TicketBrowserForm_display_columns option:selected');
		    if(selected.length == 1){
		        var before = selected.prev();
		        if (before.length > 0){
		            selected.insertBefore(before);
		        }
		    }
		});
		$('#moveColumnDown').live('click', function(){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
		    var selected = $('#template'+templateId+' #TicketBrowserForm_display_columns option:selected');
		    if(selected.length == 1){
		        var after = selected.next();
		        if (after.length > 0){
		            selected.insertAfter(after);
		        }
		    }
		});
		
		//Templates selection
		$('#openTemplates').live('click', function(e){
		    $(e).preventDefault;
		    
		    imgUp = baseUrl+'/images/arrow_up.gif';
		    imgDown = baseUrl+'/images/arrow_down.gif';
		    imgSrc = $(this).attr('src');
		    if(imgSrc == imgUp){
		        imgSrc = imgDown;
		        title = 'Hide Details';
		    }else{
		        imgSrc = imgUp;
		        title = 'Open Details';
		    }
		    $('#trTemplates').slideToggle("slow", function (){
		        $('#openTemplates').attr('src', imgSrc);
		        $('#openTemplates').attr('title', title);
		    });
		});
		
		$('#addTemplate').live('click', function(e){
			//templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			templatesLength = $('#templates option:selected').length;
			if(templatesLength > 0 && templatesLength < 4){
				$('#removeTemplate').show('slow');
				$('#moveTemplateUp').show('slow');
				$('#moveTemplateDown').show('slow');
				
				
				$('#templates option:selected').each(function (i,v){
					if($('#selectedTemplates option').length < 3){
						$('#selectedTemplates').append($('<option></option>').val($(this).val()).html($(this).text()));
						$(this).remove();
					}else{
						return false;
					}						
				});
				
			}
			
			if($('#templates option').length == 0){
				$('#addTemplate').hide('slow');
			}
		});
		$('#removeTemplate').live('click', function(e){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
			$('#selectedTemplates option:selected').each(function (i,v){
				$('#templates').append($('<option></option>').val($(this).val()).html($(this).text()));
				$(this).remove();
			});
			if($('#selectedTemplates option').length == 0){
				$('#addTemplate').show('slow');
				$('#removeTemplate').hide('slow');
				$('#moveTemplateUp').hide('slow');
				$('#moveTemplateDown').hide('slow');
			}
		});
		$('#moveTemplateUp').live('click', function(){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
		    var selected = $('#selectedTemplates option:selected');
		    if(selected.length == 1){
		        var before = selected.prev();
		        if (before.length > 0){
		            selected.insertBefore(before);
		        }
		    }
		});
		$('#moveTemplateDown').live('click', function(){
			templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
		    var selected = $('#selectedTemplates option:selected');
		    if(selected.length == 1){
		        var after = selected.next();
		        if (after.length > 0){
		            selected.insertAfter(after);
		        }
		    }
		});
		//Templates selection_END
	});
	
	function selectAllDropdownOptions(dropDown){
		selectALLFlag = false;
		jQuery(dropDown+ ' option').each(function(index,list){
			if(list.text=='All' && list.selected== true){
				selectALLFlag=true;
				$(list).attr('value', '-1');
			}
			if(selectALLFlag){
				list.selected = false;
				$(dropDown).val('-1').attr('selected', 'selected');
				return false;
			}
		});
		return selectALLFlag;
	}
jQuery('document').ready(function (){	
	$("a").tooltip({html:true});
	$("input[id*='statustype_'][name='statustype[]']").live('click', function(){
		templateId = $(this).parents().find('input#'+reportflag+'Form_templateid').attr('value');
		var statustype = $(this).val();
		var istypechecked = $(this).prop('checked');
		console.log('selected:'+$(this).val());
		console.log('istypechecked:'+istypechecked);
		//openstatuses = ['3',5];
		switch(statustype){
			case '1': 			
						
						$('#template'+templateId+' #'+reportflag+'Form_statuses option').each(function(){
							if(-1 != $.inArray($(this).val(),activestatuses)){
    								//$(this).attr('selected', true);
    								$(this).attr('selected', istypechecked);
								}
						});
						/* if(istypechecked){
							if($('#template'+templateId+' #statustype_1').attr('checked')){
								//$('#template'+templateId+' #statustype_2').attr('checked',true);
							}
						}else{
							$('#template'+templateId+' #statustype_2').attr('checked',false);
						}*/
						
					break;
			case '3': 
						$('#template'+templateId+' #'+reportflag+'Form_statuses option').each(function(){
							if(-1 != $.inArray($(this).val(),closedstatuses)){
								$(this).attr('selected', istypechecked);
							}
						});
						/* if(istypechecked){
							if($('#template'+templateId+' #statustype_0').attr('checked')){
								//$('#template'+templateId+' #statustype_2').attr('checked',true);
							}
						}else{
							$('#template'+templateId+' #statustype_2').attr('checked',false);
						}*/
					break;
			   case '0': 
						$('#template'+templateId+' #'+reportflag+'Form_statuses option').each(function(){
							if(-1 != $.inArray($(this).val(),inactivestatuses)){
								$(this).attr('selected', istypechecked);
							}	
							/*if(istypechecked){
									$(this).attr('selected', true);
									$('#template'+templateId+' #'+reportflag+'Form_statuses_0').attr('selected', true);
									$('#template'+templateId+' #'+reportflag+'Form_statuses_1').attr('selected', true);
								}else{
									$(this).attr('selected', false);
									$('#template'+templateId+' #'+reportflag+'Form_statuses_0').attr('selected', false);
									$('#template'+templateId+' #'+reportflag+'Form_statuses_1').attr('selected', false);									
								}*/
						});
						/* if(istypechecked){
							if(!$('#template'+templateId+' #statustype_1').attr('checked')){
								$('#template'+templateId+' #statustype_1').attr('checked',true);
							}
							if(!$('#template'+templateId+' #statustype_0').attr('checked')){
								$('#template'+templateId+' #statustype_0').attr('checked',true);
							}
						}else{
							if($('#template'+templateId+' #statustype_1').attr('checked')){
								$('#template'+templateId+' #statustype_1').attr('checked',false);
							}
							if($('#template'+templateId+' #statustype_0').attr('checked')){
								$('#template'+templateId+' #statustype_0').attr('checked',false);
							}
						}*/
						
					break;		
		}
	});	
	jQuery('#btnSubmit').live('click', function(){
		$('div[class="errorMessage"]').html('');
		$('input').css('border', '1px solid #ccc');
		
		action = $(this).val();
		var flagValidationStat = true;
		templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
		templateName = jQuery.trim(jQuery('#template'+templateId+' #TicketBrowserForm_templatename').val());
		if(templateName == ''){
			jQuery('#template'+templateId+' #TicketBrowserForm_templatename_em_').html('Please enter template name');
			jQuery('#template'+templateId+' #TicketBrowserForm_templatename_em_').show();
			jQuery('#template'+templateId+' #TicketBrowserForm_templatename').focus();
			jQuery('#template'+templateId+' #TicketBrowserForm_templatename_em_').prev().css('border', '1px solid red');
			flagValidationStat = false;
		}else if(!validateCreated(templateId)){
			jQuery('#template'+templateId+' #'+reportflag+'Form_is_modified_tickets_em_').html('Please select atleast one option from Created and Modified');
			jQuery('#template'+templateId+' #'+reportflag+'Form_is_modified_tickets_em_').show();
			jQuery('#template'+templateId+' #'+reportflag+'Form_is_modified_tickets_em_').focus();
			jQuery('#template'+templateId+' #'+reportflag+'Form_is_modified_tickets_em_').parent().prev().css('border', '1px solid red');
			$('#template'+templateId+" #TicketBrowserForm_is_modified_tickets_0").focus();
			flagValidationStat = false;			
		}else{
			
			jQuery.ajax({
				type: 'GET',
				//async: false,
				url:urlCheckTemplatename,
				data:{tn:templateName,tid:templateId},
				success: function(data){
					jSonData = $.parseJSON(data);
					if(jSonData.status){
						flagValidationStat = true
					}else{
						flagValidationStat = false;
						jQuery('#template'+templateId+' #TicketBrowserForm_templatename_em_').html('Template already existed');
						jQuery('#template'+templateId+' #TicketBrowserForm_templatename_em_').css('display', 'block');
						jQuery('#template'+templateId+' #TicketBrowserForm_templatename').focus();
						jQuery('#template'+templateId+' #TicketBrowserForm_templatename_em_').prev().css('border', '1px solid red');
						//flagValidationStat = false;
					}/*else{
						jQuery('#template'+templateId+' #TicketBrowserForm_templatename_em_').html('');
						jQuery('#template'+templateId+' #TicketBrowserForm_templatename_em_').hide();
						jQuery('#template'+templateId+' #TicketBrowserForm_templatename_em_').prev().css('border', '1px solid #CCCCCC');
						//flagValidationStat = false;
					}*/
				}
			});			
		}

		fromDate = jQuery('#TicketBrowserForm'+templateId+'_fromdate').val();
		toDate = jQuery('#TicketBrowserForm'+templateId+'_todate').val();
		if($('#template'+templateId+' #TicketBrowserForm_opt_dateselection_1').is(':checked') == true){
			//console.log('Date selected')
			if(fromDate != '' || toDate != ''){
				if(fromDate == ''){
					jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').html('Please select from date');
					jQuery('#TicketBrowserForm'+templateId+'_todate_em_').html('');
					jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').show();
					jQuery('#TicketBrowserForm'+templateId+'_todate_em_').hide();
					jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').parent().find('input').css('border', '1px solid red');
					jQuery('#TicketBrowserForm'+templateId+'_todate_em_').parent().find('input').css('border', '1px solid #CCCCCC');
					flagValidationStat = false;
				}
				if(toDate == ''){
					//jQuery('#TicketBrowserForm'+templateId+'_todate_em_').html('Please select to date');
					jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').html('');
					//jQuery('#TicketBrowserForm'+templateId+'_todate_em_').show();
					jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').hide();
					//jQuery('#TicketBrowserForm'+templateId+'_todate_em_').parent().find('input').css('border', '1px solid red');
					jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').parent().find('input').css('border', '1px solid #CCCCCC');
					//flagValidationStat = false;
				}
				if (Date.parse(fromDate) > Date.parse(toDate)) {
					jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').html('Invalid date selection');
					jQuery('#TicketBrowserForm'+templateId+'_todate_em_').html('');
					jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').show();
					jQuery('#TicketBrowserForm'+templateId+'_todate_em_').hide();
					jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').parent().find('input').css('border', '1px solid red');
					jQuery('#TicketBrowserForm'+templateId+'_todate_em_').parent().find('input').css('border', '1px solid red');
					flagValidationStat = false;
				}
			}else{
				jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').html('Invalid date selection');
				jQuery('#TicketBrowserForm'+templateId+'_todate_em_').html('');
				jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').show();
				jQuery('#TicketBrowserForm'+templateId+'_todate_em_').hide();
				jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').parent().find('input').css('border', '1px solid red');
				jQuery('#TicketBrowserForm'+templateId+'_todate_em_').parent().find('input').css('border', '1px solid red');
				flagValidationStat = false;
			}
		}
		
 //che		
		var _priority_From = $('#template'+templateId+' #TicketBrowserForm_opt_priority_from :checked').val();
		var _priority_To = $('#template'+templateId+' #TicketBrowserForm_opt_priority_to :checked').val();
		
		if( typeof (_priority_From) != 'undefined' && typeof (_priority_To) === 'undefined' ){				
		jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').html('Please select changed priority from the listed \"TO\" option ');
			 jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').show();
			 jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').focus();		 
			 flagValidationStat = false;			
		}else {
			var priority_To = new Array();
		     $('#template'+templateId+' #TicketBrowserForm_opt_priority_to :checked').each(function() {
		    	 priority_To.push($(this).val());
		     }); 
		     
		     var priority_From = $('#template'+templateId+' #TicketBrowserForm_opt_priority_from :checked').val();		     
		     if(jQuery.inArray(priority_From, priority_To)!==-1) { 
		    	 jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').html('Please make sure selected priority \"FROM\"  and  \"TO\" should not be equal. ');
		    	 jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').show();
				 jQuery('#TicketBrowser'+templateId+' #TicketBrowserForm_opt_priority_to').focus();		 
				// jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').prev().css('border', '1px solid red');
				 flagValidationStat = false;
		     	}else{	
					jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').hide();
		     	}
		}
		
		
		
		
		if(flagValidationStat){
			jQuery('#template'+templateId+' #TicketBrowserForm_display_columns option').each(function (i,v){
				$(v).attr('selected', 'selected');
			});
			$('#template'+templateId+' #spnActionStatus').append(loadingImg);
			$.ajax({
				type:'POST',
				//async: false,
				url: urlSaveTemplate+'?action='+action,
				data: $('#template'+templateId).serialize(),
				success: function (data){
					$('.loadingImg').remove();
					jSonData = $.parseJSON(data);
					if(jSonData.status){
						
						if($('li.ui-tabs-active a').html() != 'Browse'){
							$('li.ui-tabs-active a').html(templateName);
							$.notification({class:'success_notify', notification:'template_updated_successfully', replaceKeys:{TEMPLATE_NAME:jSonData.TEMPLATE_NAME}});
						}else{
							$.notification({class:'success_notify', notification:'template_saved_successfully', replaceKeys:{TEMPLATE_NAME:jSonData.TEMPLATE_NAME}});
							$('#template0').find('#btnReset').trigger('click');
						}
						//refresh templates list
						if(ControllerName == 'incidentManagement'){
							getTemplatesView();
						}else{
							$.ajax({
								type: 'GET',
								url: urlGetTempaltesList,
								success: function (data){
									$('#templates_info').html(data);
								}
							});
						}
						
					}else{
						if(jSonData.error_message == 'error_template_not_saved')
							$.notification({class:'error_notify', notification:'error_template_not_saved', replaceKeys:{TEMPLATE_NAME:jSonData.TEMPLATE_NAME}});
						
						if(jSonData.error_message == 'exceed_limit')
							$.notification({class:'error_notify', notification:'exceed_limit'});
					}
				}
			});
		}
	});
	
	jQuery('#btnRun').live('click', function(){
		templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
		var flagValidationStat = true;
		var _priority_From = $('#template'+templateId+' #TicketBrowserForm_opt_priority_from :checked').val();
		var _priority_To = $('#template'+templateId+' #TicketBrowserForm_opt_priority_to :checked').val();
		
		fromDate = jQuery('#TicketBrowserForm'+templateId+'_fromdate').val();
		toDate = jQuery('#TicketBrowserForm'+templateId+'_todate').val();
		
		if (Date.parse(fromDate) > Date.parse(toDate)) {
			jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').html('Invalid date selection');
			jQuery('#TicketBrowserForm'+templateId+'_todate_em_').html('');
			jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').show();
			jQuery('#TicketBrowserForm'+templateId+'_todate_em_').hide();
			jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').parent().find('input').css('border', '1px solid red');
			jQuery('#TicketBrowserForm'+templateId+'_todate_em_').parent().find('input').css('border', '1px solid red');
			flagValidationStat = false;				
		}else if(!validateCreated(templateId)){
			jQuery('#template'+templateId+' #'+reportflag+'Form_is_modified_tickets_em_').html('Please select atleast one option from Created and Modified');
			jQuery('#template'+templateId+' #'+reportflag+'Form_is_modified_tickets_em_').show();
			jQuery('#template'+templateId+' #'+reportflag+'Form_is_modified_tickets_em_').focus();
			jQuery('#template'+templateId+' #'+reportflag+'Form_is_modified_tickets_em_').next().css('border', '1px solid red');
			$('#template'+templateId+" #TicketBrowserForm_is_modified_tickets_0").focus();
			flagValidationStat = false;
		}else if( typeof (_priority_From) != 'undefined' && typeof (_priority_To) === 'undefined' ){				
			jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').html('Please select changed priority from the listed \"TO\" option ');
			 jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').show();
			 jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').focus();		 
			// jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').prev().css('border', '1px solid red');
			 flagValidationStat = false;			
		}else {
			var priority_To = new Array();
		     $('#template'+templateId+' #TicketBrowserForm_opt_priority_to :checked').each(function() {
		    	 priority_To.push($(this).val());
		     }); 
		     
		     var priority_From = $('#template'+templateId+' #TicketBrowserForm_opt_priority_from :checked').val();		     
		     if(jQuery.inArray(priority_From, priority_To)!==-1) { 
		    	 jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').html('Please make sure selected priority \"FROM\"  and  \"TO\" should not be equal. ');
		    	 jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').show();
				 jQuery('#TicketBrowser'+templateId+' #TicketBrowserForm_opt_priority_to').focus();		 
				// jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').prev().css('border', '1px solid red');
				 flagValidationStat = false;
		     	}else{	
					jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').hide();
		     	//	jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').prev().css('border', '1px solid white');			
					jQuery('#template'+templateId+' #TicketBrowserForm_display_columns option').each(function (i,v){
						$(v).attr('selected', 'selected');
					});
					$('#template'+templateId).submit();
		     	}		     			 							
		}
		
		
		if (Date.parse(fromDate) < Date.parse(toDate)) {
			jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').html('');
			jQuery('#TicketBrowserForm'+templateId+'_fromdate_em_').parent().find('input').css('border', '1px solid #CCCCCC');
			jQuery('#TicketBrowserForm'+templateId+'_todate_em_').parent().find('input').css('border', '1px solid #CCCCCC');
		
		}
		
		/*else{			
			jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').hide();
     		jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').prev().css('border', '1px solid white');			
			jQuery('#template'+templateId+' #TicketBrowserForm_display_columns option').each(function (i,v){
				$(v).attr('selected', 'selected');
			});
			$('#template'+templateId).submit();
		}*/
	});
	
	jQuery('#btnReset').live('click',function(){		
		jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').hide();		
	});
	
	jQuery('#btnRunTempaltes').live('click', function(){
		if(jQuery('#selectedTemplates option').length == 1){
			templateId = jQuery('#selectedTemplates option').val();
			url = jQuery('form#template0').attr('action');
			url += '?view='+btoa(unescape(encodeURIComponent(templateId)));
		}else{
			jQuery('#selectedTemplates option').each(function (i,v){
				$(v).attr('selected', 'selected');
			});
			data = $('#selectedTemplates').serialize();
			url = urlMultileTemplates+'?'+data;			
		}
		url = nncUrl+url;
		window.open(url,"multipleTemplateResults","addressbar=0,location=0,resizable=yes,status=0,menubar=0,scrollbars=1,toolbar=0");
	});
	
	jQuery('#scheduleTemplate').live('click', function(){
		tid = $(this).attr('data-tid');
		url = urlScheduleTemplate+'?tid='+tid+'&type=TB';
		$.colorbox({href:url, width:"1050px", height:"610px", iframe:true});
	});	
	
	$('#scheduleLogs').live('click',function(){
		tid = $(this).attr('data-tid');
		url = urlScheduleLogs+'?tid='+tid;
		$.colorbox({href:url, width:"950px", height:"610px", iframe:true});
	});
	
	
});

function resetFormFields(formId){
	//console.log(formId);
}

function refresh(){
	$('#spanRefreshTemplateList').show();
	$.ajax({
		type: 'GET',
		url: urlGetTempaltesList+'?param=json',
		success: function (html){
				$('#spanRefreshTemplateList').hide();
				jQuery('#templates').empty();
				jSonData= jQuery.parseJSON(html);
				$.each( jSonData, function(key,value) {
						if(!value ==''){
							jQuery('#templates').html(value);
						}
	            });
		       $('#selectedTemplates option').each(function (i,v){
		    	   $('#templates  option[value="'+$(this).val()+'"]' ).remove();
		       });
		},
	});
}
/*
jQuery('#TicketBrowserForm_opt_priority_to,#TicketBrowserForm_opt_priority_from').live('click', function(){
	templateId = $(this).parents().find('input#TicketBrowserForm_templateid').attr('value');
    var priority_From = new Array();
     $('#template'+templateId+' #TicketBrowserForm_opt_priority_to :checked').each(function() {
    	 priority_From.push($(this).val());
     });    
     var priority_To = $('#template'+templateId+' #TicketBrowserForm_opt_priority_from :checked').val();
   
     if(jQuery.inArray(priority_To, priority_From)!==-1) { 
    	 jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').html('please check priority');
		 jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').css('display', 'block');
		 jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').focus();		 
		 jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').prev().css('border', '1px solid red');
		 flagValidationStat = false;
     	} else {
     		jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').hide();
     		jQuery('#TicketBrowser'+templateId+'_opt_priority_to_em').prev().css('border', '1px solid white');   		
     	}
});*/
