/*
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
*/

// Functionality to fetch the clients of respective partner
$(document).ready(function(){
	//ajax call to get client correspondig to the selected partners
	$('#idPartnerData').on('change',function(){
		$.ajax({
			type: "POST",
			url: "/qualityMetric/getClientOfPat?_ajax=true",
			data: {
				'res_cli' : $('#idPartnerData').val(),
				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
			},
			beforeSend: function (){
		       $('span#loadingClient').show();
		       },
		    complete: function(){
		       $('span#loadingClient').hide();
		       },
			success: function(data){
				$('#idClientData').selectpicker('destroy');
				var datalist = new Array();
				$.each(data.clients,function(key,val){
					datalist.push("<option value = "+val.mspclientid+">"+val.clientname+"</option>");
				});
				$('#idClientData').html(datalist);
                $('#idClientData').selectpicker('multiselectEnable');
			},
		});
		
	});
});
//end of code

// Functionality to fetch the reports based on inputs like partner, client, reviewer, staff, review metric, quality reating
$(document).ready(function(){
    $("#idSearch").on("click", function(){
        var fromdate = $("#idFromDate").val();
        var todate = $("#idToDate").val();
        var partners = $("#idPartnerData").val();
        var clients = $("#idClientData").val();
        var staff =  $("#idStaffData").val();
        var reviewers = $("#idReviewerData").val();
        var reviewmetric = $("#idReviewMetricData").val();
        var qualityrating = $("#idQualityRatingData").val();

        if (partners == null){
            $("#myAlert").show()
            $("#divErrorMsg").text("Please select at least one partner");
            return false;
        }

        else if (clients == null){
            $("#myAlert").show()
            $("#divErrorMsg").text("Please select at least one client");
            return false;
        }

        else if (staff == null){
            $("#myAlert").show()
            $("#divErrorMsg").text("Please select at least one staff");
            return false;
        }

        else if (reviewers == null){
            $("#myAlert").show()
            $("#divErrorMsg").text("Please select at least one reviewer");
            return false;
        }

        else if (reviewmetric == null){
            $("#myAlert").show()
            $("#divErrorMsg").text("Please select at least one review metric");
            return false;
        }

        else if (qualityrating == null){
            $("#myAlert").show()
            $("#divErrorMsg").text("Please select at least one rating");
            return false;
        }
        else{
            $( "#idForm" ).submit();
        }

//        $.ajax({
//			type: "POST",
//			url: "/qualityMetric/Report",
//			data: {
//			    'fromdate' : fromdate,
//			    'todate' : todate,
//			    'partners' : JSON.stringify(partners),
//			    'clients' : JSON.stringify(clients),
//			    'staff' : JSON.stringify(staff),
//			    'reviewers' : JSON.stringify(reviewers),
//			    'reviewmetric' : JSON.stringify(reviewmetric),
//			    'qualityrating' : JSON.stringify(qualityrating),
//				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
//			},
//			beforeSend: function (){
//		       $('span#loadingSubmit').show();
//		       $("#idSearch").prop('disabled', true);
//		       $("#myAlert").hide()
//		       },
//		    complete: function(){
//		       $('span#loadingSubmit').hide();
//		       $("#idSearch").prop('disabled', false);
//		       },
//			success: function(data){
//				alert("success");
//			},
//		});
    });
});

// end of code
