/* * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 */

var grap = ["open_tickets_by_dept", "scheduled", "total_open_tickets", "sla_missed", "closed_tickets_by_priority", "alerts_vs_tickets", "first_resp_time", "dept_sla_trend", "department_trend", "tickets_age_by_dept", "resol_resp", "tickets_trend", "top_fiv_devices", "top_fiv_clients", "wfci_count", "hmps_count", "tkts_crtd_by_dept_pty", "opn_crtd_clsd_tkts", "created_closed_tkts","closed_tickets_by_dept"];
var drange = ["Last 8 hours", "Last 24 hours", "Last week", "Last month", "Last 3 months", "Custom"];
var graphInput = [];
$(window).bind('load', function() {
 setForm();
 var utc = moment.utc(new Date());
 var pst = moment(utc).zone('-0800');
 var currentUTCTime = pst.format('YYYY-MM-DD HH:mm');
 var yesdateUTC = pst.add(-1, 'days').format('YYYY-MM-DD HH:mm');
 var calanderFromDate = {
  defaultDate: yesdateUTC,
  maxDate: yesdateUTC,
  htmlId: 'sdmg_fdDates',
  format: 'YYYY-MM-DD HH:mm'
 };
 var calanderToDate = {
  defaultDate: currentUTCTime,
  maxDate: currentUTCTime,
  htmlId: 'sdmg_tdDates',
  format: 'YYYY-MM-DD HH:mm'
 };
 prepareCalendar(calanderFromDate);
 prepareCalendar(calanderToDate);
});
$(document).ready(function() {
 $('[data-toggle="tooltip"]').tooltip();

 $('.flip').hover(function() {
  $(this).find('.card').toggleClass('flipped');
 });

 $('[data-toggle=offcanvas]').click(function() {
  $('.row-offcanvas').toggleClass('active');
  $('.right-aside-container').stop().fadeToggle(750);
 });

 $('#sdate').on('change', function() {
  if ($('#sdate').val() == "5") {
   $('#sdmg_DateRange').show();
  } else {
   $('#sdmg_DateRange').hide();
  }
 });

 var chartOptions = google.charts.load('42', {
  'packages': ['bar', 'corechart']
 });

 $('body').on('click', '#gp', function() {
  loadAllGraphs(1);
 });
 $('body').on('click', '#open_tickets_by_dept_rf', function() {
  openTicketByDept();
 });
 $('body').on('click', '#scheduled_rf', function() {
  loadScheduledTicketsChart();
 });
 $('body').on('click', '#total_open_tickets_rf', function() {
  totalOpenTickets();
 });
 $('body').on('click', '#sla_missed_rf', function() {
  slaMissed();
 });
 $('body').on('click', '#closed_tickets_by_priority_rf', function() {
  closedTicketsByPriority();
 });
 $('body').on('click', '#alerts_vs_tickets_rf', function() {
  alertsVsTickets();
 });
 $('body').on('click', '#first_resp_time_rf', function() {
  firstRespTime();
 });
 $('body').on('click', '#resol_resp_rf', function() {
  loadResolutionResponseChart();
 });
 $('body').on('click', '#dept_sla_trend_rf', function() {
  deptSlaTrend();
 });
 $('body').on('click', '#department_trend_rf', function() {
  departmentTrend();
 });
 $('body').on('click', '#tickets_trend_rf', function() {
  ticketsTrend();
 });
 $('body').on('click', '#tickets_age_by_dept_rf', function() {
  ticketsAgeByDept();
 });
 $('body').on('click', '#top_fiv_devices_rf', function() {
  loadTopFiveDevices();
 });
 $('body').on('click', '#top_fiv_clients_rf', function() {
  loadTopFiveClients();
 });
 $('body').on('click', '#wfci_count_rf', function() {
  loadWfciCount();
 });
 $('body').on('click', '#hmps_count_rf', function() {
  loadHmspCount();
 });
 $('body').on('click', '#tkts_crtd_by_dept_pty_rf', function() {
  loadTktsCreatedByDeptPriority();
 });
 $('body').on('click', '#opn_crtd_clsd_tkts_rf', function() {
  loadOpnCrtdClsdTkts();
 });
 $('body').on('click', '#created_closed_tkts_rf', function() {
  loadCreatedClosedTkts();
 });
 $('body').on('click', '#closed_tickets_by_dept_rf', function() {
	closedTicketByDept();
 });
 $('body').on('click', '#downloadgraph', function(e) {
  name = $(this).attr('data-divid');
  downloadImage(name);
 });
});

function loadAllGraphs(flag) {

 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sgp = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();

 $.each(grap, function(k, showG) {
  $('#' + showG).hide();
 });
 if (tId != 0) {
  $.each(sgp, function(i, v) {
   switch (v) {
    case 'open_tickets_by_dept':
     $('#' + v).show();
     openTicketByDept(flag);
     break;
    case 'scheduled':
     $('#' + v).show();
     loadScheduledTicketsChart();
     break;
    case 'total_open_tickets':
     $('#' + v).show();
     totalOpenTickets();
     break;
    case 'sla_missed':
     $('#' + v).show();
     slaMissed();
     break;
    case 'closed_tickets_by_priority':
     $('#' + v).show();
     closedTicketsByPriority();
     break;
    case 'alerts_vs_tickets':
     $('#' + v).show();
     alertsVsTickets();
     break;
    case 'first_resp_time':
     $('#' + v).show();
     firstRespTime();
     break;
    case 'dept_sla_trend':
     $('#' + v).show();
     deptSlaTrend();
     break;
    case 'department_trend':
     $('#' + v).show();
     departmentTrend();
     break;
    case 'tickets_age_by_dept':
     $('#' + v).show();
     ticketsAgeByDept();
     break;
    case 'resol_resp':
     $('#' + v).show();
     loadResolutionResponseChart();
     break;
    case 'tickets_trend':
     $('#' + v).show();
     ticketsTrend();
     break;
    case 'top_fiv_devices':
     $('#' + v).show();
     loadTopFiveDevices();
     break;
    case 'top_fiv_clients':
     $('#' + v).show();
     loadTopFiveClients();
     break;
    case 'wfci_count':
     $('#' + v).show();
     loadWfciCount();
     break;
    case 'hmps_count':
     $('#' + v).show();
     loadHmspCount();
     break;
    case 'tkts_crtd_by_dept_pty':
     $('#' + v).show();
     loadTktsCreatedByDeptPriority();
     break;
    case 'opn_crtd_clsd_tkts':
     $('#' + v).show();
     loadOpnCrtdClsdTkts();
     break;
    case 'created_closed_tkts':
     $('#' + v).show();
     loadCreatedClosedTkts();
     break;
    case 'closed_tickets_by_dept':
        $('#' + v).show();
        closedTicketByDept();
        break;
   }
  });
 }
}

function setForm() {
 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/setform/",
  data: {
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  success: function(data) {
   var temp = new Array();
   var gh = new Array();
   var dr = new Array();
   $.each(grap, function(k, showG) {
    $.each(data.graphCach.sGraph, function(k, v) {
     if (v == showG) {
      gh.push("<option value = " + showG + " selected='true'>" + showG + "</option>");
     } else {
      gh.push("<option value = " + showG + ">" + showG + "</option>");
     }
    });
   });
   for (var k in drange) {
    if (data.graphCach.limit == k) {
     dr.push("<option value = " + k + " selected='true'>" + drange[k] + "</option>");
     if (k == 5) {
      var utc1 = moment.utc(new Date());
      var pst1 = moment(utc1).zone('-0800');
      var currentUTCTime1 = pst1.format('YYYY-MM-DD HH:mm');
      var yesdateUTC1 = pst1.add(-1, 'days').format('YYYY-MM-DD HH:mm');
      $('#sdmg_DateRange').show();
      var optionsFromDt1 = {
       icons: {
        time: "fa fa-clock-o",
        date: 'fa fa-calendar',
        up: 'fa fa-arrow-up',
        down: 'fa fa-arrow-down',
       },
       sideBySide: true,
       maxDate: yesdateUTC1,
       defaultDate: data.graphCach.fromDate,
       format: 'YYYY-MM-DD HH:mm'
      };
      var optionsToDt1 = {
       icons: {
        time: "fa fa-clock-o",
        date: 'fa fa-calendar',
        up: 'fa fa-arrow-up',
        down: 'fa fa-arrow-down',
       },
       sideBySide: true,
       maxDate: currentUTCTime1,
       defaultDate: data.graphCach.toDate,
       format: 'YYYY-MM-DD HH:mm'
      };
      $('#sdmg_fdDates').val(data.graphCach.fromDate);
      $('#sdmg_fdDates').datetimepicker(optionsFromDt1);
      $('#sdmg_tdDates').val(data.graphCach.toDate);
      $('#sdmg_tdDates').datetimepicker(optionsToDt1);
     }
    } else {
     dr.push("<option value = " + k + ">" + drange[k] + "</option>");
    }
   }
   var pr = '<optgroup label="Private">';
   var pb = '<optgroup label="Public">';
   $.each(data.tempList, function(k, template) {

    if (data.graphCach.tid == template.templateid) {
     if (template.templatetype == '1') {
      pr += "<option value = " + template.templateid + " selected='true'>" + template.templatename + "</option>";
     } else {
      pb += "<option value = " + template.templateid + " selected='true'>" + template.templatename + "</option>"
     }
    } else {
     if (template.templatetype == '1') {
      pr += "<option value = " + template.templateid + " >" + template.templatename + "</option>";
     } else {
      pb += "<option value = " + template.templateid + " >" + template.templatename + "</option>"
     }
    }

   });
   var temT = pr + pb;
   $('#temList').selectpicker('destroy');
   $('#sGraph').selectpicker('destroy');
   $('#sdate').selectpicker('destroy');
   $('#temList').html(temT);
   $('#sdate').html(dr);
   $('#sGraph').html(gh);
   $('#temList').selectpicker();
   $('#sGraph').selectpicker();
   $('#sdate').selectpicker();
   loadAllGraphs(0);
  }

 });
}

function loadScheduledTicketsChart() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'scheduled',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_scheduled').show();
   $('a#scheduled_rf').hide();
   $('i#downloadgraph[data-divid="scheduled_content"]').hide();
  },
  complete: function() {
   $('span#load_scheduled').hide();
   $('a#scheduled_rf').show();
   $('i#downloadgraph[data-divid="scheduled_content"]').show();
  },
  success: function(data) {
   graphInput['scheduled'] = new Array();
   graphInput['scheduled']['chartData'] = data.graphData['chartData'];
   graphInput['scheduled']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#scheduled').show();
    google.charts.setOnLoadCallback(drawScheduledTicketsChart);
   } else {
    $('#scheduled').hide();
   }
  }
 });
}
function loadResolutionResponseChart() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sg = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }
 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'resol_resp',
   'limit': sDate,
   'fromDate': frmDate,
   'toDate': toDate,
   'sg': sg,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_resol_resp').show();
   $('a#resol_resp_rf').hide();
   $('i#downloadgraph[data-divid="resol_resp_content"]').hide();
  },
  complete: function() {
   $('span#load_resol_resp').hide();
   $('a#resol_resp_rf').show();
   $('i#downloadgraph[data-divid="resol_resp_content"]').show();
  },
  success: function(data) {
   graphInput['resol_resp'] = new Array();
   graphInput['resol_resp']['chartData'] = data.graphData['chartData'];
   graphInput['resol_resp']['slamFilters'] = data.graphData['slamFilters'];

   if (data.graphData['chartData'].length > 1) {
    $('#resol_resp').show();
    google.charts.setOnLoadCallback(drawResolutionResponseChart);
   } else {
    $('#resol_resp').hide();
   }
  }
 });
}



function openTicketByDept(flag) {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'open_tickets_by_dept',
   'limit': sDate,
   'fromDate': frmDate,
   'toDate': toDate,
   'sGraph': sGraph,
   'flag':flag,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_open_tickets_by_dept').show();
   $('a#open_tickets_by_dept_rf').hide();
   $('i#downloadgraph[data-divid="open_tickets_by_dept_content"]').hide();
  },
  complete: function() {
   $('span#load_open_tickets_by_dept').hide();
   $('a#open_tickets_by_dept_rf').show();
   $('i#downloadgraph[data-divid="open_tickets_by_dept_content"]').show();

  },
  success: function(data) {
   graphInput['open_tickets_by_dept'] = new Array();
   graphInput['open_tickets_by_dept']['chartData'] = data.graphData['chartData'];
   graphInput['open_tickets_by_dept']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#open_tickets_by_dept').show();
    google.charts.setOnLoadCallback(drawOpenTicketByDept);
   } else {
    $('#open_tickets_by_dept').hide();
   }

  }
 });
}

function totalOpenTickets() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'total_open_tickets',
   'limit': sDate,
   'fromDate': frmDate,
   'toDate': toDate,
   'sGraph': sGraph,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_total_open_tickets').show();
   $('a#total_open_tickets_rf').hide();
   $('i#downloadgraph[data-divid="total_open_tickets_content"]').hide();
  },
  complete: function() {
   $('span#load_total_open_tickets').hide();
   $('a#total_open_tickets_rf').show();
   $('i#downloadgraph[data-divid="total_open_tickets_content"]').show();
  },
  success: function(data) {
   graphInput['total_open_tickets'] = new Array();
   graphInput['total_open_tickets']['chartData'] = data.graphData['chartData'];
   graphInput['total_open_tickets']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#total_open_tickets').show();
    google.charts.setOnLoadCallback(drawTotalOpenTickets);
   } else {
    $('#total_open_tickets').hide();
   }
  }
 });
}

function slaMissed() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'sla_missed',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_sla_missed').show();
   $('a#sla_missed_rf').hide();
   $('i#downloadgraph[data-divid="sla_missed_content"]').hide();
  },
  complete: function() {
   $('span#load_sla_missed').hide();
   $('a#sla_missed_rf').show();
   $('i#downloadgraph[data-divid="sla_missed_content"]').show();
  },
  success: function(data) {
   graphInput['sla_missed'] = new Array();
   graphInput['sla_missed']['chartData'] = data.graphData['chartData'];
   graphInput['sla_missed']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#sla_missed').show();
    google.charts.setOnLoadCallback(drawSlaMissed);
   } else {
    $('#sla_missed').hide();
   }

  }
 });
}

function closedTicketsByPriority() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'closed_tickets_by_priority',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_closed_tickets_by_priority').show();
   $('a#closed_tickets_by_priority_rf').hide();
   $('i#downloadgraph[data-divid="closed_tickets_by_priority_content"]').hide();
  },
  complete: function() {
   $('span#load_closed_tickets_by_priority').hide();
   $('a#closed_tickets_by_priority_rf').show();
   $('i#downloadgraph[data-divid="closed_tickets_by_priority_content"]').show();
  },
  success: function(data) {
   graphInput['closed_tickets_by_priority'] = new Array();
   graphInput['closed_tickets_by_priority']['chartData'] = data.graphData['chartData'];
   graphInput['closed_tickets_by_priority']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#closed_tickets_by_priority').show();
    google.charts.setOnLoadCallback(drawClosedTicketsByPriority);
   } else {
    $('#closed_tickets_by_priority').hide();
   }
  }
 });
}

function alertsVsTickets() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'alerts_vs_tickets',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_alerts_vs_tickets').show();
   $('a#alerts_vs_tickets_rf').hide();
   $('i#downloadgraph[data-divid="alerts_vs_tickets_content"]').hide();
  },
  complete: function() {
   $('span#load_alerts_vs_tickets').hide();
   $('a#alerts_vs_tickets_rf').show();
   $('i#downloadgraph[data-divid="alerts_vs_tickets_content"]').show();
  },
  success: function(data) {
   graphInput['alerts_vs_tickets'] = new Array();
   graphInput['alerts_vs_tickets']['chartData'] = data.graphData['chartData'];
   graphInput['alerts_vs_tickets']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#alerts_vs_tickets').show();
    google.charts.setOnLoadCallback(drawAlertsVsTickets);
   } else {
    $('#alerts_vs_tickets').hide();
   }
  }
 });
}

function firstRespTime() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'first_resp_time',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_first_resp_time').show();
   $('a#first_resp_time_rf').hide();
   $('i#downloadgraph[data-divid="first_resp_time_content"]').hide();
  },
  complete: function() {
   $('span#load_first_resp_time').hide();
   $('a#first_resp_time_rf').show();
   $('i#downloadgraph[data-divid="first_resp_time_content"]').show();
  },
  success: function(data) {
   
   graphInput['first_resp_time'] = new Array();
   graphInput['first_resp_time']['chartData'] = data.graphData['chartData'];
   graphInput['first_resp_time']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#first_resp_time').show();
    google.charts.setOnLoadCallback(drawFirstRespTime);
   } else {
    $('#first_resp_time').hide();
   }
  }
 });
}

function deptSlaTrend() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'dept_sla_trend',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_dept_sla_trend').show();
   $('a#dept_sla_trend_rf').hide();
   $('i#downloadgraph[data-divid="dept_sla_trend_rf_content"]').hide();
  },
  complete: function() {
   $('span#load_dept_sla_trend').hide();
   $('a#dept_sla_trend_rf').show();
   $('i#downloadgraph[data-divid="dept_sla_trend_rf_content"]').show();
  },
  success: function(data) {
   graphInput['dept_sla_trend'] = new Array();
   graphInput['dept_sla_trend']['chartData'] = data.graphData['chartData'];
   graphInput['dept_sla_trend']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#dept_sla_trend').show();
    google.charts.setOnLoadCallback(drawDepartmentSlaTrend);
   } else {
    $('#dept_sla_trend').hide();
   }
  }
 });
}

function departmentTrend() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'department_trend',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_department_trend').show();
   $('a#department_trend_rf').hide();
   $('i#downloadgraph[data-divid="department_trend_content"]').hide();
  },
  complete: function() {
   $('span#load_department_trend').hide();
   $('a#department_trend_rf').show();
   $('i#downloadgraph[data-divid="department_trend_content"]').show();
  },
  success: function(data) {
   graphInput['department_trend'] = new Array();
   graphInput['department_trend']['chartData'] = data.graphData['chartData'];
   graphInput['department_trend']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#department_trend').show();
    google.charts.setOnLoadCallback(drawDepartmentTrend);
   } else {
    $('#department_trend').hide();
   }
  }
 });
}

function ticketsTrend() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'tickets_trend',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_tickets_trend').show();
   $('a#tickets_trend_rf').hide();
   $('i#downloadgraph[data-divid="tickets_trend_content"]').hide();
  },
  complete: function() {
   $('span#load_tickets_trend').hide();
   $('a#tickets_trend_rf').show();
   $('i#downloadgraph[data-divid="tickets_trend_content"]').show();
  },
  success: function(data) {
   graphInput['tickets_trend'] = new Array();
   graphInput['tickets_trend']['chartData'] = data.graphData['chartData'];
   graphInput['tickets_trend']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#tickets_trend').show();
    google.charts.setOnLoadCallback(drawTicketsTrend);
   } else {
    $('#tickets_trend').hide();
   }
  }
 });
}

function ticketsAgeByDept() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }
 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'tickets_age_by_dept',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_tickets_age_by_dept').show();
   $('a#tickets_age_by_dept_rf').hide();
   $('i#downloadgraph[data-divid="tickets_age_by_dept_content"]').hide();
  },
  complete: function() {
   $('span#load_tickets_age_by_dept').hide();
   $('a#tickets_age_by_dept_rf').show();
   $('i#downloadgraph[data-divid="tickets_age_by_dept_content"]').show();
  },
  success: function(data) {
   graphInput['tickets_age_by_dept'] = new Array();
   graphInput['tickets_age_by_dept']['chartData'] = data.graphData['chartData'];
   graphInput['tickets_age_by_dept']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#tickets_age_by_dept').show();
    google.charts.setOnLoadCallback(drawTicketsAgeByDept);
   } else {
    $('#tickets_age_by_dept').hide();
   }
  }
 });
}

function loadTopFiveDevices() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'top_fiv_devices',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_top_fiv_devices').show();
   $('a#top_fiv_devices_rf').hide();
   $('i#downloadgraph[data-divid="top_fiv_devices_content"]').hide();
  },
  complete: function() {
   $('span#load_top_fiv_devices').hide();
   $('a#top_fiv_devices_rf').show();
   $('i#downloadgraph[data-divid="top_fiv_devices_content"]').show();
  },
  success: function(data) {
   graphInput['top_fiv_devices'] = new Array();
   graphInput['top_fiv_devices']['chartData'] = data.graphData['chartData'];
   graphInput['top_fiv_devices']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#top_fiv_devices').show();
    google.charts.setOnLoadCallback(drawTopFiveDevices);
   } else {
    $('#top_fiv_devices').hide();
   }
  }
 });
}

function loadTopFiveClients() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'top_fiv_clients',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_top_fiv_clients').show();
   $('a#top_fiv_clients_rf').hide();
   $('i#downloadgraph[data-divid="top_fiv_clients_content"]').hide();
  },
  complete: function() {
   $('span#load_top_fiv_clients').hide();
   $('a#top_fiv_clients_rf').show();
   $('i#downloadgraph[data-divid="top_fiv_clients_content"]').show();
  },
  success: function(data) {
   graphInput['top_fiv_clients'] = new Array();
   graphInput['top_fiv_clients']['chartData'] = data.graphData['chartData'];
   graphInput['top_fiv_clients']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#top_fiv_clients').show();
    google.charts.setOnLoadCallback(drawTopFiveClients);
   } else {
    $('#top_fiv_clients').hide();
   }
  }
 });
}

function loadWfciCount() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'wfci_count',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_wfci_count').show();
   $('a#wfci_count_rf').hide();
   $('i#downloadgraph[data-divid="wfci_count_content"]').hide();
  },
  complete: function() {
   $('span#load_wfci_count').hide();
   $('a#wfci_count_rf').show();
   $('i#downloadgraph[data-divid="wfci_count_content"]').show();
  },
  success: function(data) {
   graphInput['wfci_count'] = new Array();
   graphInput['wfci_count']['chartData'] = data.graphData['chartData'];
   graphInput['wfci_count']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#wfci_count').show();
    google.charts.setOnLoadCallback(drawWfciCounts);
   } else {
    $('#wfci_count').hide();
   }
  }
 });
}

function loadHmspCount() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'hmps_count',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_hmps_count').show();
   $('a#hmps_count_rf').hide();
   $('i#downloadgraph[data-divid="hmps_count_content"]').hide();
  },
  complete: function() {
   $('span#load_hmps_count').hide();
   $('a#hmps_count_rf').show();
   $('i#downloadgraph[data-divid="hmps_count_content"]').show();
  },
  success: function(data) {
   graphInput['hmps_count'] = new Array();
   graphInput['hmps_count']['chartData'] = data.graphData['chartData'];
   graphInput['hmps_count']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#hmps_count').show();
    google.charts.setOnLoadCallback(drawHmspCounts);
   } else {
    $('#hmps_count').hide();
   }
  }
 });
}

function loadTktsCreatedByDeptPriority() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'tkts_crtd_by_dept_pty',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_tkts_crtd_by_dept_pty').show();
   $('a#tkts_crtd_by_dept_pty_rf').hide();
   $('i#downloadgraph[data-divid="tkts_crtd_by_dept_pty_content"]').hide();
  },
  complete: function() {
   $('span#load_tkts_crtd_by_dept_pty').hide();
   $('a#tkts_crtd_by_dept_pty_rf').show();
   $('i#downloadgraph[data-divid="tkts_crtd_by_dept_pty_content"]').show();
  },
  success: function(data) {
   graphInput['tkts_crtd_by_dept_pty'] = new Array();
   graphInput['tkts_crtd_by_dept_pty']['chartData'] = data.graphData['chartData'];
   graphInput['tkts_crtd_by_dept_pty']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#tkts_crtd_by_dept_pty').show();
    google.charts.setOnLoadCallback(drawTktsCreatedByDeptPriority);
    drawOpnCrtdClsdTkts
   } else {
    $('#tkts_crtd_by_dept_pty').hide();
   }
  }
 });
}

function loadOpnCrtdClsdTkts() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'opn_crtd_clsd_tkts',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_opn_crtd_clsd_tkts').show();
   $('a#opn_crtd_clsd_tkts_rf').hide();
   $('i#downloadgraph[data-divid="opn_crtd_clsd_tkts_content"]').hide();
  },
  complete: function() {
   $('span#load_opn_crtd_clsd_tkts').hide();
   $('a#opn_crtd_clsd_tkts_rf').show();
   $('i#downloadgraph[data-divid="opn_crtd_clsd_tkts_content"]').show();
  },
  success: function(data) {
   graphInput['opn_crtd_clsd_tkts'] = new Array();
   graphInput['opn_crtd_clsd_tkts']['chartData'] = data.graphData['chartData'];
   graphInput['opn_crtd_clsd_tkts']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#opn_crtd_clsd_tkts').show();
    google.charts.setOnLoadCallback(drawOpnCrtdClsdTkts);
   } else {
    $('#opn_crtd_clsd_tkts').hide();
   }
  }
 });
}

function loadCreatedClosedTkts() {
 var tId = $('#temList').val();
 if (tId == undefined || tId == null || tId == "") {
  tId = 0;
 }
 var sGraph = $('#sgraph').selectpicker('val');
 var sDate = $('#sdate').val();
 if (sDate == '5') {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 } else {
  var frmDate = $('#sdmg_fdDates').val();
  var toDate = $('#sdmg_tdDates').val();
 }

 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/graphApi/",
  data: {
   'tid': tId,
   'report': 'created_closed_tkts',
   'limit': sDate,
   'sGraph': sGraph,
   'fromDate': frmDate,
   'toDate': toDate,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('span#load_created_closed_tkts').show();
   $('a#created_closed_tkts_rf').hide();
   $('i#downloadgraph[data-divid="created_closed_tkts_content"]').hide();
  },
  complete: function() {
   $('span#load_created_closed_tkts').hide();
   $('a#created_closed_tkts_rf').show();
   $('i#downloadgraph[data-divid="created_closed_tkts_content"]').show();
  },
  success: function(data) {
   graphInput['created_closed_tkts'] = new Array();
   graphInput['created_closed_tkts']['chartData'] = data.graphData['chartData'];
   graphInput['created_closed_tkts']['slamFilters'] = data.graphData['slamFilters'];
   if (data.graphData['chartData'].length > 1) {
    $('#created_closed_tkts').show();
    google.charts.setOnLoadCallback(drawCreatedClosedTickets);
   } else {
    $('#created_closed_tkts').hide();
   }
  }
 });
}

function drawResolutionResponseChart() {
 chartOptions = {
  chart: {
   legend: {
    position: 'top'
   },
  },
  bars: 'vertical',
  axes: {
   y: {
    all: {
     range: {
      max: 100,
      min: 70
     },
     label: 'Percentage',
    },

   }
  },
 };
 drawChart('resol_resp', 'Column', graphInput['resol_resp']['chartData'], chartOptions);
}

function drawScheduledTicketsChart() {
 chartOptions = {
  legend: {
   position: 'top'
  },
  pointSize: 5,
  vAxis: {
   title: 'Tickets count'
  },
  crosshair: {
   trigger: "both",
   orientation: "both"
  },

 };
 drawChart('scheduled', 'Line', graphInput['scheduled']['chartData'], chartOptions);
}

function drawOpenTicketByDept() {
 chartOptions = {
  bars: 'vertical',
  vAxis: {
   title: 'Tickets count',
   format: '0'
  },
  legend: {
   position: 'top'
  },
 };
 drawChart('open_tickets_by_dept', 'Column', graphInput['open_tickets_by_dept']['chartData'], chartOptions);
}

function drawClosedTicketByDept() {
	 chartOptions = {
	  bars: 'vertical',
	  vAxis: {
	   title: 'Tickets count',
	   format: '0'
	  },
	  legend: {
	   position: 'top'
	  },
	 };
	 drawChart('closed_tickets_by_dept', 'Column', graphInput['closed_tickets_by_dept']['chartData'], chartOptions);
}

function drawTotalOpenTickets() {
 chartOptions = {
  legend: {
   position: 'top'
  },
  pieSliceText: 'value',
  pieSliceTextStyle: {
   color: 'black',
  },
  pieHole: 0.4,
 };
 drawChart('total_open_tickets', 'Pie', graphInput['total_open_tickets']['chartData'], chartOptions);
}

function drawSlaMissed() {
 chartOptions = {
  legend: {
   position: 'top'
  },
  pieSliceText: 'value',
  pieSliceTextStyle: {
   color: 'black',
  },
  pieHole: 0.4,
 };
 drawChart('sla_missed', 'Pie', graphInput['sla_missed']['chartData'], chartOptions);
}

function drawClosedTicketsByPriority() {
 chartOptions = {
  legend: {
   position: 'top'
  },
  pieSliceText: 'value',
  pieSliceTextStyle: {
   color: 'black',
  },
  pieHole: 0.4,
 };
 drawChart('closed_tickets_by_priority', 'Pie', graphInput['closed_tickets_by_priority']['chartData'], chartOptions);
}

function drawAlertsVsTickets() {
 chartOptions = {
  vAxis: {
   title: 'Tickets count',
   format: '0'
  },
  legend: {
   position: 'top',
   maxLines: 3
  },
 };
 drawChart('alerts_vs_tickets', 'Column', graphInput['alerts_vs_tickets']['chartData'], chartOptions);
}

function drawFirstRespTime() {
 chartOptions = {
  legend: {
   position: 'top'
  },
  vAxis: {
   title: 'Tickets count',
   format: '0'
  },
 };
 drawChart('first_resp_time', 'Line', graphInput['first_resp_time']['chartData'], chartOptions);
}

function drawDepartmentSlaTrend() {
 chartOptions = {
  bars: 'horizontal',
  isStacked: true,
  vAxis: {
   title: 'Tickets count',
   format: '0'
  },
  legend: {
   position: 'top'
  },
  colors: ['#DC3912', '#109618', '#FF9900'],
 };
 drawChart('dept_sla_trend', 'Column', graphInput['dept_sla_trend']['chartData'], chartOptions);
}

function drawDepartmentTrend() {
 chartOptions = {
  bars: 'vertical',
  vAxis: {
   title: 'Tickets count',
   format: '0'
  },
  legend: {
   position: 'top'
  },
 };
 drawChart('department_trend', 'Column', graphInput['department_trend']['chartData'], chartOptions);
}

function drawTicketsTrend() {
 chartOptions = {
  bars: 'vertical',
  vAxis: {
   title: 'Tickets count'
  },
  legend: {
   position: 'top',
   maxLines: 3
  },
  pieSliceText: 'value',
  pieSliceTextStyle: {
   color: 'black',
  },
  pieHole: 0.4,
 };
 drawChart('tickets_trend', 'Pie', graphInput['tickets_trend']['chartData'], chartOptions);
}

function drawTicketsAgeByDept() {
 chartOptions = {
  bars: 'vertical',
  vAxis: {
   title: 'Tickets count',
   format: '0'
  },
  legend: {
   position: 'top',
   maxLines: 3
  },
 };
 drawChart('tickets_age_by_dept', 'Column', graphInput['tickets_age_by_dept']['chartData'], chartOptions);
}

function drawTopFiveDevices() {
 chartOptions = {
  vAxis: {
   title: 'Tickets count',
   format: '0'
  },
  legend: {
   position: 'top',
   maxLines: 3
  },
 };
 drawChart('top_fiv_devices', 'Column', graphInput['top_fiv_devices']['chartData'], chartOptions);
}

function drawTopFiveClients() {
 chartOptions = {
  vAxis: {
   title: 'Tickets count',
   format: '0'
  },
  legend: {
   position: 'top',
   maxLines: 3
  },
 };
 drawChart('top_fiv_clients', 'Column', graphInput['top_fiv_clients']['chartData'], chartOptions);
}

function drawWfciCounts() {
 chartOptions = {
  vAxis: {
   title: 'Tickets count',
   format: '0',
   minValue: 0,
   viewWindow: {
    min: 0
   },
  },
  legend: {
   position: 'top',
   maxLines: 3
  },
 };
 drawChart('wfci_count', 'Column', graphInput['wfci_count']['chartData'], chartOptions);
}

function drawHmspCounts() {
 chartOptions = {
  vAxis: {
   title: 'Tickets count',
   format: '0',
   minValue: 0,
   viewWindow: {
    min: 0
   },
  },
  legend: {
   position: 'top',
   maxLines: 3
  },
 };
 drawChart('hmps_count', 'Column', graphInput['hmps_count']['chartData'], chartOptions);
}

function drawTktsCreatedByDeptPriority() {
 chartOptions = {
  vAxis: {
   title: 'Tickets count',
   format: '0'
  },
  legend: {
   position: 'top',
   maxLines: 3
  },
 };
 drawChart('tkts_crtd_by_dept_pty', 'Column', graphInput['tkts_crtd_by_dept_pty']['chartData'], chartOptions);
}

function drawOpnCrtdClsdTkts() {
 chartOptions = {
  vAxis: {
   title: 'Tickets count',
   format: '0'
  },
  legend: {
   position: 'top',
   maxLines: 3
  },
 };
 drawChart('opn_crtd_clsd_tkts', 'Column', graphInput['opn_crtd_clsd_tkts']['chartData'], chartOptions);
}

function drawCreatedClosedTickets() {
 chartOptions = {
  bars: 'vertical',
  vAxis: {
   title: 'Tickets',
   format: '0'
  },
  legend: {
   position: 'top'
  },
  series: {
   3: {
    type: 'line',
    color: 'grey',
    lineWidth: 0,
    pointSize: 0,
    visibleInLegend: false
   }
  }
 };
 drawChart('created_closed_tkts', 'Column', graphInput['created_closed_tkts']['chartData'], chartOptions);
}

var annotation = false;

function drawChart(divId, chartType, data, options) {
 var chart;
 dataTable = google.visualization.arrayToDataTable(data);

 if (annotation === true) {
  dataTable = new google.visualization.DataView(dataTable);
  var cols = [0];
  for (var i = 1; i < data[0].length; i++) {
   cols.push({
    sourceColumn: i,
    type: "number",
    label: data[0][i]
   });
   cols.push({
    calc: "stringify",
    sourceColumn: i,
    type: "string",
    role: "annotation"
   });
  }
  dataTable.setColumns(cols);
 }

 chart_div = document.getElementById(divId);
 switch (chartType) {
  case 'Column':
   {
    chart = new google.visualization.ColumnChart(chart_div);
    break;
   }
  case 'Bar':
   {
    chart = new google.charts.Bar(chart_div);
    break;
   }
  case 'Pie':
   {
    chart = new google.visualization.PieChart(chart_div);
    break;
   }
  case 'Line':
   {
    chart = new google.visualization.LineChart(chart_div);
    break;
   }
 }

 google.visualization.events.addListener(chart, 'ready', function() {
  if ($('#' + divId + '_content').length) {
   $('#' + divId + '_content').text(chart.getImageURI());
  } else {
   jQuery('<div/>', {
    id: divId + '_content',
    text: chart.getImageURI(),
    style: 'display:none;',
   }).insertAfter('#' + divId);
  }

 });

 chart.draw(dataTable, options);

 var selectHandler = function(e) {
  chartFor = $(chart.oa).attr('data-chartfor');
  row = chart.getSelection()[0]['row'];
  col = chart.getSelection()[0]['column'];
 }


}

function downloadImage(name) {
 var image = $('#' + name).text();
 url = window.location.origin;
 $.ajax({
  type: 'POST',
  url: "/sdmDashboard/generateImage/",
  data: {
   'image': image,
   'report': name,
   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
  },
  beforeSend: function() {
   $('i#downloadgraph[data-divid="' + name + '"]').hide();
  },
  complete: function() {
   $('i#downloadgraph[data-divid="' + name + '"]').show();
  },
  success: function(data) {
	  console.log(url+data.imageContent);
   window.open(url+data.imageContent);
  }
 });
}

function closedTicketByDept() {
	 var tId = $('#temList').val();
	 if (tId == undefined || tId == null || tId == "") {
	  tId = 0;
	 }
	 var sGraph = $('#sgraph').selectpicker('val');
	 var sDate = $('#sdate').val();
	 if (sDate == '5') {
	  var frmDate = $('#sdmg_fdDates').val();
	  var toDate = $('#sdmg_tdDates').val();
	 } else {
	  var frmDate = $('#sdmg_fdDates').val();
	  var toDate = $('#sdmg_tdDates').val();
	 }

	 $.ajax({
	  type: 'POST',
	  url: "/sdmDashboard/graphApi/",
	  data: {
	   'tid': tId,
	   'report': 'closed_tickets_by_dept',
	   'limit': sDate,
	   'fromDate': frmDate,
	   'toDate': toDate,
	   'sGraph': sGraph,
	   'csrfmiddlewaretoken': $("input[name=csrfmiddlewaretoken]").val()
	  },
	  beforeSend: function() {
	   $('span#load_closed_tickets_by_dept').show();
	   $('a#closed_tickets_by_dept_rf').hide();
	   $('i#downloadgraph[data-divid="closed_tickets_by_dept_content"]').hide();
	  },
	  complete: function() {
	   $('span#load_closed_tickets_by_dept').hide();
	   $('a#closed_tickets_by_dept_rf').show();
	   $('i#downloadgraph[data-divid="closed_tickets_by_dept_content"]').show();

	  },
	  success: function(data) {
	   graphInput['closed_tickets_by_dept'] = new Array();
	   graphInput['closed_tickets_by_dept']['chartData'] = data.graphData['chartData'];
	   graphInput['closed_tickets_by_dept']['slamFilters'] = data.graphData['slamFilters'];
	   if (data.graphData['chartData'].length > 1) {
	    $('#closed_tickets_by_dept').show();
	    google.charts.setOnLoadCallback(drawClosedTicketByDept);
	   } else {
	    $('#closed_tickets_by_dept').hide();
	   }

	  }
	 });
	}
