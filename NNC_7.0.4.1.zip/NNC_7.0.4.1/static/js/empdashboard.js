/*
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
*/
loadsym = '';
$(document).ready(function () {

$("Tooltip").tooltip({html:true});
$('[data-toggle="tooltip"]').tooltip();

$('[data-toggle=offcanvas]').click(function() {
	$('.row-offcanvas').toggleClass('active');
	$('.right-aside-container').stop().fadeToggle(750);
});
$('[data-toggle="tooltip"]').tooltip();

$('.flip').hover(
	function () {
	  $(this).find('.card').addClass('flipped');
	},
	function () {
	   $(this).find('.card').removeClass('flipped');
	}
);

$('a#refscheduledinfo').on('click', function(){
	loadsym = 'loadrefScheduledReports';
	getScheduledActivities();
	loadsym = '';
});
$('a#refteamskills').on('click', function(){
	loadsym = 'loadrefteamskills';
	getEmpInfo();
	loadsym = '';
});
$('a#refmyteamtktsinfo').on('click', function(){
	loadsym = 'loadrefmyteamtktsinfo';
	getEmpInfo();
	loadsym = '';
});
$('a#refmytktsinfo').on('click', function(){
	loadsym = 'loadrefmytktsinfo';
	getEmpInfo();
	loadsym = '';
});

$('#addimdetials').click(function() {
	 
	  var skypeid = $('#imdata').val();
	  $.ajax({
		    type: "POST",
          	url: "/employeeDashboard/employeeAjax/",
	        data: {"skypeid": skypeid,'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()}, 
	        dataType:"html",
	        beforeSend: function (){
	            $('span#skypeload').show();
	        },
	        complete: function(){
	                $('span#skypeload').hide();
	        },
	        success: function (data) {
	        	$('.updateresponse').html(data);
	        }
	        
		}); 
	 
	});

$('#addtotalexp').click(function() {
	
	  var totalexp = $('#expdata').val();
	  $.ajax({
		    type: "POST",
        	url: "/employeeDashboard/employeeExpAjax/",
	        data: {"totalexp": totalexp,'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()}, 
	        dataType:"html",
	        beforeSend: function (){
	            $('span#expload').show();
	            
	            },
	        complete: function(){
	                $('span#expload').hide();
	                
	                },
	         
	        success: function (data) {
	        	$('.updateexpresponse').html(data);	        	
	        }
	        
		}); 

	});
getScheduledActivities();
getScheduledTickets();

});

$(window).bind('load',function(){
	getEmpInfo();
	
});
var apres;
function getEmpInfo()
{
	$.ajax({
		type: "POST",
        url: "/employeeDashboard/getEmpInfo/",
        data: {csrfmiddlewaretoken : $("input[name=csrfmiddlewaretoken]").val()},
        beforeSend: function (){
        	if(loadsym != ''){
        		$('span#'+loadsym).show();    
        		$('a#refmytktsinfo').hide();
        	}
        	else {
        		$('span#loadrefteamskills,span#loadrefmyteamtktsinfo,span#loadrefmytktsinfo').show();
        		$('a#refmytktsinfo,a#refteamskills,a#refmyteamtktsinfo').hide();
        	}
		},
		complete: function(){
			if(loadsym != ''){
				$('span#'+loadsym).hide();
				$('a#refmytktsinfo').show();
			}
			else{
				$('span#loadrefteamskills,span#loadrefmyteamtktsinfo,span#loadrefmytktsinfo').hide();
				$('a#refmytktsinfo,a#refteamskills,a#refmyteamtktsinfo').show();
			}
		},
        success:function(data){
        	apres=data;
        	var teamDet = '';
        	var srDetails = {};
        	var schrd = {};
        	srDetails['schCount'] = 0,srDetails['schCountp0'] = 0,srDetails['schCountp1'] = 0,srDetails['schCountp2'] = 0,srDetails['schCountp3'] = 0;
        	schrd['schCount'] = '',schrd['schCountp0'] = '',schrd['schCountp1'] = '',schrd['schCountp2'] = '',schrd['schCountp3'] = '';
        	srDetails['tschCount'] = 0,srDetails['tschCountp0'] = 0,srDetails['tschCountp1'] = 0,srDetails['tschCountp2'] = 0,srDetails['tschCountp3'] = 0;
        	schrd['tschCount'] = '',schrd['tschCountp0'] = '',schrd['tschCountp1'] = '',schrd['tschCountp2'] = '',schrd['tschCountp3'] = '';
        	srDetails['tRD'] = 0,srDetails['tRDp0'] = 0,srDetails['tRDp1'] = 0,srDetails['tRDp2'] = 0,srDetails['tRDp3'] = 0;
        	schrd['tRD'] = '',schrd['tRDp0'] = '',schrd['tRDp1'] = '',schrd['tRDp2'] = '',schrd['tRDp3'] = '';
        	srDetails['RD'] = 0,srDetails['RDp0'] = 0,srDetails['RDp1'] = 0,srDetails['RDp2'] = 0,srDetails['RDp3'] = 0;
        	schrd['RD'] = '',schrd['RDp0'] = '',schrd['RDp1'] = '',schrd['RDp2'] = '',schrd['RDp3'] = '';
        	
        	$.each(data.ticketInfo,function(key,val){
        		$("#"+key).text(val);
        	});
        	$.each(data.teamTicketInfo,function(key1,val1){
        		$("#"+key1).text(val1);
        	});
        	$.each(data.desigRes,function(key,val){
	        	teamDet += '<tr><td width="196px"><span class="name">';
	        	teamDet += val.empname+'</span><div>'+val.desig_name+'</div></td>';
	        	teamDet += '<td width="110px" align="center"><a href="javascript:void(0)" onclick = "getSlamRes('+val.id+')" id = '+val.id+' data-'+val.id+' = "">0</a></td></tr>';
        	});
        	$('#teamDetails').html(teamDet);
        	$.each(data.teamDetails,function(key,val){
        		$("#"+key).text(val);
        	});
        	$.each(data.tsrTickets,function(key,val){
        		if (val.priorityid == 8 && val.sid == 19){
        			srDetails['tRDp0'] += 1;
        			srDetails['tRD'] += 1;
        			schrd['tRDp0'] = schrd['tRDp0']+val.ticketid+',';
        			schrd['tRD'] = schrd['tRD']+val.ticketid+',';
        		}
        		if (val.priorityid == 9 && val.sid == 19){
        			srDetails['tRDp1'] += 1;
        			srDetails['tRD'] += 1;
        			schrd['tRDp1'] = schrd['tRDp1']+val.ticketid+',';
        			schrd['tRD'] = schrd['tRD']+val.ticketid+',';
        		}
        		if (val.priorityid == 10 && val.sid == 19){
        			srDetails['tRDp2'] += 1;
        			srDetails['tRD'] += 1;
        			schrd['tRDp2'] = schrd['tRDp2']+val.ticketid+',';
        			schrd['tRD'] = schrd['tRD']+val.ticketid+',';
        		}
				if (val.priorityid == 11 && val.sid == 19){
					srDetails['tRDp3'] += 1;
        			srDetails['tRD'] += 1;
        			schrd['tRDp3'] = schrd['tRDp3']+val.ticketid+',';
        			schrd['tRD'] = schrd['tRD']+val.ticketid+',';
				}
				if (val.priorityid == 8 && val.sid == 16){
					srDetails['tschCount'] += 1;
					srDetails['tschCountp0'] += 1;
					schrd['tschCount'] = schrd['tschCount']+val.ticketid+',';
					schrd['tschCountp0'] = schrd['tschCountp0']+val.ticketid+',';
        		}
        		if (val.priorityid == 9 && val.sid == 16){
        			srDetails['tschCount'] += 1;
					srDetails['tschCountp1'] += 1;
					schrd['tschCount'] = schrd['tschCount']+val.ticketid+',';
        			schrd['tschCountp1'] = schrd['tschCountp1']+val.ticketid+',';
        		}
        		if (val.priorityid == 10 && val.sid == 16){
        			srDetails['tschCount'] += 1;
					srDetails['tschCountp2'] += 1;
					schrd['tschCount'] = schrd['tschCount']+val.ticketid+',';
        			schrd['tschCountp2'] = schrd['tschCountp2']+val.ticketid+',';
        		}
				if (val.priorityid == 11 && val.sid == 16){
					srDetails['tschCount'] += 1;
					srDetails['tschCountp3'] += 1;
					schrd['tschCount'] = schrd['tschCount']+val.ticketid+',';
        			schrd['tschCountp3'] = schrd['tschCountp3']+val.ticketid+',';
				}
        		
        	});
        	$.each(data.mysrTickets,function(key,val){
        		if (val.priorityid == 8 && val.sid == 19){
        			srDetails['RDp0'] += 1;
        			srDetails['RD'] += 1;
        			schrd['RD'] = schrd['RD']+val.ticketid+',';
        			schrd['RDp0'] = schrd['RDp0']+val.ticketid+',';
        		}
        		if (val.priorityid == 9 && val.sid == 19){
        			srDetails['RDp1'] += 1;
        			srDetails['RD'] += 1;
        			schrd['RD'] = schrd['RD']+val.ticketid+',';
        			schrd['RDp1'] = schrd['RDp1']+val.ticketid+',';
        		}
        		if (val.priorityid == 10 && val.sid == 19){
        			srDetails['RDp2'] += 1;
        			srDetails['RD'] += 1;
        			schrd['RD'] = schrd['RD']+val.ticketid+',';
        			schrd['RDp2'] = schrd['RDp2']+val.ticketid+',';
        		}
				if (val.priorityid == 11 && val.sid == 19){
					srDetails['RDp3'] += 1;
        			srDetails['RD'] += 1;
        			schrd['RD'] = schrd['RD']+val.ticketid+',';
        			schrd['RDp3'] = schrd['RDp3']+val.ticketid+',';
				}
				if (val.priorityid == 8 && val.sid == 16){
					srDetails['schCount'] += 1;
					srDetails['schCountp0'] += 1;
					schrd['schCount'] = schrd['schCount']+val.ticketid+',';
        			schrd['schCountp0'] = schrd['schCountp0']+val.ticketid+',';
        		}
        		if (val.priorityid == 9 && val.sid == 16){
        			srDetails['schCount'] += 1;
					srDetails['schCountp1'] += 1;
					schrd['schCount'] = schrd['schCount']+val.ticketid+',';
        			schrd['schCountp2'] = schrd['schCountp1']+val.ticketid+',';
        		}
        		if (val.priorityid == 10 && val.sid == 16){
        			srDetails['schCount'] += 1;
					srDetails['schCountp2'] += 1;
					schrd['schCount'] = schrd['schCount']+val.ticketid+',';
        			schrd['schCountp2'] = schrd['schCountp2']+val.ticketid+',';
        		}
				if (val.priorityid == 11 && val.sid == 16){
					srDetails['schCount'] += 1;
					srDetails['schCountp3'] += 1;
					schrd['schCount'] = schrd['schCount']+val.ticketid+',';
        			schrd['schCountp3'] = schrd['schCountp3']+val.ticketid+',';
				}
        		
        	});
        	$.each(srDetails,function(key,val){
        		$("#"+key).text(val);
        		$("#"+key).attr('data-'+key,schrd[key].slice(0,-1));
        	});
        	setTicketData();
        setTimeout('getEmpInfo()', 300000);
        }
	});
}

function getScheduledActivities(){
	 html = '';
	 $.ajax({
	  type: "POST",
	        url: "/employeeDashboard/employeeScheduleReports/",
	        data: {'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()},
	        beforeSend: function (){
	        	if(loadsym != ''){
	        		$('span#'+loadsym).show();
	        	}
	        	else {
	        		$('span#loadrefteamskills,span#loadrefmyteamtktsinfo,span#loadrefmytktsinfo,span#loadrefScheduledReports').show();
	        	}
			},
	        success: function (data) {
			   if(data != null) { 
				   $.each(data, function(index, value){ 
					   html += '<td width="94%">';
					   html +=  '<span>'+value+'</span>';
					   if(index == 1){
						   html += ' <span class="badge badge-important"> In Progress </span><br>';
					   }else if(index == 2){
						   html += ' <span class="badge badge-important"> About To Start </span><br>';
					   }else{
						   html += ' <span class="badge badge-info">'+' Queue - '+index+' </span><br>';
					   }
					   html += '</td>';  
				   	});
			       $('#scheduledActivities').html(html);
			   }
			   setTimeout('getScheduledActivities()', 300000); 
			$('span#loadrefScheduledReports').hide();
		
	        }
	 });
}

function setTicketData(){
	var idelTickets = {};
	var closedTickets = {};
	closedTickets['tclosed'] = closedTickets['tclosed8'] = closedTickets['tclosed9'] = closedTickets['tclosed10'] = closedTickets['tclosed11'] = '';
	closedTickets['closed'] = closedTickets['closed8'] = closedTickets['closed9'] = closedTickets['closed10'] = closedTickets['closed11'] = '';
	idelTickets['idel'] = idelTickets['idel8'] = idelTickets['idel9'] = idelTickets['idel10'] = idelTickets['idel11'] = '';
	idelTickets['tidel'] = idelTickets['tidel8'] = idelTickets['tidel9'] = idelTickets['tidel10'] = idelTickets['tidel11'] = '';
	$.each(apres.tclosedT,function(key,val){
		if (val.priorityid == 8){
			closedTickets['tclosed'] = closedTickets['tclosed']+val.ticketid+',';
			closedTickets['tclosed8'] = closedTickets['tclosed8']+val.ticketid+',';
		}
		if (val.priorityid == 9){
			closedTickets['tclosed'] = closedTickets['tclosed']+val.ticketid+',';
			closedTickets['tclosed9'] = closedTickets['tclosed9']+val.ticketid+',';
		}
		if (val.priorityid == 10){
			closedTickets['tclosed'] = closedTickets['tclosed']+val.ticketid+',';
			closedTickets['tclosed10'] = closedTickets['tclosed10']+val.ticketid+',';
		}
		if (val.priorityid == 11){
			closedTickets['tclosed'] = closedTickets['tclosed']+val.ticketid+',';
			closedTickets['tclosed11'] = closedTickets['tclosed11']+val.ticketid+',';
		}
				
	});
	$.each(apres.myclosedT,function(key,val){
		if (val.priorityid == 8){
			closedTickets['closed'] = closedTickets['closed']+val.ticketid+',';
			closedTickets['closed8'] = closedTickets['closed8']+val.ticketid+',';
		}
		if (val.priorityid == 9){
			closedTickets['closed'] = closedTickets['closed']+val.ticketid+',';
			closedTickets['closed9'] = closedTickets['closed9']+val.ticketid+',';
		}
		if (val.priorityid == 10){
			closedTickets['closed'] = closedTickets['closed']+val.ticketid+',';
			closedTickets['closed10'] = closedTickets['closed10']+val.ticketid+',';
		}
		if (val.priorityid == 11){
			closedTickets['closed'] = closedTickets['closed']+val.ticketid+',';
			closedTickets['closed11'] = closedTickets['closed11']+val.ticketid+',';
		}
	});
	$.each(apres.teamidleT,function(key,val){
		if (val.priorityid == 8){
			idelTickets['tidel'] = idelTickets['tidel']+val.ticketid+',';
			idelTickets['tidel8'] = idelTickets['tidel8']+val.ticketid+',';
		}
		if (val.priorityid == 9){
			idelTickets['tidel'] = idelTickets['tidel']+val.ticketid+',';
			idelTickets['tidel9'] = idelTickets['tidel9']+val.ticketid+',';
		}
		if (val.priorityid == 10){
			idelTickets['tidel'] = idelTickets['tidel']+val.ticketid+',';
			idelTickets['tidel10'] = idelTickets['tidel10']+val.ticketid+',';
		}
		if (val.priorityid == 11){
			idelTickets['tidel'] = idelTickets['tidel']+val.ticketid+',';
			idelTickets['tidel11'] = idelTickets['tidel11']+val.ticketid+',';
		}
	});
	$.each(apres.myidleT,function(key,val){
		if (val.priorityid == 8){
			idelTickets['idel'] = idelTickets['idel']+val.ticketid+',';
			idelTickets['idel8'] = idelTickets['idel8']+val.ticketid+',';
		}
		if (val.priorityid == 9){
			idelTickets['idel'] = idelTickets['idel']+val.ticketid+',';
			idelTickets['idel9'] = idelTickets['idel9']+val.ticketid+',';
		}
		if (val.priorityid == 10){
			idelTickets['idel'] = idelTickets['idel']+val.ticketid+',';
			idelTickets['idel10'] = idelTickets['idel10']+val.ticketid+',';
		}
		if (val.priorityid == 11){
			idelTickets['idel'] = idelTickets['idel']+val.ticketid+',';
			idelTickets['idel11'] = idelTickets['idel11']+val.ticketid+',';
		}
	});
	$.each(idelTickets,function(key,val){
		$("#"+key).attr('data-'+key,idelTickets[key].slice(0,-1));
	});
	$.each(closedTickets,function(key,val){
		$("#"+key).attr('data-'+key,closedTickets[key].slice(0,-1));
	});
	$.each(apres.activeInTic,function(key,val){
		$("#"+key).attr('data-'+key,val);
	});
	$.each(apres.teamActiveInTic,function(key,val){
		$("#"+key).attr('data-'+key,val.slice(0,-1));
	});
}

function getSlamRes(attId,formName)
{
	html = '';
	var ticketsdata = $("#"+attId).attr('data-'+attId);
	if (ticketsdata) {
		$("#idTypeValue").val(ticketsdata);
		$("#templatename").val(formName);
		if(formName == 'Scheduled-Task Tickets' || formName == 'Scheduled-Observation Tickets'){
			html += '<input type="hidden" name="selectedStatuses" value="16">';
			$("#statusDec").html(html);
		}else{
			html += '<input type="hidden" name="selectedStatuses" value="1">';
			$("#statusDec").html(html);
		}
		document.getElementById("IdSlamResults").submit();
	}
}

function getScheduledTickets(){
	$.ajax({
		  type: "POST",
		        url: "/employeeDashboard/schTickets/",
		        data: {'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()},
		        success: function (data) {
		        	var taskCount = 0;
		        	var obsCount = 0;
		        	var taskTktsList = '';
		        	var obsTktsList = '';
		        	$.each(data.Response,function(key,val){
		        		taskCount = taskCount + parseInt(val.scheduledTaskCount);
		        		obsCount = obsCount + parseInt(val.scheduledObservationCount);
		        		taskTktsList += ","+val.scheduledTaskTickets;
		        		obsTktsList += ","+val.scheduledObservationTickets;
		        	});
		        	$("#schTskTkts").html(taskCount);
	        		$("#schObsTkts").html(obsCount);
	        		$("#schTskTkts").attr('data-schTskTkts',taskTktsList);
	        		$("#schObsTkts").attr('data-schObsTkts',obsTktsList);
		        	setTimeout(function() {
		        		getScheduledTickets();
		        	}, 300000);
		        }
		 });

}