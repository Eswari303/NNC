"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.shortcuts import render
from django.http import HttpResponseRedirect
from login.forms import LoginForm
from django.core.cache import caches
import datetime
from NNCPortal.configfile import ConfigManager
from login.views.commonView import Login
from NNCPortal.commonMethods import commonMethods

from django.template.loader import get_template
from django.template import Context
from django.http import HttpResponse
from django.core.mail import EmailMessage

comObj = commonMethods()
file_cache = caches['filecache']
configobj = ConfigManager()
value = configobj.getConfigValue(configobj.VALUE)
loginobj = Login()

# Create your views here.

def checkCredentials(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        username = username.strip().lower()
        password = request.POST.get('password')
        finalRes = loginobj.validateAD(username, password, request)
        return finalRes
    else :
        form = LoginForm()
        if 'uName' in request.session:
            SHomeUrl = configobj.getConfigValue(configobj.SHomeUrl)
            return HttpResponseRedirect(SHomeUrl)
        curYear = datetime.datetime.now().year
        release = comObj.getCurrentVersion()
        return render(request, 'login.html', {'form': form, 'curYear': curYear, 'release': release, })


def logout(request):
    request.session.flush()
    file_cache.delete('password')
    logURL = configobj.getConfigValue(configobj.loginurl)
    return HttpResponseRedirect(logURL)


def aboutNNC(request):
    Att_DIR = 'static/images/'
    ctx = {
    'mailcontent':'Hi this is test mail content'
    }
    message = get_template('Nocservice_mapping_report.html').render(Context(ctx))
    var1 = 'noreply@netenrich.com'
    var2 = 'pradeep.thatavarthi@netenrich.com'
    var3 = 'praneeta.varada@netenrich.com'
    var4 = 'prasanthi.chekuri@netenrich.com'
    subject = 'request form'
    file1 = Att_DIR+"1234.png"
    fromMailID = var1
    toMailList = [var2, var3]
    bccMailList = [var4]
    msg=EmailMessage(subject=subject, body=message, from_email=fromMailID, to=toMailList, bcc=bccMailList, headers={'Cc':','.join(bccMailList)})
    msg.content_subtype = 'html'
    if file1 > 0:
        msg.attach_file(file1, "application/pgp-encrypted") 
    
    msg.send()
    return HttpResponse(msg)


    