"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""

from django.shortcuts import render_to_response
from django.template import RequestContext
from django.http import HttpResponseRedirect
import dns.resolver
import ldap
from hashlib import md5
from NNCPortal.configfile import ConfigManager
from django.core.cache import caches
import logging
from NNCPortal.commonMethods import commonMethods
from datetime import datetime
import pytz
from NNCPortal import settings
configobj = ConfigManager()
file_cache = caches['filecache']
log = logging.getLogger(__name__)
comObj = commonMethods()
class Login:
    def validateAD(self,username,password,request):
        homeurl = configobj.getConfigValue(configobj.homeurl)
        mhurl = configobj.getConfigValue(configobj.mhurl)
        smsg = configobj.getConfigValue(configobj.saltmsg)
        md5Password = md5(password+smsg).hexdigest()
        cachePassword = file_cache.get('password')
        if (cachePassword == md5Password) and ('uName' in request.session):
            return HttpResponseRedirect(homeurl)
        else:
            if username.find("@") == -1:
                username = username+'@'+str(configobj.getConfigValue(configobj.userDomain))
            domainName = configobj.getConfigValue(configobj.ldapDomain)
            nameservers = dns.resolver.query(domainName, 'A')
            for name in nameservers:
                try:
                    domain = 'ldap://'+str(name)
                    conn = ldap.initialize(domain)
                    conn.protocol_version = ldap.VERSION3
                    conn.simple_bind_s(username, password) 
                    file_cache.set('password', md5Password, 900)
                    #comObj.checkSwStaffIdByEmail(username, request)
                    request = comObj.setSessionValues(request, username)
                    if int(request.session['isMBaccess']) == 1:
                        return HttpResponseRedirect(mhurl)
                    else:
                        return HttpResponseRedirect(homeurl)
                    
                except Exception as e:
                    timezone = pytz.timezone(settings.TIME_ZONE)
                    print 'Login Failed for :%s  and  because of:%s' % (username, e.message)
                    print e.args
                    print 'LDAP Host:', domainName
                    print "Login Failed occurred at datetime:", datetime.now()
                    print "Time zone:", timezone.zone
                    resMsg = "Login Failed"
                    username = username.split('@')
                    return render_to_response('login.html',{'resMsg' : resMsg,'userName' : username[0]},context_instance = RequestContext(request))
            username = username.split('@')
            return render_to_response('login.html',{'resMsg' : resMsg,'userName' : username[0]},context_instance = RequestContext(request))
    