"""
 This computer program is the confidential information and proprietary trade
 secret of NetEnrich, Inc. Possessions and use of this program must
 conform strictly to the license agreement between the user and
 NetEnrich, Inc., and receipt or possession does not convey any rights
 to divulge, reproduce, or allow others to use this program without specific
 written authorization of NetEnrich, Inc.
  
 Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""

import re
import os
import time
import base64
import json as simplejson
import datetime
from django.http import HttpResponse
from django.core.cache import caches
from django.conf import settings
from django.shortcuts import render_to_response
from django.template import RequestContext

from NNCPortal.commonMethods import commonMethods
from sdmDashboard.models.commonModel import CommonSdmModel

comObj = commonMethods()
comMObj=CommonSdmModel()
mem_cache = caches['memcached']

def loadSdmMockup(request):
    authRes = comObj.checkAuthentication(request)
    if authRes == True :
        userId = request.session['uId']
        tempList = comMObj.getTemplateList(userId)
        graphCache = mem_cache.get('graphCache',{})
        if graphCache.has_key(userId):
            graphCach = graphCache[userId]
        else:
            graphCach={}
        return render_to_response('sdm.html',{'tempList':tempList},context_instance=RequestContext(request))
    else:
        return authRes
def setForm(request):
    userId = request.session['uId']
    tempList = comMObj.getTemplateList(userId)
    graphCache = mem_cache.get('graphCache',{})
    if graphCache.has_key(userId):
        graphCach = graphCache[userId]
    else:
        graphCach={}
    jsonData = simplejson.dumps({"graphCach":graphCach,'tempList':tempList})
    return HttpResponse(jsonData, content_type="application/json") 
  
def graphApi(request):
    if request.method == 'POST':
        tid = request.POST.get('tid')
        lim = request.POST.get('limit')
        limit = graphTime(int(lim))
        reportFor = request.POST.get('report')
        sg = request.POST.getlist('sGraph[]',None)
        
        templateModel = comMObj.getTemplateDetails(int (tid))
        if limit == None:
            frmDate = comObj.pstToUTCStamp(str(request.POST.get('fromDate')))
            toDate = comObj.pstToUTCStamp(str(request.POST.get('toDate')))
            limit = [frmDate[0]['pstdate'],toDate[0]['pstdate']]
        comMObj.graphQueryConditions(templateModel,limit)
           
        graphCache = mem_cache.get('graphCache',{})
        uId = request.session['uId'] 
        if graphCache.has_key(uId) and (graphCache[uId]['tid'] == int(tid)) and (graphCache[uId]['sGraph'] != None) and not request.POST.has_key('flag'):
            if request.POST.get('flag',0) == 1:
                graphCache ={}
                graphCache.setdefault(uId,{})
                fromDate = request.POST.get('fromDate')
                toDate = request.POST.get('toDate')
                graphCache[uId]={'tid':int(tid),'limit':int(lim),'sGraph':sg,'fromDate':fromDate,'toDate':toDate}
                mem_cache.set('graphCache', graphCache, 2592000) #30 days in cache
            else:
                pass
        else:
            graphCache ={}
            graphCache.setdefault(uId,{})
            fromDate = request.POST.get('fromDate')
            toDate = request.POST.get('toDate')
            graphCache[uId]={'tid':int(tid),'limit':int(lim),'sGraph':sg,'fromDate':fromDate,'toDate':toDate}
            mem_cache.set('graphCache', graphCache, 2592000) #30 days in cache
        graphData = {}
        
        '''Resolution and Response SLA graph'''
        if reportFor == 'resol_resp':
            resolResp = comMObj.getResolResp()
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['Priority', 'Resolution SLA', 'Response SLA'])
            for resolRes in resolResp['result']:
                graphData['chartData'].append([resolRes['display_text'], int(resolRes['resol_per']), int(resolRes['resp_per'])])
              
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('resol_resp_query', resolResp['query'])
            
        '''Scheduled Tickets'''
        if reportFor == 'scheduled':
            scheduledData = comMObj.Scheduled()
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['Time', 'Tickets'])
            for scdldData in scheduledData['result']:
                graphData['chartData'].append([scdldData['hour'], int(scdldData['scheduled_tickets'])])
             
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('scheduled_query', scheduledData['query'])
    
        
        '''Department Based open tickets by priority'''
        if reportFor == 'open_tickets_by_dept':
            openTicketsByDept = comMObj.getOpenTicketsByDept()
            graphData = {}
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['Department', 'Critical', 'High', 'Medium', 'Low'])
            
            for openTicketsByDep in openTicketsByDept['result']:
                graphData['chartData'].append([openTicketsByDep['dept'], int(openTicketsByDep['Critical']), int(openTicketsByDep['High']), int(openTicketsByDep['Medium']), int(openTicketsByDep['Low'])])  
            
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('open_tickets_by_dept_query', openTicketsByDept['query'])
        
        '''Total open tickets'''
        if reportFor == 'total_open_tickets':
            totalOpenTickets = comMObj.getTotalOpenTickets()
            graphData = {}
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['Priority', 'Tickets'])
            
            for totalOpenTikts in totalOpenTickets['result']:
                graphData['chartData'].append([totalOpenTikts['priority'], totalOpenTikts['opentickets']])
                
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('total_open_tickets_query', totalOpenTickets['query'])

        '''SLA missed'''
        if reportFor == 'sla_missed':
            slaMissed = comMObj.getSlaMissed()
            graphData = {}
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['Priority', 'Tickets'])
            
            for slaMisd in slaMissed['result']:
                graphData['chartData'].append([slaMisd['priority'], slaMisd['sla_missed']])

            graphData.setdefault('slamFilters',[])
            graphData.setdefault('sla_missed_query', slaMissed['query'])
    
        '''Closed tickets based on priority'''
        if reportFor == 'closed_tickets_by_priority':
            clsdTktsByPrty = comMObj.getClosedTicketByPriority()
            graphData = {}
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['Priority', 'Tickets'])
            for clsedTktsByPrty in clsdTktsByPrty['result']:
                graphData['chartData'].append([str(clsedTktsByPrty['priority']), int(clsedTktsByPrty['closed'])])
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('closed_tickets_by_priority_query', clsdTktsByPrty['query'])
    
        '''Alerts vs Tickets'''
        if reportFor == 'alerts_vs_tickets':
            alrtsVsTikts = comMObj.getAlertsVsTickets()
            graphData = {}
            graphData.setdefault('chartData',[])
            
            graphData['chartData'].append([' ', 'Alerts', 'Critical', 'High', 'Medium', 'Low'])
            for alrtsVsTkts in alrtsVsTikts['result']:
                p0 = alrtsVsTkts['Critical'] if alrtsVsTkts['Critical'] else 0
                p1 = alrtsVsTkts['High'] if alrtsVsTkts['High'] else 0
                p2 = alrtsVsTkts['Medium'] if alrtsVsTkts['Medium'] else 0
                p3 = alrtsVsTkts['Low'] if alrtsVsTkts['Low'] else 0
                graphData['chartData'].append(['', int(alrtsVsTkts['alerts']), int(p0), int(p1), int(p2), int(p3)])
            
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('alerts_vs_tickets_query', alrtsVsTikts['query'])
        
        
        '''First response time'''
        if reportFor == 'first_resp_time':
            firstRespTime = comMObj.getFirstResponseTime()
            firstRespTimeData = {}
            for firstRespTim in firstRespTime['result']:
                for k,v in firstRespTim.iteritems():
                    firstRespTimeData.setdefault(firstRespTim['display_text'], {})
                    firstRespTimeData[str(firstRespTim['display_text'])][k] = v

            graphData = {}
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['Priority', 'Critical', 'High', 'Medium', 'Low'])
            graphData['chartData'].append(['5MIN', int(firstRespTimeData['Critical']['5MIN']),int(firstRespTimeData['High']['5MIN']),int(firstRespTimeData['Medium']['5MIN']),int(firstRespTimeData['Low']['5MIN'])])
            graphData['chartData'].append(['15MIN', int(firstRespTimeData['Critical']['15MIN']),int(firstRespTimeData['High']['15MIN']),int(firstRespTimeData['Medium']['15MIN']),int(firstRespTimeData['Low']['15MIN'])])
            graphData['chartData'].append(['30MIN', int(firstRespTimeData['Critical']['30MIN']),int(firstRespTimeData['High']['30MIN']),int(firstRespTimeData['Medium']['30MIN']),int(firstRespTimeData['Low']['30MIN'])])
            graphData['chartData'].append(['1hr', int(firstRespTimeData['Critical']['1hr']),int(firstRespTimeData['High']['1hr']),int(firstRespTimeData['Medium']['1hr']),int(firstRespTimeData['Low']['1hr'])])
            graphData['chartData'].append(['2hr', int(firstRespTimeData['Critical']['2hr']),int(firstRespTimeData['High']['2hr']),int(firstRespTimeData['Medium']['2hr']),int(firstRespTimeData['Low']['2hr'])])
            
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('first_resp_time_query', firstRespTime['query'])
        
        '''Departments SLA trend'''
        if reportFor == 'dept_sla_trend':
            deptSlaTrend = comMObj.deptSlaTrend()
            graphData = {}
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['Departments', 'Breach in 1 hr', 'Breach in > 1 hr', 'Breached'])
            for deptSlaTrnd in deptSlaTrend['result']:
                b1hr = deptSlaTrnd['breach_in_1_hr'] if deptSlaTrnd['breach_in_1_hr'] else 0
                b2hr = deptSlaTrnd['breach_in_>_1_hr'] if deptSlaTrnd['breach_in_>_1_hr'] else 0
                b3hr = deptSlaTrnd['breached'] if deptSlaTrnd['breached'] else 0
                graphData['chartData'].append([deptSlaTrnd['title'], int(b1hr), int(b2hr), int(b3hr)])

            graphData.setdefault('slamFilters',[])
            graphData.setdefault('dept_sla_trend_query', deptSlaTrend['query'])
        
        
        '''Departments trend'''
        if reportFor == 'department_trend':
            deptTrend = comMObj.getDepartmentTrend()
            graphData = {}
            graphData.setdefault('chartData',[])
            
            graphData['chartData'].append(['Department', 'Active', 'Inactive', 'Closed'])
            for depTrend in deptTrend['result']:
                graphData['chartData'].append([depTrend['dept'], int(depTrend['active']), int(depTrend['inactive']), int(depTrend['closed'])])
            
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('department_trend_query', deptTrend['query'])
    
    
        '''Tickets trend'''
        if reportFor == 'tickets_trend':
            
            graphData = {}
            graphData.setdefault('chartData',[])
            
            graphData['chartData'].append(['Statuses', 'Tickets'])
            tktsTrend = comMObj.ticketsTrend()
            for tktTrend in tktsTrend['result']:
                graphData['chartData'].append([tktTrend['title'], int(tktTrend['Tickets'])])
            
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('tickets_trend_query', tktsTrend['query'])
        
        '''Tickets age by departements'''
        if reportFor == 'tickets_age_by_dept':
            
            graphData = {}
            ticketsAgeByDept = comMObj.ticketsAgeByDept()
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['Department', '1 day', '2 days', '3 days', '4 days', '5 days', '6 days', '7 days', '>7 days'])
            for tktsAgeByDept in ticketsAgeByDept['result']:
                graphData['chartData'].append([str(tktsAgeByDept['title']), int(tktsAgeByDept['1_day']), int(tktsAgeByDept['2_day']), int(tktsAgeByDept['3_day']), int(tktsAgeByDept['4_day']), int(tktsAgeByDept['5_day']), int(tktsAgeByDept['6_day']), int(tktsAgeByDept['7_day']) , int(tktsAgeByDept['>7day'])])
            
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('tickets_age_by_dept_query', ticketsAgeByDept['query'])
            
        '''Top 5 Devices'''
        if reportFor == 'top_fiv_devices':
            graphData = {}
            topFiveDevices = comMObj.topFiveDevices()
            graphData.setdefault('chartData',[])
            topDeviceData = {}
            for topFivDevices in topFiveDevices['result']:
                topDeviceData.setdefault(topFivDevices['device'],topFivDevices['count'])
            devices = []
            deviceCounts = []
            devices = ['']+topDeviceData.keys()
            deviceCounts = ['']+topDeviceData.values()
            graphData['chartData'].append(devices)
            graphData['chartData'].append(deviceCounts)           
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('top_fiv_devices_query', topFiveDevices['query'])
            
        '''Top 5 Clients'''
        if reportFor == 'top_fiv_clients':
            graphData = {}
            topFiveClients = comMObj.topFiveClients()
            graphData.setdefault('chartData',[])
            topClientsData = {}
            for topFivClients in topFiveClients['result']:
                topClientsData.setdefault(topFivClients['client'],topFivClients['count'])
            clients = []
            tktCounts = []
            clients = ['']+topClientsData.keys()
            tktCounts = ['']+topClientsData.values()
            graphData['chartData'].append(clients)
            graphData['chartData'].append(tktCounts)           
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('top_fiv_clients_query', topFiveClients['query'])
            
        '''Wfci Count'''
        if reportFor == 'wfci_count':
            graphData = {}
            wfciCount = comMObj.wfciCount()
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['', 'Total', 'P0', 'P1', 'P2', 'P3'])
            totalCount = 0
            for wfciCnt in wfciCount['result']:
                totalCount = int(wfciCnt['total'])+int(wfciCnt['p0'])+int(wfciCnt['p1'])+int(wfciCnt['p2'])+int(wfciCnt['p3'])
                graphData['chartData'].append(['', int(wfciCnt['total']), int(wfciCnt['p0']), int(wfciCnt['p1']), int(wfciCnt['p2']), int(wfciCnt['p3'])])
                        
            if totalCount == 0:
                graphData['chartData'] = []                           
            
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('wfci_count_query', wfciCount['query'])
            
        '''Hmsp Count'''
        if reportFor == 'hmps_count':
            graphData = {}
            hmspCount = comMObj.hmspCount()
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['', 'Total', 'P0', 'P1', 'P2', 'P3'])
            totalCount = 0
            for hmspCnt in hmspCount['result']:
                totalCount = int(hmspCnt['total'])+int(hmspCnt['p0'])+int(hmspCnt['p1'])+int(hmspCnt['p2'])+int(hmspCnt['p3'])
                graphData['chartData'].append(['', int(hmspCnt['total']), int(hmspCnt['p0']), int(hmspCnt['p1']), int(hmspCnt['p2']), int(hmspCnt['p3'])])
            
            if totalCount == 0:
                graphData['chartData'] = []                           
            
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('hmps_count_query', hmspCount['query'])
            
        '''Count of tickets which are created in last hours by department and priority'''
        if reportFor == 'tkts_crtd_by_dept_pty':
            graphData = {}
            tktsCrtdByDeptPty = comMObj.getTktsCrtdByDeptPty()
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['Department', 'Critical', 'High', 'Medium', 'Low'])
            ticketsCrtdByDeptPty = {}
            for tktCrtdByDeptPty in tktsCrtdByDeptPty['result']:          
                ticketsCrtdByDeptPty.setdefault(tktCrtdByDeptPty['title'],{})
                ticketsCrtdByDeptPty[tktCrtdByDeptPty['title']].setdefault(tktCrtdByDeptPty['display_text'], tktCrtdByDeptPty['total'])
            ticketCounts = {}
            for key, value in ticketsCrtdByDeptPty.iteritems():
                ticketCounts.setdefault(key, {})
                if value.has_key('Critical'):
                    ticketCounts[key]['Critical'] = value['Critical']
                else: 
                    ticketCounts[key]['Critical'] = 0
                ticketCounts[key]['Critical'] = value['Critical'] if value.has_key('Critical') else 0
                ticketCounts[key]['High'] = value['High'] if value.has_key('High') else 0
                ticketCounts[key]['Medium'] = value['Medium'] if value.has_key('Medium') else 0
                ticketCounts[key]['Low'] = value['Low'] if value.has_key('Low') else 0
                graphData['chartData'].append([str(key), int(ticketCounts[key]['Critical']), int(ticketCounts[key]['High']), int(ticketCounts[key]['Medium']), int(ticketCounts[key]['Low'])])
            graphData.setdefault('slamFilters',[])  
            graphData.setdefault('tkts_crtd_by_dept_pty_query', tktsCrtdByDeptPty['query'])
            
        '''count of tickets for 
               a. total opentickets
               b. within last 8 hours closed tickets
               c. tickets which are created and closed in last 8 hours'''
        if reportFor == 'opn_crtd_clsd_tkts':
            graphData = {}
            opnCrtdClsdTkts = comMObj.getOpnCrtdClsdTkts()
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['', 'Open tickets', 'Closed tickets', 'Created and Closed'])
            for opnCrtdClsdTkt in opnCrtdClsdTkts['result']:
                graphData['chartData'].append(['', int(opnCrtdClsdTkt['open_tickets']), int(opnCrtdClsdTkt['closed']), int(opnCrtdClsdTkt['created_closed'])])                      
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('opn_crtd_clsd_tkts_query', opnCrtdClsdTkts['query'])
            
        if reportFor == 'created_closed_tkts':           
            graphData = {}
            graphData.setdefault('slamFilters',[])
            createdClosedTktsDataArr = comMObj.getCreatedClosedTkts()
            
            
            graphData.setdefault('chartData',createdClosedTktsDataArr)
        
        '''Department Based open tickets by priority'''
        if reportFor == 'closed_tickets_by_dept':
            openTicketsByDept = comMObj.getClosedTicketsByDept()
            graphData = {}
            graphData.setdefault('chartData',[])
            graphData['chartData'].append(['Department', 'Critical', 'High', 'Medium', 'Low'])
            
            for openTicketsByDep in openTicketsByDept['result']:
                graphData['chartData'].append([openTicketsByDep['dept'], int(openTicketsByDep['Critical']), int(openTicketsByDep['High']), int(openTicketsByDep['Medium']), int(openTicketsByDep['Low'])])  
            
            graphData.setdefault('slamFilters',[])
            graphData.setdefault('closed_tickets_by_dept', openTicketsByDept['query'])

    jsonData = simplejson.dumps({'graphData': graphData})
    return HttpResponse(jsonData, content_type="application/json")
    
def graphTime(dateRange):
    os.environ["TZ"]='US/Pacific'  
    today  = datetime.datetime.now() #now = datetime.datetime.now()
    if dateRange == 0:
        past8 = today - datetime.timedelta(hours=8)
        result = time.mktime(past8.timetuple())
    elif dateRange == 1:
        past24 = today - datetime.timedelta(hours=24)
        result = time.mktime(past24.timetuple())
    elif dateRange == 2:
        lastweek = today - datetime.timedelta(days=7)
        result = time.mktime(lastweek.timetuple())
    elif dateRange == 3:
        lastmonth = today - datetime.timedelta(days=30)
        result = time.mktime(lastmonth.timetuple())
    elif dateRange == 4:
        last3month = today - datetime.timedelta(days=90)
        result = time.mktime(last3month.timetuple())
    elif dateRange == 5:
        result = None
    if result != None:
        tmp = comObj.timeStampToPST(result)
    return result    

def generateImage(request):
    #imgFilePath = request.build_absolute_uri().replace(request.get_full_path(), '')+"/static/files/"
    imgFilePath = "/static/files/"
    
    if request.method == 'POST':
        reportFor = request.POST.get('report')
        image1 = request.POST.get('image')
        uId = request.session['uId']
        imageContent = base64.b64decode(re.sub('data:image/png;base64,', '', image1))
        fileName = str(uId)+'_'+reportFor+'.jpeg'
        filePath = settings.BASE_DIR + settings.STATIC_FILES_URL + fileName
        with open(filePath, 'wb') as f:
            f.write(imageContent)
    imgDwnldUrl = imgFilePath + fileName
    jsonData = simplejson.dumps({'imageContent': imgDwnldUrl})
    return HttpResponse(jsonData, content_type="application/json")
    
