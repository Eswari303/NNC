"""
 This computer program is the confidential information and proprietary trade
 secret of NetEnrich, Inc. Possessions and use of this program must
 conform strictly to the license agreement between the user and
 NetEnrich, Inc., and receipt or possession does not convey any rights
 to divulge, reproduce, or allow others to use this program without specific
 written authorization of NetEnrich, Inc.
  
 Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""

from django.db import connection,connections
from django.core.cache import caches
from _collections import defaultdict
mem_cache = caches['memcached']
from NNCPortal.commonMethods import commonMethods
comObj = commonMethods()
import calendar, time, datetime
from datetime import date
from calendar import monthrange
from NNCPortal.commonModels.Swticketpriorities import Swticketpriorities
from NNCPortal.commonModels.Swticketstatus import Swticketstatus
swtktstatus_obj = Swticketstatus()
stpObj = Swticketpriorities()

class CommonSdmModel():
    templateId = 0
    nocCond = ''
    channelCond=''
    mspCond=''
    clientCond=''
    deptCond=''
    priorityCond=''
    statusCond=''
    dateRangeCond=''
    ticketTypeCond=''
    
    clientIds = ''
    nocIds =''
    channelIds= ''
    mspIds = ''
    deptIds = ''
    ticketTypeCondIds =''
    statusIds =''
    dateRange = ''
    ActiveStatus = ''
    InActiveStatus = ''
    Closed = ''
    ActInactStatuses = ''
    All = ''
    closedByDeptDateRangeCond = ''


    def getTemplateList(self,userId):
        sql = "select templateid, templatename, templatetype, templateuserid,reportType from ticketbrowser_templates where (templatetype='1' AND display_template=1 AND templateuserid= "+str(userId)+") or templatetype = '0' and reportType = 'TB' and templatename NOT IN ('My Tickets','My Team Tickets')"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        finResult = comObj.dictfetchall(cursor)
        cursor.close()
        return finResult
    
    def getUserTemplatesAndPublicTemplates (self, userId=0, reportType=''):
        cursor = connections['rosterRead'].cursor()
        sql = 'SELECT templateid, templatename, templatetype, templateuserid, lastdate FROM ticketbrowser_templates'
        sql += ' WHERE ((templatetype = "1" AND display_template = 1 AND templateuserid ='+str(userId)+')'
        sql += ' OR (templatetype = "0"))'
        if reportType != '':
            sql += ' AND reportType ="'+reportType+'"'
        
        if reportType == 'TB':
            sql += " AND templatename NOT IN ('My Tickets','My Team Tickets')"
               
        sql += ' order by templatename'
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result;

    def getTemplateDetails (self, templateId):
        cursor = connections['rosterRead'].cursor()
        if templateId != '':
            sql = "select * from ticketbrowser_templates where templateid = "+str(templateId)
            CommonSdmModel.templateId = templateId
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
        return result  
    
    def graphQueryConditions(self, templateDetails,dateRange):
        ActiveStatus = swtktstatus_obj.getActiveStatus()
        InActiveStatus = swtktstatus_obj.getInActiveStatus()
        Closed = swtktstatus_obj.getClosedStatus()
        
        CommonSdmModel.ActiveStatus = ','.join(str(e) for e in ActiveStatus.keys())
        CommonSdmModel.InActiveStatus = ','.join(str(e) for e in InActiveStatus.keys())
        CommonSdmModel.Closed = ','.join(str(e) for e in Closed.keys())
        CommonSdmModel.ActInactStatuses = CommonSdmModel.ActiveStatus+','+CommonSdmModel.InActiveStatus
        CommonSdmModel.All =  CommonSdmModel.ActInactStatuses+','+CommonSdmModel.Closed
        
        for tempDetails in templateDetails:
            if tempDetails['clients'] and tempDetails.has_key('clients'):
                if tempDetails['clients'] != '':

                    CommonSdmModel.clientCond = ' AND id.cid in ('+str(tempDetails['clients'])+')'
                    CommonSdmModel.clientIds = str(tempDetails['clients']) if tempDetails['clients'] else ''
            else:
                CommonSdmModel.clientCond = ''
                CommonSdmModel.clientIds = ''
            
                if tempDetails['nocs'] and tempDetails.has_key('nocs'):
                    if tempDetails['nocs'] != '':
                        CommonSdmModel.nocCond = ' AND id.nid in ('+str(tempDetails['nocs'])+')'
                        CommonSdmModel.nocIds = str(tempDetails['nocs']) if tempDetails['nocs'] else ''
                else:
                    CommonSdmModel.nocCond = ''
                    CommonSdmModel.nocIds = ''
                    
                    if tempDetails['channel'] and tempDetails.has_key('channel'):
                        if tempDetails['channel'] != None:
                            CommonSdmModel.channelCond = ' AND id.channelid in ('+str(tempDetails['channel'])+')'
                            CommonSdmModel.channelIds = str(tempDetails['channel']) if tempDetails['channel'] else ''
                    else:
                        CommonSdmModel.channelCond = ''
                        CommonSdmModel.channelIds = ''
                    
                if tempDetails['partners'] and tempDetails.has_key('partners'):
                    if tempDetails['partners'] != '':
                        CommonSdmModel.mspCond = ' AND id.mid in ('+str(tempDetails['partners'])+')'
                        CommonSdmModel.mspIds = tempDetails['partners'] if tempDetails['partners'] else ''
                else:
                    CommonSdmModel.mspCond = ''
                    CommonSdmModel.mspIds = ''
            
            if tempDetails['departments'] and tempDetails.has_key('departments'):
                CommonSdmModel.deptCond = ' AND id.deptid in ('+str(tempDetails['departments'])+')'
                CommonSdmModel.deptIds = str(tempDetails['departments']) if tempDetails['departments'] else ''
            else:
                CommonSdmModel.deptCond = ''
                CommonSdmModel.deptIds = ''
                
            if tempDetails['ticket_type'] and tempDetails.has_key('ticket_type'):
                CommonSdmModel.ticketTypeCondCond = ' AND id.ticket_type in ('+str(tempDetails['ticket_type'])+' )'
                CommonSdmModel.ticketTypeCondIds = str(tempDetails['ticket_type']) if tempDetails['ticket_type'] else ''
            else:
                CommonSdmModel.ticketTypeCondCond = ''
                CommonSdmModel.ticketTypeCondIds = ''
            
            if tempDetails['statuses'] and tempDetails.has_key('statuses'):
                statuses = ','.join(str(tempDetails['statuses']))
                CommonSdmModel.statusCond = ' AND id.statusid in ('+str(tempDetails['statuses'])+')'
                CommonSdmModel.statusIds = str(tempDetails['statuses']) if tempDetails['statuses'] else ''
            else:
                CommonSdmModel.statusCond = ''
                CommonSdmModel.statusIds = ''
            if isinstance(dateRange,list):
                CommonSdmModel.dateRangeCond = ' AND (id.created_dt <= '+str(dateRange[1])+' AND id.created_dt >='+str(dateRange[0])+")"
                CommonSdmModel.closedByDeptDateRangeCond = ' AND (id.resolve_time <= '+str(dateRange[1])+' AND id.resolve_time >='+str(dateRange[0])+")"
            else:
                CommonSdmModel.dateRangeCond = ' AND (id.created_dt <= UNIX_TIMESTAMP(NOW()) AND id.created_dt >='+str(dateRange)+")"
                CommonSdmModel.closedByDeptDateRangeCond = ' AND (id.resolve_time <= UNIX_TIMESTAMP(NOW()) AND id.resolve_time >='+str(dateRange)+")"
                  
            CommonSdmModel.dateRange = str(dateRange)      
                
    def getResolResp(self):
        cursor = connections['ticketRead'].cursor()
        sql = "SELECT"
        sql += ' p.display_text,'
        sql += ' IFNULL(a.total,0) AS total_tickets,'
        sql += ' IFNULL(b.resoltuion,0) AS resol_met_tickets,'       
        sql += " CONCAT(IFNULL(ROUND(( b.resoltuion / a.total ) * 100),0)) resol_per,"        
        sql += " IFNULL(c.response,0) AS resp_met_tickets, CONCAT(IFNULL(ROUND(( c.response / a.total ) * 100),0))   resp_per"
        sql += ' FROM'
        sql += ' swticketpriorities p'         
        sql += ' LEFT JOIN ('
        sql += ' SELECT'
        sql += ' COUNT(id.ticketid) total,'
        sql += ' id.priorityid'
        sql += ' FROM   incident_data id'        
        sql += ' WHERE'
        sql += ' id.deptid NOT IN ( 0, 1, 2 )'
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.dateRangeCond)
        sql += ' GROUP BY id.priorityid'
        sql += ' ) a ON p.priorityid = a.priorityid'
        sql += ' LEFT JOIN ('
        sql += ' SELECT'
        sql += ' COUNT(id.ticketid) resoltuion,'
        sql += ' id.priorityid'
        sql += ' FROM   incident_data id'
        sql += ' WHERE'
        sql += ' id.deptid NOT IN ( 0, 1, 2 )'
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.dateRangeCond)
        sql += ' AND id.resol_due > 0'
        sql += ' GROUP BY id.priorityid'
        sql += ' ) b ON p.priorityid = b.priorityid'
        sql += ' LEFT JOIN ('
        sql += ' SELECT'
        sql += ' COUNT(id.ticketid) response,'
        sql += ' id.priorityid'
        sql += ' FROM incident_data id'
        sql += ' WHERE'
        sql += ' id.deptid NOT IN ( 0, 1, 2 )'
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.dateRangeCond)
        sql += ' AND id.resp_sla - id.resp_sec >= 0'
        sql += ' GROUP  BY id.priorityid'
        sql += ' ) c ON p.priorityid = c.priorityid'    
        sql += ' WHERE'
        sql += ' p.priorityid IN ( 8, 9, 10, 11 )'
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult 
    
    def getOpenTicketsByDept(self):
        cursor = connections['ticketRead'].cursor()
    
        sql = 'SELECT  sd.title as  dept,'
        sql += ' SUM((CASE WHEN (priorityid=8) THEN 1 ELSE 0 END) ) Critical,'
        sql += ' SUM((CASE WHEN (priorityid=9) THEN 1 ELSE 0 END) ) High,'
        sql += ' SUM((CASE WHEN (priorityid=10) THEN 1 ELSE 0 END) ) Medium,'
        sql += ' SUM((CASE WHEN (priorityid=11) THEN 1 ELSE 0 END) ) Low'
        sql += ' FROM incident_data id JOIN swdepartments sd ON (sd.departmentid = id.deptid)'
        sql += ' WHERE 1=1'
        #sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += ' AND id.statusid in ('+str(CommonSdmModel.ActInactStatuses)+')'
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += ' GROUP BY id.deptid'
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult 

    def getTotalOpenTickets(self):
        cursor = connections['ticketRead'].cursor() 
        sql = 'SELECT p.display_text as priority,IFNULL(c.opentickets,0) AS opentickets'
        sql += ' FROM swticketpriorities p'
        sql += ' LEFT JOIN ('
        sql += ' SELECT priorityid, COUNT(ticketid) opentickets'
        sql += ' FROM incident_data id WHERE 1=1 '
        #sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += ' AND id.statusid in ('+str(CommonSdmModel.ActInactStatuses)+')' # condition changed
        sql += ' AND priorityid IN (8,9,10,11)'
        sql += ' GROUP BY priorityid'
        sql += ' ) c ON p.priorityid = c.priorityid'
        sql += ' WHERE p.priorityid IN (8,9,10,11)'
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult 
    
    def getSlaMissed(self):
        cursor = connections['ticketRead'].cursor()
        sql = 'SELECT p.display_text as priority,IFNULL(c.Sla_Missed,0) AS sla_missed'
        sql += ' FROM swticketpriorities p'
        sql += ' LEFT JOIN ('
        sql += ' SELECT priorityid, COUNT(ticketid) Sla_Missed'
        sql += ' FROM incident_data id'
        sql += ' WHERE deptid NOT IN (0,1,2)'
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += ' AND priorityid IN (8,9,10,11) AND resol_due < 0'
        sql += ' GROUP BY priorityid'
        sql += ' ) c ON p.priorityid = c.priorityid'
        sql += ' WHERE p.priorityid IN (8,9,10,11)'
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
    
    def getClosedTicketByPriority(self):
        cursor = connections['ticketRead'].cursor()
        sql = 'SELECT p.display_text as priority,IFNULL(c.Closed,0) AS closed'
        sql += ' FROM swticketpriorities p'
        sql += ' LEFT JOIN ('
        sql += ' SELECT priorityid, COUNT(ticketid) Closed'
        sql += ' FROM incident_data id'
        sql += ' WHERE deptid NOT IN (0,1,2)'
        sql += ' AND statusid IN ('+CommonSdmModel.Closed+')'
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += ' AND priorityid IN (8,9,10,11)'
        sql += ' GROUP BY priorityid'
        sql += ' ) c ON p.priorityid = c.priorityid'
        sql += ' WHERE p.priorityid IN (8,9,10,11)'
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
    
    def getAlertsVsTickets(self):
        cursor = connections['ticketRead'].cursor()
        sql = 'SELECT COUNT(id.ticketid) alerts,'
        sql += ' SUM((CASE WHEN (priorityid=8) THEN 1 ELSE 0 END) ) Critical,'
        sql += ' SUM((CASE WHEN (priorityid=9) THEN 1 ELSE 0 END) ) High,'
        sql += ' SUM((CASE WHEN (priorityid=10) THEN 1 ELSE 0 END) ) Medium,'
        sql += ' SUM((CASE WHEN (priorityid=11) THEN 1 ELSE 0 END) ) Low'
        sql += ' FROM incident_data id'
        sql += ' WHERE id.deptid NOT IN (0,1,2)'
        sql += ' AND id.sccalertid>0'
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
    
    def getFirstResponseTime(self):
        sql = "SELECT p.display_text,ifnull(c.5MIN,0) AS 5MIN,ifnull(c.15MIN,0) AS 15MIN,ifnull(c.30MIN,0) AS 30MIN,ifnull(c.1hr,0) AS 1hr,ifnull(c.2hr,0) AS 2hr "  
        sql +=  " FROM swticketpriorities p "
        sql +=  " LEFT JOIN ("
        sql +=  " SELECT priorityid, SUM(CASE WHEN (first_resp_time<=300) THEN 1 ELSE 0 END) 5MIN, " 
        sql +=  " SUM(CASE WHEN (first_resp_time<=900) AND (first_resp_time>300) THEN 1 ELSE 0 END)  15MIN, "
        sql +=  " SUM(CASE WHEN (first_resp_time<=1800) AND (first_resp_time>900) THEN 1 ELSE 0 END) 30MIN, " 
        sql +=  " SUM(CASE WHEN (first_resp_time<=3600) AND (first_resp_time>1800) THEN 1 ELSE 0 END) 1hr, "
        sql +=  " SUM(CASE WHEN (first_resp_time<=7200) AND (first_resp_time>3600) THEN 1 ELSE 0 END) 2hr "
        sql +=  " FROM incident_data id  "
        sql +=  " WHERE deptid NOT IN (0,1,2) "
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        sql +=  " group by priorityid) c ON p.priorityid = c.priorityid where  p.priorityid IN (8,9,10,11) "
        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
    
    def getDepartmentTrend(self):
        sql = "SELECT d.title as dept,IFNULL(c.Active, 0) AS active,IFNULL(c.InActive,0) AS inactive,IFNULL(c.Closed,0) AS closed"
        sql += "  FROM swdepartments d"
        sql += "  LEFT JOIN ("
        sql += "  SELECT id.deptid,"
        sql += "  SUM((CASE WHEN (s.statustype=1) THEN 1 ELSE 0 END) ) AS 'Active',"
        sql += "  SUM((CASE WHEN (s.statustype=2) THEN 1 ELSE 0 END) ) AS 'InActive',"
        sql += "  SUM((CASE WHEN (s.statustype=3) THEN 1 ELSE 0 END) ) AS 'Closed'"
        sql += "  FROM incident_data id JOIN swticketstatus s ON id.statusid=s.ticketstatusid"
        sql += "   WHERE id.deptid NOT IN (0,1,2) "  
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += "   GROUP BY id.deptid"
        sql += "  ) c ON d.departmentid=c.deptid"
        if CommonSdmModel.deptIds:
            sql += " WHERE d.departmentid in (" +CommonSdmModel.deptIds +")"
       
       

        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
    
    def ticketsTrend(self):
        sql = "SELECT s.ticketstatusid, s.title, IFNULL(c.Tickets,0) AS Tickets"   
        sql += " FROM swticketstatus s" 
        sql += " LEFT JOIN ("
        sql += " SELECT  statusid,COUNT(ticketid) Tickets"
        sql += " FROM incident_data id"  
        sql += " WHERE deptid NOT IN (0,1,2)"   
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.statusCond) 
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += " GROUP BY statusid"
        sql += " ) c ON c.statusid=s.ticketstatusid"
        sql += " WHERE ticketstatusid IN (1,19,18,2,5,3)"

        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
    
    def ticketsAgeByDept(self):
        sql = "SELECT d.title, "
        sql += " IFNULL(a.Counts,0) AS '1_day',"
        sql += "  IFNULL(b.Counts,0) AS '2_day',"
        sql += "  IFNULL(c.Counts,0) AS '3_day',"
        sql += "  IFNULL(i.Counts,0) AS '4_day',"
        sql += "  IFNULL(e.Counts,0) AS '5_day',"
        sql += "  IFNULL(f.Counts,0) AS '6_day',"
        sql += "  IFNULL(g.Counts,0) AS '7_day',"
        sql += "  IFNULL(h.Counts,0) AS '>7day'"
        sql += "  FROM swdepartments d" 
        sql += "  LEFT JOIN ("
        sql += "  SELECT deptid, COUNT(*) AS Counts" 
        sql += "  FROM incident_data id"
        sql += "  WHERE" 
        sql += "  created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 DAY))"
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        #sql += str(CommonSdmModel.statusCond)
        sql += str(' AND id.statusid != 3 ')
        sql += str(CommonSdmModel.ticketTypeCond) 
        sql += "  GROUP BY deptid"
        sql += "  ) a ON d.departmentid=a.deptid" 
        sql += "  LEFT JOIN ("
        sql += "  SELECT deptid, COUNT(*) AS Counts" 
        sql += "  FROM incident_data id"
        sql += "  WHERE" 
        sql += "  created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 2 DAY))" 
        sql += "  AND created_dt < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 1 DAY))" 
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        #sql += str(CommonSdmModel.statusCond)
        sql += str(' AND id.statusid != 3 ')
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += "  GROUP BY deptid"
        sql += "  ) b ON d.departmentid=b.deptid" 
        sql += "  LEFT JOIN ("
        sql += "  SELECT deptid, COUNT(*) AS Counts" 
        sql += "  FROM incident_data id"
        sql += "  WHERE" 
        sql += "  created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 3 DAY))" 
        sql += "  AND created_dt < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 2 DAY))" 
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        #sql += str(CommonSdmModel.statusCond)
        sql += str(' AND id.statusid != 3 ')
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += "  GROUP BY deptid"
        sql += "  ) c ON d.departmentid=c.deptid"  
        sql += "  LEFT JOIN ("
        sql += "  SELECT deptid, COUNT(*) AS Counts" 
        sql += "  FROM incident_data id"
        sql += "  WHERE" 
        sql += "  created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 4 DAY))"
        sql += "  AND created_dt < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 3 DAY))" 
        sql += "  AND created_dt < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 2 DAY))" 
        sql += "  AND id.deptid NOT IN (0,1,2)" 
        sql += "  AND id.statusid NOT IN ("+CommonSdmModel.Closed+")" 
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        #sql += str(CommonSdmModel.statusCond)
        sql += str(' AND id.statusid != 3 ')
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += "  GROUP BY deptid"
        sql += "  ) i ON d.departmentid=i.deptid"  
        sql += "  LEFT JOIN ("
        sql += "  SELECT deptid, COUNT(*) AS Counts" 
        sql += "  FROM incident_data id"
        sql += "  WHERE" 
        sql += "  created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 5 DAY))" 
        sql += "  AND created_dt < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 4 DAY))" 
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        #sql += str(CommonSdmModel.statusCond)
        sql += str(' AND id.statusid != 3 ')
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += "  GROUP BY deptid"
        sql += "  ) e ON d.departmentid=e.deptid" 
        sql += "  LEFT JOIN ("
        sql += "  SELECT deptid, COUNT(*) AS Counts" 
        sql += "  FROM incident_data id" 
        sql += "  WHERE" 
        sql += "  created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 6 DAY))" 
        sql += "  AND created_dt < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 5 DAY))" 
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        #sql += str(CommonSdmModel.statusCond)
        sql += str(' AND id.statusid != 3 ')
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += "  GROUP BY deptid"
        sql += "  ) f ON d.departmentid=f.deptid"
        sql += "  LEFT JOIN ("
        sql += "  SELECT deptid, COUNT(*) AS Counts"
        sql += "  FROM incident_data id"
        sql += "  WHERE" 
        sql += "  created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 7 DAY))" 
        sql += "  AND created_dt < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 6 DAY))" 
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        #sql += str(CommonSdmModel.statusCond)
        sql += str(' AND id.statusid != 3 ')
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += "  GROUP BY deptid"
        sql += "  ) g ON d.departmentid=g.deptid" 
        sql += "  LEFT JOIN("
        sql += "  SELECT deptid, COUNT(*) AS Counts" 
        sql += "  FROM incident_data id" 
        sql += "  WHERE" 
        sql += "  created_dt < UNIX_TIMESTAMP(DATE_SUB(NOW(), INTERVAL 7 DAY))" 
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        #sql += str(CommonSdmModel.statusCond)
        sql += str(' AND id.statusid != 3 ')
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += "  GROUP BY deptid"
        sql += "  ) h ON d.departmentid=h.deptid" 
        sql += "  WHERE d.departmentid NOT IN (0,1,2)"
        if CommonSdmModel.deptIds:
            sql += " AND d.departmentid in (" +CommonSdmModel.deptIds +")"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult   
    
    def Scheduled(self):
        sql =" SELECT DATE_FORMAT(fieldvalue, '%H:00 %p') AS `hour`, COUNT(cv.typeid) AS scheduled_tickets"
        sql += " FROM incident_data id" 
        sql += " JOIN  swcustomfieldvalues cv ON id.ticketid=cv.typeid  AND cv.customfieldid=12"
        sql += " WHERE cv.customfieldid=12"
        sql += " AND id.statusid = 16"
        if CommonSdmModel.dateRangeCond !='':
            sql += str(CommonSdmModel.dateRangeCond)
        else :  
            sql += " AND fieldvalue>=now() AND fieldvalue <=DATE_ADD(now(), INTERVAL 8 HOUR) "
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        if CommonSdmModel.deptCond != '':
            sql += str(CommonSdmModel.deptCond)
        else:
            sql += ' AND id.deptid NOT IN (0,1,2)'
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += " GROUP BY HOUR(fieldvalue)" 
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult 
          
    def deptSlaTrend(self):
        sql =  "   SELECT sd.title,"
        sql +=  "   sum((case when (id.resol_due between 0 AND 3600) then 1 else 0 end) ) AS 'breach_in_1_hr',"
        sql +=  "   sum((case when (id.resol_due > 3600) then 1 else 0 end) ) AS 'breach_in_>_1_hr',"
        sql +=  "   sum((case when (id.resol_due < 0) then 1 else 0 end) ) AS breached" 
        sql +=  "   FROM incident_data id JOIN swdepartments sd ON (sd.departmentid = id.deptid)"
        sql +=  "   WHERE deptid NOT IN (0,1,2)"
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        sql +=  "   group by id.deptid"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
      
    def topFiveDevices(self):
        sql = "select id.device, count(id.ticketid) as count" 
        sql += " from incident_data id"
        sql += " where id.deptid NOT IN (0,1,2)"
        sql += " and id.did>0"
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += " group by id.did order by count(id.ticketid) desc limit 5"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
    
    def topFiveClients(self):
        sql = "select id.client, count(id.ticketid) as count" 
        sql += " from incident_data id"
        sql += " where id.deptid NOT IN (0,1,2)" 
        sql += " and id.cid>0"
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += " group by id.cid order by count(id.ticketid) desc limit 5"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
    
    def wfciCount(self):
        sql = "SELECT COUNT(id.ticketid) total," 
        sql += " ifnull(sum((case when (id.priorityid=8) then 1 else 0 end) ),0) p0,"
        sql += " ifnull(sum((case when (id.priorityid=9) then 1 else 0 end) ),0) p1,"
        sql += " ifnull(sum((case when (id.priorityid=10) then 1 else 0 end) ),0) p2,"
        sql += " ifnull(sum((case when (id.priorityid=11) then 1 else 0 end) ),0) p3" 
        sql += " FROM incident_data id" 
        sql += " WHERE id.deptid NOT IN (0,1,2)" 
        sql += " AND id.wfci_count > 0"
        sql += " and id.priorityid IN (8,9,10,11)" 
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.ticketTypeCond)

        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
    
    def hmspCount(self):
        sql = "SELECT COUNT(id.ticketid) total," 
        sql += " ifnull(sum((case when (id.priorityid=8) then 1 else 0 end) ),0) p0,"
        sql += " ifnull(sum((case when (id.priorityid=9) then 1 else 0 end) ),0) p1,"
        sql += " ifnull(sum((case when (id.priorityid=10) then 1 else 0 end) ),0) p2,"
        sql += " ifnull(sum((case when (id.priorityid=11) then 1 else 0 end) ),0) p3" 
        sql += " FROM incident_data id" 
        sql += " WHERE id.deptid NOT IN (0,1,2)" 
        sql += " AND id.hmsp_count > 0"
        sql += " and id.priorityid IN (8,9,10,11)" 
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
        

    def getTktsCrtdByDeptPty(self):
        sql = "SELECT sd.title, sp.display_text, COUNT(id.ticketid) total"
        sql += " FROM incident_data id" 
        sql += " JOIN swdepartments sd ON sd.departmentid = id.deptid"  
        sql += " JOIN swticketpriorities sp ON sp.priorityid = id.priorityid" 
        sql += " WHERE id.deptid NOT IN (0,1,2)"  
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.statusCond)
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += " and id.priorityid IN (8,9,10,11)"
        sql += " group by id.deptid, id.priorityid"
        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
    
    def getOpnCrtdClsdTkts(self):
        sql = "Select"
        sql += " ifnull(sum((case when (id.statusid in("+CommonSdmModel.ActInactStatuses+") ) then 1 else 0 end)),0) open_tickets," 
        if CommonSdmModel.dateRange.find(',') != -1:
            import ast
            tmp = ast.literal_eval(CommonSdmModel.dateRange)
            sql += " ifnull(sum((case when (lastactivity>="+str(tmp[0])+" and statusid in ("+str(CommonSdmModel.Closed)+")) then 1 else 0 end)),0) closed,"  
            sql += " ifnull(sum((case when (created_dt>= "+str(tmp[0])+" and statusid in ("+str(CommonSdmModel.All)+")) then 1 else 0 end)),0) created_closed" 
        else:
            sql += " ifnull(sum((case when (lastactivity>="+str(CommonSdmModel.dateRange)+" and statusid in ("+str(CommonSdmModel.Closed)+")) then 1 else 0 end)),0) closed,"  
            sql += " ifnull(sum((case when (created_dt>= "+str(CommonSdmModel.dateRange)+" and statusid in ("+str(CommonSdmModel.All)+")) then 1 else 0 end)),0) created_closed"  
        sql += " from incident_data id"  
        sql += " where id.deptid not in (0,1,2)"
        sql += str(CommonSdmModel.dateRangeCond)
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        sql += str(CommonSdmModel.ticketTypeCond)
         
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult
    
    def getCreatedClosedTkts(self):
        now = datetime.datetime.now()
        mrData = monthrange(now.year,now.month)
        thisMonthEndDt = now.strftime("%m/"+str(mrData[1])+"/%Y 23:59:59")
        thisMonthEndDtMkTime = int(time.mktime(datetime.datetime.strptime(str(thisMonthEndDt), "%m/%d/%Y %H:%M:%S").timetuple()))
        nowMkTime = int(time.mktime(datetime.datetime.strptime(now.strftime("%m/%d/%Y %H:%M:%S"), "%m/%d/%Y %H:%M:%S").timetuple()))
        memCacheTime = (thisMonthEndDtMkTime - nowMkTime)
        
        dataArr = mem_cache.get('graphCreatedClosedTktsCache_'+str(CommonSdmModel.templateId))
        
        if not dataArr:
            createdTktsQuery = "SELECT CONCAT(p.title, ' ', ' Created') title, DATE_FORMAT(FROM_UNIXTIME(created_dt),'%Y%m') YM, DATE_FORMAT(FROM_UNIXTIME(created_dt),'%b %Y') dt,COUNT(ticketid) as cnt "
            createdTktsQuery += "FROM incident_data id "
            createdTktsQuery += "JOIN swticketpriorities p ON id.priorityid=p.priorityid "
            createdTktsQuery += "WHERE created_dt>=UNIX_TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL 3 MONTH)) "
            createdTktsQuery += "AND id.priorityid IN(8,9,10,11) "
            createdTktsQuery += str(CommonSdmModel.deptCond)
            createdTktsQuery += " GROUP BY id.priorityid,DATE_FORMAT(FROM_UNIXTIME(created_dt),'%b %Y') "
            createdTktsQuery += "ORDER BY id.priorityid,created_dt"
            
            cursor = connections['ticketRead'].cursor()
            cursor.execute(createdTktsQuery)
            createdTktsResult = comObj.dictfetchall(cursor)
            
            closedTktsQuery = "SELECT CONCAT(p.title, ' ', ' Closed') title, DATE_FORMAT(FROM_UNIXTIME(lastactivity),'%Y%m') YM, DATE_FORMAT(FROM_UNIXTIME(lastactivity),'%b %Y') dt,COUNT(ticketid) as cnt "
            closedTktsQuery += "FROM incident_data id "
            closedTktsQuery += "JOIN swticketpriorities p ON id.priorityid=p.priorityid "
            closedTktsQuery += "WHERE statusid IN("+str(CommonSdmModel.Closed)+") "
            closedTktsQuery += "AND lastactivity>=UNIX_TIMESTAMP(DATE_SUB(CURDATE(), INTERVAL 3 MONTH)) "
            closedTktsQuery += "AND id.priorityid IN(8,9,10,11) "
            closedTktsQuery += str(CommonSdmModel.deptCond)
            closedTktsQuery += " GROUP BY id.priorityid,DATE_FORMAT(FROM_UNIXTIME(lastactivity),'%b %Y') "
            closedTktsQuery += "ORDER BY id.priorityid,lastactivity"
            
            cursor.execute(closedTktsQuery)
            closedTktsResult = comObj.dictfetchall(cursor)
            
            finalResult = {}
            finalResult.setdefault('createdTktsResult', createdTktsResult)
            finalResult.setdefault('closedTktsResult', closedTktsResult)
            finalResult.setdefault('createdTktsQuery', createdTktsQuery)
            finalResult.setdefault('closedTktsQuery', closedTktsQuery)
            
            chartHeader = ['Months']
            dataArr = []
            tempDataArr = []           
            chartHeaderDict = {}
            
            for key, createdTkts in enumerate(finalResult['createdTktsResult']):
                if createdTkts['dt'] not in chartHeaderDict:
                    chartHeaderDict[createdTkts['YM']] = createdTkts['dt'] 
                    
            for key in sorted(chartHeaderDict.iterkeys()):
                chartHeader.append(chartHeaderDict[key])
                
            slaEffectivePriorities = stpObj.getSlaEffectivePriorities()
            defaultDataArr = []
            for priorityInfo in slaEffectivePriorities:
                defaultDataArr.append(priorityInfo['title']+'  Created')
                defaultDataArr.append(priorityInfo['title']+'  Closed')
                
            for key, defaultArr in enumerate(defaultDataArr):
                tempDataArr = [0] * len(chartHeader)
                tempDataArr[0] = defaultArr
                dataArr.insert(key, tempDataArr)            
            
            for key, createdTkts in enumerate(finalResult['createdTktsResult']):
                listIndex = defaultDataArr.index(createdTkts['title'])
                valueIndexPos = chartHeader.index(createdTkts['dt'])
                dataArr[listIndex][valueIndexPos] = createdTkts['cnt']
            
            for closedTkts in finalResult['closedTktsResult']:
                listIndex = defaultDataArr.index(closedTkts['title'])
                valueIndexPos = chartHeader.index(closedTkts['dt'])
                dataArr[listIndex][valueIndexPos] = closedTkts['cnt']
            
            dataArr.insert(0, chartHeader)
            
            mem_cache.set('graphCreatedClosedTktsCache_'+str(CommonSdmModel.templateId), dataArr, memCacheTime)
            mem_cache.set('graphCreatedClosedTktsResultCache_'+str(CommonSdmModel.templateId), finalResult, memCacheTime)
        
        
        return dataArr
    
    def getClosedTicketsByDept(self):
        cursor = connections['ticketRead'].cursor()
    
        sql = 'SELECT  sd.title as  dept,'
        sql += ' SUM((CASE WHEN (priorityid=8) THEN 1 ELSE 0 END) ) Critical,'
        sql += ' SUM((CASE WHEN (priorityid=9) THEN 1 ELSE 0 END) ) High,'
        sql += ' SUM((CASE WHEN (priorityid=10) THEN 1 ELSE 0 END) ) Medium,'
        sql += ' SUM((CASE WHEN (priorityid=11) THEN 1 ELSE 0 END) ) Low'
        sql += ' FROM incident_data id JOIN swdepartments sd ON (sd.departmentid = id.deptid)'
        sql += ' WHERE 1=1'
        sql += str(CommonSdmModel.closedByDeptDateRangeCond)
        sql += str(CommonSdmModel.nocCond)
        sql += str(CommonSdmModel.channelCond)
        sql += str(CommonSdmModel.mspCond)
        sql += str(CommonSdmModel.clientCond)
        sql += str(CommonSdmModel.deptCond)
        #sql += ' AND id.statusid in ('+str(CommonSdmModel.Closed)+')'
        sql += ' AND id.statusid = 3'
        sql += str(CommonSdmModel.ticketTypeCond)
        sql += ' GROUP BY id.deptid'
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        finalResult = {}
        finalResult.setdefault('result', result)
        finalResult.setdefault('query', sql)
        return finalResult 
        
