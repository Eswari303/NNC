<snippet>
  <content>
# NNC - NetEnrich Nerve Center
	This is a very key Application for NetEnrich Service Delivery to manage different cases of Tickets according to priority and Service Level Agreement.
	Robust reporting system and high level visibility on immediate actionable tickets.
	Efficient tickets schedule mechanism and schedule reports. The following are the modules in this project. 
	1.	Service Management -  SLA Tickets for immediate action
	2.	Quality Matric
	3.	Tickets Management
		a.	Ticket creation (Service Request, Incident, Problem, Change)
		b.	Ticket Review
		c.	Ticket Post Reply
		d.	Auto ticket creation and updates using Email Parser
		e.	Third party PSA system integration
	4.	Resource Management
	5.	Biometric 
	6.	Dashboard
		a.	Managers Dashboard
		b.	Employee Dashboard
		c.	SDM Dashboard
		d.	Noise Dashboard
	7.	Flash Widget
	8.	Notifications
		a.	Flash widget
		b.	15 days older HMSP tickets notifications
		c.	P0 SLA Ticket reminder notification
		d.	Tickets breach in 1 hour to Assignee, Reporting Manager and IM Leads
		e.	Breached tickets notification to Assignee, Reporting Manager and IM Leads
	9.	Reports
		a.	Advance SLAM Filters and SLAM Result
		b.	Schedule Reports
		c.	Inventory Report
		d.	Storage Billing Report
		e.	Backup Report for Billing
		f.	Quality Metric (Process, Technical, Communication, Time, Customer value)
		g.	Integration Report
	
	
## Installation

To run this project following should in installed on your machine

	1. Python (v2.7 or above)
	2. Django (v1.9)
	3. UWSGI (v2.0.12 or above)
	4. MySQL (v5.5)
	5. Memcached (v1.4 or above)
	6. Redis (v3.0 or above)
	7. NodeJS (v5.4.0 or above) 

Third party modules

	1. django-mathfilters
	2. xlsxwriter
	3. requests
	4. python-memcached
	5. dnspython
	6. python-ldap
	7. django-htmlmin
	8. pyexcel-xlsx
	9. python-dateutil
	10. django-debug-toolbar
	11. django-lineage


## Usage

TODO: Write usage instructions

## Contributing

1. Fork it!
2. Create your feature branch: `git checkout -b my-new-feature`
3. Commit your changes: `git commit -am 'Add some feature'`
4. Push to the branch: `git push origin my-new-feature`
5. Submit a pull request :D

## License

Copyright (c) 2016 NetEnrich, Inc

</content>
  <tabTrigger>readme</tabTrigger>
</snippet>
