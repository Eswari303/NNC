"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import connection,connections
from managerDashboard.models.EmpSkillMap import EmpSkillMap
from NNCPortal.commonMethods import commonMethods
from django.core.cache import caches
from operator import itemgetter
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
mem_cache = caches['filecache']
comObj = commonMethods()
env = configobj.getCommConfigValue(configobj.app_env)

class CommonManagerDashboardModel(object):
                
    def getReporteeSkills(self,managerId):
        sql = "Select distinct(skill.skill),count(skill.skill)as count from emp_skill_map map join skillset skill on (skill.id = map.skill_id)  where  map.skill_id !=0 and map.staffid in (select id from nr_staff where reporting_manager_id = '"+str(managerId)+"' ) group by skill.skill"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        skills = comObj.dictfetchall(cursor)
        cursor.close()
        return skills
    
    def getEmpBiometricPunchTime(self,staffId):  
        sql = "select DATE_FORMAT(CONVERT_TZ(first_punch_in_time,'+00:00','+05:30'),'%H:%i') AS firstpunch ,DATE_FORMAT(CONVERT_TZ(last_punch_out_time,'+00:00','+05:30'),'%H:%i') AS lastpunch,current_location from cumulative_biometric_info where first_punch_in_time >= CURDATE()  and staffid="+str(staffId)
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        punchTime = comObj.dictfetchall(cursor)
        cursor.close()
        return punchTime
    
    def getEmpCurrentdayShift(self,staffId):
        sql = " SELECT staff_id,shift_name,shift_start_time,shift_end_time FROM nr_staff_shift_logs WHERE staff_id="+str(staffId)+" AND DATE(CONVERT_TZ(NOW(),'+00:00','+05:30')) = DATE(CONVERT_TZ(FROM_UNIXTIME(shift_date),'+00:00','+05:30'))";
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        staffShift = comObj.dictfetchall(cursor)
        cursor.close()
        return staffShift
    
    def getNewBiometricStatus(self,managerId):
        cursor1 = connections['rosterRead'].cursor()
        sql = "SELECT DISTINCT(st.id), CONCAT(st.staff_fname,' ',st.staff_lname) as staffname, cbi.worked_time, cbi.out_time,cbi.in_building,cbi.current_location, (UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(cbi.first_punch_in_time)) AS time_diff, CONVERT_TZ(cbi.first_punch_in_time, '+00:00', '+05:30') AS first_punch_in_time,CONVERT_TZ(cbi.last_punch_out_time,  '+00:00', '+05:30') AS last_punch_out_time,(CASE WHEN cbi.last_punch_out_time<cbi.punch_update_in_time THEN  UNIX_TIMESTAMP(NOW())-UNIX_TIMESTAMP(cbi.punch_update_in_time) ELSE 0 END) recent_punch_diff FROM nr_staff st LEFT JOIN cumulative_biometric_info cbi ON (cbi.staffid = st.id AND (DATE(CONVERT_TZ(cbi.first_punch_in_time, '+00:00', '+05:30'))=DATE(CONVERT_TZ(NOW(), '+00:00', '+05:30')) OR DATE(CONVERT_TZ(cbi.punch_update_in_time, '+00:00', '+05:30'))=DATE(CONVERT_TZ(NOW(), '+00:00', '+05:30')))) WHERE st.reporting_manager_id="+str(managerId)+" AND st.is_active=1";
        cursor1.execute(sql)
        staffShiftData = comObj.dictfetchall(cursor1)
        cursor1.close()
        return staffShiftData
    
    def getReportingPersons(self,staffId):
        sql = "select id, concat(staff_fname, ' ',staff_lname) staffname from  nr_staff where is_active = 1 and is_found = 1 and reporting_manager_id  ="+str(staffId)+" order by staff_fname asc ";
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        reporteeData = comObj.dictfetchall(cursor)
        cursor.close()
        return reporteeData
    
    def getCompleteSkills(self):
        sql = "select id,skill from skillset order by skill"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        skillsData = comObj.dictfetchall(cursor)
        cursor.close()
        return skillsData
    
    def getMapStaffSkills(self,managerId):
        sql = "SELECT nr.id as staffid,map.skill_id,map.exp_yrs, concat(nr.staff_fname,' ',nr.staff_lname) staffname FROM nr_staff nr,emp_skill_map map WHERE map.staffid = nr.id and nr.is_active = 1 AND nr.is_found = 1 AND map.staffid IN (select id from nr_staff where reporting_manager_id ='"+str(managerId)+"') ORDER BY nr.staff_fname";
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        mapSkillsData = comObj.dictfetchall(cursor)
        cursor.close()
        return mapSkillsData
    
    def deletingRecordOfStaff(self,stid,skid):
        if stid and skid:
            try:
                insertResponse = EmpSkillMap.objects.using('rosterRead').get(staffid = str(stid), skill_id = str(skid))
                insertResponse.delete()
            except Exception as e:
                pass
    
    def HmspCoutAndTicket(self,deptId,fromDate,todate):
        sql = "SELECT hmsp_count,ticketid   FROM  incident_data  WHERE deptid IN ("+str(deptId)+")   AND statusid  = 9    AND ((DATE(FROM_UNIXTIME(created_dt)) BETWEEN  '"+str(fromDate)+"'  AND '"+str(todate)+"')  OR   (DATE(FROM_UNIXTIME(lastactivity)) BETWEEN  '"+str(fromDate)+"' AND '"+str(todate)+"'))"
        cursorTicket = connections['ticketRead'].cursor()
        cursorTicket.execute(sql)
        result = comObj.dictfetchall(cursorTicket)
        cursorTicket.close()
        return result
    
    def wfciCountAndTicket(self,deptId,fromDate,todate):
        sql = "SELECT wfci_count,ticketid   FROM  incident_data  WHERE deptid IN ("+str(deptId)+")  AND statusid  = 47     AND((DATE(FROM_UNIXTIME(created_dt)) BETWEEN  '"+str(fromDate)+"'  AND '"+str(todate)+"')  OR   (DATE(FROM_UNIXTIME(lastactivity)) BETWEEN  '"+str(fromDate)+"' AND '"+str(todate)+"'))";
        cursorTicket = connections['ticketRead'].cursor()
        cursorTicket.execute(sql)
        result = comObj.dictfetchall(cursorTicket)
        cursorTicket.close()
        return result

    def pruneLeaves(self,obj):
        
        if isinstance(obj, dict):
            isLeaf = True
            for key in obj.keys():
                if key=='closedTktInfo' or key=='activeP0Count' or  key=='activeP1Count' or key=='activeP2Count' or key=='activeP3Count'  or key=='inActiveP0Count' or key=='inActiveP1Count' or key=='inActiveP2Count' or key=='inActiveP3Count' or key== 'unassignedTktInfo': 
                    isLeaf = False
                    if self.pruneLeaves(obj[key]): del obj[key]
            return isLeaf
    
        elif isinstance(obj, list) :
            leaves = []
            for (index, element) in enumerate(obj):
                if self.pruneLeaves(element): leaves.append(index)
            leaves.reverse()
            for index in leaves: obj.pop(index)
            return not bool(obj)
        else:  # String values look like attributes in your dict, so never prune them
            return 'iamout'
        
    def GetDepatmentIs(self,managerId):
        sql = "select DISTINCT kayako_deptid from staff_dept_mapping  where managerid = "+str(managerId)
        cursorStaff = connections['rosterRead'].cursor()
        cursorStaff.execute(sql)
        result = comObj.dictfetchall(cursorStaff)
        cursorStaff.close()
        return result
    
    def getDepartmentName(self, id):
        departments_data = mem_cache.get('departments_all'+env)
        if not departments_data:
            sql = "select departmentid,title from swdepartments"
            cursorStaff = connections['ticketRead'].cursor()
            cursorStaff.execute(sql)
            departments_data = comObj.dictfetchall(cursorStaff)
            cursorStaff.close()
            mem_cache.set("departments_all"+env, departments_data, 86000)
        try:
            index = map(itemgetter('departmentid'), departments_data).index(id)
            department = [{'departmentid': departments_data[index]['departmentid'], 'title': departments_data[index]['title']}]
            return department
        except Exception as e:
            return None
    
    def getIdealTickets(self, swtaffIds):
        sql = "select ticketid ,statusid,staffid from incident_data where staffid in("+swtaffIds+") and statusid not in (20,3,17,5,41,32) and lastactivity <= unix_timestamp(NOW() - INTERVAL 2 DAY) and deptid not in (0,1,2)"
        cursorIdealTick = connections['ticketRead'].cursor()
        cursorIdealTick.execute(sql)
        result = comObj.dictfetchall(cursorIdealTick)
        cursorIdealTick.close()
        return result
    
    def schedueleAndRd(self,deptId, rd, sd, fromDate, todate):
        sql = "SELECT ic.ticketid,ic.statusid as sid,getntsstatussladue(ic.ticketid,ic.statusid) as sladue FROM  incident_data ic \
                WHERE ic.deptid IN ("+str(deptId)+") AND (ic.statusid="+str(rd)+" OR ic.statusid="+str(sd)+")  \
                AND((CONVERT_TZ(FROM_UNIXTIME(ic.created_dt),'+00:00','+05:30') >= '"+str(fromDate)+"'  AND CONVERT_TZ(FROM_UNIXTIME(ic.created_dt),'+00:00','+05:30') <= '"+str(todate)+"')  OR  (CONVERT_TZ(FROM_UNIXTIME(ic.lastactivity),'+00:00','+05:30') >= '"+str(fromDate)+"'  AND CONVERT_TZ(FROM_UNIXTIME(ic.lastactivity),'+00:00','+05:30') <= '"+str(todate)+"'))";
        cursorHmspWfci = connections['ticketRead'].cursor()
        cursorHmspWfci.execute(sql)
        scheulAndRd = comObj.dictfetchall(cursorHmspWfci)
        cursorHmspWfci.close()
        return scheulAndRd
    
    '''Unassigned Tickets count breach in 60 minutes''' 
    def getUnassgBreachTicketCount(self, activeStatusIds, empKykDepts):
        sql = "SELECT priorityid, count(ticketid) as tktCount FROM incident_data WHERE statusid IN ("+activeStatusIds+") AND staffid = 0    AND deptid IN ("+empKykDepts+") AND resol_due between 1 AND 3600 GROUP BY priorityid";
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        unassgBreachTicketCount = comObj.dictfetchall(cursor)
        cursor.close()
        return unassgBreachTicketCount
    
    '''Unassigned Tickets breach in 60 minutes'''
    def getUnassgBreachTickets(self, activeStatusIds, empKykDepts):
        sql = "SELECT priorityid, ticketid FROM incident_data    WHERE statusid IN ("+activeStatusIds+") AND staffid = 0 AND deptid IN ("+empKykDepts+") AND resol_due between 1 AND 3600 AND priorityid IN (9,21) ORDER BY priorityid";
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        unassgBreachTickets = comObj.dictfetchall(cursor)
        cursor.close()
        return unassgBreachTickets
    
    '''Assigned Tickets count breach in 60 minutes'''
    def getAssgBreachTicketCount(self, activeStatusIds, empKykDepts):
        sql = "SELECT priorityid, count(ticketid) as tktCount FROM incident_data WHERE statusid IN ("+activeStatusIds+") AND staffid > 0 AND deptid IN ("+empKykDepts+") AND resol_due between 1 AND 3600 GROUP BY priorityid";
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        assgBreachTicketCount = comObj.dictfetchall(cursor)
        cursor.close()
        return assgBreachTicketCount
    
    '''Assigned Tickets breach in 60 minutes'''
    def getAssgBreachTickets(self, activeStatusIds, empKykDepts):
        sql = "SELECT priorityid, ticketid FROM incident_data    WHERE statusid IN ("+activeStatusIds+") AND staffid > 0 AND deptid IN ("+empKykDepts+") AND resol_due between 1 AND 3600 AND priorityid IN (8,9,11,21) ORDER BY priorityid";
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        assgBreachTickets = comObj.dictfetchall(cursor)
        cursor.close()
        return assgBreachTickets
    
    ''' Returns the Active status'''
    def getActiveStatus(self):
        ActiveStatus = mem_cache.get('activeStatus')
        if not ActiveStatus:
            ActiveStatus= {}
            cursor = connections['ticketRead'].cursor()
            sql = "select ticketstatusid,title from swticketstatus where title not in (select statusname from ntsignorablestates) order by displayorder";
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            for value in result:
                ActiveStatus[value['ticketstatusid']]= value['title']    
            mem_cache.set('activeStatus', ActiveStatus, 86400)
        return ActiveStatus
    
    def getstaffIdbydepartments(self,id):
        
        cursor = connections['rosterRead'].cursor()
        sql = "select  DISTINCT kayako_deptId as kayako_deptid from  staff_dept_mapping where  nrstaffid ="+str(id)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    def reporteesDepartments(self,id):
        sql = 'select DISTINCT kayako_deptid from staff_dept_mapping where nrstaffid in (select id from nr_staff where reporting_manager_id = ' +str(id)+');'
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        return res
    def getDepartmentNamedata(self,id):
        sql = "select departmentid,title from swdepartments  where    departmentid in ( "+str(id)+")"
        cursorStaff = connections['ticketRead'].cursor()
        cursorStaff.execute(sql)
        result = comObj.dictfetchall(cursorStaff)
        cursorStaff.close()
        return result
