"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """

import datetime as dt
from datetime import datetime
import os
class ManagerCommon:
    def getWeekStartAndEndDate(self,year,week):
        date = str(year)+'-W'+str(week)
        seDates = {}
        seDates['startDate'] = dt.datetime.strptime(date + '-1', "%Y-W%W-%w")
        seDates['endDate'] = dt.datetime.strptime(date + '-0', "%Y-W%W-%w")
        return seDates
    def getWeekInforamtion(self):
        finDates = {}
        os.environ["TZ"]="Asia/Kolkata"
        curDTime = datetime.now()
        curYear = curDTime.year
        comStYear = str(curYear)+'-03-31'
        comStYear = dt.datetime.strptime(comStYear, '%Y-%m-%d')
        if curDTime > comStYear :
            yearInfo = curYear
        else :
            yearInfo = curYear - 1
        j=0
        wno = 0
        for i in range(13,65) :
            wno = wno + 1
            if i <= 52:
                resDates = self.getWeekStartAndEndDate(yearInfo,i)
            else :
                j=j+1
                resDates = self.getWeekStartAndEndDate(yearInfo,j)
            
            finDatesArr = {}
            finDatesArr[str(resDates['startDate'])+'/'+str(resDates['endDate'])] = 'Week'+str(wno)+'('
            
            
            