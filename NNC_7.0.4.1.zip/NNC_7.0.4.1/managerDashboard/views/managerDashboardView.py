"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
import json
import urllib
import collections
import json as simplejson
from collections import defaultdict
from django.contrib import messages
from django.http import HttpResponse
from django.template import RequestContext
from datetime import date, timedelta, datetime
from django.shortcuts import render, render_to_response, HttpResponseRedirect

from NNCPortal.commonModels.NrStaff import NrStaff
nrstaff_obj = NrStaff()
from NNCPortal.commonModels.NrDesignations import NrDesignations
from managerDashboard.models.commonModel import CommonManagerDashboardModel
from managerDashboard.forms import ManagerDashboard
from managerDashboard.models.EmpSkillMap import EmpSkillMap
from managerDashboard.forms import SkillsEditForm
from NNCPortal.configfile import ConfigManager
from NNCPortal.commonMethods import commonMethods
from NNCPortal.commonModels.StaffDeptMapping import StaffDeptMapping
from employeeDashboard.models.commonModel import CommonEmployeeModel
from NNCPortal.commonModels.Swticketstatus import Swticketstatus
swtktstatus_obj = Swticketstatus()

comMObj=CommonManagerDashboardModel()
nrstaff_obj = NrStaff()
empObj= CommonEmployeeModel()
comObj = commonMethods()
configobj = ConfigManager()

uId = 0
username = ''

def loadManagersMockup(request):

    global uId,username
    if request.method == 'POST':
        pass
    else:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if not request.session['isManager']:
                return HttpResponseRedirect('/employeeDashboard/')
            form = ManagerDashboard()
            if 'uName' in request.session:
                username = request.session['uName']
                uId = request.session['uId'] 
            res1 = NrStaff.objects.using('rosterRead').filter(reporting_manager_id = uId).filter(is_active = 1)
            totalReportees = NrStaff.objects.using('rosterRead').filter(reporting_manager_id = uId).filter(is_active = 1).count()
            reportingPersonData = NrStaff.objects.using('rosterRead').only('id','staff_fname','staff_lname','swstaff_id').filter(reporting_manager_id = uId).filter(is_active = 1)
            res2 = NrStaff.objects.using('rosterRead').filter(id=uId)
            for res in res2:
                repManagerId =  res.reporting_manager_id
                desig_id = res.desig_id
            res3 = NrStaff.objects.using('rosterRead').filter(id=repManagerId)
            for reportingData in res3:
                reportingManagerName = reportingData.staff_fname+" "+reportingData.staff_lname
            res4 = NrDesignations.objects.using('rosterRead').filter(id = desig_id)
            for result in res4:
                desigIs = result.desig_name
            skillSet = comMObj.getReporteeSkills(uId)
           
            punchData = comMObj.getEmpBiometricPunchTime(uId)
            staffShiftData = comMObj.getNewBiometricStatus(uId)
            notAvailable = 0
            available = 0
            
            deptList = ""
            depatments  = comMObj.GetDepatmentIs(uId)
            if not depatments:
                depatments  = comMObj.getstaffIdbydepartments(uId)
            if not depatments:
                depatments  = comMObj.reporteesDepartments(uId)
            if not depatments:
                depatments = [{'kayako_deptid':9999}]
            dept_list = []
            for id in depatments:
                dept_list.append(id['kayako_deptid'])
                deptList += str(id['kayako_deptid'])+','
            
            depatmentsNames  = comMObj.getDepartmentNamedata(deptList[:-1])
            dates = {}
            fordate = date.today() - timedelta(days =1)
            
            dates['fromdate'] = fordate.strftime('%m/%d/%Y')
            dates['toDate'] = date.today().strftime('%m/%d/%Y')
            if 'uName' in request.session :
                    userName = request.session['uName'].split('@')
                    userName = str(userName[0][0:14])+'...'
            else :
                userName = 'TestUser'
            content = {
                        'form':form,
                        'teamList':res1,
                        'managerData':res2,
                        'repManagerData':reportingManagerName,
                        'mDesignation':desigIs,
                        'skillSet':skillSet,
                        'teamStrength':totalReportees,
                        'managerPunchData':punchData,
                        'staffShiftData':staffShiftData,
                        'notAvailable':notAvailable,
                        'available':available,
                        'repesoData':reportingPersonData,
                        'depatmentsNames':depatmentsNames,
                        'dateranges':dates,
                        'userName':userName,
                      }

            return render_to_response('managerMockup.html', content ,context_instance=RequestContext(request))
        else :
            return authRes

def staffSkilsMapping(request):
    username = request.session['uName']
    uId = request.session['uId']   
    if request.method == 'POST':
        result = collections.OrderedDict(sorted(request.POST.items()))
        dupstaff = skillEdit(result, 'dupstaff')
        dupskill = skillEdit(result, 'dupskill')
        dupexp = skillEdit(result, 'dupexp')
        if len(dupstaff) !=0:
            updateData(dupstaff,dupskill,dupexp)
        stname = skillEdit(result, 'staffname')
        skname = skillEdit(result, 'skillname')
        expname = skillEdit(result, 'exp_yrs')
        if len(stname) !=0:
            updateData(stname,skname,expname)
                              
        return HttpResponseRedirect('/managerDashboard/')
        
    else:
        reportingPersons = comMObj.getReportingPersons(uId)
        CompleteSkillsData = comMObj.getCompleteSkills()         
        skillsmappingData = comMObj.getMapStaffSkills(uId)
        dataCount = len(skillsmappingData)
        form = SkillsEditForm()  
        return render(request, '_staffSkillsMapping.html',{'staffPersons':reportingPersons,'CompleteSkills':CompleteSkillsData, 'SkillsMappedData': skillsmappingData, 'staffID':uId,'form' : form}, context_instance=RequestContext(request))
    
    
def deleteStaffRecord(request):
    staffid = request.POST.get('sti')
    skillid = request.POST.get('ski')
    deleteSkillsData = comMObj.deletingRecordOfStaff(staffid, skillid)
    return HttpResponse(json.dumps(deleteSkillsData), content_type="application/json")

def skillEdit(result,search):
    name = defaultdict(list)
    i =1
    for key, val in result.iteritems():
        if val !='':
            if key.find(search)> -1:
                name[i].append(val) 
                i = i+1 
    return name 

def updateData(stname,skname,expname):
    if (len(stname)==len(skname) == len(expname)):    
        for key, val in stname.iteritems():
            st = val
            sk=  skname[key]
            exp1= expname[key]
            stid = (''.join(st)).encode('utf8')
            skid = (''.join(sk)).encode('utf8')
            exp = (''.join(exp1)).encode('utf8')
        
            flag =0;
            try:
                insertResponse = EmpSkillMap.objects.using('rosterWrite').get(staffid = str(stid), skill_id = str(skid))
                         
            except Exception as e:
                
                flag = 1
                if str(e).find("matching query does not exist")> -1:
                    insertResponse = EmpSkillMap.objects.using('rosterWrite').create(staffid = str(stid), skill_id = str(skid), exp_yrs = str(exp))  
                    insertResponse.save()
  
            if(flag == 0):
                insertResponse.staffid = stid
                insertResponse.skill_id = skid 
                insertResponse.exp_yrs = exp
                insertResponse.save()                    

def deptSlaComplaiance(request):

    username = request.session['uName']
    uId = request.session['uId']  
    calander = request.POST.get('calanderType',False)
    if calander :
        calander = int(calander)
    if calander == 3:
        toDate= str(request.POST.get('toDate',False))
        fromDate= str(request.POST.get('fromDate',False))
        toDate = datetime.strptime(toDate,'%m/%d/%Y')
        fromDate = datetime.strptime(fromDate,'%m/%d/%Y')
        toDate = toDate.strftime('%Y-%m-%d')
        fromDate = fromDate.strftime('%Y-%m-%d')
    else:
        dates = comObj.getCurWeekandlastsevDaysDates(calander)
        toDate= dates['endD']
        fromDate= dates['startD']
    mainUrl = configobj.getCommConfigValue(configobj.apiurl)
    res1 = NrStaff.objects.using('rosterRead').filter(reporting_manager_id =uId).filter(is_active = 1).exclude(swstaff_id__isnull=True)
    staffllength  = NrStaff.objects.using('rosterRead').filter(reporting_manager_id =uId).filter(is_active = 1)
    TotalTeamCount =  len(staffllength)   
    staff_list = ""
    staffIdList  = [uId]
    for attr in res1:
        staff_list += str(attr.id)+','
        staffIdList.append(attr.id)
    staffList = staff_list[:-1]
    deptUrl = mainUrl+'DeptSLACompliance' 
    teamTktInfoUrl =  mainUrl+'ManagerDashboardTeamTktInfo'
    postData = {}
    postData['stffidList'] = staffIdList
    postData['dates']= [fromDate+'/'+toDate]  
    deptList = ""
    depatments  = comMObj.reporteesDepartments(uId)
    if len(depatments) <= 0:
        depatments  = comMObj.getstaffIdbydepartments(uId)
        
    dept_list = []
    for id in depatments:
        dept_list.append(id['kayako_deptid'])
        deptList += str(id['kayako_deptid'])+','
 
    postData['deptidList'] = dept_list
    deptList  = comMObj.getDepartmentName(deptList[:-1])
    deptApiResult = comObj.getPostResponce(deptUrl,postData) 
    employeeloo ={}
    priortyWise ={}
    nP1 = nP2 = nP3 = nP0 = 0
    dP1 = dP2 = dP3 = dP0 = 0 
    for  data , vals in deptApiResult.iteritems():  
        if(data == "231"):
            pass
        totlHeader ={}   
        num = 0
        denno = 0
        
        employeeloo[data] = {}
        
        employeeloo[data] = {}
        if vals.has_key('P0Count'):
            val = vals['P0Count']
        else:
            val ='0/0'
            
        employeeloo[data]['P0'] = val
        if vals.has_key('P1Count'):
            val1 = vals['P1Count']
        else:
            val1 ='0/0'
        
        employeeloo[data]['P1'] = val1
        if vals.has_key('P2Count'):
            val2 = vals['P2Count']
        else:
            val2 ='0/0'
        employeeloo[data]['P2'] = val2
        if vals.has_key('P3Count'):
            val3 = vals['P3Count']
        else:
            val3 ='0/0'
        employeeloo[data]['P3'] = val3

        employeeloo[data]['P0'] = val
        employeeloo[data]['P1'] = val1
        employeeloo[data]['P2'] = val2
        employeeloo[data]['P3'] = val3
        
        
        
        P0str = val.split('/')
        P1str = val1.split('/') 
        P2str = val2.split('/')
        P3str = val3.split('/')
        
        
        nP0 = nP0 +int(P0str[0])
        nP1 = nP1 +int(P1str[0])
        nP2 = nP2 +int(P2str[0])
        nP3 = nP3 +int(P3str[0])
        
        dP0 = dP0 +int(P0str[1])
        dP1 = dP1 +int(P1str[1])
        dP2 = dP2 +int(P2str[1])
        dP3 = dP3 +int(P3str[1])

        
        num = float(int(P0str[0])+int(P1str[0])+int(P2str[0])+int(P3str[0]))
        denno = float(int(P0str[1])+int(P1str[1])+int(P2str[1])+int(P3str[1]))
        
       
        if denno != 0:
            employeeloo[data]['deptToat'] = int((num/denno)*100)
        else :
            employeeloo[data]['deptToat'] = 100
        if(data == "231"):
            pass
            
        nP0 = float(nP0 +int(P0str[0]))
        nP1 = float(nP1 +int(P1str[0]))
        nP2 = float(nP2 +int(P2str[0]))
        nP3 = float(nP3 +int(P3str[0]))
        
        dP0 = float(dP0 +int(P0str[1]))
        dP1 = float(dP1 +int(P1str[1]))
        dP2 = float(dP2 +int(P2str[1]))
        dP3 = float(dP3 +int(P3str[1]))
        
        if dP0 != 0:
            tol0 = int((nP0/dP0)*100)
            if tol0 > 0:
                totlHeader['p0']= int((nP0/dP0)*100)
            else:
                totlHeader['p0']= 0
        else:
            totlHeader['p0']= 0
            
        if dP1 !=0:
            tol1 = int((nP1/dP1)*100)
            if tol1 >0:
                totlHeader['p1']= int((nP1/dP1)*100)
            else:
                totlHeader['p1']= 0
        else:
            totlHeader['p1']= 0
        
        if dP2 !=0:
            tol2 = int((nP2/dP2)*100)
            if tol2 > 0:
                totlHeader['p2']= int((nP2/dP2)*100)
            else:
                totlHeader['p2']= 0
                
        else:
            totlHeader['p2']= 0

        if dP3 !=0:
            tol3 = int((nP3/dP3)*100)
            if tol3 >0:
                totlHeader['p3']= int((nP3/dP3)*100)
            else:
                totlHeader['p3']= 0
                
        else:
            totlHeader['p3']= 0

    mainUrl = configobj.getCommConfigValue(configobj.apiurl)
    url = mainUrl+'ManagerDashboardTeamTktInfo'
    apiRestimeworked = comObj.getPostResponce(url,postData)
    closedP0 = closedP1 =closedP2= closedP3 = 0
    closedP0tickets = closedP1tickets = closedP2tickets = closedP3tickets = ""
    closedTot = {}
    totalClosed  = 0
    tiketsvals = ""
    for i ,val  in apiRestimeworked['closedTktInfo'].iteritems():
        closedP0 = closedP0 + val['P0Count']
        closedP1 = closedP1 + val['P1Count']
        closedP2 = closedP2 + val['P2Count']
        closedP3 = closedP3 + val['P3Count']
        totalClosed = closedP0 +closedP1+closedP2+closedP3
        closedP0tickets += val['P0tkts']
        closedP1tickets += val['P1tkts']
        closedP2tickets += val['P2tkts']
        closedP3tickets += val['P3tkts']
    closedTot['closedP0'] = closedP0
    closedTot['closedP1'] = closedP1
    closedTot['closedP2'] = closedP2
    closedTot['closedP3'] = closedP3
    closedTot['totalClosed'] = totalClosed
    closedTot['closedP0tickets'] = closedP0tickets
    closedTot['closedP1tickets'] = closedP1tickets
    closedTot['closedP2tickets'] = closedP2tickets
    closedTot['closedP3tickets'] = closedP3tickets

    comMObj.pruneLeaves(apiRestimeworked)
    employeeData = {}
    employeeCounts ={}
    teamTimeWorkedCount = 0
    utilazation = 0
    for data ,value in apiRestimeworked.iteritems():
        
        employeeData[data] = {}
        employeeCounts[data] ={}
        employeeData[data]['Active'] = {}
        employeeData[data]['InActive'] = {}
        employeeCounts[data]['Replys'] = 0
        employeeCounts[data]['Timeworked'] = 0
        employeeCounts[data]['Closed'] = 0
        employeeCounts[data]['utilating'] = 0
        
        if value['active']:
            
            employeeData[data]['Active']['P0'] = value['active']['P0']
            employeeData[data]['Active']['P1'] = value['active']['P1']
            employeeData[data]['Active']['P2'] = value['active']['P2']
            employeeData[data]['Active']['P3'] = value['active']['P3']
        
        if value['inactive']:
             
            employeeData[data]['InActive']['P0'] = value['inactive']['P0']
            employeeData[data]['InActive']['P1'] = value['inactive']['P1']
            employeeData[data]['InActive']['P2'] = value['inactive']['P2']
            employeeData[data]['InActive']['P3'] = value['inactive']['P3']
        
        for enddata,subarry  in  value['prodInf'].iteritems():
            teamTimeWorkedCount =  teamTimeWorkedCount  +int(subarry['timewrkd'])
            employeeCounts[data]['Replys']  += int(subarry['rplys'])
            employeeCounts[data]['Timeworked']  += int(subarry['timewrkd'])
            employeeCounts[data]['Closed']  += int(subarry['clsd'])
        
        for lo  in value['overallEmptotl']:
            if value['overallEmptotl']['stfutl']:
                utilazation = utilazation +  value['overallEmptotl']['stfutl']        
            else:
                pass 

            if value['overallEmptotl']:
                if value['overallEmptotl']['stfutl']:
                    employeeCounts[data]['utilating'] = int(value['overallEmptotl']['stfutl'])
            else:
                employeeCounts[data]['utilating'] = 0
                
    stautl = 0    
    for data ,value in apiRestimeworked.iteritems():
        for key,val in value['overallEmptotl'].iteritems():
            if key == 'stfutl':
                
                stautl = stautl + val
                
    TotalTeamCount = TotalTeamCount+1
    
    utilazation = (stautl/TotalTeamCount) 
    
    dates = postData['dates'][0].split('/')
    datat =dates[0]
    d1 = datetime.strptime(str(dates[0]), "%Y-%m-%d")
    d1.strftime("%d, %b %Y' ")
    
    d2 = datetime.strptime(str(dates[1]), "%Y-%m-%d")
    
    long = d1.strftime("%dth %b %Y ") +' to '+d2.strftime("%dth %b %Y ")
    
    jsonData = simplejson.dumps({'deptRes': employeeloo,'totlHeader':totlHeader,'totalCloased':closedTot,'totalWorked':teamTimeWorkedCount,'utilzation':round(utilazation),"selectedDates":long})
    
    return HttpResponse(jsonData, content_type="application/json")
    
def getHmspAndWfciCounts(request):
    username = request.session['uName']
    uId = request.session['uId'] 
    dates = comObj.getWeekStartAndEndDate()
    deptList = ""
    depatments  = comMObj.getstaffIdbydepartments(uId)
   
    dept_list = []
    for id in depatments:
        dept_list.append(id['kayako_deptid'])
        deptList += str(id['kayako_deptid'])+','

    hmspResult  = comMObj.HmspCoutAndTicket(deptList[:-1], dates['startD'], dates['endD'])
    wficResult  = comMObj.wfciCountAndTicket(deptList[:-1],  dates['startD'],  dates['endD'])
    hmspCounts  = {}
    hmaspTicketId =[]
    count = 0;
    TotalsCount = 0
    for i in hmspResult:
        
        count =  count +  i['hmsp_count']
        hmaspTicketId.append(i['ticketid'])
        TotalsCount = TotalsCount + 1

    hmspCounts['count'] = TotalsCount
    hmspCounts['ticketid'] =hmaspTicketId
    
    wfciCounts ={}
    wfciTicketId =[]
    wficTotal = 0
    for j in wficResult:
        wficTotal = wficTotal+1
        wfciTicketId.append(j['ticketid'])
    wfciCounts['count'] = wficTotal
    wfciCounts['ticketid'] =wfciTicketId
    jsonData = simplejson.dumps({'hmsp':hmspCounts,'wfci':wfciCounts})
    return HttpResponse(jsonData, content_type="application/json")
    
def getTicketInfos(request):

    username = request.session['uName']
    uId = request.session['uId']  
    reportingPersonData = NrStaff.objects.using('rosterRead').only('id','staff_fname','staff_lname','swstaff_id').filter(reporting_manager_id = uId).filter(is_active = 1)
    staffIdsLists =[]
    staffIdsLists.append(uId)
    for  data  in reportingPersonData:
        staffIdsLists.append(data.id)
    
    weekRes = comObj.getWeekStartAndEndDate()
    mainUrl = configobj.getCommConfigValue(configobj.apiurl)
    url = mainUrl+'ManagerDashboardTeamTktInfo'
    apiParams = {}
    deptList = ""
    depatments  = comMObj.getstaffIdbydepartments(uId)
    dept_list = []
    for id in depatments:
        dept_list.append(id['kayako_deptid'])
        deptList += str(id['kayako_deptid'])+','
    apiParams['deptidList'] = dept_list #empDeptList#
    apiParams['stffidList'] = staffIdsLists
    weekRes = str(weekRes['startD'])+'/'+str(weekRes['endD'])
    apiParams['dates'] = [weekRes]
    apiRes = comObj.getPostResponce(url,apiParams)    
    teamTicketInfo = {}
    teamTicketInfo['tactivep0'] = int(apiRes['activeP0Count'])
    teamTicketInfo['tactivep1'] = int(apiRes['activeP1Count'])
    teamTicketInfo['tactivep2'] = int(apiRes['activeP2Count'])
    teamTicketInfo['tactivep3'] = int(apiRes['activeP3Count'])
    teamTicketInfo['tinactivep0'] = int(apiRes['inActiveP0Count'])
    teamTicketInfo['tinactivep1'] = int(apiRes['inActiveP1Count'])
    teamTicketInfo['tinactivep2'] = int(apiRes['inActiveP2Count'])
    teamTicketInfo['tinactivep3'] = int(apiRes['inActiveP3Count'])
    teamTicketInfo['tactiveCount'] = int(apiRes['activeP0Count'])+int(apiRes['activeP1Count'])+int(apiRes['activeP2Count'])+int(apiRes['activeP3Count'])
    teamTicketInfo['tinactiveCount'] = int(apiRes['inActiveP0Count'])+int(apiRes['inActiveP1Count'])+int(apiRes['inActiveP2Count'])+int(apiRes['inActiveP3Count'])
    teamTicketInfo['tclosedCount'] = 0
    
    teamTicketInfo['unassP0'] = 0
    teamTicketInfo['unassP1'] = 0
    teamTicketInfo['unassP2'] = 0
    teamTicketInfo['unassP3'] = 0
    teamTicketInfo['unassP0Tickets'] = ""
    teamTicketInfo['unassP1Tickets'] = ""
    teamTicketInfo['unassP2Tickets'] = ""
    teamTicketInfo['unassP3Tickets'] = ""

    teamTicketInfo['unassTotal'] = 0 
    for i,j in apiRes['unassignedTktInfo'].iteritems():
        teamTicketInfo['unassP0'] += int(j['P0'])
        teamTicketInfo['unassP1'] += int(j['P1'])
        teamTicketInfo['unassP2'] += int(j['P2'])
        teamTicketInfo['unassP3'] += int(j['P3'])
        teamTicketInfo['unassTotal'] += int(j['P0'])+int(j['P1'])+int(j['P2'])+int(j['P3'])
        
        if str(j['P0tkts']) == "":
            pass
        else:
            teamTicketInfo['unassP0Tickets'] += str(j['P0tkts']) + ","
        
        if str(j['P1tkts']) == "":
            pass
        else:
            teamTicketInfo['unassP1Tickets'] += str(j['P1tkts']) + ","

        if str(j['P2tkts']) == "":
            pass
        else:
            teamTicketInfo['unassP2Tickets'] += str(j['P2tkts']) + ","

        if str(j['P3tkts']) == "":
            pass
        else:
            teamTicketInfo['unassP3Tickets'] += str(j['P3tkts']) + ","

    comMObj.pruneLeaves(apiRes)
    
    employeeData = {}
    employeeCounts ={}
    for data ,value in apiRes.iteritems():
        employeeData[data] = {}
        employeeCounts[data] ={}
        employeeData[data]['Active'] = {}
        employeeData[data]['InActive'] = {}
        employeeCounts[data]['Replys'] = 0
        employeeCounts[data]['Timeworked'] = 0
        employeeCounts[data]['Closed'] = 0
        employeeCounts[data]['utilating'] = 0
        
        if value['active']:
            employeeData[data]['Active']['P0'] = value['active']['P0']
            employeeData[data]['Active']['P1'] = value['active']['P1']
            employeeData[data]['Active']['P2'] = value['active']['P2']
            employeeData[data]['Active']['P3'] = value['active']['P3']
            employeeData[data]['Active']['P0tkts'] = value['active']['P0tkts']
            employeeData[data]['Active']['P1tkts'] = value['active']['P1tkts']
            employeeData[data]['Active']['P2tkts'] = value['active']['P2tkts']
            employeeData[data]['Active']['P3tkts'] = value['active']['P3tkts']

        if value['inactive']:
            employeeData[data]['InActive']['P0'] = value['inactive']['P0']
            employeeData[data]['InActive']['P1'] = value['inactive']['P1']
            employeeData[data]['InActive']['P2'] = value['inactive']['P2']
            employeeData[data]['InActive']['P3'] = value['inactive']['P3']
            employeeData[data]['InActive']['P0tkts'] = value['inactive']['P0tkts']
            employeeData[data]['InActive']['P1tkts'] = value['inactive']['P1tkts']
            employeeData[data]['InActive']['P2tkts'] = value['inactive']['P2tkts']
            employeeData[data]['InActive']['P3tkts'] = value['inactive']['P3tkts']
        
        for enddata,subarry  in  value['prodInf'].iteritems():
            employeeCounts[data]['Replys']  += int(subarry['rplys'])
            employeeCounts[data]['Timeworked']  += int(subarry['timewrkd'])
            employeeCounts[data]['Closed']  += int(subarry['clsd'])
        
        for lo  in value['overallEmptotl']:
            if value['overallEmptotl']:
                if value['overallEmptotl']['stfutl']:
                    employeeCounts[data]['utilating'] = round(value['overallEmptotl']['stfutl'])
                   
            else:
                employeeCounts[data]['utilating'] =0
            
    jsonData = simplejson.dumps({'employee':employeeData,'fisrtHeader':teamTicketInfo,'employeeCounts':employeeCounts})
    return HttpResponse(jsonData, content_type="application/json")


def teamSlaComplaince(request):
    username = request.session['uName']
    uId = request.session['uId']  
    calander = request.POST.get('calanderType',False)
    if calander :
        calander = int(calander)
    if calander == 3:
        toDate= str(request.POST.get('toDate',False))
        fromDate= str(request.POST.get('fromDate',False))
        toDate = datetime.strptime(toDate,'%m/%d/%Y')
        fromDate = datetime.strptime(fromDate,'%m/%d/%Y')
        toDate = toDate.strftime('%Y-%m-%d')
        fromDate = fromDate.strftime('%Y-%m-%d')
    else:
        dates = comObj.getCurWeekandlastsevDaysDates(calander)
        toDate= dates['endD']
        fromDate= dates['startD']
    reportingPersonData = NrStaff.objects.using('rosterRead').only('id','staff_fname','staff_lname','swstaff_id').filter(reporting_manager_id = uId).filter(is_active = 1).exclude(swstaff_id__isnull=True)
    
    staffIdsLists =[]
    staffIdsLists.append(uId)
    for  data  in reportingPersonData:
        staffIdsLists.append(data.id)
    mangSwId = request.session['swstaffId']
    staffIdsLists.append(mangSwId)
    deptList = ""
    depatments  = comMObj.GetDepatmentIs(uId)    
    dept_list = []
    for id in depatments:
        dept_list.append(id['kayako_deptid'])
        deptList += str(id['kayako_deptid'])+','
    
    
    mainUrl = configobj.getCommConfigValue(configobj.apiurl)
    url = mainUrl+'TeamSLACompliance'
    apiParams = {}
    apiParams['deptidList'] = dept_list #empDeptList#
    apiParams['stffidList'] = staffIdsLists#nrstaffIds#
    apiParams['dates'] = [ fromDate+'/'+toDate]
    apiRes = comObj.getPostResponce(url,apiParams)
    eachPerson ={}
    totalHeader ={}
    nP1 = nP2 = nP3 = nP0 = 0
    dP1 = dP2 = dP3 = dP0 = 0 
    for data, value  in  apiRes.iteritems():
        num = 0
        den = 0
        eachPerson[data] = {}
        if value.has_key('P0Count'):
            val = value['P0Count']
        else:
            val ='0/0'
            
        eachPerson[data]['P0'] = val
        if value.has_key('P1Count'):
            val1 = value['P1Count']
        else:
            val1 ='0/0'
        
        eachPerson[data]['P1'] = val1
        if value.has_key('P2Count'):
            val2 = value['P2Count']
        else:
            val2 ='0/0'
        eachPerson[data]['P2'] = val2
        if value.has_key('P3Count'):
            val3 = value['P3Count']
        else:
            val3 ='0/0'
        eachPerson[data]['P3'] = val3
        
        P0str = val.split('/')
        P1str = val1.split('/')
        P2str = val2.split('/')
        P3str = val3.split('/')
        num = float(int(P0str[0])+int(P1str[0])+int(P2str[0])+int(P3str[0]))
        den = float(int(P0str[1])+int(P1str[1])+int(P2str[1])+int(P3str[1]))
        
        nP0 = float(nP0 +int(P0str[0]))
        nP1 = float(nP1 +int(P1str[0]))
        nP2 = float(nP2 +int(P2str[0]))
        nP3 = float(nP3 +int(P3str[0]))
        
        dP0 = float(dP0 +int(P0str[1]))
        dP1 = float(dP1 +int(P1str[1]))
        dP2 = float(dP2 +int(P2str[1]))
        dP3 = float(dP3 +int(P3str[1]))
        
        if dP0 !=0:
            tol0 = int((nP0/dP0)*100)
            if tol0 > 0:
                totalHeader['p0']= int((nP0/dP0)*100)
            else:
                totalHeader['p0']= 0
        else:
            totalHeader['p0']= 0
            
        if dP1 !=0:
            tol1 = int((nP1/dP1)*100)
            if tol1 >0:
                totalHeader['p1']= int((nP1/dP1)*100)
            else:
                totalHeader['p1']= 0
        else:
            totalHeader['p1']= 0
        
        if dP2 !=0:
            tol2 = int((nP2/dP2)*100)
            if tol2 > 0:
                totalHeader['p2']= int((nP2/dP2)*100)
            else:
                totalHeader['p2']= 0
                
        else:
            totalHeader['p2']= 0

        if dP3 !=0:
            tol3 = int((nP3/dP3)*100)
            if tol3 >0:
                totalHeader['p3']= int((nP3/dP3)*100)
            else:
                totalHeader['p3']= 0
                
        else:
            totalHeader['p3']= 0

        if den != 0:
            eachPerson[data]['totalPriorty'] = int((num/den)*100)
        else :
            eachPerson[data]['totalPriorty'] = 0
    
    jsonData = simplejson.dumps({'teamSla':eachPerson,'totalHeader':totalHeader})
    return HttpResponse(jsonData, content_type="application/json")
        
def idealTicketscount(request):

    username = request.session['uName']
    uId = request.session['uId'] 
    reportingperson = NrStaff.objects.using('rosterRead').only('id','swstaff_id','staff_fname','staff_lname').filter(reporting_manager_id = uId).filter(is_active = 1).exclude(swstaff_id__isnull=True)
    mangerDetails = NrStaff.objects.using('rosterRead').only('id','swstaff_id','staff_fname','staff_lname').filter(id = uId).filter(is_active = 1).exclude(swstaff_id__isnull=True)
    mgSwId = ''
    for details in mangerDetails:
        mgSwId = details.swstaff_id
    staff_list = ""
    for attr in reportingperson:
        staff_list += str(attr.swstaff_id)+','
    
    staffList = staff_list[:-1]
    staffList += ',' +str(mgSwId)   
    idealTicketsdata = comMObj.getIdealTickets(staffList)
    idealTotalcount = len(idealTicketsdata)
    tks={}
    ticketslist = []
    for data  in idealTicketsdata:
        if tks.has_key(data['staffid']):
            tks[data['staffid']]['ticketId'] += str(data['ticketid'])+ ','
            tks[data['staffid']]['count'] += 1
            ticketslist.append(str(data['ticketid']))
        else:
            tks.setdefault(data['staffid'],{})
            tks[data['staffid']].setdefault('ticketId',str(data['ticketid'])+ ',')
            tks[data['staffid']].setdefault('count', 1)
            ticketslist.append(str(data['ticketid']))
    
    jsonData = simplejson.dumps({'idealTickets':tks, "idealticketslist" : ticketslist})
    return HttpResponse(jsonData,content_type="application/json")  
def scheduleAndResponse(request):
    username = request.session['uName']
    uId = request.session['uId'] 
    dateRanges = comObj.getWeekStartAndEndDate()
    deptList = ""
    depatments  = comMObj.getstaffIdbydepartments(uId)
    dept_list = []
    for id in depatments:
        dept_list.append(id['kayako_deptid'])
        deptList += str(id['kayako_deptid'])+','
        
    deptList[:-1]
    
    rd = 19
    sd = 16
    fromDate = dateRanges['startD']
    todate = dateRanges['endD']
    data = comMObj.schedueleAndRd(deptList[:-1], rd, sd, fromDate, todate)
    dataCount  = len(data)
    pairSet = {}
    rdTicketid=[]
    sdTicketid=[]
    rdFlag = 0
    sdFlag = 0
    for i in range(0,dataCount):  
        if data[i]['sid'] == 19:
            rdTicketid.append(data[i]['ticketid'])    
        else:
            sdTicketid.append(data[i]['ticketid'])   
        if data[i]['sladue'] < 3600 and data[i]['sladue'] > 0:
            if data[i]['sid'] == 19:
                rdFlag = 1
            else:
                sdFlag = 1
                
    pairSet.setdefault('rdTicketid' ,rdTicketid)
    pairSet.setdefault('sdTicketid' ,sdTicketid)
    pairSet.setdefault('rdFlag' ,rdFlag)
    pairSet.setdefault('sdFlag' ,sdFlag)
    
    jsonData = simplejson.dumps({'schuandRd':pairSet})
    return HttpResponse(jsonData,content_type="application/json")

def priorityWidgets(request):
    username = request.session['uName']
    uId = request.session['uId']  
    activeStatus = swtktstatus_obj.getActiveStatus()
    activeStatuses1 = {}
    activeStatusIds = ''
    for activeStatuses in activeStatus:
        activeStatuses1 = activeStatuses
        activeStatusIds = activeStatusIds + str(activeStatuses1) + ','
    if activeStatusIds !="":
        actvStatusIds = activeStatusIds[:-1]
    empKayakoDepts = StaffDeptMapping.objects.using('rosterRead').only('kayako_deptid').filter(nrstaffid = uId)
    empKykDeptIds = {}
    empKykDepts = ''
    for empKayakoDeptIds in empKayakoDepts:
        empKykDeptIds = empKayakoDeptIds.kayako_deptid
        empKykDepts = empKykDepts + str(empKykDeptIds) + ','
    if empKykDepts !="":
        empKykDepts = empKykDepts[:-1]

    unassgBreachTicketCount = comMObj.getUnassgBreachTicketCount(actvStatusIds, empKykDepts)
    unassgBreachTickets = comMObj.getUnassgBreachTickets(actvStatusIds, empKykDepts)
    assgBreachTicketCount = comMObj.getAssgBreachTicketCount(actvStatusIds, empKykDepts)
    assgBreachTickets = comMObj.getAssgBreachTickets(actvStatusIds, empKykDepts)

    breachTickets = defaultdict(dict)
    
    for unassgBreachTicketCounts in unassgBreachTicketCount:
        breachTickets['unas_priority_'+str(unassgBreachTicketCounts['priorityid'])] = unassgBreachTicketCounts['tktCount'];
    for unassgBreachTicket in unassgBreachTickets:
        breachTickets['unas_priority_tkts_'+str(unassgBreachTicket['priorityid'])].setdefault('tickets', unassgBreachTicket['ticketid'])
    for assgBreachTicketCounts in assgBreachTicketCount:
        breachTickets['assgn_priority_'+str(assgBreachTicketCounts['priorityid'])] = assgBreachTicketCounts['tktCount'];
    for assgBreachTicket in assgBreachTickets:
        breachTickets['assgn_priority_tkts_'+str(assgBreachTicket['priorityid'])].setdefault('tickets', assgBreachTicket['ticketid'])
    
    assUnassBreachTickets = {}
    assUnassBreachTickets['P0_asgn'] = breachTickets['assgn_priority_8'] if breachTickets['assgn_priority_8'] != {} else 0 
    assUnassBreachTickets['P1_asgn'] = breachTickets['assgn_priority_9'] if breachTickets['assgn_priority_9'] != {} else 0
    assUnassBreachTickets['P2_asgn'] = breachTickets['assgn_priority_10'] if breachTickets['assgn_priority_10']!= {} else 0
    assUnassBreachTickets['P3_asgn'] = breachTickets['assgn_priority_11'] if breachTickets['assgn_priority_11']!= {} else 0
         
    assUnassBreachTickets['P0_unasgn'] = breachTickets['unas_priority_8'] if breachTickets['unas_priority_8']!= {} else 0
    assUnassBreachTickets['P1_unasgn'] = breachTickets['unas_priority_9'] if breachTickets['unas_priority_9']!= {} else 0
    assUnassBreachTickets['P2_unasgn'] = breachTickets['unas_priority_10'] if breachTickets['unas_priority_10']!= {} else 0
    assUnassBreachTickets['P3_unasgn'] = breachTickets['unas_priority_11'] if breachTickets['unas_priority_11'] != {} else 0
    
    assUnassBreachTickets['P0_asgntkts'] = breachTickets['assgn_priority_tkts_8']
    assUnassBreachTickets['P1_asgntkts'] = breachTickets['assgn_priority_tkts_9']
    assUnassBreachTickets['P2_asgntkts'] = breachTickets['assgn_priority_tkts_10']
    assUnassBreachTickets['P3_asgntkts'] = breachTickets['assgn_priority_tkts_11']
          
    assUnassBreachTickets['P0_unasgntkts'] = breachTickets['unas_priority_tkts_8']
    assUnassBreachTickets['P1_unasgntkts'] = breachTickets['unas_priority_tkts_9']
    assUnassBreachTickets['P2_unasgntkts'] = breachTickets['unas_priority_tkts_10']
    assUnassBreachTickets['P3_unasgntkts'] = breachTickets['unas_priority_tkts_11']
     
    assUnassBreachTickets['Total'] = (assUnassBreachTickets['P0_asgn'] + assUnassBreachTickets['P1_asgn'] + assUnassBreachTickets['P2_asgn'] + assUnassBreachTickets['P3_asgn'] + assUnassBreachTickets['P0_unasgn'] + assUnassBreachTickets['P1_unasgn'] + assUnassBreachTickets['P2_unasgn'] + assUnassBreachTickets['P3_unasgn'])   
    jsonData = simplejson.dumps({'assUnassBreachTickets': assUnassBreachTickets})
    return HttpResponse(jsonData, content_type="application/json")
    
def biometricInfo(request):

    username = request.session['uName']
    uId = request.session['uId']   
    biometricInfo = {}
    dataList = comMObj.getNewBiometricStatus(uId)
    html = ''
    notAvailable = 0
    available = 0
    for id in dataList:
        if id['worked_time'] <= 0 and  id['time_diff']  <= 0 :
            html +='<div class="pname">'
            html += '<p class="perName">'
            html += '<span   class ="build_available build_available-danger" ></span>'
            html +=  id['staffname']+'</p>'
            html +='</div>'
            notAvailable +=1 
        else: 
            if id['in_building'] >0 or id['in_building'] == '' :
                staus  = 'build_available build_available-danger'
                notAvailable +=1
            else:
                staus  = 'build_available build_available-success'
                available +=1 
                        
            html +='<div class="pname Tooltip" title="First Punch In: '+str(id["first_punch_in_time"])+'<br>Recent Punch Out: '+str(id["last_punch_out_time"])+'" style="display:block" >'
            html += '<p class="perName">'
            html += '<span  class ="'+str(staus)+'"></span>'
            html +=  str(id['staffname'])+'</p>' 
            html += '<span class="plocation "> '+str(id['current_location'])+'</span>'
            html +='<p class="tworked bioHide" >'
            tmWOrked  =  id['worked_time'] + id['recent_punch_diff'] if (id['worked_time']> 0) else id['time_diff'] 
            html +='Time Worked:<span class="worked_color" ><b>'+str(comObj.getHourMins(tmWOrked))+'</b></span>'
            html +='</p>'
            html += '<p class="bworked bioHide">'
            html += 'Break Time: <span class="worked_color"  ><b>'+str(comObj.getHourMins(id['out_time']))+'</b></span>'
            html += '</p> </div>'
    teamAvailableCount = {}    
    teamAvailableCount['nav'] = notAvailable if notAvailable else 0
    teamAvailableCount['av'] = available if available else 0
    jsonData = simplejson.dumps({'teamAvailableCount': teamAvailableCount,'html':html})
    return HttpResponse(jsonData, content_type="application/json")

def userBiometric(request):
    username = request.session['uName']
    uId = request.session['uId']  
    managerPunchDataIs1 = comMObj.getEmpBiometricPunchTime(uId);
    currentLoc = firstPunch = lastPunch = ''
    for managerPunchDataIs in managerPunchDataIs1:
        currentLoc = managerPunchDataIs['current_location'];
        firstPunch =  managerPunchDataIs['firstpunch'] if  managerPunchDataIs['firstpunch'] else '';
        lastPunch=  managerPunchDataIs['lastpunch'] if  managerPunchDataIs['lastpunch'] else ''; 
    jsonData = simplejson.dumps({'currtLoc': currentLoc,'firstPunch':firstPunch,'lastPunch':lastPunch})
    return HttpResponse(jsonData, content_type="application/json")

def setManagerDetails(request):
    if request.method == 'GET' :
        uId = int(request.GET.get('id'))
        comObj.setSessionValues(request,'',uId)
    return HttpResponseRedirect('/managerDashboard/')

def checkingIsMngr(request):
    if comObj.checkAuthentication(request): 
        username = request.session['uName']
        uId = request.session['uId']
        if not request.session.has_key('isManager'):
            messages.add_message(request, messages.INFO, 'We unable display data for you,because we consider as you are a reportee and not a Manager')
            messages.warning(request, 'please contact us if we were wrong...!')
            messages.warning(request, 'Thank you.')
        else:
            messages.add_message(request, messages.INFO, "We unable display data for you, because we don't have departments mapping for you")
            messages.warning(request, 'please contact us if any concerns...!')
            messages.warning(request, 'Thank you.')
    return render_to_response('checking.html',{'userName':username},context_instance=RequestContext(request))   
    
'''Scheduled task and Scheduled observation tickets'''
def mdSchTaskObsTickets(request):
    mainUrl = configobj.getCommConfigValue(configobj.apiurl)
    staffId = request.session['uId']
    empKayakoDepts = StaffDeptMapping.objects.using('rosterRead').only('kayako_deptid').filter(nrstaffid = staffId)
    empKykDepts = ','.join([str(empKayakoDeptId.kayako_deptid) for empKayakoDeptId in empKayakoDepts])
    empKykDept = "deptId:"+empKykDepts
    empKykDeptsEncoded=urllib.quote_plus(empKykDept)
    url = mainUrl+'scheduledticketinfo?queryString='+str(empKykDeptsEncoded)
    apiResult = comObj.getAPIResponce(url)
    jsonData = simplejson.dumps(apiResult)
    return HttpResponse(jsonData, content_type="application/json")
