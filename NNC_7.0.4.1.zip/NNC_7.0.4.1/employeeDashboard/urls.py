"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.conf.urls import url
import employeeDashboard.views.employeeDashboardView

urlpatterns = [
   url(r'^employeeAjax/$', employeeDashboard.views.employeeDashboardView.getEmployeeAjax),
   url(r'^employeeExpAjax/$', employeeDashboard.views.employeeDashboardView.getEmployeeExpAjax),
   url(r'^getEmpInfo/$', employeeDashboard.views.employeeDashboardView.getEmployeeInfoAjax),
   url(r'^employeeScheduleReports/$', employeeDashboard.views.employeeDashboardView.getEmployeeScheduleReports),
   url(r'^showAppVersion/$', employeeDashboard.views.employeeDashboardView.showAppVersion),
   url(r'^trackUserStatus/$', employeeDashboard.views.employeeDashboardView.TrackLoggedinUsers.as_view()),
   url(r'^schTickets/$', employeeDashboard.views.employeeDashboardView.schTaskObsTickets),
   url(r'^empMapping/$',employeeDashboard.views.employeeDashboardView.employeeStaffMapping),
   url(r'^empMappingSave/$',employeeDashboard.views.employeeDashboardView.savingEmpDept),
   
]

