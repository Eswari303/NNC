"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
import time
import urllib
import urlparse
import datetime as dt
import json as simplejson
from django.template import RequestContext
from django.views.generic import View
from django.http import HttpResponse,HttpResponseRedirect
from django.shortcuts import render_to_response

from NNCPortal.commonModels.CumulativeBiometricInfo  import CumulativeBiometricInfo
from NNCPortal.commonModels.NrStaff import NrStaff
from employeeDashboard.models.commonModel import CommonEmployeeModel
from employeeDashboard.forms import EmpDashboard
from NNCPortal.commonMethods import commonMethods
from NNCPortal.configfile import ConfigManager
from employeeDashboard.models.NrLoggedinUsers import NrLoggedinUsers
from NNCPortal.commonModels.StaffDeptMapping import StaffDeptMapping
from NNCPortal.commonModels.commonModelMethods import CommonModelMethods
from NNCPortal.commonModels.IncidentData import IncidentData
from NNCPortal.commonModels.Swdepartments import Swdepartments
from NNCPortal.commonModels.NrDesignations import NrDesignations

nrdesignations_obj = NrDesignations()
inDataObj = IncidentData()
nrstaff_obj = NrStaff()
staffdeptmap_obj = StaffDeptMapping()
swdept_obj = Swdepartments()
commobj=CommonEmployeeModel()
configobj = ConfigManager()
comObj = commonMethods()

def loademployeesMockup(request):
    if request.method == 'POST':
        print "employee Dashboard"
    else:
        authRes = comObj.checkAuthentication(request)
        if authRes == True:
            form = EmpDashboard()
            if 'uName' in request.session:
                username = request.session['uName']
                userId = request.session['uId']
            res1 = NrStaff.objects.using('rosterRead').filter(id=userId)
            for res in res1:
                desig_id = res.desig_id
                managerid= res.reporting_manager_id
                skypeData= res.skype_id
                expData=res.total_exp
                dateofjoin=res. date_of_join
            res2 = NrStaff.objects.using('rosterRead').filter(id = managerid )
            res3 = CumulativeBiometricInfo.objects.using('rosterRead').filter(staffid=userId)
            res4 = NrDesignations.objects.using('rosterRead').filter(id = desig_id)
            
            neexp=commobj.getNeExpYears(dateofjoin)
            punchData = commobj.getEmpBiometricPunchTime(userId)
            if 'uName' in request.session :
                userName = request.session['uName'].split('@')
                userName = str(userName[0][0:14])+'...'
            else:
                userName = 'TestUser'
            return render_to_response('employeeMockup.html',{'form':form,'userName':userName,'employeeData':res1,'managerData':res2,'DesignationData':res4,'skypeData':skypeData,'expData':expData,'neexp':neexp,'employePunchData':punchData},context_instance=RequestContext(request))        
        else:
            return authRes

def getEmployeeAjax(request):
    skypeId =  request.POST.get('skypeid',False)
    if 'uName' in request.session:
        username = request.session['uName']
        userId = request.session['uId']
    else :
        userId = 87
    if skypeId != '':
        updateResponse=NrStaff.objects.using('rosterWrite').filter(id= userId).update(skype_id=skypeId)
        res="  <font color='green'> Updated successfully </font> "
    else:
        res ="<font color='red'> Please provide valid data </font>"
    return HttpResponse(res, content_type="application/json")
   
def getEmployeeExpAjax(request):
    
    totalExp =  request.POST.get('totalexp',False)
    
    if 'uName' in request.session:
        username = request.session['uName']
        userId = request.session['uId']
    else :
        userId = 87
    
    if totalExp != '':
        NrStaff.objects.using('rosterWrite').filter(id= userId).update(total_exp=totalExp )
        res="  <font color='green'> Updated successfully </font> " 
    else: 
        res ="<font color='red'> Please provide valid data </font>"    
    return HttpResponse(res, content_type="application/json")

def getEmployeeInfoAjax(request):
    if 'uId' in request.session :
        nrStaffId = request.session['uId']    
    else :
        return HttpResponseRedirect('/Login/')
    if request.session['isManager'] == 0 :
        mangId = NrStaff.objects.using('rosterRead').only('reporting_manager_id','swstaff_id').get(id = nrStaffId)
        repMnagId = mangId.reporting_manager_id
        swStaffId = mangId.swstaff_id
    else :
        repMnagId = request.session['uId']
        swStaffId = request.session['swstaffId']
    mangInfo = NrStaff.objects.using('rosterRead').only('swstaff_id','staff_fname','staff_lname').get(id = repMnagId)
    teamIds = NrStaff.objects.using('rosterRead').only('id','swstaff_id','staff_fname','staff_lname').filter(reporting_manager_id = repMnagId).filter(is_active = 1)
    empDepts = staffdeptmap_obj.getDepartments(nrStaffId)
    teamDetails = {}
    teamDetails[str(repMnagId)] = str(mangInfo.staff_fname)+' '+str(mangInfo.staff_lname)
    swstaffIds = []
    swstaffId = ''
    nrstaffId = ''
    nrstaffIds = []
    empDeptList = []
    for teamId in teamIds :
        nrstaffId += str(teamId.id)+','
        teamDetails[str(teamId.id)] = str(teamId.staff_fname)+' '+str(teamId.staff_lname)
        nrstaffIds.append( teamId.id )
        swstaffIds.append( teamId.swstaff_id )
        if teamId.swstaff_id :
            swstaffId += str(teamId.swstaff_id)+','
    swstaffId = swstaffId+str(mangInfo.swstaff_id)
    nrstaffId = nrstaffId+str(repMnagId)
    tidealTick = inDataObj.getIdealTickets1(swstaffId)
    myidealTick = inDataObj.getIdealTickets1(swStaffId)
    swstaffIds.append( mangInfo.swstaff_id )
    nrstaffIds.append(repMnagId)
    desigRes = nrstaff_obj.getEmpDesig(nrstaffId)
    depts = ''
    for empDept in empDepts :
        empDeptList.append( empDept['kayako_deptId'] );
        depts += str(empDept['kayako_deptId'])+','
    ticketInfo = {}
    teamTicketInfo = {}
    weekRes = comObj.getWeekStartAndEndDate()
    stStamp =  str(time.mktime(dt.datetime.strptime(weekRes['startD'],'%Y-%m-%d').timetuple()) )[:-2]
    etStamp = str(time.mktime(dt.datetime.strptime(weekRes['endD'],'%Y-%m-%d').timetuple()) )[:-2]
    teamCloTic = commobj.getClosedTickets(swstaffId,stStamp,etStamp)
    myCloTic = commobj.getClosedTickets(swStaffId,stStamp,etStamp)
    tclosedTick = commobj.getClosedTickets1(swstaffId,stStamp,etStamp)
    myclosedTick = commobj.getClosedTickets1(swStaffId,stStamp,etStamp)
    tTimeWorked = commobj.getTimeworkedBio(nrstaffId,weekRes['startD'],weekRes['endD'])
    teamTicketInfo['tWorkedBio'] = 0
    for workedTime in tTimeWorked :
        if workedTime['workedTime'] :
            teamTicketInfo['tWorkedBio'] += int(workedTime['workedTime'])
    teamTicketInfo['tWorkedBio'] = teamTicketInfo['tWorkedBio']/60
    myTimeWorked = commobj.getTimeworkedBio(nrStaffId,weekRes['startD'],weekRes['endD'])
    if myTimeWorked :
        if myTimeWorked[0]['workedTime'] :
            ticketInfo['myWorkedBio'] = int(myTimeWorked[0]['workedTime'])/60
    tsrTickets = inDataObj.getSdRdticketsDept(','.join(str(e) for e in empDeptList),stStamp,etStamp)
    mysrTickets = inDataObj.getSdRdtickets(swStaffId,stStamp,etStamp)

    mainUrl = configobj.getCommConfigValue(configobj.apiurl)
    url = mainUrl+'ManagerDashboardTeamTktInfo'
    apiParams = {}
    apiParams['deptidList'] = empDeptList#[231]#
    apiParams['stffidList'] = nrstaffIds#[567,87,928]#
    weekRes = str(weekRes['startD'])+'/'+str(weekRes['endD'])
    apiParams['dates'] = [weekRes]#['2015-11-30/2015-12-06']#
    apiRes = comObj.getPostResponce(url,apiParams)

    empInfo = apiRes[str(nrStaffId)]
    activeInTic = {}
    ticketInfo['activep0'] = int(empInfo['active']['P0'])
    activeInTic['activep0'] = str(empInfo['active']['P0tkts'])
    ticketInfo['activep1'] = int(empInfo['active']['P1'])
    activeInTic['activep1'] = str(empInfo['active']['P1tkts'])
    ticketInfo['activep2'] = int(empInfo['active']['P2'])
    activeInTic['activep2'] = str(empInfo['active']['P2tkts'])
    ticketInfo['activep3'] = int(empInfo['active']['P3'])
    activeInTic['activep3'] = str(empInfo['active']['P3tkts'])
    ticketInfo['activeCount'] = int(empInfo['active']['P0'])+int(empInfo['active']['P1'])+int(empInfo['active']['P2'])+int(empInfo['active']['P3'])
    activeInTic['activeCount'] = activeInTic['activep0']+','+activeInTic['activep1']+','+activeInTic['activep2']+','+activeInTic['activep3']
    ticketInfo['inactivep0'] = int(empInfo['inactive']['P0'])
    activeInTic['inactivep0'] = str(empInfo['inactive']['P0tkts'])
    ticketInfo['inactivep1'] = int(empInfo['inactive']['P1'])
    activeInTic['inactivep1'] = str(empInfo['inactive']['P1tkts'])
    ticketInfo['inactivep2'] = int(empInfo['inactive']['P2'])
    activeInTic['inactivep2'] = str(empInfo['inactive']['P2tkts'])
    ticketInfo['inactivep3'] = int(empInfo['inactive']['P3'])
    activeInTic['inactivep3'] = str(empInfo['inactive']['P3tkts'])
    ticketInfo['inactiveCount'] = int(empInfo['inactive']['P0'])+int(empInfo['inactive']['P1'])+int(empInfo['inactive']['P2'])+int(empInfo['inactive']['P3'])
    activeInTic['inactivep0'] = activeInTic['inactivep0']+','+activeInTic['inactivep1']+','+activeInTic['inactivep2']+','+activeInTic['inactivep3']
    if empInfo['overallEmptotl'] :
        ticketInfo['myUtilization'] = int(empInfo['overallEmptotl']['stfutl'])
    ticketInfo['closedCount'] = 0
    for myClo in myCloTic:
        ticketInfo['closed'+str(myClo['priorityid'])] = myClo['count']
        ticketInfo['closedCount'] += int(myClo['count'])
    ticketInfo['idealTikCount'] = 0
    myidealTic = commobj.getIdealTickets(swStaffId)
    for myideal in myidealTic :
        ticketInfo['idel'+str(myideal['priorityid'])] = myideal['count']
        ticketInfo['idealTikCount'] += int(myideal['count']) 

    ticketInfo['timeWorked'] = 0
    ticketInfo['ticketTouch'] = 0
    for key,value in empInfo.iteritems():
        for key,value in value.iteritems():
            if type(value) is dict:
                ticketInfo['timeWorked'] += int(value['timewrkd'])
                ticketInfo['ticketTouch'] += int(value['rplys'])
    teamTicketInfo['tactivep0'] = int(apiRes['activeP0Count'])
    teamTicketInfo['tactivep1'] = int(apiRes['activeP1Count'])
    teamTicketInfo['tactivep2'] = int(apiRes['activeP2Count'])
    teamTicketInfo['tactivep3'] = int(apiRes['activeP3Count'])
    teamTicketInfo['tinactivep0'] = int(apiRes['inActiveP0Count'])
    teamTicketInfo['tinactivep1'] = int(apiRes['inActiveP1Count'])
    teamTicketInfo['tinactivep2'] = int(apiRes['inActiveP2Count'])
    teamTicketInfo['tinactivep3'] = int(apiRes['inActiveP3Count'])
    teamTicketInfo['tactiveCount'] = int(apiRes['activeP0Count'])+int(apiRes['activeP1Count'])+int(apiRes['activeP2Count'])+int(apiRes['activeP3Count'])
    teamTicketInfo['tinactiveCount'] = int(apiRes['inActiveP0Count'])+int(apiRes['inActiveP1Count'])+int(apiRes['inActiveP2Count'])+int(apiRes['inActiveP3Count'])
    teamTicketInfo['tclosedCount'] = 0
    for teamClo in teamCloTic:
        teamTicketInfo['tclosed'+str(teamClo['priorityid'])] = teamClo['count']
        teamTicketInfo['tclosedCount'] += int(teamClo['count'])
    teamIdealTic = commobj.getIdealTickets(swstaffId)
    teamTicketInfo['tidelCount'] = 0
    for teamIdel in teamIdealTic:
        teamTicketInfo['tidel'+str(teamIdel['priorityid'])] = teamIdel['count']
        teamTicketInfo['tidelCount'] += int(teamIdel['count'])
    teamTicketInfo['ttimeWorked'] = 0
    teamTicketInfo['tticketTouch'] = 0
    teamTicketInfo['tutilization'] = 0
    teamTicketInfo['teamCount'] = len(desigRes)
    teamDet = {}
    teamActiveInTic = {'tactivep0' : '','tactivep1' : '','tactivep2' : '','tactivep3' : '','tinactivep0' : '','tinactivep1' : '','tinactivep2' : '','tinactivep3' : ''}
    for key,value in apiRes.iteritems():
        if type(value) is dict :
            if key.encode('UTF8') in teamDetails.keys():
                if value['overallEmptotl']:
                    if value['overallEmptotl']['stfutl']:
                        teamTicketInfo['tutilization'] += int(value['overallEmptotl']['stfutl'])
                if value['active'] and value['inactive']:
                    teamActiveInTic[str(key)] = ''
                    teamDet[str(key)] = int(value['active']['P0'])+int(value['active']['P1'])+int(value['active']['P2'])+int(value['active']['P3'])+int(value['inactive']['P0'])+int(value['inactive']['P1'])+int(value['inactive']['P2'])+int(value['inactive']['P3'])
                    if value['active']['P0tkts'] :
                        teamActiveInTic['tactivep0'] = teamActiveInTic['tactivep0']+value['active']['P0tkts']+','
                        teamActiveInTic[str(key)] = teamActiveInTic[str(key)]+value['active']['P0tkts']+','
                    if value['active']['P1tkts'] :
                        teamActiveInTic['tactivep1'] = teamActiveInTic['tactivep1']+value['active']['P1tkts']+','
                        teamActiveInTic[str(key)] = teamActiveInTic[str(key)]+value['active']['P1tkts']+','
                    if value['active']['P2tkts'] :
                        teamActiveInTic['tactivep2'] = teamActiveInTic['tactivep2']+value['active']['P2tkts']+','
                        teamActiveInTic[str(key)] = teamActiveInTic[str(key)]+value['active']['P2tkts']+','
                    if value['active']['P3tkts'] :
                        teamActiveInTic['tactivep3'] = teamActiveInTic['tactivep3']+value['active']['P3tkts']+','
                        teamActiveInTic[str(key)] = teamActiveInTic[str(key)]+value['active']['P3tkts']+','
                    if value['inactive']['P0tkts'] :
                        teamActiveInTic['tinactivep0'] = teamActiveInTic['tinactivep0']+value['inactive']['P0tkts']+','
                        teamActiveInTic[str(key)] = teamActiveInTic[str(key)]+value['inactive']['P0tkts']+','
                    if value['inactive']['P1tkts'] :
                        teamActiveInTic['tinactivep1'] = teamActiveInTic['tinactivep1']+value['inactive']['P1tkts']+','
                        teamActiveInTic[str(key)] = teamActiveInTic[str(key)]+value['inactive']['P1tkts']+','
                    if value['inactive']['P2tkts'] :
                        teamActiveInTic['tinactivep2'] = teamActiveInTic['tinactivep2']+value['inactive']['P2tkts']+','
                        teamActiveInTic[str(key)] = teamActiveInTic[str(key)]+value['inactive']['P2tkts']+','
                    if value['inactive']['P3tkts'] :
                        teamActiveInTic['tinactivep3'] = teamActiveInTic['tinactivep3']+value['inactive']['P3tkts']+','
                        teamActiveInTic[str(key)] = teamActiveInTic[str(key)]+value['inactive']['P3tkts']+','
    
            for key,value in value.iteritems():
                if type(value) is dict :
                    for key,value in value.iteritems():
                        if type(value) is dict:
                            teamTicketInfo['ttimeWorked'] += int(value['timewrkd'])
                            teamTicketInfo['tticketTouch'] += int(value['rplys'])

    jsonData = simplejson.dumps({'ticketInfo': ticketInfo,'teamDetails':teamDet,'teamActiveInTic':teamActiveInTic,'activeInTic':activeInTic,'teamTicketInfo':teamTicketInfo,'desigRes':desigRes,'tsrTickets':tsrTickets,'mysrTickets':mysrTickets,'teamidleT':tidealTick,'myidleT':myidealTick,'tclosedT':tclosedTick,'myclosedT':myclosedTick})
    return HttpResponse(jsonData, content_type="application/json")

def getEmployeeScheduleReports(request):
    templateRes = {}
    if 'uId' in request.session :
        userId = request.session['uId']
    else :
        userId = 903
    res1 = NrStaff.objects.using('rosterRead').only('staff_email').get(id=userId)
    empEmail = res1.staff_email
    scheduledData = commobj.ScheduledJobActivities()
    i = 1
    for scheduleData in scheduledData:
        if empEmail in str(scheduleData['emailIds']):
            templateRes[i] = scheduleData['TempName']
        i = i + 1      
            
    jsonData = simplejson.dumps(templateRes)
    return HttpResponse(jsonData, content_type="application/json")
def showAppVersion(request):
    release = comObj.getCurrentVersion()
    jsonData = simplejson.dumps(release)
    return HttpResponse(jsonData, content_type="application/json")

'''Scheduled task and Scheduled observation tickets'''
def schTaskObsTickets(request):
    mainUrl = configobj.getCommConfigValue(configobj.apiurl)
    staffId = request.session['uId']
    empKayakoDepts = StaffDeptMapping.objects.using('rosterRead').only('kayako_deptid').filter(nrstaffid = staffId)
    empKykDepts = ','.join([str(empKayakoDeptId.kayako_deptid) for empKayakoDeptId in empKayakoDepts])
    empKykDept = "deptId:"+empKykDepts
    empKykDeptsEncoded=urllib.quote_plus(empKykDept)
    url = mainUrl+'scheduledticketinfo?queryString='+str(empKykDeptsEncoded)
    apiResult = comObj.getAPIResponce(url)
    jsonData = simplejson.dumps(apiResult)
    return HttpResponse(jsonData, content_type="application/json")

class TrackLoggedinUsers(View):
    def post(self, request):
        now = dt.datetime.now()
        user_id = request.session['swstaffId']
        unix_time = commobj.datetimetounix(now)
        try:

            staff_obj = NrLoggedinUsers.objects.using("rosterWrite").filter(staff_id=user_id).last()
            if staff_obj.online_status is True:
                staff_obj.last_active_time = unix_time
                staff_obj.online_status = True
                staff_obj.save()
            else:
                user_obj = NrLoggedinUsers.objects.using('rosterWrite').create(staff_id=int(user_id),
                                                                               ip_address=request.META['REMOTE_ADDR'],
                                                                               last_active_time=unix_time,
                                                                               login_time=unix_time,
                                                                               online_status=True)
                user_obj.save()
            commobj.checkuserstatus()
            return HttpResponse("success")
        except Exception as e:
            print e
            print e.message
            user_obj = NrLoggedinUsers.objects.using('rosterWrite').create(staff_id=int(user_id),
                                                                          ip_address=request.META['REMOTE_ADDR'],
                                                                          last_active_time=unix_time,
                                                                          login_time=unix_time,
                                                                          online_status=True)
            user_obj.save()
            return HttpResponse("success")


def employeeStaffMapping(request):
    emp_id =  request.session['uId']
    data = {}
    if emp_id:
        departmentList =  swdept_obj.getDepartmentsList()
        staffList = staffdeptmap_obj.employeeKayakoDept(emp_id)
        departmentList.pop(1)
        staffDeptsList = {}
        for deptId in staffList:
            if deptId['kayako_deptId'] in departmentList:
                staffDeptsList[deptId['kayako_deptId']] = departmentList[deptId['kayako_deptId']] 
                departmentList.pop(deptId['kayako_deptId'])
        data = {'depts':departmentList,
            'staff':staffDeptsList,
            }
    
    return render_to_response('staffDeptMaping.html',{'data':data,'emp_id':emp_id},context_instance=RequestContext(request))


def savingEmpDept(request):
    post = request.POST
    validation = 'fail'
    dept =  urlparse.parse_qs(post['deptIds']) 
    if len(dept['dept[]']) > 0:
        delete_staffList = staffdeptmap_obj.deletingRecordOfstaff(post['nrstaffid'])
        employeeDetails = nrstaff_obj.employeeDetails(post['nrstaffid'])
        if len(employeeDetails):
            managerid = employeeDetails[0]['reporting_manager_id']
            swstaff_id = employeeDetails[0]['swstaff_id']
            id = employeeDetails[0]['id']
            for i in dept['dept[]']:
                commMM = CommonModelMethods()
                saveSatffDetails = {}
                saveSatffDetails['managerid'] = str(managerid)
                saveSatffDetails['nrstaffid'] = str(id)
                saveSatffDetails['swstaffid'] = str(swstaff_id)
                saveSatffDetails['kayako_deptId'] =str(i)
                data= commMM.insertRecord(saveSatffDetails, 'staff_dept_mapping', 'rosterWrite')
                request.session['empDeptMap'] = 1
            validation  = "success"
            
            
    jsonData = simplejson.dumps(validation)
    return HttpResponse(jsonData, content_type="application/json")

                
