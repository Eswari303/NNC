"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import connection,connections
from NNCPortal.commonModels.NrStaff import NrStaff
from employeeDashboard.models.NrLoggedinUsers import NrLoggedinUsers
from NNCPortal.commonMethods import commonMethods
from datetime import date, datetime, time
import time
comObj = commonMethods()


class CommonEmployeeModel(object):
    
    def getEmpBiometricPunchTime(self,staffId):  
        sql = "select DATE_FORMAT(CONVERT_TZ(first_punch_in_time,'+00:00','+05:30'),'%H:%i') AS firstpunch ,DATE_FORMAT(CONVERT_TZ(punch_update_in_time,'+00:00','+05:30'),'%H:%i') AS recentpunchin,DATE_FORMAT(CONVERT_TZ(last_punch_out_time,'+00:00','+05:30'),'%H:%i') AS lastpunch,current_location from cumulative_biometric_info where first_punch_in_time >= CURDATE()  and staffid="+str(staffId)
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        punchTime = comObj.dictfetchall(cursor)
        cursor.close()
        return punchTime
    
    def getNeExpYears(self,dateofjoin):
        toDate =str(datetime.now().date())
        
        sql = "SELECT CONCAT(TIMESTAMPDIFF( YEAR, '"+str(dateofjoin)+"', '"+str(toDate)+"'),'.',TIMESTAMPDIFF(MONTH, '"+str(dateofjoin)+"'+ INTERVAL TIMESTAMPDIFF(YEAR, '"+str(dateofjoin)+"', '"+str(toDate)+"') YEAR, '"+str(toDate)+"') ) AS exp_in_netenrich"; 
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        return res
    def getIdealTickets1(self,swtaffIds):
        sql = "select ticketid ,statusid,staffid,priorityid from incident_data where staffid in("+str(swtaffIds)+") and  priorityid in (8,9,10,11) and statusid not in (20,3,17,5,41,32) and lastactivity <= unix_timestamp(NOW() - INTERVAL 2 DAY) and deptid not in (0,1,2)"
        cursorIdealTick = connections['ticketRead'].cursor()
        cursorIdealTick.execute(sql)
        result = comObj.dictfetchall(cursorIdealTick)
        cursorIdealTick.close()
        return result
    def getClosedTickets1(self,swstaffIds,sdate,edate):
        tikcur = connections['ticketRead'].cursor()
        sql = 'select group_concat(ticketstatusid) as closed_statuses from swticketstatus where statustype=3 order by title'
        tikcur.execute(sql)
        status = comObj.dictfetchall(tikcur)
        sql = 'select priorityid, ticketid  from incident_data where staffid in ('+str(swstaffIds)+') and  priorityid in (8,9,10,11) and statusid in ('+status[0]['closed_statuses']+') and created_dt >= '+str(sdate)+' and created_dt <= '+str(edate)+' and deptid not in (0,1,2)'
        tikcur.execute(sql)
        res = comObj.dictfetchall(tikcur)
        tikcur.close()
        return res

    def getIdealTickets(self,swstaffIds):
        sql = 'select group_concat(ticketstatusid) as closed_statuses from swticketstatus where statustype=3 order by title'
        tikcur = connections['ticketRead'].cursor()
        tikcur.execute(sql)
        status = comObj.dictfetchall(tikcur)
        sql = 'select priorityid, count(ticketid) as count from incident_data where staffid in ('+str(swstaffIds)+') and  priorityid in (8,9,10,11) and statusid not in ('+status[0]['closed_statuses']+') and lastactivity <= unix_timestamp(now( ) - INTERVAL 2 DAY) and deptid not in (0,1,2) group by priorityid'
        tikcur.execute(sql)
        res = comObj.dictfetchall(tikcur)
        tikcur.close()
        return res
    def getClosedTickets(self,swstaffIds,sdate,edate):
        tikcur = connections['ticketRead'].cursor()
        sql = 'select group_concat(ticketstatusid) as closed_statuses from swticketstatus where statustype=3 order by title'
        tikcur.execute(sql)
        status = comObj.dictfetchall(tikcur)
        sql = 'select priorityid, count(ticketid) as count from incident_data where staffid in ('+str(swstaffIds)+') and  priorityid in (8,9,10,11) and statusid in ('+status[0]['closed_statuses']+') and created_dt >= '+str(sdate)+' and created_dt <= '+str(edate)+' and deptid not in (0,1,2) group by priorityid'
        tikcur.execute(sql)
        res = comObj.dictfetchall(tikcur)
        tikcur.close()
        return res
    def getTimeworkedBio(self,nrstaffIds,sdate,edate):
        sql = 'select sum(worked_time) as workedTime,staffid from cumulative_biometric_info where staffid in ('+str(nrstaffIds)+') and first_punch_in_time >= "'+str(sdate)+'" and first_punch_in_time <= "'+str(edate)+'" group by staffid'
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        return res
    def getSdRdtickets(self,staffInfo,stStamp,etStamp):
        sql = 'SELECT ic.priorityid,ic.ticketid,ic.statusid as sid,getntsstatussladue(ic.ticketid,ic.statusid) as sladue FROM  incident_data ic WHERE ic.staffid IN ('+str(staffInfo)+') AND (ic.statusid = 16 OR ic.statusid = 19) AND ((ic.created_dt >= '+str(stStamp)+' AND ic.created_dt <= '+str(etStamp)+') OR (ic.lastactivity >= '+str(stStamp)+' AND ic.lastactivity <= '+str(etStamp)+'))'
        tikcur = connections['ticketRead'].cursor()
        tikcur.execute(sql)
        res = comObj.dictfetchall(tikcur)
        tikcur.close()
        return res
    def getSdRdticketsDept(self,deptInfo,stStamp,etStamp):
        sql = 'SELECT ic.priorityid,ic.ticketid,ic.statusid as sid,getntsstatussladue(ic.ticketid,ic.statusid) as sladue FROM  incident_data ic WHERE ic.deptid IN ('+str(deptInfo)+') AND (ic.statusid = 16 OR ic.statusid = 19) AND ((ic.created_dt >= '+str(stStamp)+' AND ic.created_dt <= '+str(etStamp)+') OR (ic.lastactivity >= '+str(stStamp)+' AND ic.lastactivity <= '+str(etStamp)+'))'
        tikcur = connections['ticketRead'].cursor()
        tikcur.execute(sql)
        res = comObj.dictfetchall(tikcur)
        tikcur.close()
        return res
    def getDepartments(self,nrstaffid):
        sql = "select kayako_deptId from staff_dept_mapping where nrstaffid = "+str(nrstaffid)
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        return res
    def getEmpDesig(self,nrstaffids):
        sql = 'select nr.id,nd.desig_name,concat(staff_fname," ",staff_lname) as empname from nr_staff nr join nr_designations nd on nd.id = nr.desig_id and nr.id in ('+str(nrstaffids)+') order by empname'
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        return res

    def ScheduledJobActivities(self):
        sql = "SELECT JobId, templates.templatename as TempName, emailIds  FROM nnc_job_queue queue join ticketbrowser_templates  templates on (templates.templateid = queue.templateId) WHERE queue.reportType IN ('TB', 'R', 'QM')  UNION SELECT JobId, templates.templatename as TempName, emailIds  FROM nnc_sch_jobs AS nsj join ticketbrowser_templates  templates on (templates.templateid = nsj.templateId) WHERE nsj.reportType IN ('TB', 'R', 'QM') AND nsj.scheduleType = 'RunNow' ";
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        return res

    def dictfetchall(self,cursor): 
            "Returns all rows from a cursor as a dict" 
            desc = cursor.description 
            return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]

    def datetimetounix(self, date_time):
        unixtimestamp = time.mktime(date_time.timetuple())
        return unixtimestamp

    def checkuserstatus(self):
        users_date = NrLoggedinUsers.objects.using('rosterWrite').all()
        current_datetime = datetime.now()
        for user in users_date:
            last_active_time = datetime.fromtimestamp(user.last_active_time).strftime('%Y-%m-%d %H:%M:%S')
            last_active_time = datetime.strptime(last_active_time, "%Y-%m-%d %H:%M:%S")
            elapsedTime = current_datetime - last_active_time
            time_list = divmod(elapsedTime.total_seconds(), 60)
            if time_list[0] > 1:
                user.online_status = False
                user.save()
        return True
    
    """  Get depatments """
    
    def getDepartmentsList(self,departments =None):
        depts ={}
        if departments != None:
            sql = "SELECT departmentid,title FROM swdepartments WHERE departmentid IN("+str(departments)+") ORDER BY title";
        else:
            sql = "SELECT departmentid,title FROM swdepartments  ORDER BY title";
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        if result :
           for i in result:
               depts[i['departmentid']] = i['title']
        return depts 
    
    
    def employeeKayakoDept(self,id):
        sql =  "select  DISTINCT kayako_deptId from  staff_dept_mapping where  nrstaffid ="+str(id);
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    def employeeKayakoDeptStaging(self,id):
        sql =  "select  DISTINCT kayako_deptId from  staff_dept_mapping where  nrstaffid ="+str(id);
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    def deletingRecordOfstaff(self,id):
        sql = "delete from staff_dept_mapping where nrstaffid ="+str(id)
        cursor = connections['rosterWrite'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    def employeeDetails(self,id):
        sql = "SELECT reporting_manager_id,swstaff_id,id FROM nr_staff WHERE id ="+str(id)+" and  reporting_manager_id > 0 AND swstaff_id > 0 AND is_active = 1 AND is_found = 1 "
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    def staffDeptMappingStatus(self,id):
        sql = "select count(*) as count from staff_dept_mapping where nrstaffid ="+str(id)
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result[0]['count']

    