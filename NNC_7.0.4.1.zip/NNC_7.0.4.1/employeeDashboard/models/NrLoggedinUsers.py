"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """

# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from __future__ import unicode_literals

from django.db import models

class NrLoggedinUsers(models.Model):
    staff_id = models.IntegerField(blank=True, null=True)
    ip_address = models.CharField(max_length=15, blank=True, null=True)
    last_active_time = models.IntegerField(blank=True, null=True)
    login_time = models.IntegerField(blank=True, null=True)
    online_status = models.BooleanField(default=True)

    class Meta:
        managed = False
        db_table = 'nr_loggedin_users'








