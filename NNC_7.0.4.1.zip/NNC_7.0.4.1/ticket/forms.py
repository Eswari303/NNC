from django import forms

class Ticket(forms.Form):
    ticketId = forms.CharField(max_length=100)