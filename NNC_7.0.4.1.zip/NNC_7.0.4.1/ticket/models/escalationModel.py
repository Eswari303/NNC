"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """

from django.db import connection,connections


from NNCPortal.commonMethods import commonMethods
comObj = commonMethods()
#sql queries related to escalation matrix
class escalationModel(object):

    #get escalation id's device level
    def getEscalationDeviceLevel(self,deviceId):
        sql = """SELECT distinct(escalation_indices_id) AS escalationId FROM nts_escalation_mappings WHERE escalatable_element_class IN('DEVICE','UCSHOST','CLOUDINSTANCE','HYPERVISOR','VIRTUVALMACHINE'
                ,'STORAGEDEVICE','MOBILEDEVICEDO','HYPERVHOST','BLADESERVER','XENSERVERHOST','VCENTER','VMWAREHOST') AND escalatable_element_id ="""+str(deviceId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #get device group id's based on device id
    def getDevGrpIds(self,deviceId):
        sql = 'select groupid from ntsdevice_group_mappings where deviceid ='+str(deviceId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #get escalation id's device group level
    def getEscalationDeviceGrpLevel(self,devGrpId):
        sql = 'SELECT distinct(escalation_indices_id) AS escalationId FROM nts_escalation_mappings escmap WHERE escalatable_element_class = "DEVICE_GROUP" AND escalatable_element_id = '+str(devGrpId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    def getDevLocIds(self,deviceId):
        sql = 'select locationid from ntsdevice_location_mappings where deviceid = '+str(deviceId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #get escalation id's device location level
    def getEscalationDeviceLocLevel(self,locId):
        sql = "SELECT distinct(escalation_indices_id) AS escalationId FROM nts_escalation_mappings escmap WHERE escalatable_element_class ='LOCATION' AND escalatable_element_id = "+str(locId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #get escalation id's client level
    def getEscalationClientLevel(self,clientId):
        sql = "SELECT distinct(escalation_indices_id) AS escalationId FROM nts_escalation_mappings escmap WHERE escalatable_element_class ='CLIENT' AND escalatable_element_id = "+str(clientId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #get escalation id's msp level
    def getEscalationMspLevel(self,mspId):
        sql = "SELECT  distinct(id) AS escalationId FROM nts_escalation_indices  WHERE msp_id ="+str(mspId)+" and all_clients=1";
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #Query for DateRange Shifts 
    def getDateRangeShifts(self,eId):
        sql = """SELECT DISTINCT(esd.id) AS shiftId,es.id AS scheduleId FROM nts_escalation_matrix esm 
                INNER JOIN nts_escalation_schedule es ON(es.id = esm.escalation_schedule_id AND esm. escalation_indices_id =  """+str(eId)+""") 
                INNER JOIN nts_escalation_shift_details esd ON (esd.escalation_schedule_id = es.id)
                INNER JOIN nts_escalation_shift_type_daterange estd ON(esd.escalation_shift_type_datarange_id =estd.id)
                INNER JOIN nts_cfg_timezones cfgtz ON (cfgtz.id=es.timezone_id)  WHERE (estd.start_datetime <= CONVERT_TZ(NOW(),\"UTC\",cfgtz.name) AND estd.end_datetime >= CONVERT_TZ(NOW(),\"UTC\",cfgtz.name))
        """
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #Query for Weekdays Shifts
    def getWeekDaysShifts(self,eId):
        sql = """SELECT DISTINCT(esd.id) AS shiftId,es.id AS scheduleId FROM nts_escalation_matrix esm 
                INNER JOIN nts_escalation_schedule es ON(es.id = esm.escalation_schedule_id AND esm. escalation_indices_id = """+str(eId)+""")
                INNER JOIN nts_escalation_shift_details esd ON (esd.escalation_schedule_id = es.id) 
                INNER JOIN nts_escalation_shift_type_weekdays estw ON(esd.escalation_shift_type_weekday_id =estw.id) 
                INNER JOIN nts_cfg_timezones cfgtz ON (cfgtz.id=es.timezone_id)  WHERE (estw.start_time <= DATE_FORMAT(CONVERT_TZ(NOW(),'UTC',cfgtz.name),'%H:%i:%s') 
                AND estw.end_time >= DATE_FORMAT(CONVERT_TZ(NOW(),'UTC',cfgtz.name),'%H:%i:%s'))  order by es.id ASC
        """
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #escalataion time zone details
    def getTimeZoneDetails(self,eId):
        sql = "select nei.name,nei.description,nct.name as tz_name,nct.label as tz_label from nts_escalation_indices nei,nts_cfg_timezones nct where nei.timezone_id=nct.id and nei.id = "+str(eId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #escalation schedule id's
    def getScheduleIds(self,eId):
        sql = "SELECT es.id AS scheduleId FROM nts_escalation_matrix esm INNER JOIN nts_escalation_schedule es ON(es.id = esm.escalation_schedule_id ) AND esm. escalation_indices_id = "+str(eId)+" order by priority ASC"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #escalation schedule information
    def getScheduleInfo(self,sId):
        sql = "select es.name as name,esm.repeat_count as repeat_count,esm.repeat_freq as repeat_freq from nts_escalation_schedule es left join nts_escalation_matrix esm on (esm.escalation_schedule_id = es.id) where es.id ="+str(sId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #escalation schedule shift count
    def getSchCount(self,sId):
        sql = "select count(*) as count from nts_escalation_shift_details where escalation_schedule_id ="+str(sId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #escalation shift details
    def getShiftDetails(self,sId):
        sql = "select name,escalation_shift_type_weekday_id,escalation_shift_type_datarange_id,id,shift_type from nts_escalation_shift_details where escalation_schedule_id ="+str(sId)+" order by id"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #escalation shift details based on shift type
    def getShiftTypeDetails(self,tId):
        sql = "select sun_flag,mon_flag,tue_flag,wed_flag,thu_flag,fri_flag,sat_flag,start_time,end_time from nts_escalation_shift_type_weekdays where id = "+str(tId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #escalation shift details when shift type 2
    def getShiftTypeDetails2(self,tId):
        sql = "select start_datetime,end_datetime from nts_escalation_shift_type_daterange where id = "+str(tId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #escalation shift users
    def getShiftUsers(self,sId):
        sql = "select ntscon.first_name,ntscon.last_name,ntscon.email,ntscon.mobile_number,ntscon.phone_number,ntscon.time_zone from  nts_escalation_shift_users esu left join ntscontactmappings ntscon on (ntscon.id = esu.user_id) where escalation_shift_details_id = "+str(sId)+" order by esu.id asc"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    #validating esclation id
    def validateEscid(self,Id):
        sql ='select count(*) as count from nts_escalation_indices where id='+str(Id)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        if result[0]['count'] > 0:
            return True
        else:
            return False