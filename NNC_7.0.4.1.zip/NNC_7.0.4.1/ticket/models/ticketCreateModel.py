"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """

from django.db import connections    
from NNCPortal.commonMethods import commonMethods
comObj = commonMethods() 
from django.core.cache import caches
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
mem_cache = caches['memcached']
import json,os
env = configobj.getCommConfigValue(configobj.app_env)
                                                                                                                                                         
class ticketCreateModel(object):

        def getResolutionNotesFields(self):
            sql = 'select title,description,isrequired from swcustomfields where customfieldgroupid=31 order by displayorder'
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            customfields = cursor.fetchall()
            cursor.close()
            
            sql = 'select customfieldoptionid,optionvalue,isselected from swcustomfieldoptions where customfieldid=181 order by displayorder'
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            cfoptions = cursor.fetchall()
            cursor.close()
            
            sql = 'select customfieldoptionid,optionvalue,isselected from swcustomfieldoptions where customfieldid=191 order by displayorder'
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            cfoptions1 = cursor.fetchall()
            cursor.close()

            return {'customfields':customfields,'cfoptions':cfoptions,'cfoptions1':cfoptions1,'isrequired':{0:'',1:'*'},'ischecked':{0:'',1:'checked="true"'}}
    
        def getCustomFieldGroups(self):
            sql = "SELECT customfieldgroupid, title FROM swcustomfieldgroups ORDER BY displayorder"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql);
            result = comObj.dictfetchall(cursor)
            cursor.close()
            return result
        def GetstaffDetails(self):
            
            sql = "SELECT staffid, fullname FROM `swstaff` `t` WHERE staffgroupid != 41 ORDER BY fullname"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            staffSet = {}
            for i in result:
                staffSet[i['staffid']] = i['fullname']
            
            return staffSet
        
        def getClients(self):
            clientNames = mem_cache.get('client_data'+env)
            if not clientNames:
                sql ="select mspclientid, clientname from ntsmspclients where status =1 order by clientname "
                cursor = connections['ticketRead'].cursor()
                cursor.execute(sql)
                result = comObj.dictfetchall(cursor)
                cursor.close()
                clientNames = {}
                for i in result:
                    clientNames[i['mspclientid']] = i['clientname']
                mem_cache.set('client_data'+env, clientNames, 86400)
            return clientNames

        def getDeviceByClient(self,clientId):
            sql = "select id, device_name from ntsmspdevicedata where (state IS NULL OR  state IN('','active','deleted-active')) AND client_id IN ("+str(clientId)+") order by device_name"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            devicesNames = {}
            for i in result:
                devicesNames[i['id']] = str(i['device_name'].encode('utf-8'))
            return devicesNames
        
        def getDeviceCatagorie(self):
            deviceCatagorie = mem_cache.get('deviceCatagories'+env)
            if not deviceCatagorie:
                sql = "select devicecatid, devicecatname from ntsdevicecategories   order by devicecatname "
                cursor = connections['ticketRead'].cursor()
                cursor.execute(sql)
                result = comObj.dictfetchall(cursor)
                cursor.close()
                deviceCatagorie = {} 
                for i in result:
                    deviceCatagorie[i['devicecatid']] = str(i['devicecatname'])
                mem_cache.set('deviceCatagories'+env, deviceCatagorie, 86400)
            return deviceCatagorie
        
        def getClientTechnology(self,clientId):
            sql = "SELECT technology  FROM ntstechnologies where clientid ="+str(clientId)
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            if result:
                return result[0]
            else:
                return result
        
        def getSlaResloutions(self,ticketId):
            sql = " select ticketid ,resol_sla as resolslatime, resp_sla as respslatime, resol_due as resolsladue , resp_sec as respsladue, statusid , priorityid , deptid, staffid , cv.fieldvalue  as scheduleTime, automation_flag as af from incident_data as id LEFT JOIN swcustomfieldvalues cv on id.ticketid=cv.typeid and cv.customfieldid=12 where id.ticketId="+str(ticketId)
            cursor = connections['ticketWrite'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            return result 
        
        
        def getTicketSlaResponce(self,ticketId):
            sql ="SELECT  resol_sla,resp_sla from  incident_data  where ticketId="+str(ticketId)
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            return result[0]
        
        def getPriortyAndStaus(self,ticketId):
            sql ="select  statusid , priorityid from incident_data as id where ticketId="+str(ticketId)
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            return result 
        
        def getNotes(self,clientid):
            cursor = connections['ticketRead'].cursor()
            sql = "select device_name,subject,description,CONVERT_TZ(created_time,'UTC','America/Los_Angeles') as created_time,last_updated_time,first_name,last_name,CONVERT_TZ(expiry_date,'UTC','America/Los_Angeles') as expiry_date from ntsnotes where client_id = '"+str(clientid)+"' and (expiry_date ='' or (expiry_date !='' and CONVERT_TZ(expiry_date,'UTC','America/Los_Angeles') >=now()))";
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            
            return result
        
        def getAttachementInfo(self,attId):
            cursor = connections['ticketRead'].cursor()
            sql = "select contents from swattachmentchunks where attachmentid = "+str(attId)
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            return result
        
        def getEscalationMatrixDetails(self,mspId,clientId,deviceid):
            weekdaysArr = ('sun','mon','tue','wed','thu','fri','sat');
            NewEscidslist = {}
            if deviceid and deviceid !='':
                cursor = connections['ticketRead'].cursor()
                sql = "SELECT distinct(escalation_indices_id) AS escalationId FROM nts_escalation_mappings WHERE escalatable_element_class IN('DEVICE','UCSHOST','CLOUDINSTANCE','HYPERVISOR','VIRTUVALMACHINE','STORAGEDEVICE','MOBILEDEVICEDO','HYPERVHOST',"
                sql += "'BLADESERVER','XENSERVERHOST','VCENTER','VMWAREHOST') AND escalatable_element_id ="+str(deviceid)
                cursor.execute(sql)
                devicesresult = comObj.dictfetchall(cursor)
                cursor.close()
                if len(devicesresult)>0:
                    i=0
                    NewEscidslist['device'] = {}
                    for device in  devicesresult:
                        NewEscidslist['device'].setdefault(i,{})
                        NewEscidslist['device'][i].setdefault('id',device['escalationId'])
                        i = i+1
                
                # Getting Device group id for device */
                devgrpQuery = "select groupid from ntsdevice_group_mappings where deviceid ="+str(deviceid)
                cursor1 = connections['ticketRead'].cursor()
                cursor1.execute(devgrpQuery)
                devgresult =comObj.dictfetchall(cursor1)
                cursor1.close()
                devicegrpids = []
                for jj in devgresult:
                    for groupid,value  in jj.iteritems():
                        devicegrpids.append(value)
                for data  in  devicegrpids:
                    if data:
                        nQuery = "SELECT distinct(escalation_indices_id) AS escalationId FROM nts_escalation_mappings escmap WHERE escalatable_element_class ='DEVICE_GROUP'"
                        nQuery += "AND escalatable_element_id = "+str(data)             
                        cursor = connections['ticketRead'].cursor()
                        cursor.execute(nQuery)
                        devgrpEscaltions =comObj.dictfetchall(cursor)
                        cursor.close()
                        j=0
                        NewEscidslist.setdefault('devicegroup',{})
                        for devicegEscalation  in  devgrpEscaltions:
                            NewEscidslist['devicegroup'].setdefault(j,{})
                            NewEscidslist['devicegroup'][j].setdefault('id',devicegEscalation['escalationId'])
                            j = j+1
                #Getting Location id for device id 
                locaQuery = "select locationid from ntsdevice_location_mappings where deviceid ="+str(deviceid)
                cursor2 = connections['ticketRead'].cursor()
                cursor2.execute(locaQuery)
                locationresult =comObj.dictfetchall(cursor2)
                cursor2.close()
                if len(locationresult) >0:
                        locationid = locationresult[0]["locationid"]
                else:locationid  =''
                if locationid and locationid != '':
                    locnameQuery = "select name from ntslocation where id ="+str(deviceid)
                    cursor3 = connections['ticketRead'].cursor()
                    cursor3.execute(locnameQuery)
                    locationNameres =comObj.dictfetchall(cursor3)
                    cursor3.close()
                    if len(locationNameres) >0:
                        locationName = locationNameres[0]["name"]
                    else:
                        locationName =''
                    nQuery = "SELECT distinct(escalation_indices_id) AS escalationId FROM nts_escalation_mappings escmap WHERE escalatable_element_class ='LOCATION'"
                    nQuery += " AND escalatable_element_id = "+str(locationid)
                    cursor4 = connections['ticketRead'].cursor()
                    cursor4.execute(nQuery)
                    locationEscRes =comObj.dictfetchall(cursor4)
                    cursor4.close()
                    k=0
                    NewEscidslist['Location'] = {}
                    for locationEsc in locationEscRes:
                       NewEscidslist['Location'].setdefault(k,{}) 
                       NewEscidslist['Location'][k].setdefault('id',locationEsc["escalationId"])
                       k=k+1
                
            if clientId and clientId !='':
                nQuery = "SELECT distinct(escalation_indices_id) AS escalationId FROM nts_escalation_mappings escmap WHERE escalatable_element_class ='CLIENT' "
                nQuery += "AND escalatable_element_id = "+str(clientId)
                cursor = connections['ticketRead'].cursor()
                cursor.execute(nQuery)
                clientEscRes =comObj.dictfetchall(cursor)
                cursor.close()
                NewEscidslist['client'] = {}
                l=0
                for clientEsc in clientEscRes:
                    NewEscidslist['client'].setdefault(l,{})
                    NewEscidslist['client'][l].setdefault('id',clientEsc["escalationId"])
                    l = l+1
                
            if mspId and mspId !='':
                nQuery = "SELECT  distinct(id) AS escalationId FROM nts_escalation_indices  WHERE msp_id ="+str(mspId)+" and all_clients=1";
                cursor = connections['ticketRead'].cursor()
                cursor.execute(nQuery)
                mspEscRes =comObj.dictfetchall(cursor)
                cursor.close()
                NewEscidslist['msp']={}
                m=0
                for mspEsc in mspEscRes:
                    NewEscidslist['msp'].setdefault(m,{})
                    NewEscidslist['msp'][m].setdefault('id',mspEsc["escalationId"])
                    m=m+1

            EscalationMatrixInfo ={}
            EscalationInfo = {}
            
            for key2,Newescid in NewEscidslist.iteritems():
                k1=0
                matrix =0
                for kk,data_esc in Newescid.iteritems():
                    NewEscData = {}
                    Query = "select nei.name,nei.description,nct.name as tz_name,nct.label as tz_label from nts_escalation_indices nei,nts_cfg_timezones nct where nei.timezone_id=nct.id and nei.id = "+str(data_esc['id'])
                    cursor = connections['ticketRead'].cursor()
                    cursor.execute(Query)
                    EscMatrixInfo = comObj.dictfetchall(cursor)
                    cursor.close()
                    EscalationMatrixInfo.setdefault(key2,{})
                    EscalationMatrixInfo[key2].setdefault(matrix,{})
                    EscalationMatrixInfo[key2][matrix].setdefault('Name',EscMatrixInfo[0]["name"])
                    EscalationMatrixInfo[key2][matrix].setdefault('Description', EscMatrixInfo[0]["description"])
                    EscalationMatrixInfo[key2][matrix].setdefault('tz_name',EscMatrixInfo[0]["tz_name"])
                    EscalationMatrixInfo[key2][matrix].setdefault('tz_label',EscMatrixInfo[0]["tz_label"])
            
                    SceduledIDs = {}
                    
                    query="SELECT es.id AS scheduleId FROM nts_escalation_matrix esm INNER JOIN nts_escalation_schedule es ON(es.id = esm.escalation_schedule_id ) AND esm. escalation_indices_id = "+str(data_esc['id'])+" order by priority ASC";
                    cursor = connections['ticketRead'].cursor()
                    cursor.execute(query)
                    ScheduleIdInfo = comObj.dictfetchall(cursor)
                    cursor.close()
                    y=0
                    for schedule in ScheduleIdInfo:
                        SceduledIDs.setdefault(y,schedule['scheduleId'])
                        y=y+1
                        
                    for key1,value in SceduledIDs.iteritems():
                        Query = "select es.name as name,esm.repeat_count as repeat_count,esm.repeat_freq as repeat_freq from nts_escalation_schedule es left join nts_escalation_matrix esm on (esm.escalation_schedule_id = es.id) where es.id ="+str(value)
                        cursor = connections['ticketRead'].cursor()
                        cursor.execute(Query)
                        ScheduleInfo = comObj.dictfetchall(cursor)
                        cursor.close()
                        EscalationInfo.setdefault(key2,{})
                        EscalationInfo[key2].setdefault(matrix,{})
                        EscalationInfo[key2][matrix].setdefault(value,{})
                        EscalationInfo[key2][matrix][value].setdefault('ScheduleName',ScheduleInfo[0]['name'])
                        EscalationInfo[key2][matrix][value].setdefault('Count',ScheduleInfo[0]['repeat_count'])
                        EscalationInfo[key2][matrix][value].setdefault('Freq',ScheduleInfo[0]['repeat_freq'])
                        k1 = 0;
                        shiftcountQ = "select count(*) as count from nts_escalation_shift_details where escalation_schedule_id ="+str(value)
                        cursor = connections['ticketRead'].cursor()
                        cursor.execute(shiftcountQ)
                        ShiftCountInfo = comObj.dictfetchall(cursor)
                        cursor.close()
                        EscalationInfo[key2][matrix][value].setdefault('shiftcount',ShiftCountInfo[0]['count'])
                            
                        Shiftsres = {}
                        shiftsQ ="select name,escalation_shift_type_weekday_id,escalation_shift_type_datarange_id,id,shift_type from nts_escalation_shift_details where escalation_schedule_id ="+str(value)+" order by id";
                        cursor = connections['ticketRead'].cursor()
                        cursor.execute(shiftsQ)
                        ShiftIdInfo = comObj.dictfetchall(cursor)
                        cursor.close()
                        Shiftsres.setdefault(key1,{})
                        for shift in ShiftIdInfo:
                            Shiftsres[key1].setdefault(k1,{})
                            Shiftsres[key1][k1].setdefault('id',shift['id'])
                            Shiftsres[key1][k1].setdefault('name',shift['name'])
            
                            if shift['shift_type'] == 1:
                                weekdayQ = "select sun_flag,mon_flag,tue_flag,wed_flag,thu_flag,fri_flag,sat_flag,start_time,end_time from nts_escalation_shift_type_weekdays where id = "+str(shift['escalation_shift_type_weekday_id'])
                                cursor = connections['ticketRead'].cursor()
                                cursor.execute(weekdayQ)
                                weekdaydatetime = comObj.dictfetchall(cursor)
                                cursor.close()
                                Shiftsres[key1][k1].setdefault('datetime', "From: "+str(weekdaydatetime[0]['start_time'])+" To: "+str(weekdaydatetime[0]['end_time']))
                                dayString =''
                                for day in weekdaysArr:
                                    flag = str(day)+"_flag";
                                    if weekdaydatetime[0][flag] == 1:
                                        dayString = dayString +","+day.title()
                                days = dayString.split(',')
                                Shiftsres[key1][k1].setdefault('days',days)
                
                            elif shift['shift_type'] == 2:
                                daterangeQ = "select start_datetime,end_datetime from nts_escalation_shift_type_daterange where id = "+str(weekdaydatetime[0]['escalation_shift_type_datarange_id']);
                                cursor = connections['ticketRead'].cursor()
                                cursor.execute(daterangeQ)
                                datarangedatetime = comObj.dictfetchall(cursor)
                                cursor.close()
                                Shiftsres[key2][k1].setdefault('datetime',"From: "+str(datarangedatetime[0]['start_datetime'])+" To: "+str(datarangedatetime[0]['end_datetime']))
                            
                        k1 = k1 + 1
                        
            
                        i1=0;j1=0;
                        for yk,Shiftsinfo in Shiftsres.iteritems() :
                            for ykk,shifts in Shiftsinfo.iteritems():
                                EscalationInfo[key2][matrix][value].setdefault(i1,{})
                                EscalationInfo[key2][matrix][value][i1].setdefault('ShiftName',shifts['name'])
                                EscalationInfo[key2][matrix][value][i1].setdefault('datetime',shifts['datetime'])
                                EscalationInfo[key2][matrix][value][i1].setdefault('days',shifts['days'])
                                EscalationInfo[key2][matrix][value][i1].setdefault('Shiftid',shifts['id'])
                                ShiftUsersQ = "select ntscon.first_name,ntscon.last_name,ntscon.email,ntscon.mobile_number,ntscon.phone_number,ntscon.time_zone from  nts_escalation_shift_users esu left join ntscontactmappings ntscon on (ntscon.id = esu.user_id) where escalation_shift_details_id = "+str(shifts['id'])+" order by esu.id asc"
                                cursor = connections['ticketRead'].cursor()
                                cursor.execute(ShiftUsersQ)
                                ShiftUserRes = comObj.dictfetchall(cursor)
                                cursor.close()
                                if ShiftUserRes:
                                    fisrtName = ''.join([i if ord(i) < 128 else ' ' for i in ShiftUserRes[0]['first_name']])
                                    lastName = ''.join([i if ord(i) < 128 else ' ' for i in ShiftUserRes[0]['last_name']])
                                    EscalationInfo[key2][matrix][value][i1].setdefault(j1,{})
                                    EscalationInfo[key2][matrix][value][i1][j1].setdefault('User',fisrtName+lastName)
                                    EscalationInfo[key2][matrix][value][i1][j1].setdefault('EMail',ShiftUserRes[0]['email'])
                                    EscalationInfo[key2][matrix][value][i1][j1].setdefault('phone_number',ShiftUserRes[0]['phone_number'])
                                    EscalationInfo[key2][matrix][value][i1][j1].setdefault('mobile_number',ShiftUserRes[0]['mobile_number'])
                                    EscalationInfo[key2][matrix][value][i1][j1].setdefault('time_zone',ShiftUserRes[0]['time_zone'])
                                    j1= j1+1
                                i1 = i1+1
                    matrix = matrix + 1;
                    EscalationInfo['EscalationMatrixinfo'] = EscalationMatrixInfo;        
            return EscalationInfo
        
        
        
        
        # To Get Swcustomfieldsoptins   Query
        
        
        def getFieldNotesOptions(self):
            result = mem_cache.get('fieldnotesoptions'+env)
            if not result:
                sql ="select  optionvalue FROM swcustomfieldoptions as cfo join swcustomfields as  cf on cf.customfieldid = cfo.customfieldid  where cf.title='Notification Description'"
                print sql
                cursor = connections['ticketRead'].cursor()
                cursor.execute(sql)
                result = comObj.dictfetchall(cursor)
                cursor.close()
                mem_cache.set('fieldnotesoptions'+env, result, 86400)
            return result
            
        def getFieldNotesButtons(self):
            result = mem_cache.get('fieldnotesbuttons'+env)
            if not result:
                sql ="select  optionvalue FROM swcustomfieldoptions as cfo join swcustomfields as  cf on cf.customfieldid = cfo.customfieldid  where cf.title='Notification Notes'"
                print sql
                cursor = connections['ticketRead'].cursor()
                cursor.execute(sql)
                result = comObj.dictfetchall(cursor)
                cursor.close()
                mem_cache.set('fieldnotesbuttons'+env, result, 86400)
            return result
        
        def customFeildvalues(self,ticketId):
            sql='select  fieldvalue  from swcustomfieldvalues where typeid= %s  and customfieldid =211 ' %(ticketId)
            print sql
            cursor =connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            return result

        def customFeildvalueVistara(self,ticketId):
            sql='select  fieldvalue  from swcustomfieldvalues where typeid= %s  and customfieldid =241 ' %(ticketId)
            print sql
            cursor =connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            return result

        
        def getCustomFieldsInfoByGroup(self,ticketId,groupId):
            sql = "SELECT fld.customfieldgroupid, fld.title, fld.customfieldid, fld.fieldtype, fld.isrequired, fld.defaultvalue, fld.description, fldval.fieldvalue  \
                        FROM swcustomfields fld    \
                    LEFT JOIN  swcustomfieldvalues fldval ON (fldval.customfieldid = fld.customfieldid AND fldval.typeid = "+str(ticketId)+")  \
                    WHERE fld.customfieldgroupid = "+str(groupId)+"   GROUP BY customfieldid  ORDER BY fld.displayorder"
            print sql 
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql);
            result =  comObj.dictfetchall(cursor)
            cursor.close()
            return result
        def getMspCode(self,mspId):
            sql = "select mspcode from ntsmsps where mspid=%s" %(mspId)
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql);
            result =  comObj.dictfetchall(cursor)
            cursor.close()
            return result
        
        def getClientCode(self,clientId):
            sql ="select clientcode from ntsmspclients where mspclientid= %s" %(clientId)
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql);
            result =  comObj.dictfetchall(cursor)
            cursor.close()
            return result
        
        
        def addslashes(self,s):
            d = {'"':'\\"', "'":"\\'", "\0":"\\\0", "\\":"\\\\"}
            return ''.join(d.get(c, c) for c in s)

        
        
        def getPSAIntegReqInfo(self,mspName,clientName):
            sql ="SELECT * FROM `clients_info` where msp_name='"+self.addslashes(mspName)+"' and client_name='"+self.addslashes(clientName) +"' and is_Activated!=0"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql);
            result =  comObj.dictfetchall(cursor)
            cursor.close()
            return result
        
        def getFieldOptions(self,customfieldid):
            sql = "SELECT optionvalue FROM swcustomfieldoptions WHERE customfieldid = %s ORDER BY displayorder" % (customfieldid)
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql);
            result =  comObj.dictfetchall(cursor)
            cursor.close()
            return result
        
        def  getCustomFieldValues(self,customFieldId, ticketId):
            
            sql = "SELECT fieldvalue FROM swcustomfieldvalues WHERE customfieldid='"+str(customFieldId)+"' AND typeid='"+str(ticketId)+"'";
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql);
            result =  comObj.dictfetchall(cursor)
            cursor.close()
            return result
        
        def getCustomGroupIds(self):
            sql = " select customfieldgroupid,title from swcustomfieldgroups where customfieldgroupid !=1";
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql);
            result =  comObj.dictfetchall(cursor)
            cursor.close()
            return result
            
        def apiResponseHandling(self,apiResponceOrg,request,excp,ticketId=0):
            tmp = comObj.currentAndYesterDayInPST()
            rootPath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            attPath = rootPath.rsplit('/', 1)
            errorTrackingLog = '/var/log/NNCDjango/APIErrorTracking'+env+'.txt'
            with open(errorTrackingLog, 'a') as f:
                f.write('\n =========================='+str(tmp[0]['currentTimeInPST'])+'===============================')
                f.write('\n'+str(ticketId))
                f.write('\n'+str(request.session['uName']))
                if apiResponceOrg.content:
                    f.write('\n Response: '+str(apiResponceOrg.content)+'\n ---')  
                    f.write('\n Exception: '+str(excp)+'\n ---') 
                else:
                    f.write('\n Response: Content not available:-'+str(apiResponceOrg)+'\n ---')
                    f.write('\n Exception: '+str(excp)+'\n ---')
                f.close() 
            apiResponceContent = ""
            apiResponceContent = str(apiResponceOrg.content.encode('utf-8')).split("{") 
            apiResponceContent = str(apiResponceContent[1]).rstrip("}")
            apiResponceContent = "{"+str(apiResponceContent )+"}"
            apiResponce = json.loads(apiResponceContent)
            return apiResponce

        def getITSMenabledClients(self, clientId):
            sql = "SELECT is_itsm_enabled FROM itsm_mspclient_details WHERE is_itsm_enabled=1 and id="+clientId
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = cursor.fetchall()
            #result =  comObj.dictfetchall(cursor)
            cursor.close()
            return result

        def getMSPfromCustomFieldValues(self, ticketId):
            sql = "select fieldvalue from swcustomfieldvalues where customfieldid=3 and typeid="+ticketId
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = cursor.fetchall()
            #result =  comObj.dictfetchall(cursor)
            cursor.close()
            return result

        def getMSPIDfromNNC(self, ticketId):
            sql = "select transaction_time from ntspsa_queue where ticketid="+ticketId
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = cursor.fetchall()
            #result =  comObj.dictfetchall(cursor)
            cursor.close()
            return result
