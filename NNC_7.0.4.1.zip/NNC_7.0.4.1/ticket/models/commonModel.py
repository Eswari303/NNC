"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import connections
from django.core.cache import caches
from _mysql import result
from datetime import datetime
from calendar import timegm
from collections import defaultdict
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
file_cache = caches['filecache']
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)
from NNCPortal.commonMethods import commonMethods
comObj = commonMethods()
class CommonTicketModel(object):
    
    def predefinedReplies(self):
        res = mem_cache.get('predefReplies'+env)
        if not res:
            sql = "SELECT predefinedcategoryid,title from swpredefinedcategories where parentcategoryid = 0 order by predefinedcategoryid";
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            
            i=0
            while i < len(result):
                sql1 = "SELECT predefinedcategoryid, parentcategoryid, title from swpredefinedcategories where parentcategoryid = '"+str(result[i]['predefinedcategoryid'])+"' order by predefinedcategoryid"
                cursor = connections['ticketRead'].cursor()
                cursor.execute(sql1)
                result1 = comObj.dictfetchall(cursor)
                cursor.close()
                result[i]['Sub_category'] = result1
                
                k=0
                while k < len(result):
                    sql3 = "SELECT predefinedreplyid, subject from swpredefinedreplies where predefinedcategoryid = '"+str(result[i]['predefinedcategoryid'])+"' order by predefinedreplyid"
                    cursor = connections['ticketRead'].cursor()
                    cursor.execute(sql3)
                    result3 = comObj.dictfetchall(cursor)
                    cursor.close()
                    result[i]['Replies'] = result3        
                    k=k+1
                
                j=0
                while  j < len(result1):
                    sql2 = "SELECT predefinedreplyid, subject from swpredefinedreplies where predefinedcategoryid = '"+str(result1[j]['predefinedcategoryid'])+"' order by predefinedreplyid"
                    cursor = connections['ticketRead'].cursor()
                    cursor.execute(sql2)
                    result2 = comObj.dictfetchall(cursor)
                    cursor.close()
                    result[i]['Sub_category'][j]['Subject'] = result2
                    j=j+1
                
                i=i+1
            
            sql4 = "SELECT predefinedreplyid, subject from swpredefinedreplies where predefinedcategoryid = '0' order by predefinedreplyid"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql4)
            result4 = comObj.dictfetchall(cursor)
            cursor.close()
            res = result+result4
            mem_cache.set('predefReplies'+env,res,86400)
        return res
    
    def getKnowledgeBase(self):
        result = mem_cache.get('knowldgBase'+env)
        if not result:
            sql = """select swkbal.kbcategoryid, swkbal.kbarticleid, swkbc.title, swkba.subject 
                    from swkbarticlelinks swkbal 
                    join swkbcategories swkbc on swkbc.kbcategoryid = swkbal.kbcategoryid 
                    join swkbarticles swkba on swkba.kbarticleid = swkbal.kbarticleid"""
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('knowldgBase'+env,result,86400)
        return result
    
    def getKbArticles(self):
        kbarticles = mem_cache.get('KbArticles'+env)
        if not kbarticles:
            sql = "select kbarticleid from swkbarticlelinks where kbcategoryid = 0"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            i=0
            kbarticles=[]
            while i < len(result):
                sql1 = "select kbarticleid, subject from swkbarticles where kbarticleid = '"+str(result[i]['kbarticleid'])+"'"
                cursor = connections['ticketRead'].cursor()
                cursor.execute(sql1)
                result1 = comObj.dictfetchall(cursor)
                cursor.close()
                for list in result1:
                    kbarticles.append(list)
                i=i+1
            mem_cache.set('KbArticles'+env,kbarticles,86400)
        return kbarticles 
    
    def getEmailContacts(self):
        emailList = mem_cache.get('emailList'+env)
        if not emailList:
            #sql= "(select fullname as label,email as value from swstaff) union all (select fullname as label,email1address as value from swcontacts where contacttype='public')"
            sql =" select su.fullname as label,se.email as value from swusers as su inner join swuseremails as se on (su.userid =se.userid) "
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            emailList = comObj.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('emailList'+env, emailList, 86400)
        return emailList
    
    def getSearchTags(self):
        sql= "select tag_name as label,tag_name as value from nts_incident_tags"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)           
        cursor.close()
        return result
    
    def getClientContacts(self):
        sql= "select distinct nmc.clientname as label,cm.phone_number as value from ntsmspclients nmc join ntscontactmappings cm on(nmc.mspclientid=cm.org_id) where phone_number != ''"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)           
        cursor.close()
        return result
    
    '''To get Predefined reply data'''
    def getPredefinedReplyData(self,predefid):
        sql="select contents from swpredefinedreplydata where predefinedreplyid="+str(predefid)        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor) 
        cursor.close()
        finalresult = ''
        for res in result:
            finalresult = res['contents']        
        return finalresult
       
    '''To get KBA reply data'''
    def getKbaReplyData(self,kbaid):
        sql="select contents from swkbarticledata where kbarticleid="+str(kbaid)        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor) 
        cursor.close()
        finalresult = ''
        for res in result:
            finalresult = res['contents']
        return finalresult  
    
    def getPostReview(self,ticketId):
        sql = "SELECT post_id,ticket_id,MIN(proc_rating) proc_rating,MIN(tech_rating) tech_rating,MIN(comm_rating) comm_rating,MIN(time_rating) time_rating,MIN(customer_value_rating) customer_value_rating FROM post_reviews WHERE ticket_id = "+str(ticketId)+" AND (post_id !=0 OR post_id IS NOT NULL)   GROUP BY post_id"        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor) 
        cursor.close()
        return result
    
    def getReviewforPost(self, ticketId, postId):
        condtion = '';
        if postId != False and ticketId != False:
            condtion =  ' ticket_id = '+ticketId+' AND  post_id = '+postId
        else:
            condtion = ' ticket_id = '+ticketId+' AND (post_id =0 OR post_id IS NULL)'
            
        sql = "SELECT post_id,reviewer_id,review_date,proc_rating,tech_rating,comm_rating,time_rating,customer_value_rating,comments,review_time FROM post_reviews WHERE "+str(condtion)        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor) 
        cursor.close()
        return result
    
    def getNewTicketReview(self, ticketId):
        sql = "SELECT post_id,MIN(proc_rating) proc_rating,MIN(tech_rating) tech_rating,MIN(comm_rating) comm_rating,MIN(time_rating) time_rating,MIN(customer_value_rating) customer_value_rating  FROM post_reviews WHERE ticket_id="+ticketId+" AND (post_id =0 OR post_id IS  NULL)"        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor) 
        cursor.close()
        return result

    def getStaffEmailForPosts(self,postId):
        sql = 'SELECT staff.email FROM swticketposts post JOIN swstaff staff ON staff.staffid = post.staffid WHERE post.ticketpostid = '+postId        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor) 
        cursor.close()
        return result
    
    def getStaffTwTb(self, postId):
        sql = "SELECT posts.ticketid, posts.staffid, staff.fullname, staff.email, posts.contents, track.timespent, track.timebillable "
        sql += "FROM swticketposts posts "
        sql += "JOIN swstaff staff ON staff.staffid = posts.staffid "
        sql += "LEFT JOIN swtickettimetrack track ON (staff.staffid = track.creatorstaffid AND track.ticketid = posts.ticketid AND track.dateline=posts.dateline) "
        sql += "WHERE posts.ticketpostid = "+postId
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor) 
        cursor.close()
        return result

    def getSumOfTimeWorkedAndBillable(self, ticketId):
        sql = "SELECT SUM(timespent) AS timeworked, SUM(timebillable) AS timebillable " 
        sql += "FROM swtickettimetrack "
        sql += "WHERE ticketid = "+ticketId
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor) 
        cursor.close()
        return result
    
    def getTicketInfo(self, ticketId):
        sql = "select fullname, subject from swtickets where ticketid="+ticketId
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor) 
        cursor.close()
        return result
    
    def getEmailCcmailList(self,ticketId):
        sql = "SELECT emails.email FROM swticketrecipients recipient JOIN swticketemails emails ON emails.ticketemailid = recipient.ticketemailid WHERE recipient.ticketid = "+str(ticketId)+" and emails.ticketemailid != 311"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor) 
        cursor.close()
        return result
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict"
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
    
    def getCurrentUnixTimestamp(self, currentUnixTime=None):
        if currentUnixTime is None:
            currentUnixTime = datetime.utcnow()
        return timegm(currentUnixTime.utctimetuple())
    
    def getResSchTime(self,userTime,diffTime,resTZ):
        sql = "SELECT FROM_UNIXTIME(UNIX_TIMESTAMP(CONVERT_TZ('"+str(userTime)+"', '"+str(resTZ)+"', '+00:00'))-"+str(diffTime)+") as schTime"        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor) 
        cursor.close()
        return result
    
    def getHmspReasons(self):
        result = mem_cache.get('hmspreason'+env)
        if not result:
            sql = "select optionvalue,customfieldoptionid from swcustomfieldoptions where customfieldid = 201 order by displayorder"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('hmspreason'+env, result, 86400)
        return result
    
    def ticketReviewMail(self, staffNam, postId, reviewData, ts, tb, reviewer, date, subject, posts):
        rating = {}
        rating[1] = "Below Expectation"
        rating[2] = "Meets Expectation"
        rating[3] = "Exceeds Expectation"
        html = '<table width="100%" cellpadding="0" cellspacing="0" style=" font-size: 12px; font-family: arial;">'
        html += '<tr><td colspan=2 height=10 style="background-color:#ADD2E1;"></td></tr>'
        html += '<tr style="background-color: #565656; color: white; padding-left:10px">'
        html += '<td valign="middle" style="padding-left:10px;">Ticket Review</td>'
        html += '<td> <div  style="text-align:center; valing: middle;">'
        html += '<img title="NetEnrich" src="static/images/netenrich_logo.png" height="90px"/>'
        html += '</div></td></tr>'
        html += '<tr><td colspan=2 height=3 style="background-color:#ADD2E1;"></td></tr><tr><td height="80" align="left" valign="middle">'
        html += '<p>Dear '+str(staffNam)+',</p>'
        html += '<p>'
        if str(postId) == '':
            html += 'Ticket has been reviewed. Please check the review:</p>'   
        else:
            html += 'Your post has been reviewed. Please check the review:</p>' 
        html += '</td></tr><tr><td colspan="2"><table align="left" width="100%" style="border:1px solid #C3C3C3;font-size: 12px; font-family: arial;" cellspacing="6" cellpading="0">'
        i=0
        if i%2 == 0:
            html += '<tr style="background-color:white";>'
        else:
            html +=  '<tr style="background-color:#efefef";>'
        html += '<td align="left" style="height:20px;" width="20%">Ticket Id:</td>'
        html += '<td align="left" style="height:20px;">'+str(reviewData['ticket_id'])+'</td></tr>'
        i=i+1
        if i%2 == 0:
            html += '<tr style="background-color:white";>'
        else:
            html +=  '<tr style="background-color:#efefef";>'
        html += '<td align="left" style="height:20px;" width="20%">Subject:</td>'
        html += '<td align="left" style="height:20px;"> '+str(subject)+' </td></tr>'
        if str(postId) != '':
            i=i+1
            if i%2 == 0:
                html += '<tr style="background-color:white";>'
            else:
                html +=  '<tr style="background-color:#efefef";>'
            html += '<td align="left" style="height:20px;" width="20%">Post:</td>'
            html += '<td align="left" style="height:20px;">'+str(''.join([jk if ord(jk) < 128 else ' ' for jk in posts]))+'</td></tr>'
        if ( int(ts) > 0 and int(tb) > 0) :
            i=i+1
            if i%2 == 0:
                html += '<tr style="background-color:white";>'
            else:
                html +=  '<tr style="background-color:#efefef";>'
            html += '<td align="left" style="height:20px;" width="20%">Time Spent:</td>'
            html += '<td align="left" style="height:20px;">Worked ('+str(ts)+' m) and Billable ('+str(tb)+' m)</td></tr>'
        i=i+1
        if i%2 == 0:
            html += '<tr style="background-color:white";>'
        else:
            html +=  '<tr style="background-color:#efefef";>'
        html +=  '<td align="left" style="height:20px;" width="20%">Process:</td>'
        html +=  '<td align="left" style="height:20px;">'+str(rating[reviewData['proc_rating']])+'</td></tr>'
        i=i+1
        if i%2 == 0:
            html += '<tr style="background-color:white";>'
        else:
            html +=  '<tr style="background-color:#efefef";>'
        html += '<td align="left" style="height:20px;" width="20%">Technical:</td>'
        html += '<td align="left" style="height:20px;">'+str(rating[reviewData['tech_rating']])+'</td></tr>'
        i=i+1
        if i%2 == 0:
            html += '<tr style="background-color:white";>'
        else:
            html +=  '<tr style="background-color:#efefef";>'
        html +=  '<td align="left" style="height:20px;" width="20%">Communication:</td>'
        html +=  '<td align="left" style="height:20px;">'+str(rating[reviewData['comm_rating']])+'</td></tr>'
        i=i+1
        if i%2 == 0:
            html += '<tr style="background-color:white";>'
        else:
            html +=  '<tr style="background-color:#efefef";>'
        html += '<td align="left" style="height:20px;" width="20%">Time:</td>'
        html += '<td align="left" style="height:20px;">'+str(rating[reviewData['time_rating']])+'</td></tr>'
        i=i+1
        if i%2 == 0:
            html += '<tr style="background-color:white";>'
        else:
            html +=  '<tr style="background-color:#efefef";>'
        html += '<td align="left" style="height:20px;" width="20%">Customer Value:</td>'
        html += '<td align="left" style="height:20px;">'+str(rating[reviewData['customer_value_rating']])+'</td></tr>'
        i=i+1
        if i%2 == 0:
            html += '<tr style="background-color:white";>'
        else:
            html +=  '<tr style="background-color:#efefef";>'
        html += '<td align="left" style="height:20px;" width="20%">Comments:</td>'
        html += '<td align="left" style="height:20px;">'+str(reviewData['comments'])+'</td></tr>'
        i=i+1
        if i%2 == 0:
            html += '<tr style="background-color:white";>'
        else:
            html +=  '<tr style="background-color:#efefef";>'
        html += '<td align="left" style="height:20px;" width="20%">Review Time:</td>'
        html += '<td align="left" style="height:20px;">'+str(reviewData['review_time'])+'Mins</td></tr>'
        i=i+1
        if i%2 == 0:
            html += '<tr style="background-color:white";>'
        else:
            html +=  '<tr style="background-color:#efefef";>'
        html += '<td align="left" style="height:20px;" width="20%">Reviewer:</td>'
        html += '<td align="left" style="height:20px;">'+str(reviewer)+'</td> </tr>'
        i=i+1
        if i%2 == 0:
            html += '<tr style="background-color:white";>'
        else:
            html +=  '<tr style="background-color:#efefef";>'
        html += '<td align="left" style="height:20px;" width="20%">Reviewed at:</td>'
        html += '<td align="left" style="height:20px;">'+str(date)+'</td></tr></table></td></tr>'
        html += '<tr><td height=60 valign="bottom">Sincerely,<br><b>NNC Team</b></td></tr></table>'
        return html
    
    def getDefaultCustomFields(self, columns = defaultdict(dict)):
        sql = "SELECT * FROM sla_mgnt_custom_columns WHERE is_default_field= 1 and is_display = 1"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        for res in result:
            columns[res['column_name']] = res['column_name']
        return columns
    
    def getTicketLastActivity(self,ticketid):
        sql = "SELECT lastactivity ,FROM_UNIXTIME(lastactivity, '%Y-%m-%d %H:%i:%s') as dtString1,FROM_UNIXTIME(lastactivity, '%d %b %Y %H:%i') as dtString FROM swtickets WHERE ticketid="+str(ticketid)
        cursor = connections['ticketWrite'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        data = {}
        cursor.close()
        if  result:
            for res in result:
                data['lastactivity'] = res['lastactivity']
                data['dtString'] = res['dtString']
                data['dtString1'] = res['dtString1']
            sql1 = "SELECT TIMESTAMPDIFF(SECOND,'"+str(data['dtString1'])+"',now()) as diff FROM dual"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql1)
            result1 = comObj.dictfetchall(cursor)
            tmp = int(result1[0]['diff'])/3600
            data['diff'] = int(tmp)
            cursor.close()
        else:
            data['lastactivity'] = ''
            data['dtString'] = ''
            data['dtString1'] = ''
            data['diff'] = 0
        return data 
    
    def getUserEmails(self,mspClient,emailid):
        sql = "SELECT count(email) as emailcount FROM ntscontactmappings where org_id in ("+str(mspClient)+") and email='"+str(emailid)+"'"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql);
        result =  comObj.dictfetchall(cursor)
        print type(result)
        cursor.close()
        res1 = {}
        for res in result:
            res1 = res 
        return res1
    
    def getBillingEntries(self, ticketId):
        sql = "SELECT timetrackid, ticketid, dateline, creatorstaffid, timespent, timebillable, forstaffid, notes FROM swtickettimetrack where ticketid = "+ticketId
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    def formValidation(self,request,formName=''):
        post = request.POST
        flag = 0
        message = ''
        NotAllowedStrings= ['',None,'None',' ',"Invalid date"]
        if formName == 'quickEdit':
            if post.get('quick_tId','') in NotAllowedStrings:
                flag = 1
                message = 'TicketId should not be empty'
                return message
            if post.get('quick_deptId','') in NotAllowedStrings:
                flag = 1
                message = 'Department should not be empty'
                return message
            if post.get('quick_pId','') in NotAllowedStrings:
                flag = 1
                message = 'Priority should not be empty'
                return message
            if post.get('quick_osId','') in NotAllowedStrings:
                flag = 1
                message = 'Owner should not be empty'
                return message
            if post.get('quick_tsId','') in NotAllowedStrings:
                flag = 1
                message = 'Status should not be empty' 
                return message
            if int(post.get('quick_tsId',0)) == 16:
                if post.get('quick_timezone','') in NotAllowedStrings:
                    flag = 1  
                    message = 'Timezone should not be empty'
                    return message
                if post['quick_upDate_scheduledTime'] in NotAllowedStrings:
                    flag = 1
                    message = 'ScheduledTime should be valid date' 
                    return message
        if formName == 'postReply':
            if post['department'] in NotAllowedStrings:
                flag = 1
                message = 'Department should not be empty'
                return message
            if post['selectedPriority'] in NotAllowedStrings:
                flag = 1
                message = 'Priority should not be empty'
                return message
            if post['status'] in NotAllowedStrings:
                flag = 1
                message = 'Status should not be empty'
                return message
            if int(post['status']) == 16:
                if post['gnschPost'] in NotAllowedStrings:
                    flag = 1
                    message = 'Schedule Time should not be empty'
                    return message
            if int(post['status']) == 9:
                if request.POST.get('hmspReason','') in NotAllowedStrings:
                    flag = 1
                    message = 'HMSP Reason should not be empty'
                    return message
                if request.POST.get('hmspReason','') == "Miscellaneous":
                    if request.POST.get('hmspmisReason','') in NotAllowedStrings:
                        flag = 1
                        message = 'HMSP Reason should not be empty'
                        return message
            """if post['postSub'] in NotAllowedStrings:
                flag = 1
                message = 'Subject should not be empty'
                return message"""
            if post['ticketContent'] in NotAllowedStrings:
                flag = 1
                message = 'Post Content should not be empty'
                return message
            if post['timeWorked'] in NotAllowedStrings:
                flag = 1
                message = 'Time Worked Content should not be empty'
                return message
        return message
                
