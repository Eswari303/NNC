"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
import os
import ast
import pytz
import json
import md5
import time
import urlparse
import os.path
import urllib
import requests
from random import choice
from string import ascii_uppercase
from operator import is_not
from functools import partial
import json as simplejson
from datetime import datetime, timedelta
from collections import defaultdict
from django.conf import settings
from django.contrib import messages
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from django.core.cache import caches
from django.template import RequestContext
from django.shortcuts import render_to_response

from NNCPortal.configfile import ConfigManager
from NNCPortal.commonMethods import commonMethods

from NNCPortal.commonModels.NrStaff import NrStaff
from NNCPortal.commonModels.Ntsmsps import Ntsmsps
from NNCPortal.commonModels.Ntsmspnocs import Ntsmspnocs
from NNCPortal.commonModels.Ntschannel import Ntschannel
from NNCPortal.commonModels.NtsMimeTypes import NtsMimeTypes
from NNCPortal.commonModels.IncidentData import IncidentData
from NNCPortal.commonModels.NtsDeviceType import NtsDeviceType
from NNCPortal.commonModels.Ntsmspclients import Ntsmspclients
from NNCPortal.commonModels.Swdepartments import Swdepartments
from NNCPortal.commonModels.Swticketstatus import Swticketstatus
from NNCPortal.commonModels.NtsMspDeviceData import NtsMspDeviceData
from NNCPortal.commonModels.Swticketpriorities import Swticketpriorities
from NNCPortal.commonModels.commonModelMethods import CommonModelMethods
from NNCPortal.commonModels.SlaMgntCustomColumns import SlaMgntCustomColumns

from serviceManagement.models.SwStaff import Swstaff
from serviceManagement.models.serviceManagementQuerys import SlamResultQuerys
from serviceManagement.models.NtsTicketType import Ntstickettype
from serviceManagement.models.commonModel import CommonServiceModel
from serviceManagement.models.commonScheduleModel import CommonScheduleModel

from ticket.forms import Ticket
from ticket.models.ticketCreateModel import ticketCreateModel
from ticket.models.commonModel import CommonTicketModel
from ticket.models.escalationModel import escalationModel

configobj = ConfigManager()
tkttype_obj = Ntstickettype()
Salmquey = SlamResultQuerys()
msps_obj = Ntsmsps()
swtStatusObj = Swticketstatus()
channel_obj = Ntschannel()
swpriorities_obj = Swticketpriorities()
comMObj=CommonServiceModel()
ticketmodel = ticketCreateModel()
escaObj = escalationModel()
nrStaffObj  = NrStaff()
mem_cache = caches['memcached']
comObj = commonMethods()
swdept_obj = Swdepartments()
slaCustomFiledObj = SlaMgntCustomColumns()
nocdata_obj = Ntsmspnocs()
commonObj = CommonScheduleModel()
NtsDeviceTypeObj = NtsDeviceType()
ntsmimetype_obj = NtsMimeTypes()
NtsmspClientObj = Ntsmspclients()
incidentdat_obj = IncidentData()
NtsMspDeviceDataObj = NtsMspDeviceData()
env = configobj.getCommConfigValue(configobj.app_env)
nullList = [False, '0', 0, '0000']

""" support Mail ids """
cdi_supportmail = "CDI-support@netenrich.com"
#Electro_Switch_Corp_mail = "pip@bemisworldwide.com"
# Create your views here.
from htmlmin.decorators import minified_response
attachmentUploadPath = configobj.getCommConfigValue(configobj.FileUploadPath)

@minified_response
def loadTicketMockup(request):
    authRes = comObj.checkAuthentication(request)
    if request.method == 'POST':
        print "inside ServiceManagement"
    else :
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            tb_admin = request.session['tb_admin']
            form = Ticket()
            msps = msps_obj.getMSPSdata()
            #msps = mem_cache.get('msps')
            #if not msps:
                #msps = Ntsmsps.objects.using('ticketRead').only('mspname','mspid').filter(status = 1).order_by('mspname')
                #mem_cache.set('msps', msps, 3600)
            nocs = nocdata_obj.getNocdata()
            #nocs = mem_cache.get('nocs')
            #if not nocs:
                #nocs = Nocdetails.objects.using('mspDB').all().order_by('name')
                #mem_cache.set('nocs', nocs, 3600)
            clients = defaultdict(dict) 
            clients = NtsmspClientObj.showPartnerClients()
            #clients = Ntsmspclients.objects.using('ticketRead').only('clientname','mspclientid').filter(status = 1).order_by('clientname')
            #mem_cache.set('clients', clients, 3600)           
            #if not clients:
                #clients = NtsmspClientObj.showpatclient()
                #mem_cache.set('clients', clients, 3600)

            departments = swdept_obj.departments()
            #departments = mem_cache.get('departments_new')
            #if not departments:
                #departments = departmentObj.departments()
                #departments = Swdepartments.objects.using('ticketRead').only('title','departmentid').order_by('title')
                #mem_cache.set('departments_new', departments, 86400)
            tktstatus = swtStatusObj.getNewStatus()
            #tktstatus = mem_cache.get('newStatus')
            #if not tktstatus:
                #tktstatus = swtStatusObj.getNewStatus()
                #closed = mem_cache.get('closedStatus')
                #if not closed :
            closed = swtStatusObj.getClosedStatus()
            tktstatus = {key: tktstatus[key] for key in tktstatus if key not in closed.keys()}
            priorities = swpriorities_obj.getPriority()
            #priorities = mem_cache.get('priorities')  
            #if not priorities:
                #priorities = Swticketpriorities.objects.using('ticketRead').only('display_text','priorityid').order_by('displayorder')
                #mem_cache.set('priorities', priorities, 86400)
            channels = channel_obj.getChanneldata() 
            #channels = mem_cache.get('channels')    
            #if not channels:
                #channels = Ntschannel.objects.using('ticketRead').only('name','id').order_by('name')
                #mem_cache.set('channels', channels, 86400)
            swStaff = defaultdict(dict)
            #swStaff = mem_cache.get('swStaff')
            #if not swStaff:
            swStaff = nrStaffObj.getSwStaffByRoster()
                #mem_cache.set('swStaff', swStaff, 86400)
            ticketType = tkttype_obj.getAllTicketTypes()
            #ticketType = mem_cache.get('ticketType')
            #if not ticketType:
                #ticketType = Ntstickettype.objects.using('ticketRead').only('typeid', 'typename').order_by('typename')
                #mem_cache.set('ticketType', ticketType, 86400)
            finalCustomFields = slaCustomFiledObj.getCustomCoulmnFields()
            customFields = slaCustomFiledObj.getCustomFields()
            customFIeldsFromDb = defaultdict(dict)
            for customField in customFields:
                customFIeldsFromDb[customField['custom_field_group']]['cust_fld_'+str(customField['customfieldid'])] = customField['title']
            devices = defaultdict(dict)
            days = range(1, 31)
            deviceTypes = defaultdict(dict)
            deviceTypes = NtsDeviceTypeObj.getDeviceTypes()
            #deviceTypes = mem_cache.get('deviceTypes')
            #if not deviceTypes:
                #deviceTypes = NtsDeviceTypeObj.getDeviceTypes()
                #mem_cache.set('deviceTypes', deviceTypes, 86400)
            tmp = comObj.currentAndYesterDayInPST()
            fromDate = yesDate = tmp[0]['yesterDayPST']
            toDate = tmp[0]['currentTimeInPST']
            if 'uName' in request.session :
                userName = request.session['uName'].split('@')
                userName = str(userName[0][0:14])+'...'
            else :
                userName = 'TestUser'
            ActiveStatus = swtStatusObj.getActiveStatus()
            InActiveStatus = swtStatusObj.getInActiveStatus()
            closed = swtStatusObj.getClosedStatus()
            ActiveStatus = ','.join(str(e) for e in ActiveStatus.keys())
            InActiveStatus = ','.join(str(e) for e in InActiveStatus.keys())
            closed = ','.join(str(e) for e in closed.keys())
            allS = ActiveStatus+','+InActiveStatus+','+closed
            allStatuses={'active':ActiveStatus,'inactive':InActiveStatus,'closed':closed,'all':allS}
            all_nocdetails = mem_cache.get('NocDeviceTreeView0','has expired')
            resntsflds = ticketmodel.getResolutionNotesFields()
            ticketModelObj= CommonTicketModel()
            ################# for Predefined Replies backend data #######################
            predefReplies=ticketModelObj.predefinedReplies()
            ################ for knowledgebase backend data #################
            knowledgebase=ticketModelObj.getKnowledgeBase()
            kbarticles=ticketModelObj.getKbArticles()
            #emailList = mem_cache.get('emailList') 
            #if not emailList :   
            emailList = simplejson.dumps(ticketModelObj.getEmailContacts())
                #mem_cache.set('emailList', emailList, 86400)
            clientContacts = simplejson.dumps(ticketModelObj.getClientContacts())
            searchTags = simplejson.dumps(ticketModelObj.getSearchTags())   
            randomString = ''.join(choice(ascii_uppercase) for i in range(8))
            #sort_tktstatus = mem_cache.get('ordered')
            #if not sort_tktstatus:
            sort_tktstatus = swtStatusObj.newOrderStatus()
            return render_to_response('ticketCreate.html', {'form':form,'randomString':randomString, 'sort_tktstatus':sort_tktstatus, 'searchTags':searchTags,'clientContacts':clientContacts,'emailList':emailList,'msps':msps,'channels':channels,'tktstatus':tktstatus,'priorities':priorities,'clients':clients,'nocs':nocs,'departments':departments,'toDate':toDate,'fromDate':fromDate,'userName':userName, 'swStaff':swStaff, 'ticketType':ticketType,'finalCustomFields':finalCustomFields, 'allStatuses':allStatuses,'all_nocdetails':all_nocdetails, 'deviceTypes': deviceTypes, 'devices': devices, 'days': days, 'tb_admin': tb_admin,'PredefinedReplies':predefReplies,'knowledgebase':knowledgebase,'kbarticles':kbarticles},context_instance=RequestContext(request))
        else :
            return authRes
"""def getNewStatus():
        newStatus = {}
        status =Salmquey.getSwticketstatus()
        oldStatus = {}
        for stat in status :
            oldStatus[stat['ticketstatusid']] = stat['display_text'] 
            if int(stat['parent_id']) == 0 :
                newStatus[stat['ticketstatusid']] = stat['display_text']
        for stat in status :
            if int(stat['parent_id']) == 18 :
                newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']])+' - '+str(stat['display_text'])  
            elif int(stat['parent_id']) == 2 :
                newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']])+' - '+str(stat['display_text'])
            elif int(stat['parent_id']) == 3 :
                newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']])+' - '+str(stat['display_text'])
            elif int(stat['parent_id']) == 5 :
                newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']])+' - '+str(stat['display_text'])
            elif int(stat['parent_id']) == 19 :
                newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']])+' - '+str(stat['display_text']) 
            elif int(stat['parent_id']) == 1 :
                newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']])+' - '+str(stat['display_text']) 
        mem_cache.set('newStatus', newStatus, 86400)"""
def loadDivContent(request):
    authRes = comObj.checkAuthentication(request)
    if authRes == True:
        form = Ticket()
        return render_to_response('divcontent.html',context_instance=RequestContext(request))
    else :
        return authRes
def getClientAjax(request):
    devices = []
    if request.method == "POST" :
        finResult = request.POST
        res = dict(finResult.lists())
        if request.POST.get('res_devices', False) :
            for clientId in res['res_devices'] :
                dev = NtsMspDeviceDataObj.getDevices(clientId)
                if dev :
                    devices = devices + dev
        else :
            devices = NtsMspDeviceDataObj.getDevices(client_id='')
    jsonData = simplejson.dumps({'devices': devices})
    return HttpResponse(jsonData, content_type="application/json")
def getPatClients(request):
    if request.method == "POST" :
        search_text = request.POST.get('res_cli', False)
    else :
        search_text = ''
    cli = NtsmspClientObj.getClientsOfPartner(search_text)
    jsonData = simplejson.dumps({'clients': cli})
    return HttpResponse(jsonData, content_type="application/json")
def uploadAttachment(request):
    attDynamic = request.POST.get('attDynamic','')
    filename = request.FILES['uploadFile'].name
    extension =  filename.split('.')[-1]
    extension = extension.lower()
    file = request.FILES['uploadFile']
    ValidationMessage =''
    configobj = ConfigManager()
    maxFileSize = configobj.getCommConfigValue(configobj.maxFileSize)
    maxFileSize = int(maxFileSize)
    #ntsMimes = mem_cache.get('ntsMimes')
    #if not ntsMimes:
    ntsMimes =[]
    NtsMimeTypesObj = ntsmimetype_obj.getNtsmimetypes()
        #NtsMimeTypesObj = NtsMimeTypes.objects.using('ticketRead').all()
    for mimeObj in NtsMimeTypesObj:
        ntsMimes.append(mimeObj['ext'])
        #mem_cache.set('ntsMimes', ntsMimes, 86400)
    if extension not in ntsMimes:
        ValidationMessage =  'Invalid file type:  unsupported file "'+str(extension)+ '" extension'
    if file.size > maxFileSize:
        if maxFileSize > 1048576:
            inMB = maxFileSize/1048576
            ValidationMessage = "File size too large: max size "+str(inMB)+" MB"
    if ValidationMessage == '':
        attDynamic = "".join([i if ord(i) < 128 else "" for i in attDynamic])
        handle_uploaded_file(request.FILES['uploadFile'],attDynamic)
        return HttpResponse(request.FILES['uploadFile'].name)
    else:
        return HttpResponse("RestrictedToUpload: "+str(ValidationMessage))
def handle_uploaded_file(upfile,attDynamic):
    #attUrl = str(configobj.getCommConfigValue(configobj.attUrl))
    rootPath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    attPath = rootPath.rsplit('/', 1)
    if attDynamic :
        #attUrl = '/backup/nncportal_attachments/'+str(attDynamic)+'/'  #str(attPath[0])+'/static/files/'+str(attDynamic)+'/'
        attUrl = attachmentUploadPath+str(attDynamic)+'/'
        if not os.path.exists(attUrl) :
            os.makedirs(attUrl)
            os.chmod(attUrl, 777)
    fname = "".join([i if ord(i) < 128 else "" for i in upfile.name])
    destination = open(attUrl+fname.encode('utf-8'), 'wb+')
    for chunk in upfile.chunks():
        destination.write(chunk)
    destination.close()
def deleteAttached(request):
    if request.method=='POST':
        fname = str(request.POST['fname'])
        attDynamic = request.POST.get('attDynamic')
        #attUrl = str(configobj.getCommConfigValue(configobj.attUrl))
        rootPath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        attPath = rootPath.rsplit('/', 1)
        #attUrl = '/backup/nncportal_attachments/'+str(attDynamic)+'/' #str(attPath[0])+'/static/files/'+str(attDynamic)+'/'
        attUrl = attachmentUploadPath+str(attDynamic)+'/'
        os.remove(attUrl+fname)
        return HttpResponse('deleted')
def search_fun(request):
    if request.method=='POST' and request.POST['ele']!='':
        message = request.POST['ele']
        inputCmd = message
        ''' here finding the owner based on command #get @owner:ownerfirstname.ownerlastname '''
        ownerName = ''
        message = message.lower()
        msglists = message.split(" ")
        for msglist in msglists:
            msg = msglist.split(':')
            if '@owner' in str(msg[0].lower()):
                ownerName = str(msg[1])
        #checking wheather proper command is given or not
        #if "@owner" in str(msglists[0]):
        if ownerName != '':
            #  fetching swstaff id based on employee username
            swstaff_id = NrStaff.objects.using('rosterRead').filter(user_name = str(ownerName))
            #return swstaff_id
            #  checking wheather user available or not
            if swstaff_id:
                #  if swstaff id is none sending not available response
                if swstaff_id[0].swstaff_id is None:
                    return HttpResponse('Owner not available')
                # if swstaff id is available executing below block
                else:
                    #message = str(msg[0]) +":"+str(swstaff_id[0].swstaff_id)
                    message = message.replace(str(ownerName),str(swstaff_id[0].swstaff_id))
                    data_hub = message
            # if not available  return this response
            else:
                return HttpResponse('Invalid Owner name')
        else:
            data_hub = message
            ''' end of finding owner '''
        try:
            uName = request.session['uName']
            uid = request.session['uId']
            staffID  = request.session['swstaffId']
            configobj = ConfigManager()
            r=requests.post(configobj.getCommConfigValue(configobj.HUBOTURL),data={'message':message,'uName':uName,'uid':uid,'staffID':staffID,'inputCmd':inputCmd})
            data_hub = r.content
            data_hub = simplejson.loads(data_hub)
            temp = ""
            for k,v in data_hub.iteritems():
                temp += '<b>'+str(k)+':</b>'+str(v)+'<br>' 
            return HttpResponse(temp)
        except Exception,e:
            return HttpResponse('connection error')
        return HttpResponse(temp)
    else:
        return HttpResponse('Request not allowed')
def createTicket(request):
    url = comObj.ticketingUrls()+'/organizations/844/incident/'
    params = {}
    params['mId'] = str(request.POST.get('partners',False))
    params['cId'] = str(request.POST.get('clients',False))
    params['dId'] = str(request.POST.get('devices',False))
    params['pId'] = str(request.POST.get('selectedPriorities',False))
    params['deptId'] = str(request.POST.get('department',False))
    params['sId'] = str(request.POST.get('grpStatus',False))
    params['sub'] = str(request.POST.get('subject','').encode('utf-8'))
    params['content'] = str(request.POST.get('ticketContent','').encode('utf-8')).replace('<br />','')
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[-1].strip()
    else:
        ip = request.META.get('REMOTE_ADDR')
    params['ipAdd'] = ip
    params['uEmailId'] = str(request.POST.get('reqEmailId',False)) #req mail id
    params['stId'] = str(request.session['swstaffId'])
    params['sec'] = 'Staff'
    params['sendMailFlag'] = str(request.POST.get('sendMail',False))
    params['wTime'] = str(request.POST.get('timeWorked',False))
    params['dTime'] = str(request.POST.get('ticDue',False))
    params['bTime'] = str(request.POST.get('billable',False))
    params['tTypeId'] = str(request.POST.get('incidenttype',False))
    params['devCatId'] = str(request.POST.get('deviceType',False))
    params['oId'] = str(request.POST.get('staff',False))
    params['cc'] = str(request.POST.get('ccEmailId',False))
    params['alType'] = '1'
    params['reqPhone'] = request.POST.get('reqPhone',False)
    params['incidenttags'] = request.POST.get('tags','')
    params['qos_feedback'] = request.POST.get('qos_feedback','')  
    params['avfailure']  = 0
    if (int(params['tTypeId']) == 10 or int(params['tTypeId']) == 12 or int(params['tTypeId']) == 13):
        params['avfailure'] =  request.POST.get('integrationcheck',0)
    fileAtt = request.POST.getlist('attachments[]',False)
    attachFiles = {}
    if fileAtt :
        attDynamic = str(request.POST.get('attDynamic','').encode('utf-8'))
        rootPath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        attPath = rootPath.rsplit('/', 1)
        #attUrl = '/backup/nncportal_attachments/'+str(attDynamic)+'/' #str(attPath[0])+'/static/files/'+attDynamic+'/'
        attUrl = attachmentUploadPath+str(attDynamic)+'/'
        count = 0
        for att in fileAtt :
            if att:
                att = "".join([i if ord(i) < 128 else "" for i in att])
                attachFiles['attchmnt['+str(count)+']']=open(attUrl+str(att.encode('utf-8')),'rb')
                count = count + 1
    token = comObj.getAuthToken('ticket')
    resHed = {'TOKEN' : token}
    apiResponce ={}
    apiResponce['HTTP Response Code']=''
    apiResponce['Result']=''
    try:
        apiResponceOrg = requests.post(url, data=params,files=attachFiles, headers=resHed, verify=False)
        tmp = comObj.currentAndYesterDayInPST()
        rootPath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        attPath = rootPath.rsplit('/', 1)
        errorTrackingLog = '/var/log/NNCDjango/APIErrorTracking'+env+'.txt'
        with open(errorTrackingLog, 'a') as f:
            f.write('\n =========================='+str(tmp[0]['currentTimeInPST'])+'===============================')
            f.write('\n'+str(request.session['uName']))
            if apiResponceOrg.content:
                f.write('\n Ticket Creation API Response: '+str(apiResponceOrg.content)+'\n ---')  
            f.close() 
        apiResponce = apiResponceOrg.json()
    except Exception as e: 
        apiResponce = ticketmodel.apiResponseHandling(apiResponceOrg,request,str(e))
    finally:
        ticketId =""   
        if apiResponce['HTTP Response Code'] == '201 Created' :
            ticketId = apiResponce['Result']
            resURL = "/ticket/view/"+str(apiResponce['Result'])
            resMsg = ""
            messages.success(request, 'post_updated_successfully')
        elif apiResponce['HTTP Response Code'] == '206 Partial Content':
            ticketId = apiResponce['Result'].split(':')
            resURL = "/ticket/view/"+str(ticketId[0])
            resMsg = ""
            resMsg = str(apiResponce['HTTP Response Code'])+' - '+str(ticketId[1])
            messages.warning(request, 'post_updated_fileupload_failed')
        else :
            resURL = ""
            resMsg = str(apiResponce['HTTP Response Code'])+' - '+str(apiResponce['Result'])
        jsonData = simplejson.dumps({'resURL': resURL,'resMsg':resMsg,'ticketResult':ticketId})
        return HttpResponse(jsonData, content_type="application/json")

def handler400(request):
    response = render_to_response('incident_does_not_exist.html', {}, context_instance=RequestContext(request))
    response.status_code = 400
    return response


@minified_response
def ticketView(request,ticket_id):
    authRes = comObj.checkAuthentication(request)
    if authRes == True :
        url = comObj.ticketingUrls() +'/organizations/844/incident/'+str(ticket_id)
        jsonOp = comObj.getAPIResponce(url,'ticket')

        #print jsonOp
        try:
            ticketDetails = jsonOp['Result']['Ticket Info']
        except:
            return handler400(request)
        temp = int(ticketDetails['sccAId']) if ticketDetails.has_key('sccAId') else ''
        ticketDetails['sccAId'] = temp
        ticketDetails['sub'] = ticketDetails['sub'].replace("\n", " ")
        pageTitle = ticketDetails['tId'] +': '+ ticketDetails['sub']
        ticketServiceGrpInfo = jsonOp['Result']['Service Group Info']
        ticketBillingInfo = jsonOp['Result']['Billing Info']
        #SwcustomFieldsGroup =  ticketmodel.getCustomFieldGroups()
        ticketCustFieldsInfo = {}
        incomingAlertTime = schedulingTime = ''
        if(len(jsonOp['Result']['Custom Fields Info']) > 0):
            for i in jsonOp['Result']['Custom Fields Info']:
                ticketCustFieldsInfo[i['cfGrpId']] = {}
                ticketCustFieldsInfo[i['cfGrpId']]['title']  = i['grpTitle']
                noneRemove = filter(partial(is_not, None), i['customfields'])
                for custField in noneRemove:
                    if(int(custField['cfId']) == 8):
                        if(custField['fVal']):
                            incomingAlertTime = custField['fVal']
                    if(int(custField['cfId']) == 12):                     
                        if(custField['fVal']):
                            schedulingTime = custField['fVal']
                    ticketCustFieldsInfo[i['cfGrpId']]['custFields'] ={}
                    dataArray  ={}
                    dataArray['field'] = custField['cfTitle']
                    dataArray['value'] = custField['fVal']
                    dataArray['type'] = custField['fTy']
                    ticketCustFieldsInfo[i['cfGrpId']]['custFields'][custField['cfId']] = dataArray
        ticketServiceTypeInfo =''     
        if(len(jsonOp['Result']['Service Type Info']) > 0):
                    k=1 
                    glue=''
                    for serviceTypeInfo in jsonOp['Result']['Service Type Info'] :
                        ticketServiceTypeInfo += glue+str(k)+" "+serviceTypeInfo['serType']
                        glue = "\n"
                        k = k+1
                  
        status =swtStatusObj.getNewStatus()
        ticketStatus = status[int(ticketDetails['tsId'])]
        createdDate = datetime.fromtimestamp(int(ticketDetails['cdLine']), pytz.timezone("US/Pacific")).strftime('%d %b %Y  %H:%M')  
        if ticketDetails['lupdate']: 
            lastupdated = datetime.fromtimestamp(int(ticketDetails['lupdate']), pytz.timezone("US/Pacific")).strftime('%d %b %Y %H:%M')
        else:
            lastupdated = ''
        devicecatagories = ticketmodel.getDeviceCatagorie()
        deviceCondtion = devicecatagories.has_key(int(ticketDetails['dcId']))
        if(deviceCondtion != False):
            devicata = devicecatagories[int(ticketDetails['dcId'])]
        else:
            devicata = ''
        clients = ticketmodel.getClients()
        '''
        deviceName = ticketmodel.getDeviceByClient(int(ticketDetails['cId']))
        if int(ticketDetails['dId']) >0:
            if deviceName.has_key(int(ticketDetails['dId']) ):
                device = deviceName[int(ticketDetails['dId'])]
            else: device = '(Not Found)'
        elif ticketDetails['sccAId']:
            device = '(Not Found)'
        else:
            device = "others"
        '''
        device = ''
        if ticketDetails['dName'] == None:
            device = '(Not Found)'
        else:
            device = ticketDetails['dName']

        Technology = ticketmodel.getClientTechnology(int(ticketDetails['cId']))
        clientName = clients[int(ticketDetails['cId'])] if clients.has_key(int(ticketDetails['cId'])) else ''
        dataSet = {}
        dataSet['pageTitle'] = pageTitle
        dataSet['ticketServiceGrpInfo'] = ticketServiceGrpInfo
        dataSet['ticketBillingInfo'] = ticketBillingInfo
        dataSet['ticketCustFieldsInfo'] = ticketCustFieldsInfo
        dataSet['ticketServiceTypeInfo'] = ticketServiceTypeInfo
        ''' Quick Update fields'''
        ticketModelObj= CommonTicketModel() 
        closed = swtStatusObj.getClosedStatus()
        #Activestatusnames = swtStatusObj.getActiveStatus()
        Inactivestatusnames = swtStatusObj.getInActiveStatus()
        quickEditDisabledStatuses = closed.keys()+Inactivestatusnames.keys()
        """ #####Customization:: blocking of some statuses for either partner or client if there is customization ##### """
        """ For Now Aqueduct technologies and Comm-works partners have the customization """
        partnerDisabledStatuses = clientDisabledStatuses = ""
        blockstatuses_msps = configobj.getCommConfigValue(configobj.blockstatus_msps)
        print "blockstatuses_msps",blockstatuses_msps
        print "MSPID:",ticketDetails['mId']
        print type(ticketDetails['mId'])
        blockstatuses_clients = configobj.getCommConfigValue(configobj.blockstatus_clients)
        if ticketDetails['mId'] in blockstatuses_msps:
            partnerDisabledStatuses = swtStatusObj.getPartnerBlockedStatuses(ticketDetails['mId'])
            print "partnerDisabledStatuses",partnerDisabledStatuses
        if ticketDetails['cId'] in blockstatuses_clients:
            clientDisabledStatuses = swtStatusObj.getClientBlockedStatuses(ticketDetails['cId'])
        """ ################# End ########################"""
        ActiveStatus = swtStatusObj.getActiveStatus()   
        del ActiveStatus[19]         
        ActiveStatus = ','.join(str(e) for e in ActiveStatus.keys())
        #InActiveStatus = swtStatusObj.getInActiveStatus()
        #del InActiveStatus[11]
        #del InActiveStatus[46]         
        InActiveStatus = ','.join(str(e) for e in Inactivestatusnames.keys())
        allStatuses={'active':ActiveStatus,'inactive':InActiveStatus}
        tktstatus = status
        LastActivityDuration = ticketModelObj.getTicketLastActivity(ticket_id)
        closedFlag = 0
        if int(ticketDetails['tsId']) == 3:
            if int(LastActivityDuration['diff']) > 24:
                closedFlag = 1
            ticketDetails.setdefault('statusDropDownFlag',0)
        else:
            ticketDetails.setdefault('statusDropDownFlag',1)
        ticketDetails.setdefault('closedFlag',closedFlag)
        departments = swdept_obj.departments()
        #departments = mem_cache.get('departments_new')
        #if not departments:
            #departments = departmentObj.departments()
            #departments = Swdepartments.objects.using('ticketRead').only('title','departmentid').order_by('title')
            #mem_cache.set('departments_new', departments, 86400)
        priorities = swpriorities_obj.getPriority()
        #priorities = mem_cache.get('priorities')       
        #if not priorities:
            #priorities = Swticketpriorities.objects.using('ticketRead').only('display_text','priorityid').order_by('displayorder')
            #mem_cache.set('priorities', priorities, 86400)
        swStaff = defaultdict(dict)
        #swStaff = mem_cache.get('swStaff')
        #if not swStaff:
        swStaff = nrStaffObj.getSwStaffByRoster()
            #mem_cache.set('swStaff', swStaff, 86400)
        ticketType = tkttype_obj.getAllTicketTypes()
        #ticketType = mem_cache.get('ticketType')
        #if not ticketType:
            #ticketType = Ntstickettype.objects.using('ticketRead').only('typeid', 'typename').order_by('typename')
            #mem_cache.set('ticketType', ticketType, 86400)  
        searchTags = simplejson.dumps(ticketModelObj.getSearchTags()) 
        ticketTags = {}        
        if (ticketDetails['incidentTags'] != None) :
            ticketTags = ticketDetails['incidentTags'].split(",")                    
        timezones = comObj.getTimezones()
        defaultTimeZone = configobj.getCommConfigValue(configobj.defaultTimeZone)
        ticketDetails.setdefault('timezones',timezones)
        ticketDetails.setdefault('defaultTimeZone',defaultTimeZone)
        """ added extra data into ticket details """
        dataSet['ticketDetail'] = ticketDetails
        dataSet['pUrl'] = comObj.generateVistaraPartnerUrl(int(ticketDetails['mId']))
        dataSet['cUrl'] = comObj.generateVistaraClientUrl(int(ticketDetails['cId']))
        dataSet['dUrl'] = comObj.generateVistaraDeviceUrl(int(ticketDetails['cId']), int(ticketDetails['dId']))
        dataSet['aUrl'] = comObj.generateVistaraAlertUrl(int(ticketDetails['cId']), int(ticketDetails['sccAId']))
        ticketModelObj= CommonTicketModel()

        #emailList = mem_cache.get('emailList') 
        #if not emailList :   
        emailList = simplejson.dumps(ticketModelObj.getEmailContacts())
            #mem_cache.set('emailList', emailList, 86400)
        predefReplies=ticketModelObj.predefinedReplies()
        knowledgebase=ticketModelObj.getKnowledgeBase()
        kbarticles=ticketModelObj.getKbArticles()
        #poststatus = mem_cache.get('newStatus')
        #if not poststatus:
        poststatus = swtStatusObj.getNewStatus()
        datePicker = {}
        tmp = comObj.currentAndYesterDayInPST()
        schedulingTimeFlag = 0
        if int(ticketDetails['tsId']) != 16:
            datePicker['curDate'] = str(tmp[0]['currentTimeInPST'])
            datePicker['yesDate'] = str(tmp[0]['currentTimeInPST']) 
        elif int(ticketDetails['tsId']) == 16 and schedulingTime ==  '':
            datePicker['curDate'] = ''
            datePicker['yesDate'] = str(tmp[0]['currentTimeInPST'])
        else:
            schedulingTimeFlag = 1
            datePicker['curDate'] = schedulingTime
            datePicker['yesDate'] = str(tmp[0]['currentTimeInPST'])
        hmspReasons = ticketModelObj.getHmspReasons()
        ccEmailList = ticketModelObj.getEmailCcmailList(ticket_id)
        eList = ''
        internaleList = ""
        for ccEmail in ccEmailList :
            eList = eList+ccEmail['email']+','
            if '@netenrich.com' in str(ccEmail['email']) :
                internaleList = internaleList+ccEmail['email']+','
        """Client Custom features for partners CDI and Alternative Technology group
            CDI: Appending given email when status is in WFCI/WFPI
            Alternative group of technologies: Appending given email when priority is in Critical """            
        if((int(ticketDetails['tsId']) == 9 or int(ticketDetails['tsId']) == 46) and (int(ticketDetails['mId']) == 109612 or int(ticketDetails['mId']) == 590253) and cdi_supportmail not in eList):
            eList += ","+cdi_supportmail+","
        """ removing this feature as per request"""
        #if(int(ticketDetails['pId']) == 8 and int(ticketDetails['cId'])== 558536 and Electro_Switch_Corp_mail not in eList) :
        #    eList += ","+Electro_Switch_Corp_mail+","
        randomString = ''.join(choice(ascii_uppercase) for i in range(8))
        notification_note = ticketmodel.getFieldNotesOptions()
        notification_button = ticketmodel.getFieldNotesButtons()
        swcustomFieldvalue = ticketmodel.customFeildvalues(ticket_id)
        QOSflag = 0
        integrationcheckflag = 0
        if int(ticketDetails['tyId']) == 14:
            if ticketDetails['sub'].count("[QOS]") > 0 :
                QOSflag = 0                
            elif ticketDetails['sub'].count("[QOS+]") >0:
                QOSflag = 1 
        if int(ticketDetails['tyId']) == 10 or int(ticketDetails['tyId']) == 12 or int(ticketDetails['tyId']) == 13:
            if ticketDetails['psaTid']:
                if ticketDetails['psaTid'] != '0000':
                        integrationcheckflag = 1
        if len(swcustomFieldvalue) ==0:
            customvalue = 0
        else:
            if swcustomFieldvalue[0]['fieldvalue'] !='E-mail':
                customvalue = 1
            else:
                customvalue = 0
        TktUserInfo = {}
        i = 0
        TktUserInfo = mem_cache.get(ticket_id)
        watchinguser_string = ''
        if TktUserInfo:
            if type(TktUserInfo) is str:
                TktUserInfo = json.loads(TktUserInfo)
            for userinfo in TktUserInfo:
                if int(userinfo) != int(request.session['uId']) and i < 5:
                    watchinguser_string += TktUserInfo[userinfo]['userName']+"("+TktUserInfo[userinfo]['timespent']+"), " 
                    i = i+1 
        watchinguser_string = watchinguser_string.rstrip(", ")
        #sort_tktstatus = mem_cache.get('ordered')
        #if not sort_tktstatus:
        sort_tktstatus = swtStatusObj.newOrderStatus()
        msp_flag = configobj.getCommConfigValue(configobj.mspid_checks)
        return render_to_response('ticketView.html', {'msp_flag':msp_flag,'Display':dataSet, 'partnerDisabledStatuses':partnerDisabledStatuses,'clientDisabledStatuses':clientDisabledStatuses,'sort_tktstatus':sort_tktstatus, 'ticketTags':ticketTags,'randomString':randomString,'ccEmailList':eList[:-1],'internaleList':internaleList[:-1],'hmspReasons':hmspReasons,'datePicker':datePicker,'poststatus':poststatus,'searchTags':searchTags,'emailList':emailList,'PredefinedReplies':predefReplies,'knowledgebase':knowledgebase,'kbarticles':kbarticles,'clientName':clientName,'deviceName':device,'incomeAlerttime':incomingAlertTime,'schedulingTime':schedulingTime,'deviceCata':devicata,'Technology':Technology,'createDt':createdDate,'lastUpdate':lastupdated,'tickStatus':ticketStatus,'tktstatus':tktstatus,'priorities':priorities,'departments':departments,'swStaff':swStaff, 'ticketType':ticketType, 'quickEditDisabledStatuses':quickEditDisabledStatuses,'notification_note':notification_note,'notification_button':notification_button,'swcustomFieldvalue':customvalue,'allStatuses':allStatuses,'QOSflag':QOSflag,'integrationcheckflag':integrationcheckflag,'schedulingTimeFlag':schedulingTimeFlag,'watchinguser_string':watchinguser_string},context_instance=RequestContext(request))
    else :
        return authRes
        
def getMappedTicketView(request, ticketId):
    ticketType = tkttype_obj.getAllTicketTypes()
    dataSet = incidentdat_obj.getTicketdetails(ticketId)
    return render_to_response('mappedTicketView.html', {'ticketType':ticketType, 'dataSet':dataSet},context_instance=RequestContext(request))

def getMappedDataAjax(request):
    ticketId = str(request.GET.get('ticketId',False))
    typeid = str(request.GET.get('typeid',False))
    departments = swdept_obj.departments()
    staffDetails = ticketmodel.GetstaffDetails()
    mappedDataAjax = incidentdat_obj.getMappedTicketsDataAjax(ticketId,typeid)
    for key in mappedDataAjax:
        key['deptid'] = departments.get(key['deptid'], 'Not Found')
        key['staffid'] = staffDetails.get(key['staffid'], "Not Found")
        key['created_dt'] = str(datetime.fromtimestamp(int(key['created_dt'])).strftime('%d %b %Y %H:%M'))
        key['lastactivity'] = str(datetime.fromtimestamp(int(key['lastactivity'])).strftime('%d %b %Y %H:%M'))
    mappedDataAjax = simplejson.dumps({'ticketsDataAjax': mappedDataAjax})
    return HttpResponse(mappedDataAjax, content_type="application/json")

def unMapIncidents(request):
    ticketId = request.POST.get('ticketId[]', False)
    dataGiven = incidentdat_obj.unMapAjax(ticketId)
    return HttpResponse(dataGiven)

def getTotalTicketstoMAP(request, ticketId):
    dataSet = incidentdat_obj.getTicketdetails(ticketId)
    return render_to_response('ticketToMap.html', {'dataSet': dataSet}, context_instance=RequestContext(request))

def getticketstomapAjax(request):
    departments = swdept_obj.departments()
    staffDetails = ticketmodel.GetstaffDetails()
    ticketType = tkttype_obj.getAllTicketTypes()
    modTT = {}
    for key in ticketType:
        for k, v in key.iteritems():
            modTT[k] = v
    totalTicketDetails = incidentdat_obj.getOtherTicketsToMap()
    for key in totalTicketDetails:
        key['deptid'] = departments.get(key['deptid'], "Not Found")
        key['staffid'] = staffDetails.get(key['staffid'], "Not Found")
        key['created_dt'] = str(datetime.fromtimestamp(int(key['created_dt'])).strftime('%d %b %Y %H:%M'))
        key['lastactivity'] = str(datetime.fromtimestamp(int(key['lastactivity'])).strftime('%d %b %Y %H:%M'))
        key['typeid'] = modTT.get(key['typeid'], "Not Found")
    totalTicketDetails = simplejson.dumps({'totalTicketDetails': totalTicketDetails})
    return HttpResponse(totalTicketDetails, content_type="application/json")

def mapIncidentsToParent(request):
    pTicket = request.POST.get('pTicket', False)
    cTicket = request.POST.get('cTicket[]', False)
    ticketsInfo = incidentdat_obj.mapTicketsToParent(pTicket, cTicket)
    return HttpResponse(ticketsInfo)

def slaResloution(request):
    tId  =request.POST.get('ticketId')
    dataSet = {}
    if int(tId) > 0:
        sla=ticketmodel.getSlaResloutions(tId)
        if str(sla[0]['respslatime']) != 'NO SLA':
            responsetime = int(sla[0]['respslatime']) 
            dataSet['responseTimeSLA'] = Salmquey.getHours(responsetime)
        else:
            responsetime = 'NO SLA'
            dataSet['responseTimeSLA'] = 'NO SLA'
        if str(sla[0]['resolslatime']) != 'NO SLA':
            resolutiontime = int(sla[0]['resolslatime']) 
            dataSet['resolutionSLA'] = Salmquey.getHours(resolutiontime)
        else:
            resolutiontime = 'NO SLA'
            dataSet['resolutionSLA'] = 'NO SLA'
        resloutiondue = int(sla[0]['resolsladue'])
        respsladue = ''
        if sla[0]['respsladue']:
            respsladue = int(sla[0]['respsladue'])
            dataSet['responseTimeDue'] = Salmquey.getHours(str(respsladue))
        dateFormat =Salmquey.getHours(resloutiondue)
        res =Salmquey.getSLADisplayColumns(resloutiondue,dateFormat)
        dataSet['resolutionDueText'] = res['resolutionDueText']
        status = swtStatusObj.getNewStatus()
        prioritys= Salmquey.priorty()
        dataSet ['prioritys']=prioritys[sla[0]['priorityid']]
        dataSet['status'] = status[sla[0]['statusid']]
        dataSet['af'] = sla[0]['af']
    jsonData = simplejson.dumps({'sampleRes': dataSet})
    return HttpResponse(jsonData, content_type="application/json")
def getPostReplies(request):
    limit = request.POST.get('limit')
    offset = request.POST.get('offset')
    ticket_id = request.POST.get('ticketId')
    attDynamic = request.POST.get('attDynamic','').encode('utf-8')
    lastPostTime = request.POST.get('recentTime')
    notifcation = 'false'
    organizationId = configobj.getCommConfigValue(configobj.NESPID)
    lastPostTime = -1 if lastPostTime == 'false' else lastPostTime
    if int(lastPostTime) < 0:
        url = comObj.ticketingUrls() +'/organizations/'+str(organizationId)+'/incident/'+str(ticket_id)+'/post/'+limit+'/'+offset
    else:
        url = comObj.ticketingUrls() +'/organizations/'+str(organizationId)+'/incident/'+str(ticket_id)+'/post/20/0?dateline='+str(lastPostTime)
    pstReplies = comObj.getAPIResponce(url, "ticket")
    countPReplies = len(pstReplies['Result'])
    if countPReplies >0 and int(lastPostTime) > 0 :
        notifcation = 'true'
    postRepliesList = []
    ticktPostIds = []
    stopPagination = 0
    if pstReplies['Result'] == "No Records Found":
        finalPostReplies = {}
        stopPagination = 1
    else:
        for postReplies in pstReplies['Result']:
            finalPostReplies = {}
            finalPostReplies['email'] = postReplies['email']
            finalPostReplies['content'] = postReplies['content'].encode('utf-8')
            finalPostReplies['fName'] = postReplies['fName']
            finalPostReplies['emailTo'] = postReplies['emailTo']
            finalPostReplies['email'] = postReplies['email']
            finalPostReplies['sTime'] = postReplies['sTime']
            finalPostReplies['bTime'] = postReplies['bTime']
            finalPostReplies['tId'] = postReplies['tId']
            finalPostReplies['tpId'] = postReplies['tpId']
            os.environ["TZ"]="US/Pacific"
            finalPostReplies['utcTimeStampDateLine'] = int(postReplies['dLine'])
            finalPostReplies['dateLine'] = str(datetime.fromtimestamp(int(postReplies['dLine'])).strftime('%d %b %Y %H:%M'))
            ticketModelObj = CommonTicketModel()
            currentMkTime  = ticketModelObj.getCurrentUnixTimestamp()
            finalPostReplies['days'] = comObj.getHourMins(int(currentMkTime) - int(postReplies['dLine']))
            ticktPostIds.append(postReplies['tpId'])
            #staffEmails = mem_cache.get('staffEmails')    
            #if not staffEmails:
            staffEmails = commonObj.getStaffInfo()
                #mem_cache.set('staffEmails', staffEmails, 86400)
            finalPostReplies['class'] = ''
            for staff in staffEmails:
                if postReplies['email'] == staff['value']:
                    finalPostReplies['clas'] = 'avatar-wrap'
                else:
                    finalPostReplies['clas'] = 'avatar-client'
            finalPostReplies['attInfo'] = {}        
            if postReplies.has_key('attachmentinfo') :
                i = 0
                for attachment in postReplies['attachmentinfo'] :
                    finalPostReplies['attInfo'][i]= {}
                    finalPostReplies['attInfo'][i]['flName'] = attachment['flName']
                    finalPostReplies['attInfo'][i]['attId'] = attachment['attId']
                    i += 1
            postRepliesList.append(finalPostReplies)
    jsonData = simplejson.dumps({'postReplies': postRepliesList, 'countPReplies': countPReplies, 'ticketPostId': ticktPostIds, 'stopPagination': stopPagination,'notifcation':notifcation,'url':url})
    return HttpResponse(jsonData, content_type="application/json")
def quickEditTicketInfo(request):
    ticketModelObj= CommonTicketModel()
    validaionMessage = ticketModelObj.formValidation(request,'quickEdit')
    apiInput={}
    if validaionMessage !='':
        apiInput['Result'] = 0
        apiInput['errorMessage'] = validaionMessage
        jsonData = simplejson.dumps(apiInput)
        return HttpResponse(jsonData, content_type="application/json")
    post = request.POST 
    if 'swstaffId' in request.session.keys():
        apiInput['stId']= request.session['swstaffId']
    else:
        return HttpResponseRedirect('/NNCPortal/Login/')
    apiInput['tId']=post['quick_tId']
    if post['quick_deptId']:
        apiInput['deptId']=post['quick_deptId']
    if post['quick_pId']:
        apiInput['pId']=post['quick_pId']
    if post['quick_osId']:
        apiInput['osId']=post['quick_osId']
    apiInput['alType'] = '1'
    if request.POST.getlist('quick_incidentTags','') !=[u'']:
        tags = request.POST.getlist('quick_incidentTags','')
        apiInput['incidenttags']= tags[0]
    tid = post['quick_tId'] 
    tsId = request.POST.get('quick_tsId','')
    if not tid:
        return False  
    if post.get('quick_tsId') == '16':    
        timezoneValue = str(request.POST.get('quick_timezone',''))
        schTime = str(request.POST.get('quick_upDate_scheduledTime',''))
        if schTime != '' and tsId != '':
            apiInput['tsId']=request.POST.get('quick_tsId','')
            if str(timezoneValue) == 'America/Los_Angeles' :
                apiInput['schT'] = schTime
            else : 
                res = comObj.getScheduledTimeZoneConversion(schTime, timezoneValue)
                apiInput['schT'] = res[0]['scheduledtime'].strftime('%Y-%m-%d %H:%M:%S')
        if schTime =='' or apiInput['schT'] == '' or apiInput['schT'] == None or apiInput['schT'] == ' ':
            apiInput['Result'] = 0
            apiInput['errorMessage'] = validaionMessage
            jsonData = simplejson.dumps(apiInput)
            return HttpResponse(jsonData, content_type="application/json")
    elif tsId != '':
        apiInput['tsId'] = tsId
    organizationId = configobj.getCommConfigValue(configobj.NESPID)
    url = comObj.ticketingUrls()+"/organizations/"+str(organizationId)+"/incident/"+str(tid)
    jsonOp = comObj.getPutResponce(url,apiInput,'ticket')
    if jsonOp.find('Edited')>0:
        LastActivityDuration = ticketModelObj.getTicketLastActivity(tid)
        apiInput['Result']= 1
        #apiInput['lastUpdated']= LastActivityDuration['dtString']
        apiInput['lastUpdated']= datetime.fromtimestamp(int(LastActivityDuration['lastactivity']), pytz.timezone("US/Pacific")).strftime('%d %b %Y %H:%M')
    else:
        apiInput['Result']= 0
        apiInput['errorMessage'] = ""
    jsonData = simplejson.dumps(apiInput)
    return HttpResponse(jsonData, content_type="application/json")
def getStatusAndPriorty(request):
    tId  =request.POST.get('ticketId')
    status = swtStatusObj.getNewStatus()
    prioritys= Salmquey.priorty()
    data =  ticketmodel.getPriortyAndStaus(tId)
    statusAndPriorty = {}
    statusAndPriorty ['prioritys']=prioritys[data[0]['priorityid']]
    statusAndPriorty['status'] = status[data[0]['statusid']]
    jsonData = simplejson.dumps({'postReplies':statusAndPriorty})
    return HttpResponse(jsonData, content_type="application/json")
def addUser(request):
    return render_to_response('ticketPost.html', {},context_instance=RequestContext(request))
def addPhone(request):
    return render_to_response('personalDetials.html', {},context_instance=RequestContext(request))
def auditLog(request,ticketid):
        os.environ["TZ"]="US/Pacific" 
        organizationId = configobj.getCommConfigValue(configobj.NESPID)
        logType = configobj.getCommConfigValue(configobj.logType)
        logType = ast.literal_eval(logType) 
        url = comObj.ticketingUrls()+"/organizations/"+str(organizationId)+"/incident/"+str(ticketid)+"/auditlog"
        getAuditlog = comObj.getAPIResponce(url,'ticket')
        if(getAuditlog['HTTP Response Code']=='200 OK'):
            html = ''
            html = '<table class="table table-hover table-bordered" id="tbl_auditlog">'
            html += '<thead><tr><th>Description</th><th>Date</th><th>Timeline</th><th>EntryType</th></tr></thead>'
            html += '<tbody>'
            flag = 0
            if getAuditlog['Result'] != 'No Records Found': 
                for rec in getAuditlog['Result']:
                    flag = flag+1
                    ticketModelObj = CommonTicketModel()
                    currentMkTime  = ticketModelObj.getCurrentUnixTimestamp()
                    listType = logType[int(rec['lType'])] if logType.has_key(int(rec['lType'])) else ''
                    if listType == 'NNC_STAFF':
                        listType = rec['sfName']
                    if  rec['lType'] == '1':
                        listType = rec['sfName']
                    if flag%2 == 0 :
                        html += "<tr class='even'>"
                    else:
                        html += "<tr class='odd'>"
                    html += '<td>'+str(rec['actMsg'].encode('utf-8')).replace(',', ', ')+'</td>'
                    log_date = comObj.timeStampToPST(int(rec['dLine']))
                    if log_date !='' and log_date[0]['pstdate'] != None:
                        html += '<td>'+str(log_date[0]['pstdate'].strftime('%d %b %Y %H:%M'))+'</td>'
                    else:
                        html += '<td></td>'
                    html += '<td>'+comObj.getHourMins(int(currentMkTime) - int(rec['dLine']))+'</td>'
                    html += '<td>'+str(listType)+'</td></tr> '
            else:
                html += '<td>No Records Found</td>'
            html += '</tbody>'
            html += '</table>'
            jsonData = simplejson.dumps({'html':html})
            return HttpResponse(jsonData, content_type="application/json")
        else:
            return False
def getPredefinedReplyData(request):   
    predefid = request.POST.get('predefid')
    ticketModelObj= CommonTicketModel()
    predefineddata = ticketModelObj.getPredefinedReplyData(predefid)    
    return HttpResponse(predefineddata)
def getKbaReplyData(request):    
    kbaid = request.POST.get('kbaid')
    ticketModelObj= CommonTicketModel()
    kbadata = ticketModelObj.getKbaReplyData(kbaid)    
    return HttpResponse(kbadata)
def devicenotes (request):
    clientId = request.GET.get('cId')
    device = ticketmodel.getNotes(int(clientId))
    return render_to_response('devicenotes.html',{ 'device':device },context_instance=RequestContext(request))
def uploadImage (request):
    mediaPath = request.build_absolute_uri().replace(request.get_full_path(), '')+"/static/media/"
    uploadPath = os.path.join(settings.BASE_DIR, "static/media/")
    upfile = request.FILES['file']
    ext = str(upfile.name).split(".")[1]
    newFileName = md5.new(time.strftime('%Y-%m-%d %H:%M:%S')).hexdigest()+'.'+ext
    destination = open(uploadPath+newFileName, 'wb+')
    for chunk in upfile.chunks():
        destination.write(chunk)
    destination.close()
    return HttpResponse(mediaPath+newFileName)
def ticketPostDetails(request):
    ticketPostIds = request.POST.get('tpIds')
    tktId = request.POST.get('ticketId')
    tktPsts = CommonTicketModel()
    tktPosts = tktPsts.getPostReview(tktId)
    ticketDetails = {}
    for postData in tktPosts:
        ticketDetails.setdefault(postData['post_id'], {})
        ticketDetails[postData['post_id']].setdefault('PostData', postData['post_id'])
        ticketDetails[postData['post_id']].setdefault('ticket_id', postData['ticket_id'])
        ticketDetails[postData['post_id']].setdefault('proc_rating', postData['proc_rating'])
        ticketDetails[postData['post_id']].setdefault('tech_rating', postData['tech_rating'])
        ticketDetails[postData['post_id']].setdefault('comm_rating', postData['comm_rating'])
        ticketDetails[postData['post_id']].setdefault('customer_value_rating', postData['customer_value_rating'])
        ticketDetails[postData['post_id']].setdefault('time_rating', postData['time_rating'])
    jsonData = simplejson.dumps({'ticketDetails': ticketDetails})
    return HttpResponse(jsonData, content_type="application/json")
def prepareRatingHtml(rating):
    ratingHtml = {}
    ratingHtml[1]  = '<span class="full" data-toggle="tooltip" title="Below Expection"> </span><span class="star" data-toggle="tooltip" title="Below Expection"> </span><span class="star" data-toggle="tooltip" title="Below Expection"></span>'
    ratingHtml[2] = '<span class="full" data-toggle="tooltip" title="Meets Expection"></span><span class="full" data-toggle="tooltip" title="Meets Expection"></span><span class="star" data-toggle="tooltip" title="Meets Expection"></span>'
    ratingHtml[3] = '<span class="full" data-toggle="tooltip" title="Exceeds Expection"></span><span class="full" data-toggle="tooltip" title="Exceeds Expection"></span><span class="full" data-toggle="tooltip" title="Exceeds Expection"></span>'
    return ratingHtml[rating]
def getreviewForPost(request):
    ticketId = request.GET.get('tktId',False)
    postId = request.GET.get('tktPstId',False)
    if postId != False:
        reviewType = "Post"
    else:
        reviewType = "Ticket"
    tktRevwPsts = CommonTicketModel()
    reviewData = tktRevwPsts.getReviewforPost(ticketId, postId)
    ticketDetails = {}
    i=0
    for postData in reviewData:
        ticketDetails.setdefault(i,{})
        staffName = Swstaff.objects.using('ticketRead').only('fullname').filter(staffid = postData['reviewer_id'])
        for stffName in staffName:
            ticketDetails[i].setdefault('staffname', stffName.fullname)
        ticketDetails[i].setdefault('PostData', postData['post_id'])
        ticketDetails[i].setdefault('reviewer_id', postData['reviewer_id'])
        ticketDetails[i].setdefault('review_date', str(datetime.fromtimestamp(int(postData['review_date'])).strftime('%d %b %Y %H:%M')))
        ticketDetails[i].setdefault('proc_rating', prepareRatingHtml(postData['proc_rating']))
        ticketDetails[i].setdefault('tech_rating', prepareRatingHtml(postData['tech_rating']))
        ticketDetails[i].setdefault('comm_rating', prepareRatingHtml(postData['comm_rating']))
        ticketDetails[i].setdefault('customer_value_rating', prepareRatingHtml(postData['customer_value_rating']))
        ticketDetails[i].setdefault('time_rating', prepareRatingHtml(postData['time_rating']))
        ticketDetails[i].setdefault('comments', postData['comments'])
        ticketDetails[i].setdefault('review_time', postData['review_time'])
        i=i+1
    return render_to_response('_reviewData.html',{'ReviewDetails': ticketDetails, 'reviewType': reviewType})
def loadReviewForm(request):
    flagForjsHide = 0
    if request.method == 'POST':
        tktId = request.POST.get('ticketId')
        pstId = request.POST.get('postId')
    else:
        tktId = request.GET.get('ticketId')
        flagForjsHide = 1
        pstId = ''
    postMailId = ''
    if pstId:
        tktRevwPsts = CommonTicketModel()
        postMailsId = tktRevwPsts.getStaffEmailForPosts(pstId)
        for pstMailId in postMailsId:
            postMailId = pstMailId['email']
    else:
        userId = IncidentData.objects.using('ticketRead').only('staffid').filter(ticketid = tktId)
        for usrId in userId:
            staffid = usrId.staffid
        postMailsId = NrStaff.objects.using('rosterRead').only('staff_email').filter(swstaff_id = staffid)
        for mailId in postMailsId:
            postMailId = mailId.staff_email
    comSchObj = CommonScheduleModel()
    staffInfo = comSchObj.getStaffInfo()
    staffInfo = simplejson.dumps(staffInfo)
    ticketDetails = {}
    return render_to_response('_form_ticket_post_review.html',{'ReviewDetails': ticketDetails, 'tktId': tktId, 'pstId': pstId, 'reviewEmailList': staffInfo, 'postMailId': postMailId,'flagForjsHide':flagForjsHide})
def saveReviewData(request):
    ticketModelObj = CommonTicketModel()
    currentMkTime  = ticketModelObj.getCurrentUnixTimestamp()
    postId = ''
    if request.method == 'POST':
        postId = str(request.POST.get('postId'))
        reviewData = {}
        reviewData['post_id'] = str(request.POST.get('postId'))
        reviewData['review_date'] = currentMkTime
        reviewData['reviewer_id'] = request.session['swstaffId']
        reviewData['proc_rating'] = int(request.POST.get('PostReviews_proc_rating'))
        reviewData['tech_rating'] = int(request.POST.get('PostReviews_tech_rating'))
        reviewData['comm_rating'] = int(request.POST.get('PostReviews_comm_rating'))
        reviewData['time_rating'] = int(request.POST.get('PostReviews_time_rating'))
        reviewData['customer_value_rating'] = int(request.POST.get('PostReviews_customer_value_rating'))
        reviewData['comments'] = str(request.POST.get('PostReviews_comments').encode('utf-8'))
        reviewData['review_time'] = str(request.POST.get('PostReviews_review_time'))
        reviewData['mail_sent_to'] = str(request.POST.get('PostReviews_reviewMails'))
        reviewData['ticket_id'] = str(request.POST.get('ticketId'))
    else :
        reviewData = {}
        reviewData['review_date'] = currentMkTime
        reviewData['reviewer_id'] = request.session['swstaffId']
        reviewData['proc_rating'] = int(request.GET.get('PostReviews_proc_rating'))
        reviewData['tech_rating'] = int(request.GET.get('PostReviews_tech_rating'))
        reviewData['comm_rating'] = int(request.GET.get('PostReviews_comm_rating'))
        reviewData['time_rating'] = int(request.GET.get('PostReviews_time_rating'))
        reviewData['customer_value_rating'] = int(request.GET.get('PostReviews_customer_value_rating'))
        reviewData['comments'] = str(request.GET.get('PostReviews_comments').encode('utf-8'))
        reviewData['review_time'] = str(request.GET.get('PostReviews_review_time'))
        reviewData['mail_sent_to'] = str(request.GET.get('PostReviews_reviewMails'))
        reviewData['ticket_id'] = str(request.GET.get('ticketId'))
    commMM = CommonModelMethods()
    postRvwId = commMM.insertRecord(reviewData, 'post_reviews', 'ticketWrite')
    if postRvwId:
        status = "Success"
    else:
        status = "Failed"
    '''send review as mail'''
    reviewer = request.session['fullName']
    if postId:
        tktRevwPsts = CommonTicketModel()
        twTb = tktRevwPsts.getStaffTwTb(postId)
        for twTbDetails in twTb:
            if twTbDetails['timespent']:
                ts = twTbDetails['timespent']
            else:
                ts = 0
            if twTbDetails['timebillable']:
                tb = twTbDetails['timebillable']
            else:
                tb = 0
            posts = twTbDetails['contents'].encode('utf-8')
            staffNam = twTbDetails['fullname']
    else:
        posts = ''
        tktRevwPsts = CommonTicketModel()
        twTb = tktRevwPsts.getSumOfTimeWorkedAndBillable(reviewData['ticket_id'])
        for twTbDetails in twTb:
            if twTbDetails['timeworked']:
                ts = twTbDetails['timeworked']
            else:
                ts = 0
            if twTbDetails['timebillable']:
                tb = twTbDetails['timebillable']
            else:
                tb = 0
            staffNam = reviewData['mail_sent_to']
    tiktDetailss= tktRevwPsts.getTicketInfo(reviewData['ticket_id'])
    for tktDetailss in tiktDetailss:
        subject = tktDetailss['subject']
    date = str(datetime.fromtimestamp(int(reviewData['review_date'])).strftime('%d %b %Y %H:%M'))
    revwrMail = request.session['uName']
    mail_sent_to = reviewData['mail_sent_to'].split(',')
    mail_sent_to.append(revwrMail)
    ''' email '''
    inputData = {}
    html1 = ticketModelObj.ticketReviewMail(staffNam, postId, reviewData, ts, tb, reviewer, date, subject, posts)
    inputData['templateName']='mail_post_review.html'
    inputData['to'] = mail_sent_to
    inputData['bcc'] = []
    inputData['subject'] = 'Ticket Review Details'
    comObj.sendEmail(html1,inputData)
    jsonData = simplejson.dumps({'status': status})
    return HttpResponse(jsonData, content_type="application/json")
def getEsclationMatrixis(request):
    if request.POST:
        post = request.POST
        mspId = post.get('mspId','')
        clientId = post.get('clientId','')
        deviceId = post.get('deviceId','')
        EsclationMatrixInfo = ticketmodel.getEscalationMatrixDetails(mspId,clientId,deviceId)
        html =''
        if EsclationMatrixInfo.has_key('EscalationMatrixinfo'):  
            users =0
            for  key,val in EsclationMatrixInfo.iteritems(): 
                if key != 'EscalationMatrixinfo':
                    k =0
                    matrixid = 0
                    for kr,newdata_escui in val.iteritems():
                        escalation_tz_name = EsclationMatrixInfo['EscalationMatrixinfo'][key][k]['tz_name']
                        escalation_tz_label = EsclationMatrixInfo['EscalationMatrixinfo'][key][k]['tz_label']
                        toTimeZone = escalation_tz_label.split(' ') 
                        toTimeZone = toTimeZone[1]
                        currrentTimeres = comObj.getCurrentTimeandDay('+00:00',toTimeZone) 
                        curdate = str(currrentTimeres['currentDate'].strftime("%a %H:%M:%S"))
                        curdate = curdate.split(' ')
                        ticktime = ''.join(curdate[1])
                        tickday = ''.join(curdate[0])
                        html += '<div class="matix" id="MatrixInfo"><br>'
                        html += 'Escalation Time Zone&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: '+str(escalation_tz_name)+'<br>'
                        html += 'Escalation Current Time&nbsp;: '+str(currrentTimeres['time'])+'<br>'
                        html += 'Escalation Current Day&nbsp;&nbsp;: '+str(currrentTimeres['day'])+'<br>'
                        if key == 'device':
                            divkey =0
                            html += '<b>'+str(EsclationMatrixInfo['EscalationMatrixinfo'][key][k]['Name'])+'</b><br>'
                            html += '<div class="pane collapsed">'+str(EsclationMatrixInfo['EscalationMatrixinfo'][key][k]['Description'])+'| Device level Matrix <a href="javascript:void(0)"><i id="showMatrix" class=" fa fa-arrow-down"></i></a>'
                        elif key == 'devicegroup':
                            divkey=1
                            html += '<b>'+str(EsclationMatrixInfo['EscalationMatrixinfo'][key][k]['Name'])+'</b><br>'
                            html += '<div class="pane collapsed">'+str(EsclationMatrixInfo['EscalationMatrixinfo'][key][k]['Description'])+' | Device Group level Matrix <a href="javascript:void(0)"><i id="showMatrix" class=" fa fa-arrow-down"></i></a>'
                        elif key == 'Location':
                            divkey=2
                            html += '<b>'+str(EsclationMatrixInfo['EscalationMatrixinfo'][key][k]['Name'])+'</b><br>'
                            html += '<div class="pane collapsed">'+str(EsclationMatrixInfo['EscalationMatrixinfo'][key][k]['Description'])+'| Site level Matrix <a href="javascript:void(0)"><i id="showMatrix" class=" fa fa-arrow-down"></i></a>'                    
                        elif key == 'client':
                            divkey=3
                            html += '<b>'+str(EsclationMatrixInfo['EscalationMatrixinfo'][key][k]['Name'])+'</b><br>'
                            html += '<div class="pane collapsed">'+str(EsclationMatrixInfo['EscalationMatrixinfo'][key][k]['Description'])+'| Client level Matrix <a href="javascript:void(0)"><i id="showMatrix" class=" fa fa-arrow-down"></i></a>'
                        elif key == 'msp':
                            divkey=4
                            html += '<b>'+str(EsclationMatrixInfo['EscalationMatrixinfo'][key][k]['Name'])+'</b><br>'
                            html += '<div class="pane collapsed">'+str(EsclationMatrixInfo['EscalationMatrixinfo'][key][k]['Description'])+'| VAR level Matrix <a href="javascript:void(0)"><i id="showMatrix" class=" fa fa-arrow-down"></i></a>'
                        s=1
                        data=0
                        for keys,scheduledata in newdata_escui.iteritems():
                            shiftsno = 0
                            shift=0
                            html += '<table class="table  table-bordered" id="schedules'+str(keys)+'>'
                            html += '<thead><tr><th >Level</th><th>Schedule Name</th>'       
                            for shiftskey,shiftsdata in scheduledata.iteritems():
                                if shiftskey == shift:
                                    shiftname = str(scheduledata[shift]['ShiftName'])
                                    days = str(scheduledata[shift]['days'])
                                    datetime1 = str(scheduledata[shift]['datetime'])
                                    shiftid = str(scheduledata[shift]['Shiftid'])
                                    if shift !=0:
                                        html += '<tr id="schedules'+str(shiftsno)+'">'
                                        html += '<thead><td colspan ="2">'
                                    html += '<th>Shift Name</th>'
                                    html += '<th >Days</th>'
                                    html += '<th>Time</th>'
                                    html += '<th>User</th>'
                                    html += '<th>Email</th></td></thead></tr>'            
                                    trbgclass = "shiftlevelbgremove"
                                    timeduration  = datetime1
                                    timeduration  = timeduration.replace("From: ",'')
                                    shiftdateparts = timeduration.split(" To: ")
                                    from datetime import timedelta
                                    startT = shiftdateparts[0].split(':')
                                    endT = shiftdateparts[1].split(':')
                                    ticktime1 = ticktime.split(':')
                                    sstarttime = timedelta(hours=int(startT[0]),minutes=int(startT[1]), seconds=int(startT[2])).total_seconds()
                                    sendtime = timedelta(hours=int(endT[0]),minutes=int(endT[1]), seconds=int(endT[2])).total_seconds()
                                    curdaytime = timedelta(hours=int(ticktime1[0]),minutes=int(ticktime1[1]), seconds=int(ticktime1[2])).total_seconds() #'09:00:00'
                                    weedays = {"Mon" : 0,"Tue" : 1,"Wed" : 2,"Thu" : 3,"Fri" : 4,"Sat" : 5,"Sun" : 6}
                                    weedaysindex = { 0:"Mon",1:"Tue",2:"Wed",3:"Thu",4:"Fri",5:"Sat",6:"Sun" }
                                    pos = days.find(tickday)
                                    if int(sstarttime) < int(sendtime):  #Business Hours
                                        if pos != '-1': #Day Matched
                                            if (curdaytime > sstarttime) and  (curdaytime < sendtime):
                                                trbgclass =  "shiftlevelbg"
                                    else: #After Business Hours
                                        if (curdaytime > sstarttime) or (curdaytime < sendtime):
                                            if curdaytime >  sstarttime:
                                                if pos != '-1': #Day Matched
                                                    trbgclass =  "shiftlevelbg"
                                            else:
                                                dayindex = weedays[tickday]
                                                dayindex = dayindex - 1 
                                                if dayindex == '-1':
                                                    dayindex = 6
                                                    checktickday = weedaysindex[dayindex]
                                                    checkpos = days.find(checktickday)
                                                    if checkpos != -1:  #Day Matched
                                                        trbgclass =  "shiftlevelbg"
                                    html += '<tbody><tr class="RowToClick '+str(trbgclass)+'" >'
                                    if shift == 0:
                                        html += '<td><input type="checkbox" />'
                                        html += '<span class="lbl padding-8">'+str(s)+'</span></td>'
                                        html += '<td> '+str(''.join([i if ord(i) < 128 else ' ' for i in scheduledata['ScheduleName']]))+'</td>' 
                                    else:
                                        html += '<td colspan ="2">'
                                    html += '<td>'+str(shiftname)+'<i class="icon-chevron-down"></i></td>'
                                    html += '<td>'+str(days)+'</td>'
                                    html += '<td>'+str(datetime1)+'</td>'
                                    shiftdiv ='Shift'+str(s)+str(shift)+str(divkey)+str(k)
                                    shift = shift +1
                                    shiftUsersInfo = comObj.getEscalationUsers(shiftid)
                                    usernames     = ""
                                    useremails     = ""
                                    brline = '</br>'
                                    for keyuser,shiftsinfo in shiftUsersInfo.iteritems():
                                        usernames += str(shiftUsersInfo[keyuser]['User'])+str(brline)
                                        useremails += str(shiftUsersInfo[keyuser]['Email'])+str(brline)
                                    
                                    html += '<td>'+str(usernames)+'</td>'
                                    html += '<td>'+str(useremails)+'</td></tr>'
                                    html += '<tr>'
                                    html += '<td colspan="2"></td><td colspan="5">'
                                    html += '<table class="table table-bordered"><thead><tr class="'+str(trbgclass)+'"><th><input type="checkbox" /><span class="lbl padding-8"></span></th>'
                                    html += '<th>User</th><th>Email</th><th >Phone</th><th>Mobile</th><th>Time Zone</th></tr></thead><tbody>'
                                    for keyuser,shiftsinfo in shiftUsersInfo.iteritems():
                                        selected = "selected" if users and users == 0 else  ""
                                        usermailid= users
                                        html += '<tr class="'+str(trbgclass)+'">'
                                        html += '<td><input type="checkbox" name="esc_mail[]" id="esc_mail" value="'+str(shiftUsersInfo[keyuser]['Email'])+'" />'
                                        html += '<span class="lbl padding-8"></span></td>'
                                        html += '<td>'+str(shiftUsersInfo[keyuser]['User'])+'</td>'
                                        html += '<td >'+str(shiftUsersInfo[keyuser]['Email'])+'</td>'
                                        html += '<td>'+str(shiftUsersInfo[keyuser]['phone_number'])+'</td>'
                                        html += '<td>'+str(shiftUsersInfo[keyuser]['mobile_number'])+'</td>'
                                        html += '<td>'+str(shiftUsersInfo[keyuser]['time_zone'])+'</td></tr>'
                                        users = users+1
                                    html +=  '</tbody></table></td></tr></tbody>'
                                shiftsno = shiftsno + 1
                            s = s+1
                        html += '</table></table></div></div>'
        else:
            html += '<div style="display: block;" class="matrix"'
            html += '<table align="center">'
            html += '<tr><td><b>No Matrices Found</b></td></tr></table></div>'  
        jsonData = simplejson.dumps({'html':html})
        return HttpResponse(jsonData, content_type="application/json")

#request to get escalation details to the userinterface
def getEsclationMatrixResult(request):
    post = request.POST
    mspId = post.get('mspId',False)
    clientId = post.get('clientId',False)
    deviceId = post.get('diviceId',False)
    weekdaysArr = ['sun','mon','tue','wed','thu','fri','sat']
    neZonelist = {'Kwajalein':'(GMT-12:00) International Date Line West','Pacific/Midway':'(GMT-11:00) Midway Island','Pacific/Samoa':'(GMT-11:00) Samoa','Pacific/Honolulu':'(GMT-10:00) Hawaii',
  'America/Anchorage':'(GMT-09:00) Alaska','America/Los_Angeles':'(GMT-08:00) Pacific Time (US &amp; Canada)','America/Tijuana':'(GMT-08:00) Tijuana, Baja California','America/Denver':'(GMT-07:00) Mountain Time (US &amp; Canada)',
  'America/Chihuahua':'(GMT-07:00) Chihuahua','America/Mazatlan':'(GMT-07:00) Mazatlan','America/Phoenix':'(GMT-07:00) Arizona','America/Regina':'(GMT-06:00) Saskatchewan','America/Tegucigalpa':'(GMT-06:00) Central America',
  'America/Chicago':'(GMT-06:00) Central Time (US &amp; Canada)','America/Mexico_City':'(GMT-06:00) Mexico City','America/Monterrey':'(GMT-06:00) Monterrey','America/New_York':'(GMT-05:00) Eastern Time (US &amp; Canada)',
  'America/Bogota':'(GMT-05:00) Bogota','America/Lima':'(GMT-05:00) Lima','America/Rio_Branco':'(GMT-05:00) Rio Branco','America/Indiana/Indianapolis':'(GMT-05:00) Indiana (East)','America/Caracas':'(GMT-04:30) Caracas',
  'America/Halifax':'(GMT-04:00) Atlantic Time (Canada)','America/Manaus':'(GMT-04:00) Manaus','America/Santiago':'(GMT-04:00) Santiago','America/La_Paz':'(GMT-04:00) La Paz','America/St_Johns':'(GMT-03:30) Newfoundland',
  'America/Argentina/Buenos_Aires':'(GMT-03:00) Georgetown','America/Sao_Paulo':'(GMT-03:00) Brasilia','America/Godthab':'(GMT-03:00) Greenland','America/Montevideo':'(GMT-03:00) Montevideo','Atlantic/South_Georgia':'(GMT-02:00) Mid-Atlantic',
  'Atlantic/Azores':'(GMT-01:00) Azores','Atlantic/Cape_Verde':'(GMT-01:00) Cape Verde Is.','Europe/Dublin':'(GMT) Dublin','Europe/Lisbon':'(GMT) Lisbon','Europe/London':'(GMT) London','Africa/Monrovia':'(GMT) Monrovia',
  'Atlantic/Reykjavik':'(GMT) Reykjavik','Africa/Casablanca':'(GMT) Casablanca','Europe/Belgrade':'(GMT+01:00) Belgrade','Europe/Bratislava':'(GMT+01:00) Bratislava','Europe/Budapest':'(GMT+01:00) Budapest',
  'Europe/Ljubljana':'(GMT+01:00) Ljubljana','Europe/Prague':'(GMT+01:00) Prague','Europe/Sarajevo':'(GMT+01:00) Sarajevo','Europe/Skopje':'(GMT+01:00) Skopje','Europe/Warsaw':'(GMT+01:00) Warsaw','Europe/Zagreb':'(GMT+01:00) Zagreb',
  'Europe/Brussels':'(GMT+01:00) Brussels','Europe/Copenhagen':'(GMT+01:00) Copenhagen','Europe/Madrid':'(GMT+01:00) Madrid','Europe/Paris':'(GMT+01:00) Paris','Africa/Algiers':'(GMT+01:00) West Central Africa','Europe/Amsterdam':'(GMT+01:00) Amsterdam',
  'Europe/Berlin':'(GMT+01:00) Berlin','Europe/Rome':'(GMT+01:00) Rome','Europe/Stockholm':'(GMT+01:00) Stockholm','Europe/Vienna':'(GMT+01:00) Vienna','Europe/Minsk':'(GMT+02:00) Minsk','Africa/Cairo':'(GMT+02:00) Cairo',
  'Europe/Helsinki':'(GMT+02:00) Helsinki','Europe/Riga':'(GMT+02:00) Riga','Europe/Sofia':'(GMT+02:00) Sofia','Europe/Tallinn':'(GMT+02:00) Tallinn','Europe/Vilnius':'(GMT+02:00) Vilnius','Europe/Athens':'(GMT+02:00) Athens',
  'Europe/Bucharest':'(GMT+02:00) Bucharest','Europe/Istanbul':'(GMT+02:00) Istanbul','Asia/Jerusalem':'(GMT+02:00) Jerusalem','Asia/Amman':'(GMT+02:00) Amman','Asia/Beirut':'(GMT+02:00) Beirut','Africa/Windhoek':'(GMT+02:00) Windhoek',
  'Africa/Harare':'(GMT+02:00) Harare','Asia/Kuwait':'(GMT+03:00) Kuwait','Asia/Riyadh':'(GMT+03:00) Riyadh','Asia/Baghdad':'(GMT+03:00) Baghdad','Africa/Nairobi':'(GMT+03:00) Nairobi','Asia/Tbilisi':'(GMT+03:00) Tbilisi',
  'Europe/Moscow':'(GMT+03:00) Moscow','Europe/Volgograd':'(GMT+03:00) Volgograd','Asia/Tehran':'(GMT+03:30) Tehran','Asia/Muscat':'(GMT+04:00) Muscat','Asia/Baku':'(GMT+04:00) Baku','Asia/Yerevan':'(GMT+04:00) Yerevan',
  'Asia/Yekaterinburg':'(GMT+05:00) Ekaterinburg','Asia/Karachi':'(GMT+05:00) Karachi','Asia/Tashkent':'(GMT+05:00) Tashkent','Asia/Kolkata':'(GMT+05:30) Calcutta','Asia/Colombo':'(GMT+05:30) Sri Jayawardenepura','Asia/Katmandu':'(GMT+05:45) Kathmandu',
  'Asia/Dhaka':'(GMT+06:00) Dhaka','Asia/Almaty':'(GMT+06:00) Almaty','Asia/Novosibirsk':'(GMT+06:00) Novosibirsk','Asia/Rangoon':'(GMT+06:30) Yangon (Rangoon)','Asia/Krasnoyarsk':'(GMT+07:00) Krasnoyarsk','Asia/Bangkok':'(GMT+07:00) Bangkok',
  'Asia/Jakarta':'(GMT+07:00) Jakarta','Asia/Brunei':'(GMT+08:00) Beijing','Asia/Chongqing':'(GMT+08:00) Chongqing','Asia/Hong_Kong':'(GMT+08:00) Hong Kong','Asia/Urumqi':'(GMT+08:00) Urumqi','Asia/Irkutsk':'(GMT+08:00) Irkutsk',
  'Asia/Ulaanbaatar':'(GMT+08:00) Ulaan Bataar','Asia/Kuala_Lumpur':'(GMT+08:00) Kuala Lumpur','Asia/Singapore':'(GMT+08:00) Singapore','Asia/Taipei':'(GMT+08:00) Taipei','Australia/Perth':'(GMT+08:00) Perth','Asia/Seoul':'(GMT+09:00) Seoul',
  'Asia/Tokyo':'(GMT+09:00) Tokyo','Asia/Yakutsk':'(GMT+09:00) Yakutsk','Australia/Darwin':'(GMT+09:30) Darwin','Australia/Adelaide':'(GMT+09:30) Adelaide','Australia/Canberra':'(GMT+10:00) Canberra','Australia/Melbourne':'(GMT+10:00) Melbourne',
  'Australia/Sydney':'(GMT+10:00) Sydney','Australia/Brisbane':'(GMT+10:00) Brisbane','Australia/Hobart':'(GMT+10:00) Hobart','Asia/Vladivostok':'(GMT+10:00) Vladivostok','Pacific/Guam':'(GMT+10:00) Guam','Pacific/Port_Moresby':'(GMT+10:00) Port Moresby',
  'Asia/Magadan':'(GMT+11:00) Magadan','Pacific/Fiji':'(GMT+12:00) Fiji','Asia/Kamchatka':'(GMT+12:00) Kamchatka','Pacific/Auckland':'(GMT+12:00) Auckland','Pacific/Tongatapu':'(GMT+13:00) Nukualofa'}
#     #todo : need to remove
#     deviceId = 2608548
#     clientId = 597428
#     mspId = 591629
    newEscData = {}
    if deviceId :
        newEscData['device'] = {}
        #Getting escalation ids for device level
        devLevel = escaObj.getEscalationDeviceLevel(deviceId)
        for idx,device in enumerate(devLevel) :
            newEscData['device'][idx] = {}
            newEscData['device'][idx]['id'] = device['escalationId'] 
        #Getting Device group id for device
        devGrpIds = escaObj.getDevGrpIds(deviceId)
        newEscData['devicegroup'] = {}
        for devicegrp in devGrpIds :
            if devicegrp['groupid'] :
                devGrpLevel = escaObj.getEscalationDeviceGrpLevel(devicegrp['groupid'])
                for index,grpEsca in enumerate(devGrpLevel) :
                    newEscData['devicegroup'][index] = {}
                    newEscData['devicegroup'][index]['id'] = grpEsca['escalationId']
        #Getting Location id for device id
        devLocIds = escaObj.getDevLocIds(deviceId)
        newEscData['location'] = {}
        for devLocation in devLocIds :
            if devLocation['locationid'] :
                devLocLevel = escaObj.getEscalationDeviceLocLevel(devLocation['locationid'])
                for index,locEsca in enumerate(devLocLevel) :
                    newEscData['location'][index] = {}
                    newEscData['location'][index]['id'] = locEsca['escalationId']
    if clientId :
        newEscData['client'] = {}
        clientLevel = escaObj.getEscalationClientLevel(clientId)
        for index,clientEsca in enumerate(clientLevel) :
            newEscData['client'][index] = {}
            newEscData['client'][index]['id'] = clientEsca['escalationId']
    if mspId :
        newEscData['msp'] = {}
        mspLevel = escaObj.getEscalationMspLevel(mspId)
        for index,mspEsca in enumerate(mspLevel) :
            newEscData['msp'][index] = {}
            newEscData['msp'][index]['id'] = mspEsca['escalationId']
    ecalationMatrixInfo = {}
    for key2,newescid in newEscData.iteritems():
        k=matrix=0
        if newescid :
            ecalationMatrixInfo[key2] = {}
        for key1,data_esc in newescid.iteritems() :
            newEscData = {}
            newEscData['Weekdays'] = {}
            newEscData['Daterange'] = {}
            ValidateFlag = escaObj.validateEscid(data_esc['id'])
            if not ValidateFlag:
                continue
            #Query for DateRange Shifts 
            dateRanShi = escaObj.getDateRangeShifts(data_esc['id'])
            for shift in dateRanShi :
                newEscData['Daterange'][shift['scheduleId']] = shift['shiftId']
            
            #Query for Weekdays Shifts
            weekRanShi = escaObj.getWeekDaysShifts(data_esc['id'])
            for shift in weekRanShi :
                newEscData['Weekdays'][shift['scheduleId']] = shift['shiftId']
            #escalataion time zone details
            timeDet = escaObj.getTimeZoneDetails(data_esc['id'])
            ecalationMatrixInfo[key2][matrix] = {}
            for tdetails in timeDet :
                ecalationMatrixInfo[key2][matrix]['Name'] = tdetails['name']
                ecalationMatrixInfo[key2][matrix]['Description'] = tdetails['description']
                ecalationMatrixInfo[key2][matrix]['tz_name'] = tdetails['tz_name']
                ecalationMatrixInfo[key2][matrix]['tz_label'] = tdetails['tz_label']
            if 'tz_name' in ecalationMatrixInfo[key2][matrix]:
                timeZone = ecalationMatrixInfo[key2][matrix]['tz_name'] 
            else:
                timeZone = 'US/Pacific'
            sceduledIDs = []
            #get esculation schedule id's
            schids = escaObj.getScheduleIds(data_esc['id'])
            for sch in schids :
                sceduledIDs.append(sch['scheduleId'])
            schIndex = -1
            for sInd,schId in enumerate(sceduledIDs) :                
                schIndex += 1
                deviceArray = devicegroupArray = clientArray = mspArray = locationArray = []
                ecalationMatrixInfo[key2][matrix][schIndex] = {}
                ecalationMatrixInfo[key2][matrix][schIndex][schId] = {}
                ecalationMatrixInfo[key2][matrix][schIndex][schId]['deviceArray'] = ''
                ecalationMatrixInfo[key2][matrix][schIndex][schId]['devicegroupArray'] = ''
                ecalationMatrixInfo[key2][matrix][schIndex][schId]['locationArray'] = ''
                ecalationMatrixInfo[key2][matrix][schIndex][schId]['clientArray'] = ''
                ecalationMatrixInfo[key2][matrix][schIndex][schId]['mspArray'] = ''
                #get schedule infomation
                schInfo = escaObj.getScheduleInfo(schId)
                for schres in schInfo :
                    ecalationMatrixInfo[key2][matrix][schIndex][schId]['ScheduleName'] = schres['name']
                    ecalationMatrixInfo[key2][matrix][schIndex][schId]['Count'] = schres['repeat_count']
                    ecalationMatrixInfo[key2][matrix][schIndex][schId]['Freq'] = str(schres['repeat_freq'])
                k = 0
                #get shiftcount of scheduleid
                schCount = escaObj.getSchCount(schId)
                ecalationMatrixInfo[key2][matrix][schIndex][schId]['shiftcount'] = schCount[0]['count']
                shiftsres = {}
                shiftsres[sInd] = {}
                #get shift details
                shiftDet = escaObj.getShiftDetails(schId)
                for sDet in shiftDet :
                    shiftsres[sInd][k] = {}
                    shiftsres[sInd][k]['id'] = sDet['id']
                    shiftsres[sInd][k]['name'] = sDet['name'] 
                    if int(sDet['shift_type']) == 1 :
                        #get shift details when type is 1
                        stDetails = escaObj.getShiftTypeDetails(sDet['escalation_shift_type_weekday_id'])
                        for stDet in stDetails :
                            shiftsres[sInd][k]['datetime'] = "From: "+str(stDet['start_time'])+" To: "+str(stDet['end_time'])
                            day_string = ''
                            for day in weekdaysArr :
                                flag = day+'_flag'
                                if int(stDet[flag]) == 1 :
                                    day_string += day.title()+','
                        
                        day_string = day_string[:-1]
                        shiftsres[sInd][k]['days'] = day_string
                    elif int(sDet['shift_type']) == 2 :
                        #get shift details when type is 2
                        shiftDet = escaObj.getShiftTypeDetails2(sDet['escalation_shift_type_datarange_id']) 
                        for sDet in shiftDet :
                            shiftsres[sInd][k]['datetime'] = "From: "+str(sDet['start_datetime'])+" To: "+str(sDet['end_datetime'])
                    k += 1
                
                i=j=0
                for shkey,shInfo in shiftsres.iteritems() :
                    for shkey2,shifts in shInfo.iteritems() :
                        trbgclass = False
                        os.environ["TZ"]= timeZone
                        ticktime = datetime.now().time().strftime('%H:%M:%S')
                        tickday = datetime.now().strftime("%A")[:3]
                        shiftDatetime = str(shifts['datetime']).replace("From: ","")   
                        shiftdateparts = shiftDatetime.split(' To: ')
                        sstarttime = datetime.strptime(shiftdateparts[0],'%H:%M:%S')
                        sendtime = datetime.strptime(shiftdateparts[1],'%H:%M:%S')
                        curdaytime = datetime.strptime(ticktime,'%H:%M:%S')
                        weedays = {"Mon":0,"Tue":1,"Wed":2,"Thu":3,"Fri":4,"Sat":5,"Sun":6}
                        weedaysindex = dict((value,key) for key,value in weedays.iteritems())
                        if sstarttime < sendtime :
                            if tickday in str(shifts['days']) :
                                if curdaytime > sstarttime and curdaytime < sendtime :
                                    trbgclass = True
                        else :
                            if curdaytime > sstarttime or curdaytime < sendtime :
                                if curdaytime > sstarttime :
                                    if tickday in str(shifts['days']) :
                                        trbgclass = True
                                else :
                                    dayindex = int(weedays[tickday])
                                    dayindex -= 1
                                    if dayindex == -1 :
                                        dayindex = 6
                                    checktickday = weedaysindex[dayindex]
                                    if checktickday in str(shifts['days']) :
                                        trbgclass = True
                        ecalationMatrixInfo[key2][matrix][schIndex][schId][i] = {}
                        ecalationMatrixInfo[key2][matrix]['ticktime'] = ticktime
                        ecalationMatrixInfo[key2][matrix]['tickday'] = tickday
                        if trbgclass :
                            ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['inShift'] = trbgclass
                        else :
                            ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['inShift'] = trbgclass
                        ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['ShiftName'] = shifts['name']
                        ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['datetime'] = shifts['datetime']
                        ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['days'] = shifts['days']
                        ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['Shiftid'] = shifts['id']
                        ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['userDetails'] = ''
                        ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['emailDetails'] = ''
                        ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['shiftEmails'] = ''
                        
                        #get shift users list
                        shiftUsr = escaObj.getShiftUsers(shifts['id'])
                        for shiftUserRes in shiftUsr :
                            ecalationMatrixInfo[key2][matrix][schIndex][schId][i][j] = {}
                            ecalationMatrixInfo[key2][matrix][schIndex][schId][i][j]['User'] = shiftUserRes['first_name'].encode('UTF8')+' '+shiftUserRes['last_name'].encode('UTF8')
                            ecalationMatrixInfo[key2][matrix][schIndex][schId][i][j]['EMail'] = shiftUserRes['email']
                            ecalationMatrixInfo[key2][matrix][schIndex][schId][i][j]['phone_number'] = shiftUserRes['phone_number']
                            ecalationMatrixInfo[key2][matrix][schIndex][schId][i][j]['mobile_number'] = shiftUserRes['mobile_number']
                            ecalationMatrixInfo[key2][matrix][schIndex][schId][i][j]['time_zone'] = neZonelist[shiftUserRes['time_zone']] if neZonelist.has_key(shiftUserRes['time_zone']) else shiftUserRes['time_zone']
                            if shiftUserRes['email'] :
                                ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['userDetails'] += shiftUserRes['first_name'].encode('UTF8')+' '+shiftUserRes['last_name'].encode('UTF8')+'<br>'
                                ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['emailDetails'] += str(shiftUserRes['email'])+'<br>'
                                ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['shiftEmails'] += str(shiftUserRes['email'])+','
                                if str(key2) == 'device' :
                                    if shiftUserRes['email'] not in deviceArray :
                                        ecalationMatrixInfo[key2][matrix][schIndex][schId]['deviceArray'] += str(shiftUserRes['email'])+','
                                        deviceArray.append(shiftUserRes['email'])
                                if str(key2) == 'devicegroup' :
                                    if shiftUserRes['email'] not in devicegroupArray :
                                        ecalationMatrixInfo[key2][matrix][schIndex][schId]['devicegroupArray'] += str(shiftUserRes['email'])+','
                                        devicegroupArray.append(shiftUserRes['email'])
                                if str(key2) == 'location' :
                                    if shiftUserRes['email'] not in locationArray :
                                        ecalationMatrixInfo[key2][matrix][schIndex][schId]['locationArray'] += str(shiftUserRes['email'])+','
                                        locationArray.append(shiftUserRes['email'])
                                if str(key2) == 'client' :
                                    if shiftUserRes['email'] not in clientArray :
                                        ecalationMatrixInfo[key2][matrix][schIndex][schId]['clientArray'] += shiftUserRes['email']+','
                                        clientArray.append(shiftUserRes['email'])
                                if str(key2) == 'msp' :
                                    if shiftUserRes['email'] not in mspArray :
                                        ecalationMatrixInfo[key2][matrix][schIndex][schId]['mspArray'] += str(shiftUserRes['email'])+','
                                        locationArray.append(shiftUserRes['email'])
                            j += 1
                        ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['shiftEmails'] = ecalationMatrixInfo[key2][matrix][schIndex][schId][i]['shiftEmails'][:-1]
                        i += 1
                ecalationMatrixInfo[key2][matrix][schIndex][schId]['deviceArray'] = ecalationMatrixInfo[key2][matrix][schIndex][schId]['deviceArray'][:-1]
                ecalationMatrixInfo[key2][matrix][schIndex][schId]['devicegroupArray'] = ecalationMatrixInfo[key2][matrix][schIndex][schId]['devicegroupArray'][:-1]
                ecalationMatrixInfo[key2][matrix][schIndex][schId]['locationArray'] = ecalationMatrixInfo[key2][matrix][schIndex][schId]['locationArray'][:-1]
                ecalationMatrixInfo[key2][matrix][schIndex][schId]['clientArray'] = ecalationMatrixInfo[key2][matrix][schIndex][schId]['clientArray'][:-1]
                ecalationMatrixInfo[key2][matrix][schIndex][schId]['mspArray'] = ecalationMatrixInfo[key2][matrix][schIndex][schId]['mspArray'][:-1]  
            matrix += 1
    os.environ["TZ"]="US/Pacific"
    jsonData = simplejson.dumps({'html':ecalationMatrixInfo})
    return HttpResponse(jsonData, content_type="application/json")

def createPost(request):
    ticketModelObj= CommonTicketModel()
    validaionMessage = ticketModelObj.formValidation(request,'postReply')
    if validaionMessage != '' :
        resURL = ""
        resMsg =  " 400 Bad Request - " + str(validaionMessage)
        jsonData = simplejson.dumps({'resURL': resURL,'resMsg':resMsg})
        return HttpResponse(jsonData, content_type="application/json") 
    ticketId = str(request.POST.get("ticketId",''))
    mspId = request.POST.get('mspId',0)
    clientId = request.POST.get('clientId',0)    
    url = comObj.ticketingUrls()+'/organizations/844/incident/'+ticketId+'/post'
    params = {}
    params['tsId'] = int(request.POST.get('status',''))
    if params['tsId'] == 16 :
        timezoneValue = str(request.POST.get('tzone',''))
        if str(timezoneValue) == 'America/Los_Angeles' :
            params['schT'] = str(request.POST.get('gnschPost',''))
        else :
            schTime = str(request.POST.get('gnschPost',''))
            res = comObj.getScheduledTimeZoneConversion(schTime, timezoneValue)
            params['schT'] = res[0]['scheduledtime'].strftime('%Y-%m-%d %H:%M:%S')
        if params['schT'] == '' or params['schT'] == None or params['schT'] == ' ' or params['schT'] == 'None':
            resURL = ""
            resMsg =  " 400 Bad Request - Scheduled Time should not be empty"
            jsonData = simplejson.dumps({'resURL': resURL,'resMsg':resMsg})
            return HttpResponse(jsonData, content_type="application/json")
    if params['tsId'] == 9 or params['tsId'] == 46:
        params['hmspReason'] = str(request.POST.get('hmspReason','').encode('utf-8'))
        if str(params['hmspReason']) == "Miscellaneous" :
            params['hmspReason'] = str(request.POST.get('hmspmisReason','').encode('utf-8'))
    
    params['content'] = request.POST.get('ticketContent','').replace('<br />','').encode('utf-8')
    params['osId'] = str(request.POST.get('ownerPost',''))
    params['pId'] = str(request.POST.get('selectedPriority',''))
    params['bTime'] = str(request.POST.get('billable',''))
    params['deptId'] = str(request.POST.get('department',''))
    params['emailto'] = str(request.POST.get('toEmailId',''))
    params['wTime'] = str(request.POST.get('timeWorked',''))
    params['tId'] = ticketId
    params['sub'] = str(request.POST.get('postSub','').encode('utf-8'))
    params['avfailure']  = 0
    if (params['sub'][:4] == "[PM]"  or params['sub'][:4] == "[VA]"  or params['sub'][:4] == "[CM]"):
        params['avfailure'] =  request.POST.get('integrationcheck',0)    
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[-1].strip()
    else:
        ip = request.META.get('REMOTE_ADDR')
    params['ipAdd'] = ip
    params['sendMailFlag'] = request.POST.get('sendMail',False)
    params['creator'] = 1
    internalflag = request.POST.get('neinternal',False)    
    if int(internalflag) == 1:
        params['postType'] = 1
        params['ccmail'] = ''
    else:
        params['postType'] = 0
        params['ccmail'] = str(request.POST.get('ccEmailId',''))
    params['alType'] = '1'
    params['email'] = str(request.session['uName'])
    params['emailToClient'] = request.POST.get('emailToClient',0)
    params['mailtoclientsub'] = request.POST.get('mailtoclientsub','')
    params['incidenttags'] = request.POST.get('tags','')
    customernotification = request.POST.get('customernotification',False)
    selectnote = request.POST.get('selectnote',False)
    params['qos_feedback'] = request.POST.get('qos_feedback','')
    params['bTypeId'] = request.POST.get('billableType','')
    params['wTypeId'] = request.POST.get('workType','')
    if customernotification !='Notes':
        params['notedesc'] =customernotification
    else:
        params['notedesc'] =selectnote
    fileAtt = request.POST.getlist('attachments[]',False)
    attachFiles = {}
    if fileAtt :
        attDynamic = str(request.POST.get('attDynamic','').encode('utf-8'))
        rootPath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        attPath = rootPath.rsplit('/', 1)
        #attUrl = '/backup/nncportal_attachments/'+attDynamic+'/' #str(attPath[0])+'/static/files/'+attDynamic+'/'
        attUrl = attachmentUploadPath+str(attDynamic)+'/'
        count = 0
        for att in fileAtt :
            if att:
                att = "".join([i if ord(i) < 128 else "" for i in att])
                attachFiles['attchmnt['+str(count)+']']=open(attUrl+str(att.encode('utf-8')),'rb')
                count = count + 1
    token = comObj.getAuthToken('ticket')
    resHed = {'TOKEN' : token}
    apiResponce ={}
    apiResponce['HTTP Response Code']=''
    apiResponce['Result']=''
    try:
        apiResponceOrg = requests.post(url, data=params,files=attachFiles, headers=resHed, verify=False)
        tmp = comObj.currentAndYesterDayInPST()
        rootPath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        attPath = rootPath.rsplit('/', 1)
        errorTrackingLog = '/var/log/NNCDjango/APIErrorTracking'+env+'.txt'
        with open(errorTrackingLog, 'a') as f:
            f.write('\n =========================='+str(tmp[0]['currentTimeInPST'])+'===============================')
            f.write('\n'+str(ticketId))
            f.write('\n'+str(request.session['uName']))
            if apiResponceOrg.content:
                f.write('\n Post Reply API Response: '+str(apiResponceOrg.content)+'\n ---')  
            f.close()
        apiResponce = apiResponceOrg.json()
    except Exception as e: 
        apiResponce = ticketmodel.apiResponseHandling(apiResponceOrg,request,str(e),ticketId)
    finally:
        if apiResponce['HTTP Response Code'] == '201 Created':
            resURL = "/ticket/view/"+ticketId
            resMsg = ""
            messages.success(request, 'post_updated_successfully')
        elif apiResponce['HTTP Response Code'] == '206 Partial Content':
            ticketPostId = apiResponce['Result'].split(':')
            resURL = "/ticket/view/"+str(ticketId)
            resMsg = ""
            resMsg = str(apiResponce['HTTP Response Code'])+ " - " + str(ticketPostId[1])
            messages.warning(request, 'post_updated_fileupload_failed')
        else :
            resURL = ""
            resMsg = str(apiResponce['HTTP Response Code'])+ " - " + str(apiResponce['Result'])
        jsonData = simplejson.dumps({'resURL': resURL,'resMsg':resMsg})
        return HttpResponse(jsonData, content_type="application/json")

def downloadAttachment(request):
    attInfo = ticketmodel.getAttachementInfo(request.GET.get('attId'))
    attData = ''
    for chunk in attInfo :
        attData =  attData + chunk['contents']
    response = HttpResponse(attData, content_type='application/force-download')
    response['Content-Disposition'] = 'attachment; filename="%s"' % str(request.GET.get('attName'))
    return response

def psaIntegration(request):
    url = comObj.ticketingUrls()+'/organizations/844/psa'
    params = {}
    params['tId'] = str(request.POST.get('ticketId',False))
    params['tsId'] = str(request.POST.get('ticktStId',False))
    params['pId'] = str(request.POST.get('priority',False))
    stringConApi = simplejson.dumps(params)
    json=comObj.getPostResponce(url, stringConApi,'ticket')
    status = 'success'
    jsonData = simplejson.dumps({'resURL':status})
    return HttpResponse(jsonData, content_type="application/json")

def getreviewForTicket(request):
    ticketId = request.POST.get('ticketId',False)
    tktRvws = CommonTicketModel()
    tktRvwDetails = tktRvws.getNewTicketReview(ticketId)
    ticketDetails = {}
    for postData in tktRvwDetails:
        ticketDetails['proc_rating'] = postData['proc_rating']
        ticketDetails['tech_rating'] = postData['tech_rating']
        ticketDetails['comm_rating'] = postData['comm_rating']
        ticketDetails['customer_value_rating'] = postData['customer_value_rating']
        ticketDetails['time_rating'] = postData['time_rating']
        ticketDetails['ticket_id'] = ticketId
    jsonData = simplejson.dumps({'ticketDetails': ticketDetails})
    return HttpResponse(jsonData, content_type="application/json")

def notesForm(request,ticketId):
    #swStaff = mem_cache.get('swStaff')
    #if not swStaff:
    swStaff = comMObj.getSwStaffByRoster()
        #mem_cache.set('swStaff', swStaff, 86400)
    return render_to_response('addNotes.html',{'swStaff':swStaff,'ticketId':ticketId},context_instance=RequestContext(request))

def addNote(request,ticketId):
    params = {}
    params['nType'] = 1#request.POST.get('noteType')
    params['tyId'] = ticketId
#     if int(params['nType']) == 1:
#         params['tyId'] = ticketId
#     elif int(params['nType']) == 2:
#         params['tyId'] = request.session['swstaffId']
    if request.POST.get('userName') :
        params['fStId'] = request.POST.get('userName')
    else :
        params['fStId']= 0
    params['bStId'] = request.session['swstaffId']
    params['note'] = request.POST.get('content').encode('utf-8')
    url = comObj.ticketingUrls()+'/organizations/844/incident/'+ticketId+'/note'
    res = comObj.getPostResponce(url,simplejson.dumps(params),'ticket')
#     responce = ticketView(request,ticketId)
#     return responce
#     if str(res['HTTP Response Code']) == '200 OK':
#         print 'Note inserted Succussfully'
#     else :
#         print "Note not inserted"
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))

def apistest(request):
    apiInput = ''
    print  'API --'
    #url = comObj.ticketingUrls()+"organizations/844/customfieldgroup/5/customfields"
    url = comObj.ticketingUrls()+"organizations/844/incident/14269404/customfieldgroup/5/customfields"
    #http://api.netenrich.net/api_staging/organizations/844/incident/14269404/customfieldgroup/5/customfields");
    print 'login',url 
    #url ='https://api.netenrich.net/api_staging/organizations/844/customfieldgroup/5/customfields'
    #jsonOp = comObj.getPutResponce(url,apiInput,'ticket');
    #jsonOp = comObj.getAPIResponce(url,'ticket') for getting method
    data1 = [{
                "customfieldid" : "13",
                "fieldvalue": "sampleOrder11377"
            },
        {
                "customfieldid" : "31",
                "fieldvalue": "sampleComments"
        },
        {
                "customfieldid" : "51",
                "fieldvalue": "sampleStartOB modify123222"
        },
         {
                "customfieldid" : "41",
                "fieldvalue": "Delete"
        }
             ]
        
    print data1
    jsonOp = comObj.apiForPostJsonData(url,data1,'ticket')
    #print jsonOp
    return render_to_response('ticketEdit.html',{'display':'krnthi'})    

def ticketEditView(request):
    post = request.GET
    tikId = post.get('tktId',False)
    #url = comObj.ticketingUrls() +'/organizations/844?customfieldgroupid=31'
    url = comObj.ticketingUrls() +'/organizations/844/incident/'+str(tikId)
    #url = 'http://api.netenrich.net/api_staging/organizations/844?customfieldgroupid=1'
    jsonOp = comObj.getAPIResponce(url,'ticket')
    ticketDetails = jsonOp['Result']['Ticket Info']
    customFieldsGroups = jsonOp['Result']['Custom Fields Info']
    KYKCustomFieldTypes = {
            1 : 'TEXT',
            2 : 'TEXTAREA',
            3 : 'PASSWORD',
            4 : 'CHECKBOX',
            5 : 'RADIO',
            6 : 'SELECT',
            7 : 'SELECTMULTIPLE',
            8 : 'CUSTOM',         
        }
    html =''
    customFeildGroupList = []
    for custom in customFieldsGroups:
        if int(custom['cfGrpId']) !=1:
            customFeildGroupList.append(custom['cfGrpId'])
            html +='<div class="accord accord-default"><div class="accord-heading"><b>'+ custom['grpTitle']+'</b></div>'
            
            html +='<form id="cust_grp_'+str(custom['cfGrpId'])+'" data-groupId="'+str(custom['cfGrpId'])+'" data-ticketId="'+str(ticketDetails['tId'])+'" style="margin: 0px !important;" >'
            html +='<div id="collapseOne" class="accord-collapse collapse in">'           
            html +='<div class="mod-content sp">'
            html +='<ul class="property-list two-cols">'
            customFeilds = ticketmodel.getCustomFieldsInfoByGroup(ticketDetails['tId'],custom['cfGrpId'])
            divDividing =1
            
            for customFieldInfo in customFeilds:
                feildType = KYKCustomFieldTypes[int(customFieldInfo['fieldtype'])]
                
                if divDividing % 2 == 0:
                    html +='<li class="item item-right">'
                else:
                    html +='<li class="item ">'
                
                html +='<div class="wrap">'
                html +='<strong class="name">'+ customFieldInfo['title'] 
                
                if customFieldInfo['description'] :
                    html +='<br><span style="font-weight: normal;">'+ customFieldInfo['description'] +'</span>'
                html +='</strong>'

                html += '<span class="value">'
                if  (customFieldInfo['fieldvalue'] != None):
                    
                     value = customFieldInfo['fieldvalue']
                else:
                     value = customFieldInfo['defaultvalue']
                if int(customFieldInfo['customfieldid'] == 3):
                    nTktSystemInfo = ticketmodel.getPSAIntegReqInfo(ticketDetails['mName'],ticketDetails['cName'])
                    nMspCode = ticketmodel.getMspCode(ticketDetails['mId'])
                    nClientCode =ticketmodel.getClientCode(ticketDetails['cId'])
                    html +='<input type="text" class="form-control" name="customfieldid_'+str(customFieldInfo['customfieldid'])+'"   value="'+str(value)+'">'
                
                else:
                    if(feildType =='TEXT'):
                        html +='<input type="text" class="form-control" name="customfieldid_'+str(customFieldInfo['customfieldid'])+'"   value="'+str(value)+'">'
                    elif( feildType =='TEXTAREA'):
                        html +='<textarea  class="form-control" name="customfieldid_'+str(customFieldInfo['customfieldid'])+'"  >'+str(value) +'</textarea>'
                    elif (feildType =='PASSWORD'):
                        html += '<input type="password" value="'+str(value)+'">'
                    elif(feildType == 'SELECT'):
                        
                        dropdown = '<select name="customfieldid_'+str(customFieldInfo['customfieldid'])+'" >'
                        optionVlaues = ticketmodel.getFieldOptions(customFieldInfo['customfieldid'])
                        optionHtml = ''
                        for options in optionVlaues:
                             
                            if options['optionvalue'] == str(value):
                                
                                optionHtml +='<option value="'+options['optionvalue']+'" selected >'+ options['optionvalue']+'</option>'
                            else:
                                optionHtml +='<option value="'+options['optionvalue']+'">'+ options['optionvalue']+'</option>'
                        html += dropdown+str(optionHtml)+'</select>'
                    elif (feildType == 'SELECTMULTIPLE'):
                        dropdown = '<select name="customfieldid_'+str(customFieldInfo['customfieldid'])+'"  multiple >'
                        optionVlaues = ticketmodel.getFieldOptions(customFieldInfo['customfieldid'])
                        resultSet = {}
                        for data in optionVlaues:
                            resultSet[data['optionvalue']] = data['optionvalue']
                        resultSet
                        
                        selectedValues = ticketmodel.getCustomFieldValues(customFieldInfo['customfieldid'],ticketDetails['tId'])
                        
                        resultSelectedSet = {}
                        for data in selectedValues:
                            del resultSet[data['fieldvalue']]
                            resultSelectedSet[data['fieldvalue']] = data['fieldvalue']
                        
                        optionHtml = ''
                        for sel,secltValue in resultSelectedSet.iteritems():
                            optionHtml +='<option value="'+secltValue+'" selected >'+secltValue+'</option>'
                            
                        for key,fidValue in resultSet.iteritems():
                                optionHtml +='<option value="'+fidValue+'"  >'+fidValue+'</option>'
                                                
                        html += dropdown+str(optionHtml)+'</select>'
                    elif (feildType == 'RADIO'):
                        
                        optionVlaues = ticketmodel.getFieldOptions(customFieldInfo['customfieldid'])
                        
                        html += '<div style="font-size: 12px !important;"><ul id="listItems">'
                        for radioOption in optionVlaues:
                            if radioOption['optionvalue'] == str(value):
                                html +='<input type="radio"  name="customfieldid_'+str(customFieldInfo['customfieldid'])+'" checked value="'+radioOption['optionvalue']+'" >'+radioOption['optionvalue']+'<br>'
                            else:
                                html +='<input type="radio"   name="customfieldid_'+str(customFieldInfo['customfieldid'])+'" value="'+radioOption['optionvalue']+'">'+radioOption['optionvalue']+'<br>'
                        
                        html += '</ul></div>'
                html += '</span>'
                html += '</div>'
                html += '</li>'
                divDividing =divDividing +1
               
            html += '</ul></div></div>'

            html +='</div>'
            html +='</form>'
    getCustomGroupIds= ticketmodel.getCustomGroupIds()
    displayingGroupFields = {}
    
    for grpIds in getCustomGroupIds:
        
        if str(grpIds['customfieldgroupid']) in customFeildGroupList:
            pass
            
        else:
            displayingGroupFields[grpIds['customfieldgroupid']] = grpIds['title']
    

    msps = Ntsmsps.objects.using('ticketRead').only('mspname','mspid').filter(status = 1).order_by('mspname')
    clients = Ntsmspclients.objects.using('ticketRead').only('clientname','mspclientid').filter(status = 1).order_by('clientname')
    swStaff = comMObj.getSwStaffByRoster()
    
    deviceDetails  = comObj.getDeviceByClientIds(ticketDetails['cId'])
    ticketTypes  = tkttype_obj.getAllTicketTypes()
    serviceCatory =comObj.serviceCatory()
    deviceCategory = comObj.deviceCategory()
    ticketCustoFields = jsonOp['Result']['Custom Fields Info']
    data ={
          'msp':msps,
          'clients':clients,
          'staff':swStaff,
          'deviceNmaes':deviceDetails,
          'ticketType':ticketTypes,
          'serviceCatory':serviceCatory,
          'deviceCategory':deviceCategory,
          'ticketDetails':ticketDetails,
          'ticketCustoFields':ticketCustoFields,
          'viewHtml':html,
          'displayingGroupFields':displayingGroupFields,
           }
    rendering = 'ticketEdit.html'
    return render_to_response(rendering,{'data':data},context_instance=RequestContext(request))


def linkcustomfieldViews(request):    
    post =  request.POST
    if len(post['view']) >2:
        customGrpId = post['view']
        customGrpId = customGrpId[:-1]
        url = comObj.ticketingUrls() +'/organizations/844?customfieldgroupid='+urllib.quote(customGrpId.encode("utf8"))
    else:
        linkcustomfieldGroup = post['view']
        url = comObj.ticketingUrls() +'/organizations/844?customfieldgroupid='+linkcustomfieldGroup
    #print url    
    jsonOp = comObj.getAPIResponce(url,'ticket')
    customFeilds =  jsonOp['Result']
    
    html =''
    for custom in  customFeilds:
        html +='<div class="accord accord-default"><div class="accord-heading"><b>'+ custom['groupTitle']+'</b></div>'
        
        html +='<form id="cust_grp_'+str(custom['customFieldGroupId'])+'" data-groupId="'+str(custom['customFieldGroupId'])+'"  style="margin: 0px !important;" >'
        html +='<div id="collapseOne" class="accord-collapse collapse in">'           
        html +='<div class="mod-content sp">'
        html +='<ul class="property-list two-cols">'
        divDividing = 1
        
        for ji in custom['customFieldOptions']:
            #print ji
            
            if divDividing % 2 == 0:
                html +='<li class="item item-right">'
            else:
                html +='<li class="item ">'
             
            html +='<div class="wrap">'
            html +='<strong class="name">'+ ji['title'] 
             
            if ji['description'] :
                
                html +='<br><span style="font-weight: normal;">'+ ji['description'] +'</span>'
            html +='</strong>'
             
            html += '<span class="value">'
            if ji['fieldType'] == 'TEXT':
                html += '<input type="text" name="customfieldid_'+str(ji['customFieldId'])+'"   value="'+str(ji['defaultValue'])+'">'
            elif ji['fieldType'] =='SELECT':
                dropdown = '<select name="customfieldid_'+str(ji['customFieldId'])+'" >'
                
                for opts in  ji['customfieldOptions'] :
                    
                    dropdown +='<option value="'+opts['optionValue']+'">'+opts['optionValue']+'</option>'
                dropdown += '</select>'    
                html += dropdown 
            elif ji['fieldType'] =='TEXTAREA':
                html +='<textarea name="customfieldid_'+str(ji['customFieldId'])+'"  >'+str(ji['defaultValue']) +'</textarea>'
            elif ji['fieldType'] =='SELECTMULTIPLE':
                dropdown = '<select name="customfieldid_'+str(ji['customFieldId'])+'" multiple >'
                
                for opts in  ji['customfieldOptions'] :
                    
                    dropdown +='<option value="'+opts['optionValue']+'">'+opts['optionValue']+'</option>'
                dropdown += '</select>'    
                html += dropdown
            
            elif ji['fieldType'] =='RADIO':
                 
                radioshtml = '<div style="font-size: 12px !important;"><ul id="listItems">'
                for opts in  ji['customfieldOptions'] :
                    if (int(opts['isSelected']) == 1):
                        radioshtml +='<input  name="customfieldid_'+str(ji['customFieldId'])+'"  type="radio" value="'+opts['optionValue']+'" checked="checked" >'+ opts['optionValue'] +'<br>'
                    else:
                        radioshtml +='<input  name="customfieldid_'+str(ji['customFieldId'])+'"  type="radio" value="'+opts['optionValue']+'"  >'+ opts['optionValue'] +'<br>'
                radioshtml += '</ul></div>'
                html += radioshtml
    
            html += '</span>'
            html += '</div>'
            html += '</li>'
            divDividing =divDividing +1
        html += '</ul></div></div>'
        html +='</div>'
        html +='</form>'
    
        
    jsonData = simplejson.dumps({'html': html})
    return HttpResponse(jsonData, content_type="application/json")


def ticketEditSave(request):
    post = request.POST
    tikId = post.get('ticketId',False)
    
    apiData = []
    onbaording = post.get('onboardingData',False)

    if (onbaording != False and len(onbaording) !=0):
        onboardingData = urlparse.parse_qs(onbaording)

        apiDataSet ={}
        apiDataSet['customFieldsGrpId'] = 5
        dataSet ={}
        datacount  = 0
        for key,value  in onboardingData.iteritems():
            dataVlaue ={}
            dataVlaue['customfieldid']= key.replace("customfieldid_", "")
            if len(value)>1:
                dataVlaue['isserialized']= 1
            else:
                dataVlaue['isserialized']= 0
            dataVlaue['fieldvalue']= value
            dataSet[datacount]=dataVlaue
            datacount = datacount+1
        apiDataSet['fieldsInfo'] = dataSet
        apiData.append(apiDataSet)
    msp = post.get('msp',False)
    if (msp != False and len(msp) !=0):
        msp = urlparse.parse_qs(msp)
        mspapiDataSet ={}
        mspapiDataSet['customFieldsGrpId'] = 2
        mspdataSet ={}
        mspdatacount  = 0
        for key,value  in msp.iteritems():
            mspdataVlaue ={}
            mspdataVlaue['customfieldid']= key.replace("customfieldid_", "")
            if len(value)>1:
                mspdataVlaue['isserialized']= 1
            else:
                mspdataVlaue['isserialized']= 0
            mspdataVlaue['fieldvalue']= value
            mspdataSet[mspdatacount]= mspdataVlaue
            mspdatacount = mspdatacount+1
        mspapiDataSet['fieldsInfo'] = mspdataSet
        apiData.append(mspapiDataSet)
    mspTools = post.get('mspTools',False)
    
    if (mspTools != False and len(mspTools) !=0):
    
        mspToolsdata = urlparse.parse_qs(mspTools)
       
        mspToolsDataSet ={}
        mspToolsDataSet['customFieldsGrpId'] = 11
        mspToolData ={}
        mspToolCount  = 0
        for key4,value4  in mspToolsdata.iteritems():
            mspToolDataValue ={}
            mspToolDataValue['customfieldid']= key4.replace("customfieldid_", "")
            if len(value4)>1:
                mspToolDataValue['isserialized']= 1
            else:
                mspToolDataValue['isserialized']= 0
            mspToolDataValue['fieldvalue']= value4
            mspToolData[mspToolCount]= mspToolDataValue
            mspToolCount = mspToolCount+1
        mspToolsDataSet['fieldsInfo'] = mspToolData
        
        apiData.append(mspToolsDataSet)
    mspQos = post.get('mspQos',False)
    
    if (mspQos != False and len(mspQos) !=0):
        mspQosdata = urlparse.parse_qs(mspQos)        
        mspQosDataSet ={}
        mspQosDataSet['customFieldsGrpId'] = 21
        mspQosData ={}
        mspQosCount  = 0
        for key2,value2  in mspQosdata.iteritems():
            mspQosDataValue ={}
            mspQosDataValue['customfieldid']= key2.replace("customfieldid_", "")
            if len(value2)>1:
                mspQosDataValue['isserialized']= 1
            else:
                mspQosDataValue['isserialized']= 0
            mspQosDataValue['fieldvalue']= value2
            mspQosData[mspQosCount]= mspQosDataValue
            mspQosCount = mspQosCount+1
        mspQosDataSet['fieldsInfo'] = mspQosData
        
        apiData.append(mspQosDataSet)       
    
    ticktResNote = post.get('ticketResNote',False)
    
    if (ticktResNote != False and len(ticktResNote) !=0):
        
        ticktResNotedata = urlparse.parse_qs(ticktResNote)
       
        ticktResNoteDataSet ={}
        ticktResNoteDataSet['customFieldsGrpId'] = 31
        ticktResNoteData ={}
        ticktResNoteCount  = 0
        for key3,value3  in ticktResNotedata.iteritems():
            ticktResNoteDataValue ={}
            ticktResNoteDataValue['customfieldid']= key3.replace("customfieldid_", "")
            if len(value3)>1:
                ticktResNoteDataValue['isserialized']= 1
            else:
                ticktResNoteDataValue['isserialized']= 0
            ticktResNoteDataValue['fieldvalue']= value3
            ticktResNoteData[ticktResNoteCount]= ticktResNoteDataValue
            ticktResNoteCount = ticktResNoteCount+1
        ticktResNoteDataSet['fieldsInfo'] = ticktResNoteData
        
        apiData.append(ticktResNoteDataSet)       
    
    lpiDataSeril = post.get('lpiData',False)
        
    if (lpiDataSeril != False and len(lpiDataSeril) !=0):
        lpiData = urlparse.parse_qs(lpiDataSeril)

        lipDataSet ={}
        lipDataSet['customFieldsGrpId'] = 1
        dataSetLpi ={}
        datacountLip  = 0
        for key,value  in lpiData.iteritems():
            
            dataVlaueLpi ={}
            if key== 'alertlop':
                pass
            else:
                dataVlaueLpi['customfieldid']= key.replace("customfieldid_", "")
                if len(value)>1:
                    dataVlaueLpi['isserialized']= 1
                else:
                    dataVlaueLpi['isserialized']= 0
    
                dataVlaueLpi['fieldvalue']= value
                dataSetLpi[datacountLip]=dataVlaueLpi
                
                datacountLip = datacountLip+1
                
            """if lpiData.has_key('customfieldid_8'):
                pass
            else:
                valuelen =len(dataSetLpi)
                
                dataVlaueLpi1 ={}
                dataVlaueLpi1['customfieldid'] = 8
                dataVlaueLpi1['isserialized']= 0
                dataVlaueLpi1['fieldvalue']= ['']
                dataSetLpi[valuelen]=dataVlaueLpi1"""
            
        lipDataSet['fieldsInfo'] = dataSetLpi
        
        apiData.append(lipDataSet)
        
    url = comObj.ticketingUrls()+"/organizations/844/incident/"+str(tikId)+"/customfields"
    jsonOp = comObj.apiForPostJsonData(url,apiData,'ticket') 
    ticketEditData = post.get('ticketForm',False)

    if (ticketEditData != False and len(ticketEditData) !=0):
        
        dataTicket = urlparse.parse_qs(ticketEditData)
        
        apiInputPut = {}
        apiInputPut['tId'] = tikId
        apiInputPut['dId'] = dataTicket['deviceName'][0] if(dataTicket.has_key('deviceName') ) else ''
        apiInputPut['mId'] = dataTicket['partners'][0] if(dataTicket.has_key('partners') ) else ''
        apiInputPut['cId'] = dataTicket['clients'][0] if(dataTicket.has_key('clients') ) else ''
        apiInputPut['dcId'] = dataTicket['deviceCategory'][0] if(dataTicket.has_key('deviceCategory') ) else ''
        apiInputPut['scId'] = dataTicket['serviceCategory'][0] if(dataTicket.has_key('serviceCategory') ) else ''
        #apiInputPut['osId'] = dataTicket['ownerStaffId'][0] if(dataTicket.has_key('ownerStaffId') ) else ''
        apiInputPut['sub'] = dataTicket['subject'][0] if(dataTicket.has_key('subject') ) else ''
        apiInputPut['email'] = dataTicket['email'][0] if(dataTicket.has_key('email') ) else ''
        apiInputPut['postFlag'] = 0 
        apiInputPut['tyId'] = dataTicket['ticketType'][0] if(dataTicket.has_key('ticketType') ) else ''
        apiInputPut['stId'] = dataTicket['ownerStaffId'][0] if(dataTicket.has_key('ownerStaffId') ) else ''
    
        organizationId = configobj.getCommConfigValue(configobj.NESPID)
        url = comObj.ticketingUrls()+"/organizations/"+str(organizationId)+"/incident/"+str(tikId)    
        
        jsonOp = comObj.getPutResponce(url,apiInputPut,'ticket')
        
    jsonData = simplejson.dumps({'html': 'success'})
    return HttpResponse(jsonData, content_type="application/json")

def displayOfCustomFeilds(request):
    post = request.POST
    tikId = post.get('tktId',False)
    url = comObj.ticketingUrls() +'/organizations/844/incident/'+str(tikId)
    jsonOp = comObj.getAPIResponce(url,'ticket')
    ticketDetails = jsonOp['Result']['Ticket Info']
    customFieldsGroups = jsonOp['Result']['Custom Fields Info']
    ITSMenabledClient = ticketmodel.getITSMenabledClients(str(jsonOp['Result']['Ticket Info']['cId']))
    ITSMenabledPartner = ticketmodel.getITSMenabledClients(str(jsonOp['Result']['Ticket Info']['mId']))
    KYKCustomFieldTypes = {
            1 : 'TEXT',
            2 : 'TEXTAREA',
            3 : 'PASSWORD',
            4 : 'CHECKBOX',
            5 : 'RADIO',
            6 : 'SELECT',
            7 : 'SELECTMULTIPLE',
            8 : 'CUSTOM',
        }
    html =''
    customFeildGroupList = []
    for custom in customFieldsGroups:
        if int(custom['cfGrpId']) !=1:
            customFeildGroupList.append(custom['cfGrpId'])
            html +='<div class="accord accord-default"><div class="accord-heading"><b>'+ custom['grpTitle']+'</b></div>'
            html +='<form id="cust_grp_'+str(custom['cfGrpId'])+'" data-groupId="'+str(custom['cfGrpId'])+'" data-ticketId="'+str(ticketDetails['tId'])+'" style="margin: 0px !important;" >'
            html +='<div id="collapseOne" class="accord-collapse collapse in">'
            html +='<div class="mod-content sp">'
            html +='<ul class="property-list two-cols">'
            customFeilds = ticketmodel.getCustomFieldsInfoByGroup(ticketDetails['tId'],custom['cfGrpId'])
            divDividing =1
            mspList = [u'0000', '0000', None]
            for customFieldInfo in customFeilds:
                feildType = KYKCustomFieldTypes[int(customFieldInfo['fieldtype'])]
                if divDividing % 2 == 0:
                    html +='<li class="item item-right">'
                else:
                    html +='<li class="item ">'
                html +='<div class="wrap">'
                html +='<strong class="name">'+ customFieldInfo['title']
                html +=' :</strong> '
                html += '<span class="value">'
                newValue = ''
                if customFieldInfo['fieldvalue'] not in mspList:
                     value = customFieldInfo['fieldvalue']
                elif int(customFieldInfo['customfieldid']) == 3:
                    if not ITSMenabledPartner:
                        value = '<font style="color:red">PSA not enabled for partner</font>'
                    elif not ITSMenabledClient:
                        value = '<font style="color:red">PSA not enabled for client</font>'
                    elif ticketmodel.getMSPIDfromNNC(ticketDetails['tId']):
                        value = '<span class="mspStatus">Request is in queue</span>'
                    else:
                        value = '<span class="emptyStatus">'

                    if ticketDetails.has_key('isPsaEnabled') and int(ticketDetails['isPsaEnabled']) == 1:
                        if ( str(ticketDetails['psaTid']) == '0000' or ticketDetails['psaTid'] == None ):
                            if ticketDetails.has_key('psaType'):
                                if (ticketmodel.getMSPIDfromNNC(ticketDetails['tId'])):
                                    value +='<br><font class="mylink">Click <a href="'+str(ticketDetails['ticketingUrl'])+'" target="_blank" title="ticketingUrl"><b> here </b></a>to login to '+ str(ticketDetails['psaType'])+'</font>'
                                else:
                                    value +='<br><font class="mylink link1">Click <a data-msp="'+str(ticketDetails['mId'])+'" href="javascript:void(0);" data-ticketstatus ="'+str(ticketDetails["tsId"])+'" id="psaIntegartions"><b>here</b></a> to create ticket in '+str(ticketDetails['psaType'])+' </font>'
                                    value +='<br><font class="mylink">Click <a href="'+str(ticketDetails['ticketingUrl'])+'" target="_blank" title="ticketingUrl"><b> here </b></a>to login to '+ str(ticketDetails['psaType'])+'</font>'
                            else:
                                value +='<br><font class="mylink">Click <a href="'+str(ticketDetails['ticketingUrl'])+'" target="_blank" title="ticketingUrl"><b> here </b></a>to login to '+ str(ticketDetails['ticketingUrl'])+'</font>'
                        else:
                            value +='<br><font class="mylink">Click <a href="'+str(ticketDetails['ticketingUrl'])+'" target="_blank" title="ticketingUrl"><b> here </b></a>to login to '+ str(ticketDetails['ticketingUrl'])+'</font>'
                    if (ticketDetails.has_key('psaError')):
                        value +='<br> <p><font style="color:red">'+str(ticketDetails['psaError'])+' </font></p>'
                elif int(customFieldInfo['customfieldid']) == 241:
                    if ticketmodel.getMSPIDfromNNC(ticketDetails['tId']):
                        value = '<span class="vistaraStatus">Request is in queue</span>'
                    else:
                        value = ''
                else:
                    value = customFieldInfo['defaultvalue']
                html += value
                html += '</span>'
                html += '</div>'
                html += '</li>'
                divDividing =divDividing +1
            html += '</ul></div></div>'
            html +='</div>'
            html +='</form>'
    jsonData = simplejson.dumps({'html':html })
    return HttpResponse(jsonData, content_type="application/json")
            
def loadNotes(request,ticketId):
    url = comObj.ticketingUrls() +'/organizations/844/incident/'+str(ticketId)+'/staff/'+str(request.session['swstaffId'])+'/notes'
    notesInfo = comObj.getAPIResponce(url,'ticket')
    if(notesInfo['HTTP Response Code']=='200 OK'):
        for notes in notesInfo['Result'] :
            temp = comObj.timeStampToPST(str(notes['dLine']))
            notes['dLine'] = str(temp[0]['pstdate'])
    jsonData = simplejson.dumps({'notesINfo': notesInfo['Result']})
    return HttpResponse(jsonData, content_type="application/json")

""" 
    List of Alerts related to ticket can be viewed using this method...
"""
def showAlertsData(request):   
    """ To get API related values usign this method to get connected to monitoring tool"""
    monitoringUrl =  configobj.getCommConfigValue(configobj.Monitoringurl)    
    APIvalues = configobj.getCommConfigValue(configobj.MonitoringAPIValues)
    APIvalues = json.loads(APIvalues)
    """To get token from concerned monitoring api oauth """
    token = comObj.getAuthToken("monitoring")   
    post = request.GET
    clientId = post.get("cId",False)
    incidentId = post.get("incId",False)
    ticketId = post.get("tId",False)
    
    """ Preparing urls based on incident id or ticket id """
    if incidentId:
        url = str(APIvalues["BaseUrl"])+"api/v2/tenants/client_"+str(clientId)+"/alerts/search?sortName=ts&isDescendingOrder=true&queryString=ticketId:"+str(incidentId)
    else:
        url = str(APIvalues["BaseUrl"])+"api/v2/alerts/tenants/client_"+str(clientId)+"/tickets/"+str(ticketId)
    headersInfo = {'Content-Type': 'application/json','Accept': 'application/json','Authorization': token}    
    alertdata = requests.get(url,headers=headersInfo,verify=False)
    data = json.loads(alertdata.content)
    data['aUrl'] = comObj.generateVistaraClientUrl(int(data['results'][0]['tenantId']))
    alertscount = 0
    if str(alertdata) == '<Response [200]>':
        if 'totalPages' in data.keys():
            totalPages = int(data['totalPages'])
            totalPages = totalPages - 1
            if totalPages > 1: 
                for page in range(totalPages):
                    if incidentId:
                        url = str(APIvalues["BaseUrl"])+"api/v2/tenants/client_"+str(clientId)+"/alerts/search?pageNo="+str(page)+"&sortName=ts&isDescendingOrder=true&queryString=ticketId:"+str(incidentId)
                    else:
                        url = str(APIvalues["BaseUrl"])+"api/v2/alerts/tenants/client_"+str(clientId)+"/tickets/"+str(ticketId)
                    alertdata = requests.get(url,headers=headersInfo,verify=False)
                    data1 = json.loads(alertdata.content)
                    data['results'] = data['results']+data1['results']          
        alertscount = len(data['results'])
    else:
        data = data['error_description']
    return render_to_response('showAlerts.html',{ 'alertdata':data,'monitoringUrl':monitoringUrl, 'alertscount':alertscount },context_instance=RequestContext(request))


def linkcutomGroupForDept(request):
    """ Above fuction will hit api for link custom feild groups according to deptId"""
    post = request.POST
    url = comObj.ticketingUrls() +'/organizations/844/department?deptId='+str(post['deptId'])
    
    jsonOp = comObj.getAPIResponce(url,'ticket')
    data =jsonOp['Result'][0]['customFieldGrps']
   
    dataList =''
    for i in data:
        if int(i['cfgrpId']) != 1:
            dataList += i['cfgrpId'] +str('+')
    jsonData = simplejson.dumps({'deptId': dataList})
    return HttpResponse(jsonData, content_type="application/json")

def emailValidation(request):
    externalmails = ''
    emailcount = 0
    email_list = []
    ndomain = "netenrich"
    ticketModelObj= CommonTicketModel()
    emailids = request.POST.get('emailids',False)
    mspClient = request.POST.get('mspCleint',False)
    
    if "," in emailids:
        email_list = emailids.split(",")
    if len(email_list) > 1:
        for emailid in email_list:
            emailid  = emailid.strip(" ")
            reqmail_domain = emailid.split("@")[1].split(".")[0]
            if(str(reqmail_domain) != str(ndomain)):
                emailcount = ticketModelObj.getUserEmails(mspClient,emailid)                       
                if int(emailcount['emailcount']) == 0:
                    externalmails += emailid+","
        externalmails = externalmails.rstrip(",")
    else:
        reqmail_domain = emailids.split("@")[1].split(".")[0]
        if(str(reqmail_domain) != str(ndomain)):
            emailcount = ticketModelObj.getUserEmails(mspClient,emailids)
            if int(emailcount['emailcount']) == 0:
                externalmails = emailids
    jsonData = simplejson.dumps({'externalmails': externalmails})
    return HttpResponse(jsonData, content_type="application/json")

def tktWatchingUserTrack(request):
    userName = request.POST.get('userName','')
    userId = request.POST.get('userId',0)
    ticketId = request.POST.get('ticketid',0)
    timespent = request.POST.get('timespent',0)
    tkt_lastactivity = request.POST.get('tkt_lastactivity',0) 
    CurrentUserInfo = {userId:{'timespent':timespent,'userName':userName,'tkt_lastactivity':tkt_lastactivity}}
    cacheStrCurrentWatchingUser = 'currentWatchingUser_'+str(ticketId)+env
    TktUserInfo = mem_cache.get(cacheStrCurrentWatchingUser)
    if type(TktUserInfo) is str:
        TktUserInfo = json.loads(TktUserInfo)
    if not TktUserInfo:
        mem_cache.set(cacheStrCurrentWatchingUser, CurrentUserInfo,600)
    else:  
        for eachuser in  TktUserInfo.keys(): 
            diff = int(CurrentUserInfo[userId]['tkt_lastactivity']) - int(TktUserInfo[eachuser]['tkt_lastactivity'])
            if eachuser != userId:
                TktUserInfo.update(CurrentUserInfo)   
                mem_cache.set(ticketId,TktUserInfo,600) 
            else:                
                if int(diff) > 60000:
                    TktUserInfo = {key:value for key,value in TktUserInfo.items() if key != eachuser}
                TktUserInfo.update(CurrentUserInfo)
                mem_cache.set(cacheStrCurrentWatchingUser,TktUserInfo,600)    
    return HttpResponse("success")

def billing(request,ticketId):
    data = {}
    #wStaff = mem_cache.get('swStaff')
    #if not swStaff:
    swStaff = comMObj.getSwStaffByRoster()
        #mem_cache.set('swStaff', swStaff, 86400)
    curDTime = datetime.now()
    billDate = curDTime.strftime('%m/%d/%Y  %H:%M')
    data['billDate'] = billDate
    data['swStaffid'] = request.session['swstaffId']
    maxDate = curDTime - timedelta(days=1)
    maxDate = maxDate.strftime('%m/%d/%Y %H:%M')
    return render_to_response('billing.html',{'swStaff':swStaff,'ticketId':ticketId, 'data': data, 'billDate': billDate},context_instance=RequestContext(request))

def addBilling(request, ticketId):
    tempParams = {}
    tempParams['ticketid'] = ticketId
    tempParams['timespent'] = request.POST.get('timeWrkd')
    tempParams['timebillable'] = request.POST.get('timeBillble')
    billDate = request.POST.get('billDate')
    bilDate = datetime.strptime(billDate, "%m/%d/%Y %H:%M").strftime('%Y-%m-%d %H:%M')
    dateline = comObj.pstToUTCStamp(bilDate)
    tempParams['dateline'] = dateline[0]['pstdate']
    tempParams['forstaffid'] = request.POST.get('worker')
    tempParams['notes'] = request.POST.get('summry')
    tempParams['creatorstaffid'] = request.session['swstaffId']
    commModMethd = CommonModelMethods()
    timetrackid = commModMethd.insertRecord(tempParams, 'swtickettimetrack', 'ticketWrite')
    return HttpResponseRedirect(request.META.get('HTTP_REFERER'))
    
def loadBillingEntries(request,ticketId):
    ticketModelObj = CommonTicketModel()
    billingData = ticketModelObj.getBillingEntries(ticketId)
    html = ''
    timespentSum = 0
    timebillableSum = 0
    
    for billingDat in billingData:
        timespentSum += int(billingDat['timespent'])
        timebillableSum += int(billingDat['timebillable'])
        html += '<table id="tbl_billing" class="table table-hover table-bordered">'
        html += '<tbody>'
        html += '<tr>'
        #staffName = nrStaffObj.getStaffInformation(3291)
        staffName = nrStaffObj.getStaffInformation(int(billingDat['forstaffid']))
        os.environ["TZ"] = "US/Pacific"
        bilingDat = str(datetime.fromtimestamp(int(billingDat['dateline'])).strftime('%d %b %Y %I:%M %p'))

        html += '<td colspan="4">Billing entry for: '+str(staffName[0]['empname'])+' on '+bilingDat+' </td>'
        html += '</tr>'
        if billingDat['notes']:
            html += '<tr>'
            html += '<td colspan="4">'+str(billingDat['notes'])+'</td>'
            html += '</tr>'
        
        html += '<tr>'
        html += '<td style="width:25%;">Worked:</td>'
        html += '<td style="width:25%;">'+str(billingDat['timespent'])+'</td>'
        html += '<td style="width:25%;">Billable:</td>'
        html += '<td style="width:25%;">'+str(billingDat['timebillable'])+'</td>'
        html += '</tr>'
        html += '</tbody>'
    html += '<tbody>'
    html += '<tr>'
    html += '<td style="width:25%;"><b>Total Time Worked:</b></td>'
    html += '<td style="width:25%;"><b>'+str(timespentSum)+'</b></td>'
    html += '<td style="width:25%;"><b>Total Time Billed:</b></td>'
    html += '<td style="width:25%;"><b>'+str(timebillableSum)+'</b></td>'
    html += '</tr>'
    html += '</tbody>'
    html += '</table>'
    jsonData = simplejson.dumps({'billingData': html})
    return HttpResponse(jsonData, content_type="application/json")

def getMSPID(request):
    result = []
    ticketId = str(request.GET.get('ticketId',False))
    getalertsCount = incidentdat_obj.getAlertsCount(ticketId)
    mspID = ticketmodel.getMSPfromCustomFieldValues(ticketId)
    vistaraID = ticketmodel.customFeildvalueVistara(ticketId)
    result.extend((mspID, vistaraID))
    jsonData = simplejson.dumps({'resultMSP':result, 'getalertsCount': getalertsCount})
    return HttpResponse(jsonData, content_type="application/json")
