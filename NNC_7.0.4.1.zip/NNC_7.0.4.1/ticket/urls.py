"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """

from django.conf.urls import url, handler400
from ticket.views.ticketCreateView import *
handler400 = 'handler400'
urlpatterns = [
    url(r'^create/$', loadTicketMockup),
    url(r'^divcontent/$', loadDivContent),
    url(r'^createTicket/$', createTicket),
    url(r'^partnerAjax$', getPatClients),
    url(r'^clientAjax$', getClientAjax),
    url(r'^quickEdit/$', quickEditTicketInfo),
    url(r'^view/(?P<ticket_id>\d+)/$', ticketView),
    url(r'^addattachment$', uploadAttachment),
    url(r'^delattachment$', deleteAttached),
    url(r'^postReplies/$', getPostReplies),
    url(r'^auditLog/(?P<ticketid>\d+)/$', auditLog),
    url(r'^slaResloutions$', slaResloution),
    url(r'^pritStatus$', getStatusAndPriorty),
    url(r'^predefinedReplyData/$', getPredefinedReplyData),
    url(r'^kbaReplyData/$', getKbaReplyData),
    url(r'^devicenotesview$', devicenotes),
    url(r'^esclationold/$', getEsclationMatrixis),
    url(r'^esclation/$', getEsclationMatrixResult),
    url(r'^uploadImage', uploadImage),
    url(r'^ticketPostDetails/$', ticketPostDetails),
    url(r'^createPost/', createPost),
    url(r'^ticketPostDetails/$', ticketPostDetails),
    url(r'^addUser/$', addUser),
    url(r'^addPhone/', addPhone),
    url(r'^downloadAttachment/', downloadAttachment),
    url(r'^urlGetReviewsForPost/$', getreviewForPost),
    url(r'^ticketPostView/$', loadReviewForm),
    url(r'^ticketPostSave/', saveReviewData),
    url(r'^pasIntegration/', psaIntegration),
    url(r'^ticketReviews/$', getreviewForTicket),
    url(r'^showAlertsData/$', showAlertsData),
    url(r'^addNote/(?P<ticketId>[0-9A-Za-z]+)$', addNote),
    url(r'^loadNotes/(?P<ticketId>\d+)/$', loadNotes),
    url(r'^notesForm/(?P<ticketId>[0-9A-Za-z]+)$', notesForm),
    url(r'^ticketEdit/$',ticketEditView),
    url(r'^testApi/$',apistest),
    url(r'^linkcustomfieldView/$',linkcustomfieldViews),
    url(r'^ticketEditSave/$',ticketEditSave),
    url(r'^customFieldsView/$',displayOfCustomFeilds),
    url(r'^customfeildGroupids',linkcutomGroupForDept),
    url(r'^emailValidation$',emailValidation),
    url(r'^tktWatchingUsertrack',tktWatchingUserTrack),
    url(r'^billing/(?P<ticketId>[0-9A-Za-z]+)$', billing),
    url(r'^addBilling/(?P<ticketId>[0-9A-Za-z]+)$', addBilling),
    url(r'^loadBillingEntries/(?P<ticketId>\d+)/$', loadBillingEntries),
    url(r'^mappedTicketView/(?P<ticketId>\d+)/$', getMappedTicketView),
    url(r'^getMappedDataAjax/', getMappedDataAjax),
    url(r'^unMapIncidents/', unMapIncidents),
    url(r'^getTotalTicketstoMAP/(?P<ticketId>\d+)/$', getTotalTicketstoMAP),
    url(r'^gettotalTicketstoMAP/', getticketstomapAjax),
    url(r'^mapIncidentsToParent/', mapIncidentsToParent),
    url(r'^getMSPID/', getMSPID)
]
