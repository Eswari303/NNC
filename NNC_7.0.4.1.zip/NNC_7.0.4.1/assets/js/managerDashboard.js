$(document).ready(function(){

	$('#manDateRange').on('change',function(){
		if($('#manDateRange').val() == "customSelect"){
			$('#customdates').show();
	  } else {
		  $('#customdates').hide();
	  }
	});
	
	$("#btnRun").click(function(){
		var today = new Date();
       	var toDate = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
		 if ($("#manDateRange").val() == "customSelect"){
			    
	        	var tdate = new Date($("#tdDate").val())
	            var fdate = new Date($("#fdDate").val())
	            if(tdate < fdate){
	            	var validation = false;
	            	errorMessage += "<li>Please select valid Date range</li>"
	            }
	        } else if($("#manDateRange").val() == 'sevendays'){
		       	var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate()-7);
		       	var lWeek = lastWeek.getFullYear()+'-'+(lastWeek.getMonth()+1)+'-'+lastWeek.getDate();
	        	var tdate = toDate
	            var fdate = lWeek
	        } else {
	        	var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate()+7);
		       	var cuWeek = lastWeek.getFullYear()+'-'+(lastWeek.getMonth()+1)+'-'+lastWeek.getDate();
	        	var tdate = cuWeek
	            var fdate = toDate
	        }
		
		
		loadComplaince(fdate,tdate)
		/*var validation = true
		var errorMessage = ''
        $('#lodingRes').show();
        
       
       
        $.ajax({
    		type: "POST",
    		url: "/managerDashboard/deptSlaComplaiance/",
    		data: {
    			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
    			'fromDate':fdate,
    			'toDate':tdate
    		},
    		success: function(data){
    			alert(data.deptRes.deptid)
    			
    				
    				//r1Html = ""
    				r1Html = '<td style="font-weight:bold">'+data.deptRes.deptid+'</td><td>'+data.deptRes.P0Count+'</td><td >'+data.deptRes.P1Count+'</td><td>'+data.deptRes.P2Count+'</td><td>'+data.deptRes.P3Count+'</td><td>'+data.deptRes.deptid+'</td>'
    				$('#rowdiv').show();
    				$('#rowdiv').html(r1Html);
    			
    		},
        });
        $('#lodingRes').hide();	*/
    });
	
	
	
});
$(window).bind('load',function(){
	
	  
	  var today = new Date();
	  var tDate = today.getFullYear()+'-'+(today.getMonth()+1)+'-'+today.getDate();
	  var lastWeek = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 7);
	  var nWeek = lastWeek.getFullYear()+'-'+(lastWeek.getMonth()+1)+'-'+lastWeek.getDate();
	  //alert(tDate)
	  loadComplaince(tDate,nWeek)
});
function loadComplaince(fdate, tdate){
	
	var validation = true
	var errorMessage = ''
    $('#lodingRes').show(); 
   
    $.ajax({
		type: "POST",
		url: "/managerDashboard/deptSlaComplaiance/",
		data: {
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val(),
			'fromDate':fdate,
			'toDate':tdate
		},
		success: function(data){
			
				if(data.deptRes.P0Count == undefined){
					p0='0/0'
				} else {
					p0 = data.deptRes.P0Count
				}
				if(data.deptRes.P1Count == undefined){
					p1='0/0'
				} else {
					p1 = data.deptRes.P1Count
				}
				if(data.deptRes.P2Count == undefined){
					p2='0/0'
				} else {
					p2 = data.deptRes.P2Count
				}
				if(data.deptRes.P3Count == undefined){
					p3='0/0'
				} else {
					p3 = data.deptRes.P3Count
				}
				r1Html = '<td style="font-weight:bold">'+data.deptRes.deptid+'</td><td>'+p0+'</td><td >'+p1+'</td><td>'+p2+'</td><td>'+p3+'</td><td>'+data.deptRes.deptid+'</td>'
				$('#rowdiv').show();
				$('#rowdiv').html(r1Html);
				
				//alert(data.teamTktInfoRes.P0Count)
				closedHtml = '<span class="Emp_priority">'+data.teamTktInfoRes.P0Count+'</span><span class="Emp_priority">'+data.teamTktInfoRes.P1Count+'</span><span class="Emp_priority">'+data.teamTktInfoRes.P2Count+'</span><span class="Emp_priority">'+data.teamTktInfoRes.P3Count+'</span>'
				$('#closedData').show();
				$('#closedData').html(closedHtml);
				
				closedCountHtml = data.teamTktInfoRes.totltkts
				$('#totalClosedTkts').show();
				$('#totalClosedTkts').html(closedCountHtml);
				
				utiPcentIs = data.utiData.utPcent
				$('#utPcent').show();
				$('#utPcent').html(utiPcentIs);
				
				tmWrked = data.utiData.twkd
				$('#tmWrked').show();
				$('#tmWrked').html(tmWrked);
		},
    });
    $('#lodingRes').hide();	
}
