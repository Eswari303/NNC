/*$(document).ready(function(){
console.log('inside widgets');
loadWidgets();
});*/
function loadWidgets(){
$('#slide1').attr('class','item active');
$('#slide2,#slide3').attr('class','item');
	$.ajax({
		type: "POST",
		url: "/noiseDashboard/flashWidgets/",
		data: {
			'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
		},
		success: function(data){
			var widCount = 1;
			$.each(data.widgetsRes,function(key,val){
				if(val.wdgtTyp == 1 && val.count > 0){
					w1html = '<a  href="#" ><b class="label label-danger">P0</b><span class="badge badge-green" id="bin30minp0">'+val.count+'</span> <span class="wtext">Breach in 30m</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w1html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 2 && val.count > 0){
					w2html = '<a  href="#" ><b class="label label-danger">P0</b><span class="badge badge-green" id="bin30minp0">'+val.count+'</span> <span class="wtext">No update from last 30 mins</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w2html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 8 && val.count > 0){
					w3html = '<a  href="#" ><b class="label label-success">P1</b><span class="badge badge-red" id = "bin30minp1">'+val.count+'</span> <span class="wtext">Breach in 30m</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w3html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 9 && val.count > 0){
					w4html = '<a  href="#" ><b class="label label-success">P1</b><span class="badge badge-red" id = "bin30minp1">'+val.count+'</span> <span class="wtext">No update from last 30 mins</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w4html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 3 && val.count > 0){
					w5html = '<a  href="#"><i class="fa fa-bell fa-fw fa-lg icon"></i><span class="badge badge-red" id="scheduled">'+val.count+'</span><span class="wtext">Scheduled Ticket(s) Starts in 60m</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w5html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 4 && val.count > 0){
					w6html = '<a  href="#" ><i class="fa fa-clock-o fa-lg icon"></i><span class="badge badge-green" id="hmsp">'+val.count+'</span> <span class="wtext">HMSP Ticket(s) wihtout PSA Ticket</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w6html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 5 && val.count > 0){
					w7html = '<a  href="#"><i class="fa fa-bell fa-fw fa-lg icon"></i><span class="badge badge-red">'+val.count+'</span><span class="wtext">Un-assigned ticket(s) crossed 30 mins</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w7html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 6 && val.count > 0){
					w8html = '<a  href="#" ><i class="fa fa-clock-o fa-lg icon"></i><span class="badge badge-green">'+val.count+'</span> <span class="wtext">New status ticket(s) crossed 60 mins</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w8html);
					widCount = widCount+1;
				}
				if(val.wdgtTyp == 7 && val.count > 0){
					w9html = '<a  href="#" ><b class="label label-danger">RD</b><span class="badge badge-green">'+val.count+'</span> <span class="wtext">RD status ticket(s) crossed 30 mins</span></a>';
					$('#w'+widCount).show();
					$('#w'+widCount).html(w9html);
					widCount = widCount+1;
				}
			});
			if((widCount-1)<=6){
				console.log('inside if')
				$('#slide3').removeAttr( "class" );
			}
			else if((widCount-1)<=3){
				console.log('inside elseif')
				$('#slide2').removeAttr( "class" );
				$('#slide3').removeAttr( "class" );
			}
			else{
				$('#slide1').removeAttr( "class" );
				$('#slide2').removeAttr( "class" );
				$('#slide3').removeAttr( "class" );
			console.log(widCount);
			}
		},
	});
//setTimeout(function(){loadWidgets()}, 60000);
}
