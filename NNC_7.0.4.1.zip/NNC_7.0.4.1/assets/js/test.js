$(document).ready(function(){
	console.log('krasndsds');
	$('#nosDevHide').show();
	
	$("#btnRun").click(function(event){ 
		event.preventDefault();
        $('#loadingReports').show();
        var tdate = new Date($("#dptdDate").val())
        var fdate = new Date($("#dpfdDate").val())
        var toDate = tdate.getFullYear()+'-'+(tdate.getMonth()+1)+'-'+tdate.getDate();
        var fromDate = fdate.getFullYear()+'-'+(fdate.getMonth()+1)+'-'+fdate.getDate();
        $.ajax({type: "POST",
          url: "/noiseDashboard/noiseSubmit/",          
          data: { toDate: toDate, fromDate: fromDate, nocid: $("#nocid").val(), partners: $("#partners").val(), clients: $("#clients").val(), departments: $("#departments").val(),section_option: $("#section-option").val(), csrfmiddlewaretoken : $("input[name=csrfmiddlewaretoken]").val()},
          success:function(data){
        	  $('#nosDevHide').show();
        	  $('#nosCliHide').show();
        	  $('#nosisuHide').show();
        	  var nosDeviceData
              var nosClientsData
              var nosticketedSubjectLineData
	          console.log(data)
	          if(data.noiseDeviceData){
	        	  if(data.noiseDeviceData == 0){
	        		  nosDeviceData = '<tr><td></td><td></td><td> No records found </td></tr>';
	        	  }
	        	  else{
	        		  $.each(data.noiseDeviceData,function(key,val){
							nosDeviceData += '<tr>';
							nosDeviceData +='<td>'+val.msp+'</td>';
							nosDeviceData +='<td>'+val.client+'</td>';
							nosDeviceData +='<td>'+val.device_name+'</td>';
							if (val.devicetype)
								nosDeviceData +='<td>'+val.devicetype+'</td>';
							else
								nosDeviceData +='<td>None</td>';
							nosDeviceData +='<td>'+val.count+'</td>';
							//nosDeviceData += '<td><a href="/noiseDashboard/downloadDeviceDataTickets/?"'+$("#ndform").serialize()+'&deviceId='+$(this).attr("data-searchval")+'id="hrefDownloadDeviceTickets" data-searchval='+val.device_id+'><strong>'+val.count+'</strong></a></td>';
							nosDeviceData +='<td><a href="javascript:void(0);" data-target="#my-modal" id="href1" data-searchval='+val.device_id+'><strong>'+val.count+'</strong></a></td>';
							nosDeviceData += '</tr>';
			          });
	        	  }
	        	  $('#nosDevData').html(nosDeviceData);
	          }
	          else{
	        	  $('#nosDevHide').hide();
	          }
        	  if(data.noisyClientsData){
        		  if(data.noisyClientsData == 0){
	        		  nosClientsData = '<tr><td></td><td><center> No records found </center></td></tr>';
	        	  }
        		  else {
        			  $.each(data.noisyClientsData,function(key,val){
    		        	  nosClientsData += '<tr>';
    		        	  nosClientsData +='<td>'+val.msp+'</td>';
    		        	  nosClientsData +='<td>'+val.client+'</td>';
    		        	  nosClientsData +='<td>'+val.count+'</td>';
    		        	  nosClientsData += '</tr>';
    		          });
        		  }
	        	  $('#nosCliData').html(nosClientsData);
        	  }
        	  else{
        		  $('#nosCliHide').hide();
        	  }
        	  if(data.noisyticketedSubjectLineData){
        		  if(data.noisyticketedSubjectLineData == 0){
        			  nosticketedSubjectLineData = '<tr><td></td><td> No records found </td></tr>';
	        	  }
        		  else{
        			  $.each(data.noisyticketedSubjectLineData,function(key,val){
    		        	  nosticketedSubjectLineData += '<tr>';
    		        	  nosticketedSubjectLineData +='<td>'+val.subjectinfo+'</td>';
    		        	  nosticketedSubjectLineData +='<td>'+val.totaltickets+'</td>';
    		        	  //nosticketedSubjectLineData+='<td><a section="Top 20 Issues" data-id ='+val.subjectinfo+' id="ticketedSubLine" href="javascript:void(0)"><strong>'+val.totaltickets+'</strong></a></td>';
    		        	  nosticketedSubjectLineData += '</tr>';
    		          });
        		  }
	        	  $('#nosIsuData').html(nosticketedSubjectLineData);
        	  }
        	  else{
        		  $('#nosisuHide').hide();
        	  }
	        },
        });
	});
	
	$("a#href1").click(function(event){ 
	
		console.log('krsnthi');
	});
	
});