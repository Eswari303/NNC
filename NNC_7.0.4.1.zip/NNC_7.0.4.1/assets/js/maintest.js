$(document).ready(function(){
	console.log('inside js');
	$('#postid').on('click', function(){
	    console.log("form submitted!")  // sanity check
	    /*create_post();*/
	});	

