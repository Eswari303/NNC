
$(document).ready(function(){
	var multiselectEnable = {
			maxHeight: 200,
			numberDisplayed: 1,
			enableFiltering: true,
			enableCaseInsensitiveFiltering: true,
			includeFilterClearBtn: false,
	};
	
	$('input:radio[name="prioCheck"]').change(function(){
		alert("sfsdfsdfds")
	    if($(this).val() == '2'){
	       alert("test");
	    }
	});
	
	
		
	$('#nocid').on('change',function(){
		$.ajax({
			type: "POST",
			url: "/serviceManagement/nocAjax/",
			data: {
				'res_pat' : $('#nocid').val(),
				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
			},
			beforeSend: function (){
		       $('span#loadingNoc').show();
		       $('span#loadingClient').show();
		       },
		    complete: function(){
		       $('span#loadingNoc').hide();
		       $('span#loadingClient').hide();
		       },
			success: function(data){
				$('#partners').multiselect('destroy');
			    $('#clients').multiselect('destroy');
				var patData = new Array();
				var cliData = new Array();
				$.each(data.msps,function(key,val){
					patData.push("<option value = "+val.mspid+">"+val.mspname+"</option>");
				});
				$('#partners').html(patData);
				$.each(data.clients,function(key,val){
					cliData.push("<option value = "+val.mspclientid+">"+val.clientname+"</option>");
				});
				$('#clients').html(cliData);
				$('#partners').multiselect(multiselectEnable);
				$('#clients').multiselect(multiselectEnable);
			},
		});
	});
	
	$('#partners').on('change',function(){
		$.ajax({
			type: "POST",
			url: "/serviceManagement/partnerAjax/",
			data: {
				'res_cli' : $('#partners').val(),
				'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()
			},
			beforeSend: function (){
		       $('span#loadingClient').show();
		       },
		    complete: function(){
		       $('span#loadingClient').hide();
		       },
			success: function(data){
				$('#clients').multiselect('destroy');
				var datalist = new Array();
				$.each(data.clients,function(key,val){
					datalist.push("<option value = "+val.mspclientid+">"+val.clientname+"</option>");
				});
				$('#clients').html(datalist);
				$('#clients').multiselect(multiselectEnable);
			},
		});
		
	});

	
	
});


