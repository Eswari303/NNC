$(document).ready(function(){ 
	if (loginRep.length > 0) {
		$("#credentialsError").show();
		$("#errorDisplay").hide();
		document.getElementById('username').value = inputUName; 
	 }
	 else {
		 $("#credentialsError").hide();
		 $("#errorDisplay").hide();
	 }
	$('#password,#username').keypress(function(e){
		var key = e.which;
		if(key == 13)  // the enter key code
		  {
		    $('#loginid').trigger('click');
		    return false;  
		  }
	});
	/*$('#loginid').on('click',function(){
		var errorMsg = new Array();
		console.log($("#username").val());
		if($.trim($("#username").val()) == ''){
			//$("#errorDisplay").show();
		    //$("#inputVal").text("Username is required");
			console.log("username testing");
		    errorMsg.push("Username is Required");
		}
		if($.trim($("#password").val()) == ''){
			//$("#errorDisplay").show();
		    //$("#inputVal").text("Password is Required");
			console.log("password testing");
			errorMsg.push("Password is Required");
		}
		var htmlData = '';
		$.each(errorMsg,function(i,v){
			htmlData += '<li>'+v+'</li>';
		});
		 if (errorMsg.length != 0) {
			 $("#errorDisplay").show();
			$("#inputVal").html(htmlData);
		}
	})*/
});
function loginValidation()
{
	var status = true;
	var errorMsg = new Array();
	if($.trim($("#username").val()) == ''){
	    errorMsg.push("Username is required");
	}
	if($.trim($("#password").val()) == ''){
		errorMsg.push("Password is required");
	}
	var htmlData = '';
	if (errorMsg.length != 0) {
		$.each(errorMsg,function(i,v){
			htmlData += '<li>'+v+'</li>';
		});
		status = false
		$("#errorDisplay").show();
		$("#credentialsError").hide();
		$("#inputVal").html(htmlData);
	}
	else {
		$("#errorDisplay").hide();
	}
	return status
}


