$(document).ready(function () {

$('a#refscheduledinfo').on('click', function(){
   getScheduledActivities();
});

$('#addimdetials').click(function() {
	 
	  var skypeid = $('#imdata').val();
	  console.log(skypeid);
	  //url = "/employeeDasboard/employeeAjax/";
	  //open(url);
	  $.ajax({
		    type: "POST",
          	url: "/employeeDashboard/employeeAjax/",
	        data: {"skypeid": skypeid,'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()}, 
	        dataType:"html",
	        beforeSend: function (){
	            $('span#skypeload').show();
	            
	            },
	        complete: function(){
	                $('span#skypeload').hide();
	                
	                },
	        success: function (data) {
	        	$('.updateresponse').html(data);
	        	console.log(data);
	        	
	        }
	        
		}); 
	 
	});

$('#addtotalexp').click(function() {
	
	  var totalexp = $('#expdata').val();
	  console.log(totalexp);
	  //url = "/employeeDasboard/employeeAjax/";
	  //open(url);
	  $.ajax({
		    type: "POST",
        	url: "/employeeDashboard/employeeExpAjax/",
	        data: {"totalexp": totalexp,'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()}, 
	        dataType:"html",
	        beforeSend: function (){
	            $('span#expload').show();
	            
	            },
	        complete: function(){
	                $('span#expload').hide();
	                
	                },
	         
	        success: function (data) {
	        	$('.updateexpresponse').html(data);
	        	console.log(data);
	        	
	        }
	        
		}); 

	});
getScheduledActivities();
});

$(window).bind('load',function(){
	getEmpInfo();
});
function getEmpInfo()
{
	$.ajax({
		type: "POST",
        url: "/employeeDashboard/getEmpInfo/",
        data: {csrfmiddlewaretoken : $("input[name=csrfmiddlewaretoken]").val()},
        success:function(data){
        	var teamDet = ''
        	$.each(data.ticketInfo,function(key,val){
        		$("#"+key).text(val)
        	});
        	$.each(data.teamTicketInfo,function(key1,val1){
        		$("#"+key1).text(val1)
        	});
        	$.each(data.desigRes,function(key,val){
	        	teamDet += '<tr><td width="196px"><span class="name">';
	        	teamDet += val.empname+'</span><div>'+val.desig_name+'</div></td>';
	        	teamDet += '<td width="110px" align="center" id = '+val.id+'>0</td></tr>';
        	});
        	$('#teamDetails').html(teamDet);
        	$.each(data.teamDetails,function(key,val){
        		$("#"+key).text(val)
        	});
        }
	});
}
function getScheduledActivities(){
	 html = '';
	 $.ajax({
	  type: "POST",
	        url: "/employeeDashboard/employeeScheduleReports/",
	        data: {'csrfmiddlewaretoken' : $("input[name=csrfmiddlewaretoken]").val()},
	        success: function (data) {
	   if(data != null) { 
	    $.each(data, function(index, value){ 
	     html += '<td width="94%">';
	     html +=  '<span>'+value+'</span>';
	     if(index == 1){
	      html += ' <span class="badge badge-important"> In Progress </span><br>';
	     }else if(index == 2){
	      html += ' <span class="badge badge-important"> About To Start </span><br>';
	     }else{
	      html += ' <span class="badge badge-info">'+' Queue - '+index+' </span><br>';
	     }
	     html += '</td>';  
	    });
	       $('#scheduledActivities').html(html);
	   }
	   setTimeout('getScheduledActivities()', 300000); 
	        }
	 });
}

