"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import models
from django.core.cache import caches
mem_cache = caches['memcached']
from django.db import connections
from collections import OrderedDict
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
env = configobj.getCommConfigValue(configobj.app_env)

class Swdepartments(models.Model):
    departmentid = models.AutoField(primary_key=True)
    title = models.CharField(max_length=100)
    departmenttype = models.CharField(max_length=7)
    departmentmodule = models.CharField(max_length=13)
    isdefault = models.IntegerField()
    displayorder = models.IntegerField()

    class Meta:
        db_table = 'swdepartments'

    def departments(self):
        dept_except012 = mem_cache.get('dept_except012'+env)
        if not dept_except012:
            cursor = connections['ticketRead'].cursor()
            sql = "SELECT departmentid,title FROM swdepartments WHERE departmentid NOT IN (0,1,2) and departmenttype = 'public'  ORDER BY title"
            cursor.execute(sql)
            result = self.dictfetchall(cursor)
            cursor.close()
            dept_except012=OrderedDict()
            for i in result:
                dept_except012[i['departmentid']] = i['title']
            mem_cache.set('dept_except012'+env,dept_except012,86400)
        return dept_except012

    def dictfetchall(self,cursor):
        "Returns all rows from a cursor as a dict"
        desc = cursor.description
        return [
                dict(zip([col[0] for col in desc], row))
                for row in cursor.fetchall()
        ]
