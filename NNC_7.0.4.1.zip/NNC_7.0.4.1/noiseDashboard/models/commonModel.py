"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import connection,connections
from django.core.cache import caches
file_cache = caches['filecache']
from NNCPortal.commonMethods import commonMethods
comObj = commonMethods()
import logging
log  = logging.getLogger('NNCPortal')
from NNCPortal.commonModels.Swticketstatus import Swticketstatus
swt_obj = Swticketstatus()

class CommonNoiseModel(object):
    #This method return top 20 client data to view.
    def getNoisyClientsData(self,toDate,fromDate,nocs,partners,clients,departments):
        #log.info('inside getNoisyClientsData function to get top 20 client data')
        condition = '';
        if nocs != '':
            condition = " AND nid in ("+str(nocs)+")"
        
        condition1 = '';
        if partners != '' :
            condition1 = " AND mid in ("+str(partners)+")"
        
        
        condition2 = '';
        if clients != '':
            condition2 = " AND cid in ("+str(clients)+")"
        
        
        condition3 = '';
        if departments != '':
            condition3 = " AND deptid in ("+str(departments)+")"
        
        sql = 'SELECT client as client,cid as clientid, (select mspname from ntsmsps where mspid = mid) as msp,count(ticketid) as count FROM incident_data WHERE created_dt >= '+str(fromDate)+' AND created_dt <= '+str(toDate)+' AND cid != 0'
        
        if condition != '':            
            sql = sql + condition
        if condition1 != '':
            sql = sql + condition1
        if condition2 != '':
            sql = sql + condition2
        if condition3 != '':
            sql = sql + condition3    
           
        sql = sql + " group by cid order by count(ticketid) desc limit 20"; 
        #log.info('getNoisyClientsData query:%s'%sql)       
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        #log.info('getNoisyClientsData result:%s'%res)
        return res
    #This method returns top 20 device data to view
    def getNoisyDeviceData(self,toDate,fromDate,nocs,partners,clients,departments):
        #log.info('inside getNoisyDeviceData to return top 20 device data')  
                   
        condition = '';
        if nocs != '':
            condition = " AND id.nid in ("+str(nocs)+")"
        
        condition1 = '';
        if partners != '' :
            condition1 = " AND mid in ("+str(partners)+")"       
        
        condition2 = '';
        if clients != '':
            condition2 = " AND cid in ("+str(clients)+")"        
        
        condition3 = '';
        if departments != '':
            condition3 = " AND id.deptid in ("+str(departments)+")"
        
        sql = 'SELECT dd.id as device_id,dd.device_name,id.client,(select mspname from ntsmsps where mspid = id.mid) as msp,id.devicetype,count(id.ticketid) as count FROM  ntsmspdevicedata dd JOIN incident_data id ON dd.id = id.did WHERE id.created_dt >= '+str(fromDate)+' AND id.created_dt <= '+str(toDate)
        if condition != '':            
            sql = sql + condition
        if condition1 != '':
            sql = sql + condition1
        if condition2 != '':
            sql = sql + condition2
        if condition3 != '':
            sql = sql + condition3    
           
        sql = sql + " group by dd.id order by count(id.ticketid) desc limit 20";        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        #log.info('getNoisyDeviceData result:%s'%res)
        return res
    #this method return the top 20 noisy subjects to view
    def getNoisyticketedSubjectLineData(self,toDate,fromDate,nocs,partners,clients,departments): 
        #log.info('inside getNoisyticketedSubjectLineData to get top 20 subject line data')
        condition = '';
        if nocs != '':
            condition = " AND nid in ("+str(nocs)+")"
        
        condition1 = '';
        if partners != '' :
            condition1 = " AND mid in ("+str(partners)+")"       
        
        condition2 = '';
        if clients != '':
            condition2 = " AND cid in ("+str(clients)+")"        
        
        condition3 = '';
        if departments != '':
            condition3 = " AND deptid in ("+str(departments)+")"
        
        sql = 'SELECT substring(trim(subject),1,19) subjectinfo,count(ticketid) totaltickets FROM  incident_data where created_dt >='+str(fromDate)+' AND created_dt <= '+str(toDate)
        if condition != '':            
            sql = sql + condition
        if condition1 != '':
            sql = sql + condition1
        if condition2 != '':
            sql = sql + condition2
        if condition3 != '':
            sql = sql + condition3    
           
        sql = sql + " group by substring(trim(subject),1,20) order by  count(ticketid) desc limit 20";        
        #log.info('getNoisyticketedSubjectLineData query:%s'%sql)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        #log.info('getNoisyticketedSubjectLineData result:%s'%res)
        return res
    #this method returns the all the partners under particular nocid
    def getpartners(self,nocid = 0):
        #log.info('inside getPartners method the find all the partners under particular nocId')
        cursor = connections['ticketRead'].cursor()
        if nocid :
            #log.info('check result is exist in cache or not')
            partners = file_cache.get(str(nocid)+'pat')
            if not partners :
                #log.info('result not exist in cache')
                sql = 'select distinct t.mspid, t.mspname from ntsmsps t join ntsmspclients ntsc on t.mspid = ntsc.mspid where ntsc.status = 1 and ntsc.nocid = '+str(nocid)+' order by t.mspname'
                #log.info('result partner query:%s'%sql)
                cursor.execute(sql)
                partners = comObj.dictfetchall(cursor)
                file_cache.set(str(nocid)+'pat', partners, 86400)
                #log.info('set result in the cache')
        else :
            #log.info('case to load all the partners when un select all the nocs')
            partners = file_cache.get(str(nocid)+'pat')
            if not partners :
                sql = 'select distinct t.mspid, t.mspname from ntsmsps t join ntsmspclients ntsc on t.mspid = ntsc.mspid where ntsc.status = 1 order by t.mspname'
                cursor.execute(sql)
                #log.info('result partner query:%s'%sql)
                partners = comObj.dictfetchall(cursor)
                file_cache.set(str(nocid)+'pat', partners, 86400)
        cursor.close()
        return partners
    #this method return all the clients under nocId
    def getClients(self,nocid = 0):
        #log.info('inside getClients method to return all the clients under noc')
        cursor = connections['ticketRead'].cursor()
        if nocid :
            #log.info('check clients exist or not under nocid')
            clients = file_cache.get(str(nocid)+'cli')
            if not clients :
                #log.info('result not exist in cache')
                sql = 'select mspclientid, clientname from ntsmspclients where status = 1 and nocid = '+str(nocid)+' order by clientname'
                cursor.execute(sql)
                #log.info('result clients query:%s'%sql)
                clients = comObj.dictfetchall(cursor)
                file_cache.set(str(nocid)+'cli', clients, 86400)
                #log.info('set clients results in cache')
        else :
            #log.info('case to load all the client when un select all the nocs')
            clients = file_cache.get(str(nocid)+'cli')
            if not clients:
                sql = 'select mspclientid, clientname from ntsmspclients where status = 1 order by clientname'
                cursor.execute(sql)
                clients = comObj.dictfetchall(cursor)
                #log.info('result clients query:%s'%sql)
                file_cache.set(str(nocid)+'cli', clients, 86400)
        cursor.close()
        return clients
    #this method returns all the clients under the partner
    def getClientsofPat(self,pid = 0):
        #log.info('inside getClientsofPat method to return all the clients info under partner')
        cursor = connections['ticketRead'].cursor()
        if pid :
            #log.info('check result exist in cache or not')
            clients = file_cache.get(pid)
            if not clients :                
                sql = 'select mspclientid, clientname from ntsmspclients where status = 1 and  mspid in ('+str(pid)+') order by clientname'
                cursor.execute(sql)
                #log.info('result clients query:%s'%sql)
                clients = comObj.dictfetchall(cursor)
                file_cache.set(pid, clients, 86400)
                #log.info('set results in the cache')
        else :
            #log.info('case to load all the client when un select all the partners')
            clients = file_cache.get(pid)
            if not clients :
                sql = 'select mspclientid, clientname from ntsmspclients where status = 1 order by clientname'
                #log.info('result clients query:%s'%sql)
                cursor.execute(sql)
                clients = comObj.dictfetchall(cursor)
                file_cache.set(pid, clients, 86400)
        cursor.close()
        return clients
    #this method returns top 20 device data based on selected drop downs
    def getTopDeviceData(self,toDate,fromDate,nocs,partners,clients,departments,deviceId):
        #log.info('inside getTopDeviceData method to return top 20 device data based on selected drop downs')

        condition = ''
        if nocs != '':
            condition = " AND id.nid in ("+str(nocs)+")"
        
        condition1 = ''
        if partners != '' :
            condition1 = " AND id.mid in ("+str(partners)+")"       
        
        condition2 = ''
        if clients != '':
            condition2 = " AND id.cid in ("+str(clients)+")"        
        
        condition3 = ''
        if departments != '':
            condition3 = " AND id.deptid in ("+str(departments)+")"
        sql = """select SQL_CALC_FOUND_ROWS DISTINCT(id.ticketid),id.resol_sla,id.ticketid,
            (select title from swticketpriorities where priorityid = id.priorityid)as priority,
            (select title from swdepartments where departmentid = id.deptid) as department,
            (select fullname from swstaff where staffid = id.staffid) as Owner,
            (select fullname from swstaff where staffid = st.staffid) as staffid,
            (select title from swticketstatus where ticketstatusid = id.statusid) as status, 
            CONVERT_TZ(from_unixtime(id.created_dt),"+08:00","+00:00") as created_dt,CONVERT_TZ(from_unixtime(id.lastactivity),"+08:00","+00:00") as lastactivity,
            id.subject,st.timeworked,id.client,id.device,(select mspname from ntsmsps where mspid = id.mid) as msp
            FROM incident_data id JOIN swtickets st ON st.ticketid=id.ticketid WHERE id.did = """+str(deviceId) +""" AND id.deptid != 1 AND id.created_dt >= """+str(fromDate)+""" AND id.created_dt <= """+str(toDate)
        if condition != '':   
            sql = sql + condition
        if condition1 != '':
            sql = sql + condition1
        if condition2 != '':
            sql = sql + condition2
        if condition3 != '':
            sql = sql + condition3   
        sql = sql + " ORDER BY id.resol_due, id.ticketid ASC";      
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        #log.info('final Result for getTopDeviceData:%s'%res)
        return res
    #this method returns top 20 clients data based on selected drop downs
    def getTopClientData(self,toDate,fromDate,nocs,partners,clients,departments,clientId):
        #log.info('inside getTopClientsData to get top 20 clients results based on drop downs')
        
        condition = '';
        if nocs != '':
            condition = " AND id.nid in ("+str(nocs)+")"
        
        condition1 = '';
        if partners != '' :
            condition1 = " AND id.mid in ("+str(partners)+")"       
        
        condition2 = '';
        if clients != '':
            condition2 = " AND id.cid in ("+str(clients)+")"        
        
        condition3 = '';
        if departments != '':
            condition3 = " AND id.deptid in ("+str(departments)+")"
        sql = """select SQL_CALC_FOUND_ROWS DISTINCT(id.ticketid),id.resol_sla,id.ticketid,
            (select title from swticketpriorities where priorityid = id.priorityid)as priority,
            (select title from swdepartments where departmentid = id.deptid) as department,
            (select fullname from swstaff where staffid = id.staffid) as Owner,
            (select fullname from swstaff where staffid = st.staffid) as staffid,
            (select title from swticketstatus where ticketstatusid = id.statusid) as status, 
            CONVERT_TZ(from_unixtime(id.created_dt),"+08:00","+00:00") as created_dt,CONVERT_TZ(from_unixtime(id.lastactivity),"+08:00","+00:00") as lastactivity,
            id.subject,st.timeworked,id.client,id.device,(select mspname from ntsmsps where mspid = id.mid) as msp
            FROM incident_data id JOIN swtickets st ON st.ticketid=id.ticketid WHERE id.cid = """+str(clientId) +""" AND id.deptid != 1 AND id.created_dt >= """+str(fromDate)+""" AND id.created_dt <= """+str(toDate)
        if condition != '':            
            sql = sql + condition
        if condition1 != '':
            sql = sql + condition1
        if condition2 != '':
            sql = sql + condition2
        if condition3 != '':
            sql = sql + condition3   
        sql = sql + " ORDER BY id.resol_due, id.ticketid";        
        #log.info('getTopClientData query:%s'%sql)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        #log.info('getTopClientData result:%s'%res)
        return res
    #this method returns top 20 issue data based on selected drop downs
    def getTopIssueData(self,toDate,fromDate,nocs,partners,clients,departments,subject):
        #log.info('inside getTopIssueData to get top 20 issue results based on drop downs')
        condition = '';
        if nocs != '':
            condition = " AND id.nid in ("+str(nocs)+")"
        
        condition1 = '';
        if partners != '' :
            condition1 = " AND id.mid in ("+str(partners)+")"       
        
        condition2 = '';
        if clients != '':
            condition2 = " AND id.cid in ("+str(clients)+")"        
        
        condition3 = '';
        if departments != '':
            condition3 = " AND id.deptid in ("+str(departments)+")"
        sql = """select SQL_CALC_FOUND_ROWS DISTINCT(id.ticketid),id.resol_sla,id.ticketid,
            (select title from swticketpriorities where priorityid = id.priorityid)as priority,
            (select title from swdepartments where departmentid = id.deptid) as department,
            (select fullname from swstaff where staffid = id.staffid) as Owner,
            (select fullname from swstaff where staffid = st.staffid) as staffid,
            (select title from swticketstatus where ticketstatusid = id.statusid) as status, 
            CONVERT_TZ(from_unixtime(id.created_dt),"+08:00","+00:00") as created_dt,CONVERT_TZ(from_unixtime(id.lastactivity),"+08:00","+00:00") as lastactivity,
            id.subject,st.timeworked,id.client,id.device,(select mspname from ntsmsps where mspid = id.mid) as msp
            FROM incident_data id JOIN swtickets st ON st.ticketid=id.ticketid WHERE id.subject like '%"""+subject+"""%' AND id.deptid != 1 AND id.created_dt >= """+str(fromDate)+""" AND id.created_dt <= """+str(toDate)
        if condition != '':            
            sql = sql + condition
        if condition1 != '':
            sql = sql + condition1
        if condition2 != '':
            sql = sql + condition2
        if condition3 != '':
            sql = sql + condition3   
        sql = sql + " ORDER BY id.resol_due, id.ticketid";    
        #log.info('getTopIssueData query:%s'%sql)  
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        #log.info('getTopIssueData result:%s'%res)
        return res
    #this method returns top 20 subjest based on selected issue
    def getticketedSubjectLineDrilldown(self,fromDate,toDate,nocs,subject,partners,clients,departments): 
        #log.info('inside getticketedSubjectLineDrilldown to get top 20 subject results')
        condition = '';
        if nocs != '':
            condition = " AND nid in ("+str(nocs)+")"
        
        condition1 = '';
        if partners != '' :
            condition1 = " AND mid in ("+str(partners)+")"       
        
        condition2 = '';
        if clients != '':
            condition2 = " AND cid in ("+str(clients)+")"        
        
        condition3 = '';
        if departments != '':
            condition3 = " AND deptid in ("+str(departments)+")" 
        
        sql = 'select subject as subjectinfo, count(ticketid) totaltickets from incident_data where created_dt >='+str(fromDate)+' AND created_dt <= '+str(toDate)
        if condition != '':     
            sql = sql + condition
        if condition1 != '':
            sql = sql + condition1
        if condition2 != '':
            sql = sql + condition2
        if condition3 != '':
            sql = sql + condition3   
           
        sql = sql + " and subject like '"+str(subject)+"%' group by subject";        
        #log.info('getticketedSubjectLineDrilldown query:%s'%sql)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        res = comObj.dictfetchall(cursor)
        cursor.close()
        #log.info('getticketedSubjectLineDrilldown result:%s'%res)
        return res
    def getWidgetTickets(self,dept,wdg):
        closed_statuses = swt_obj.getClosedStatuses_emp()
        searchAttribute = '='
        #Excluded wfci and wfpi status along with closed statuses for Unassigned tickets crossed 60 mins widget
        remwfciWfpiStatus = '9,46,'+closed_statuses[0]['closed_statuses']
        if len(dept.split(',')) > 1:
            searchAttribute = 'IN'
        if wdg == 1:
            sql = "select ticketid from incident_data where priorityid = 8 and resol_due >= 0 and resol_due <= 1800 and statusid not in (5 ,3,17,20,32 ,41) and  deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 2:
            sql = "select ticketid from incident_data where statusid in (1,7,12,18,19,21,22,23) and priorityid = 8 and unix_timestamp(now())-lastactivity > 1800 and  deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 3:
            sql = 'SELECT ticketid as count from incident_data i Join swcustomfieldvalues scfv where i.ticketid = scfv.typeid and scfv.customfieldid=12 and scfv.fieldvalue like "%-%-% %:%:%" and CONVERT_TZ(scfv.fieldvalue,"US/Pacific","UTC") between now() and date_add(now(), interval 30 minute)  and i.statusid not in (5 ,3 ,17 ,20 ,32 ,41) and i.deptid ' + searchAttribute + ' (' + dept + ')';
        elif wdg == 4:
            sql = "select i.ticketid  from incident_data i join swcustomfieldvalues scfv on i.ticketid = scfv.typeid where i.statusid = 9  and scfv.customfieldid = 3 and fieldvalue = ' ' and i.deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 5:
            sql = "select i.ticketid from incident_data i join swtickets st on st.ticketid=i.ticketid where unix_timestamp(now())-i.lastactivity>1800 and i.statusid not in ("+remwfciWfpiStatus+") and i.nid in (1,2,7,8,9,18,5,33) and st.ownerstaffid=0 and i.deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 6:
            sql = "select ticketid from incident_data where statusid=1 and unix_timestamp(now())-lastactivity>3600  and nid in (1,2,7,8,9,18,5,33) and deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 7:
            sql = "select ticketid from incident_data where statusid=19 and unix_timestamp(now())-lastactivity>1800 and deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 8:
            sql = "select ticketid from incident_data where priorityid = 9 and resol_due >= 0 and resol_due <= 1800 and statusid not in (5 ,3,17,20,32 ,41) and  nid in (1,2,7,8,9,18,5,33) and deptid " + searchAttribute + " (" + dept + ")"
        elif wdg == 9:
            sql = "select ticketid from incident_data where statusid in (1,7,12,18,19,21,22,23) and priorityid = 9 and unix_timestamp(now())-lastactivity > 1800 and  deptid " + searchAttribute + " (" + dept + ")"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        tickets = cursor.fetchall()
        cursor.close()
        data = ""
        for i in tickets:
            data += str(i[0]) + ","
        return data[0:len(data) - 1]
