"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from __future__ import unicode_literals
from django.db import models
from django.template.defaultfilters import default

class Ntsmspclients(models.Model):
    mspclientid = models.BigIntegerField(primary_key=True)
    mspid = models.BigIntegerField(null = True)
    clientname = models.CharField(max_length=255, blank=True)
    status = models.IntegerField(blank=True, null=True)
    clientcode = models.CharField(max_length=50, blank=True, null=True)
    updated_time = models.DateTimeField(blank=True, null=True)
    servicestageid = models.IntegerField(blank=True, default = 0)
    servicetypeid = models.IntegerField(blank=True, default = 0)
    channel_id = models.IntegerField(blank=True, default = 0, null = True)
    nocid = models.BigIntegerField(default = 0)
    nocname = models.CharField(max_length=100, blank=True)
    
    
    class Meta:
        managed = True
        app_label = 'noiseDashboard'
        db_table = 'ntsmspclients'