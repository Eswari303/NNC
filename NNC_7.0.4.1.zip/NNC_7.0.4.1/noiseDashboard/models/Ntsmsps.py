"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from __future__ import unicode_literals
from django.db import models
from django.template.defaultfilters import default

class Ntsmsps(models.Model):
    mspid = models.BigIntegerField(primary_key=True)
    mspname = models.CharField(max_length=255, blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    mspcode = models.CharField(max_length=50, blank=True, null=True)
    updated_time = models.DateTimeField(blank=True, null=True)
    channel_id = models.IntegerField(blank=True, default = 0)
    ticketing_module = models.IntegerField(blank=True, default = 0)
    tcks_support = models.IntegerField(blank=True, default = 0)
    ticketing_system_id = models.BigIntegerField(null=True,blank=True)
    
    def __unicode__(self):
        return self.mspid
    
    class Meta:
        managed = True
        app_label = 'noiseDashboard'
        db_table = 'ntsmsps'