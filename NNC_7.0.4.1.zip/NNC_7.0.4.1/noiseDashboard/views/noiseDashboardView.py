"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
import time
import os
import urllib
from datetime import datetime, timedelta
import datetime as dt
import json as simplejson
from django.core.cache import caches
from collections import OrderedDict
from django.http import HttpResponse
from django.shortcuts import render_to_response

from noiseDashboard.models.Swdepartments import Swdepartments
from NNCPortal.commonModels.Ntsmsps import Ntsmsps
from NNCPortal.commonModels.StaffDeptMapping import StaffDeptMapping
from NNCPortal.commonMethods import commonMethods
from noiseDashboard.models.commonModel import CommonNoiseModel
from noiseDashboard.forms import NoiseDashboardForm
from django.template import RequestContext
from NNCPortal.configfile import ConfigManager
from NNCPortal.commonModels.Ntsmspclients import Ntsmspclients
from NNCPortal.commonModels.Ntsmspnocs import Ntsmspnocs

file_cache = caches['filecache']
mem_cache = caches['memcached']

swdept_obj = Swdepartments()
comObj = commonMethods()
comMObj = CommonNoiseModel()
nocdata_obj = Ntsmspnocs()
mspclnt_obj = Ntsmspclients()
msps_obj = Ntsmsps()
configobj = ConfigManager()
staffdeptmap_obj = StaffDeptMapping()

def subjectLineDrillDown(request):
    toDate= request.GET.get('toDate',False)
    fromDate= request.GET.get('fromDate',False)
    toDate1 =  str(time.mktime(dt.datetime.strptime(toDate,'%m/%d/%Y').timetuple()) )[:-2]
    fromDate1 = str(time.mktime(dt.datetime.strptime(fromDate,'%m/%d/%Y').timetuple()) )[:-2]
    toDate1 = int(toDate1)+19800
    fromDate1 = int(fromDate1)+19800
    subject = request.GET.get('subId',False)
    finResult = request.GET
    res = dict(finResult.lists())
    nocid = request.GET.get('nocid',False)
    nocidIs = ""
    if request.GET.get('nocid[]', False) :
        for nocid in res['nocid[]'] :
            nocidIs = nocidIs + nocid +str(",")
    if nocidIs !="":
        nocid = nocidIs[:-1] 
    partners= request.GET.get('partners[]',False)
    partnersIs = ""
    if request.GET.get('partners[]', False) :
        for partners in res['partners[]'] :
            partnersIs = partnersIs + partners +str(",")
    if partnersIs !="":
        partners = partnersIs[:-1]  
    
    clients= request.GET.get('clients[]',False) 
    clientsIs = ""
    if request.GET.get('clients[]', False) :
        for clients in res['clients[]'] :
            clientsIs = clientsIs + clients +str(",")
    if clientsIs !="":
        clients = clientsIs[:-1]  
    
    departments= request.GET.get('departments[]',False) 
    departmentsIs = ""
    if request.GET.get('departments[]', False) :
        for departments in res['departments[]'] :
            departmentsIs = departmentsIs + departments +str(",")
    if departmentsIs !="":
        departments = departmentsIs[:-1]
        
    if nocid == False:
        nocid="" 
    if partners == False:
        partners=""  
    if clients == False:
        clients=""  
    if departments == False:
        departments=""
    subject = subject.replace('\\','%')
    ticketedSubjectLineDrilldown = comMObj.getticketedSubjectLineDrilldown(fromDate1,toDate1,nocid,subject,partners,clients,departments)
    #return render_to_response('_ticketedSubjectLinePopup.html',{'ticketdrilldown':ticketedSubjectLineDrilldown})
    return render_to_response('_ticketedSubjectLinePopup.html', {'ticketdrilldown':ticketedSubjectLineDrilldown,'clients':clients,'nocs':nocid,'depts':departments,'toDate':toDate,'fromDate':fromDate, 'partners': partners,'subjectID':subject})

def loadMockup(request):
    if request.method == 'POST':
        print "inside NoiseDashboard"
    else :
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            form = NoiseDashboardForm()
            msps = msps_obj.getMSPSdata()
            #msps = mem_cache.get('msps')
            #if not msps:
                #msps = Ntsmsps.objects.using('ticketRead').only('mspname','mspid').order_by('mspname')
                #mem_cache.set('msps', msps, 86400)
            nocs = nocdata_obj.getNocdata()
            #nocs = mem_cache.get('nocs')
            #if not nocs:
                #nocs = Nocdetails.objects.using('mspDB').all().order_by('name')
                #mem_cache.set('nocs', nocs, 86400)
            clients = mspclnt_obj.showPartnerClients()
            #clients = mem_cache.get('clients')            
            #if not clients:
                #clients = Ntsmspclients.objects.using('ticketRead').only('clientname','mspclientid').order_by('clientname')
                #mem_cache.set('clients', clients, 86400)
            departments = swdept_obj.departments()
            #departments = mem_cache.get('departments_new')
            #if not departments:
                #departments = sw_dept.departments()
                #departments = Swdepartments.objects.using('ticketRead').only('title','departmentid').order_by('title')
                #mem_cache.set('departments_new', departments, 86400)
            os.environ["TZ"]="Asia/Kolkata"
            curDTime = datetime.now()
            toDate = curDTime.strftime('%m/%d/%Y')
            yesDate = curDTime - timedelta(days=6)
            fromDate = yesDate.strftime('%m/%d/%Y')
            if 'uName' in request.session :
                userName = request.session['uName'].split('@')
                userName = str(userName[0][0:14])+'...'
            else :
                userName = 'TestUser'
            return render_to_response('noiseMockup.html', {'form':form,'msps':msps,'clients':clients,'nocs':nocs,'departments':departments,'toDate':toDate,'fromDate':fromDate,'userName':userName},context_instance=RequestContext(request))
        else :
            return authRes
def flashWidgets1(request):
    mainUrl = configobj.getCommConfigValue(configobj.apiurl)
    staffId = request.session['uId']
    deptId = StaffDeptMapping.objects.using('rosterRead').only('kayako_deptid').get(nrstaffid=staffId)
    url = mainUrl+'criticalTktCount/'+str(deptId.kayako_deptid)
    apiResult = comObj.getAPIResponce(url)
    for key,apiRes in apiResult.items() :
        widgetsRes = apiRes
        break
    jsonData = simplejson.dumps({'widgetsRes': widgetsRes})
    return HttpResponse(jsonData, content_type="application/json")
def flashWidgets(request):
    mainUrl = configobj.getCommConfigValue(configobj.apiurl)
    staffId = request.session['uId']
    empKayakoDepts = StaffDeptMapping.objects.using('rosterRead').only('kayako_deptid').filter(nrstaffid = staffId)
    empKykDepts = ','.join([str(empKayakoDeptId.kayako_deptid) for empKayakoDeptId in empKayakoDepts])
    empKykDept = "deptId:"+empKykDepts
    empKykDeptsEncoded=urllib.quote_plus(empKykDept)
    url = mainUrl+'criticalTktCount?queryString='+str(empKykDeptsEncoded)
    apiResult = comObj.getAPIResponce(url)
    for key,apiRes in apiResult.iteritems() :
        widgetsRes = apiRes
        break
    finalWidgetRes = {}
    for result in widgetsRes :
        if result['wdgtTyp'] not in finalWidgetRes.keys() :
            finalWidgetRes.setdefault(result['wdgtTyp'],{'wdgtTyp':result['wdgtTyp'],'deptid' : str(result['deptid'])+',','count':int(result['count']),'tickets':''})
            if int(result['count']) < 50 and int(result['count']) > 0 :
                finalWidgetRes[result['wdgtTyp']]['tickets'] += str(result['tickets'])+','
            elif int(result['count']) >= 50 :
                resTickets = comMObj.getWidgetTickets(result['deptid'],int(result['wdgtTyp']))
                if resTickets :   
                    finalWidgetRes[result['wdgtTyp']]['tickets'] += resTickets+',' 
        else :
            finalWidgetRes[result['wdgtTyp']]['deptid'] += str(result['deptid'])+','
            finalWidgetRes[result['wdgtTyp']]['count'] = finalWidgetRes[result['wdgtTyp']]['count']+int(result['count'])
            if int(result['count']) < 50 and int(result['count']) > 0 :
                finalWidgetRes[result['wdgtTyp']]['tickets'] += str(result['tickets'])+','
            elif int(result['count']) >= 50 :
                resTickets = comMObj.getWidgetTickets(result['deptid'],int(result['wdgtTyp']))
                if resTickets :   
                    finalWidgetRes[result['wdgtTyp']]['tickets'] += resTickets+','  
    for key,result in finalWidgetRes.iteritems() :
        result['deptid'] = result['deptid'][:-1]
        result['tickets'] = result['tickets'][:-1]
    jsonData = simplejson.dumps({'widgetsRes': finalWidgetRes})
    return HttpResponse(jsonData, content_type="application/json")
def getNocAjax(request):
    patners = []
    clients = []
    if request.method == "POST" :
        finResult = request.POST
        res = dict(finResult.lists())
        if request.POST.get('res_pat[]', False) :
            for nocid in res['res_pat[]'] :
                pat = comMObj.getpartners(nocid)
                cli = comMObj.getClients(nocid)
                if pat :
                    patners = patners + pat
                if cli :
                    clients = clients + cli
        else :
            patners = comMObj.getpartners()
            clients = comMObj.getClients()
    jsonData = simplejson.dumps({'msps': patners, 'clients': clients})
    return HttpResponse(jsonData, content_type="application/json")

def getPatClients(request):
    if request.method == "POST" :
        search = request.POST.getlist('res_cli[]', False)
        if search :
            search_text = ",".join(search)
        else :
            search_text = ''
    else :
        search_text = ''
    cli = comMObj.getClientsofPat(search_text)
    jsonData = simplejson.dumps({'clients': cli})
    return HttpResponse(jsonData, content_type="application/json")
    
def loadTop20Res(request):
    toDate1= str(request.POST.get('toDate',False))
    fromDate1= str(request.POST.get('fromDate',False))
    toDate =  str(time.mktime(dt.datetime.strptime(toDate1,'%Y-%m-%d').timetuple()) )[:-2]
    fromDate = str(time.mktime(dt.datetime.strptime(fromDate1,'%Y-%m-%d').timetuple()) )[:-2]
    toDate = int(toDate)+19800
    fromDate = int(fromDate)+19800

    finResult = request.POST
    res = dict(finResult.lists())
    nocid= request.POST.get('nocid[]',False) 
    nocidIs = ""
    if request.POST.get('nocid[]', False) :
        for nocid in res['nocid[]'] :
            nocidIs = nocidIs + nocid +str(",")
    if nocidIs !="":
        nocid = nocidIs[:-1]
    
    partners= request.POST.get('partners[]',False)
    partnersIs = ""
    if request.POST.get('partners[]', False) :
        for partners in res['partners[]'] :
            partnersIs = partnersIs + partners +str(",")
    if partnersIs !="":
        partners = partnersIs[:-1]  
    
    clients= request.POST.get('clients[]',False) 
    clientsIs = ""
    if request.POST.get('clients[]', False) :
        for clients in res['clients[]'] :
            clientsIs = clientsIs + clients +str(",")
    if clientsIs !="":
        clients = clientsIs[:-1]  
    
    departments= request.POST.get('departments[]',False) 
    departmentsIs = ""
    if request.POST.get('departments[]', False) :
        for departments in res['departments[]'] :
            departmentsIs = departmentsIs + departments +str(",")
    if departmentsIs !="":
        departments = departmentsIs[:-1]  
        
    if nocid == False:
        nocid="" 
    if partners == False:
        partners=""  
    if clients == False:
        clients=""  
    if departments == False:
        departments=""   
              
    noiseDeviceData=""
    noisyClientsData=""
    noisyticketedSubjectLineData=""
    
    section_option = request.POST.get('section_option[]',False)
    if request.POST.get('section_option[]', False) :
        for section_option in res['section_option[]'] :
            if section_option == '1':
                noiseDeviceData = comMObj.getNoisyDeviceData(toDate,fromDate,nocid,partners,clients,departments)
            if section_option == '2':  
                noisyClientsData = comMObj.getNoisyClientsData(toDate,fromDate,nocid,partners,clients,departments)
            if section_option == '3':
                noisyticketedSubjectLineData = comMObj.getNoisyticketedSubjectLineData(toDate,fromDate,nocid,partners,clients,departments)
       
    jsonData = simplejson.dumps({'noiseDeviceData':noiseDeviceData,'noisyClientsData':noisyClientsData,'noisyticketedSubjectLineData':noisyticketedSubjectLineData})
    return HttpResponse(jsonData,content_type="application/json")

def downloadTicketData(request):
    toDate1= str(request.GET.get('toDate',False))
    fromDate1= str(request.GET.get('fromDate',False))
    todt = toDate1.split(' ')
    frdt = fromDate1.split(' ')
    toDate =  str(time.mktime(dt.datetime.strptime(todt[0],'%m/%d/%Y').timetuple()) )[:-2]
    fromDate = str(time.mktime(dt.datetime.strptime(frdt[0],'%m/%d/%Y').timetuple()) )[:-2]
    toDate = int(toDate)+19800
    fromDate = int(fromDate)+19800
    inputId = request.GET.get('id',False)
    finResult = request.GET
    res = dict(finResult.lists())
    nocid = request.GET.get('nocId',False)
    nocidIs = ""
    if request.GET.get('nocid[]', False) :
        for nocid in res['nocid[]'] :
            nocidIs = nocidIs + nocid +str(",")
    if nocidIs !="":
        nocid = nocidIs[:-1]
    
    partners= request.GET.get('partners[]',False)
    partnersIs = ""
    if request.GET.get('partners[]', False) :
        for partners in res['partners[]'] :
            partnersIs = partnersIs + partners +str(",")
    if partnersIs !="":
        partners = partnersIs[:-1]  
    
    clients= request.GET.get('clients[]',False) 
    clientsIs = ""
    if request.GET.get('clients[]', False) :
        for clients in res['clients[]'] :
            clientsIs = clientsIs + clients +str(",")
    if clientsIs !="":
        clients = clientsIs[:-1]  
    
    departments= request.GET.get('departments[]',False) 
    departmentsIs = ""
    if request.GET.get('departments[]', False) :
        for departments in res['departments[]'] :
            departmentsIs = departmentsIs + departments +str(",")
    if departmentsIs !="":
        departments = departmentsIs[:-1]
        
    if nocid == False:
        nocid="" 
    if partners == False:
        partners=""  
    if clients == False:
        clients=""  
    if departments == False:
        departments=""   

    titles = OrderedDict()
    titles['resol_sla'] = "SLA Resolution"
    titles['ticketid'] = "Ticket Id"
    titles['priority'] = "Priority"
    titles['department'] = "Department"
    titles['Owner'] = "Owner"
    titles['status'] = "Status"
    titles['created_dt'] = "Created Date (PDT)"
    titles['subject'] = "Subject"
    titles['staffid'] = "Requester"
    titles['lastactivity'] = "Last Update (PDT)"
    titles['timeworked'] = "Time Worked (Min)"
    titles['msp'] = "Partner Name"
    titles['client'] = "Client Name"
    titles['device'] = "Device Name"
    if (request.GET.get('data-source',False) == 'Devices') :
        filename = 'Top20Devices.xlsx'
        tktData = comMObj.getTopDeviceData(toDate,fromDate,nocid,partners,clients,departments,inputId)
    elif (request.GET.get('data-source',False) == 'Clients') :
        filename = 'Top20Clients.xlsx'
        tktData = comMObj.getTopClientData(toDate,fromDate,nocid,partners,clients,departments,inputId)
    elif (request.GET.get('data-source',False) == 'Issues') :
        filename = 'Top20Issues.xlsx'
        tktData = comMObj.getTopIssueData(toDate,fromDate,nocid,partners,clients,departments,inputId)
    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename='+filename
    i=0
    excelRes= {}
    for data in tktData :
        if data['created_dt'] :
            data['created_dt'] = data['created_dt'].strftime('%Y-%m-%d %H:%M:%S')#dt.datetime.strptime(data['created_dt'],'%Y-%m-%d %H:%M:%S')
        if data['lastactivity'] :
            data['lastactivity'] = data['lastactivity'].strftime('%Y-%m-%d %H:%M:%S')#dt.datetime.strptime(data['lastactivity'],'%Y-%m-%d %H:%M:%S')
        if data['resol_sla']:
            if not data['resol_sla'] == 'NO SLA' :
                data['resol_sla'] = comObj.getHours(data['resol_sla'])
        excelRes[i] = comObj.prepareExcelData(titles,data)
        i+=1
    xlsx_data = comObj.WriteToExcel(titles,excelRes)
    response.write(xlsx_data)
    return response
