"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.core.cache import caches

from NNCPortal.configfile import ConfigManager
from NNCPortal.commonMethods import commonMethods
from NNCPortal.commonModels.commonModelMethods import CommonModelMethods
from NNCPortal.commonModels.NrStaff import NrStaff
from serviceManagement.models.TicketbrowserTemplates import TicketbrowserTemplates
from serviceManagement.models.NncJobSchRecurence import NncJobSchRecurence
from serviceManagement.models.TicketbrowserTemplates import TicketbrowserTemplates
from serviceManagement.models.NncSchJobs import NncSchJobs
from serviceManagement.models.commonScheduleModel import CommonScheduleModel
from datetime import datetime
from collections import OrderedDict
import datetime as dt,os
import json as simplejson

comObj = commonMethods()
comMObj=CommonScheduleModel()
file_cache = caches['memcached']
configobj = ConfigManager()
commMM = CommonModelMethods()
nrstaff_obj = NrStaff()
nncschjob_obj = NncSchJobs()
tktbrwsr_obj = TicketbrowserTemplates()

def showSchTemp(request):
    uId = request.session['uId']
    tId = 0
    tType = "TB"
    schRes = nncschjob_obj.getJobDetailsByTemplateIdAndUserId(uId,tType,tId)
    finalRes = []
    finRes = {}
    for res in schRes :
        finRes['tempName'] = res['JobName']
        finRes['tempType'] = configobj.getRepTypeConfigValue(str(res['reportType']))
        finRes['reportType'] = res['reportType']
        finRes['schType'] = res['scheduleType']
        if finRes['schType'] == 'Daily':
            if res['daily_everyaftergivendaycount'] :
                finRes['recPat'] = 'Every '+str(res['daily_everyaftergivendaycount'])+' day(s)'
            else :
                finRes['recPat'] = 'Every weekday'
        elif finRes['schType'] == 'Weekly':
            finRes['recPat'] = 'Every '+str(res['weekly_recu_every_given_week'])+' week(s) on '+str(res['weekly_weekdays'])
        elif finRes['schType'] == 'Monthly':
            if res['monthly_rptDay'] :
                finRes['recPat'] = 'Every '+str(res['monthly_rptDay'])+' day'
            else :
                finRes['recPat'] = 'Every '+str(res['monthly_theDay'])
        if res['recu_from'] and res['execution_time'] :
            finRes['stDate'] = str(res['recu_from'].strftime('%m/%d/%Y'))+' '+str(res['execution_time'].strftime('%H:%M'))
        if res['isnoenddate'] :
            finRes['recRange'] = 'No end date'
        elif res['endafter'] :
            finRes['recRange'] = 'End after '+str(res['endafter'])+' occurences'
        elif res['recu_end']:
            finRes['recRange'] = res['recu_end'].strftime('%m/%d/%Y')
        if res['LastRunTime'] :
            finRes['lRunTime'] = res['LastRunTime'].strftime('%Y-%m-%d %H:%M')
        else :
            finRes['lRunTime'] = ''
        finRes['staff_name'] = res['staff_name']
        finRes['lastdate'] = res['lastdate'].strftime('%Y-%m-%d %H:%M')
        finRes['templateId'] = res['templateId']
        finRes['jobId'] = res['jobId']
        finRes['templateuserid'] = res['templateuserid']
        finalRes.append(finRes)
        finRes = {}
    return render_to_response('showScheduleTemplates.html',{'schRes':finalRes})

def addSchTemp(request):
    userId = request.session['uId']
    tempList = tktbrwsr_obj.getTemplateList(userId)
    dates = {}
    os.environ["TZ"]="Asia/Kolkata"
    curDTime = datetime.now()
    endYear = curDTime.year+3
    dates['start'] = curDTime.strftime('%Y-%m-%d %H:%M:00')
    dates['end'] = str(endYear)+curDTime.strftime('-%m-%d %H:%M:%S')
    dates = comObj.convertDateUTC(dates,'IST')
    dates = comObj.convertDateReq(dates,'PDT')
    dates['start'] = datetime.strptime(dates['start'],'%Y-%m-%d %H:%M:%S').strftime('%m/%d/%Y %H:%M:00')
    dates['end'] = datetime.strptime(dates['end'],'%Y-%m-%d %H:%M:%S').strftime('%m/%d/%Y %H:%M:%S')
    dateRes = dates['start'].split(' ')
    dates['start'] = dateRes[0]
    dates['end'] = dates['end'].split(' ')[0]
    timeRes = dateRes[1].split(':')
    if int(timeRes[1]) >= 30 :
        stime = int(timeRes[0])+1
        if stime > 9 :
            dates['startTime'] = str(stime)+':00:'+timeRes[2]
        else :
            dates['startTime'] = '0'+str(stime)+':00:'+timeRes[2]
    else :
        dates['startTime'] = str(timeRes[0])+':30:'+timeRes[2]
    timeArray = getTimeArray()
    dates['email'] = request.session['uName']
    staffInfo = nrstaff_obj.getStaffInfo()
    staffInfo = simplejson.dumps(staffInfo)
    dates['day'] = curDTime.day
    return render_to_response('addSchTemp.html',{'tempList': tempList,'dates':dates,'timeArray':timeArray,'staffInfo':staffInfo},context_instance=RequestContext(request))
def addNewTemp(request):
    
    finResult = {}
    if request.POST.get('selTemp', False) :
        selTempDet = eval(request.POST.get('selTemp', False))
        finResult['reportType'] = 'TB' if selTempDet['reportType'] == '' else selTempDet['reportType']
        jobId = ''
    else :
        selTempDet = {}
        tRes = (request.POST.get('updateTemplate', False))
        tempInfo = tRes.split('|')
        jobDetails = TicketbrowserTemplates.objects.using('rosterRead').get(templateid = tempInfo[0])
        selTempDet['templatename'] = jobDetails.templatename
        selTempDet['templatetype'] = jobDetails.templatetype
        selTempDet['templateid'] = tempInfo[0]
        selTempDet['reportType'] = tempInfo[1]
        jobId = tempInfo[2]
    newJob = {}
    finResult['dailyEvery'] = request.POST.get('dailyEvery', False)
    finResult['monEvery'] = request.POST.get('monEvery', False)
    finResult['endAfter'] = request.POST.get('endAfter', False)
    finResult['weeklyEvery'] = request.POST.get('weeklyEvery', False)
    scheduleType = str(request.POST.get('schType', False))
    if selTempDet['templatename'] :
        newJob['JobName'] = selTempDet['templatename']
    newJob['reportType'] = selTempDet['reportType']
    newJob['scheduleType'] = scheduleType
    newJob['templateid'] = selTempDet['templateid']
    newJob['ispublic'] = 1
    newJob['createddate'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S') #---------
    if int(selTempDet['templatetype']) == 1 :
        newJob['emailIds'] = str(request.POST.get('emailList', False)).replace(" ", "")
    else:
        newJob['emailIds'] = request.session['uName']
    newJob['nextrunqueuetime'] = None
    newJob['createdby'] = request.session['uId']
    newJob['lastruntime'] = None
    if jobId:
        condition = 'JobId = '+str(jobId)
        res = commMM.updateRecord(newJob, 'nnc_sch_jobs', condition, 'rosterWrite')
    else :
        jobId = commMM.insertRecord(newJob, 'nnc_sch_jobs', 'rosterWrite')
    newJobRec = {}
    newJobRec['jobId'] = jobId
    newJobRec['recu_from'] = datetime.strptime(request.POST.get('startDate', False),'%m/%d/%Y').strftime('%Y-%m-%d')
    newJobRec['execution_time'] = request.POST.get('ScheduleForm[rec_start_from_time]', False)
    if str(request.POST.get('rec_pattern', False)) == 'no_end_date' :
        newJobRec['isnoenddate'] = 1
        newJobRec['endafter'] = None
        newJobRec['recu_end'] = None
    elif str(request.POST.get('rec_pattern', False)) == 'end_after' :
        newJobRec['isnoenddate'] = None
        newJobRec['endafter'] = request.POST.get('endAfter', False)
        newJobRec['recu_end'] = None
    elif str(request.POST.get('rec_pattern', False)) == 'end_by' :
        newJobRec['isnoenddate'] = None
        newJobRec['endafter'] = None
        newJobRec['recu_end'] = datetime.strptime(request.POST.get('endDate', False),'%m/%d/%Y').strftime('%Y-%m-%d')
    if scheduleType == "Daily" :
        if str(request.POST.get('rad_opt_daily', False)) == 'Every' :
            newJobRec['daily_everyaftergivendaycount'] = finResult['dailyEvery']
            newJobRec['daily_iseveryweekday'] = None
        else :
            newJobRec['daily_everyaftergivendaycount'] = None
            newJobRec['daily_iseveryweekday'] = 1
        newJobRec['weekly_recu_every_given_week'] = None
        newJobRec['weekly_weekdays'] = None
        newJobRec['monthly_rptDay'] = None
        newJobRec['monthly_theDay'] = None
    elif scheduleType == "Weekly" :
        weekCheck = request.POST.getlist('weekCheck[]', False)
        newJobRec['weekly_recu_every_given_week'] = finResult['weeklyEvery']
        if weekCheck :
            newJobRec['weekly_weekdays'] = "|".join(weekCheck)
        newJobRec['daily_everyaftergivendaycount'] = None
        newJobRec['daily_iseveryweekday'] = None
        newJobRec['monthly_rptDay'] = None
        newJobRec['monthly_theDay'] = None  
    elif scheduleType == "Monthly" :
        if str(request.POST.get('monEvery', False)) == 'Every_n_days' :
            newJobRec['monthly_rptDay'] = request.POST.get('mon_n_Every', False)
            newJobRec['monthly_theDay'] = None
        else :
            newJobRec['monthly_theDay'] = str(request.POST.get('monWeek', False))+"|"+str(request.POST.get('weekDay', False))
            newJobRec['monthly_rptDay'] = None        
        newJobRec['daily_everyaftergivendaycount'] = None
        newJobRec['daily_iseveryweekday'] = None
        newJobRec['weekly_recu_every_given_week'] = None
        newJobRec['weekly_weekdays'] =  None
    
    recRes = NncJobSchRecurence.objects.using('rosterRead').only('JobId').filter(JobId = jobId).exists()
    if recRes:
        condition = 'JobId = '+str(jobId)
        res = commMM.updateRecord(newJobRec, 'nnc_job_sch_recurence', condition, 'rosterWrite')
    else :
        jobId = commMM.insertRecord(newJobRec, 'nnc_job_sch_recurence', 'rosterWrite')
    responce = showSchTemp(request)
    return responce
    
def loadSchTemp(request):
    tid = request.GET.get('tid',False)
    type = request.GET.get('type',False)
    uid = request.GET.get('uid',False)
    jobId = request.GET.get('jobId',False)
        
    tempRes = {}
    tempName = TicketbrowserTemplates.objects.using('rosterRead').only('templatename','templatetype').get(templateid = tid)
    tempRes['tempId'] = tid
    tempRes['tempType'] = type
    tempRes['tempName'] = tempName.templatename
    tempRes['tempPubPri'] = tempName.templatetype
    jobDetails = NncSchJobs.objects.using('rosterRead').get(JobId = jobId)
    jobSchRecurence = NncJobSchRecurence.objects.using('rosterRead').get(JobId = jobId)
    tempRes['jobId'] = jobId
    tempRes['job_name'] = jobDetails.JobName if jobDetails.JobName != '' else tempName.templatename
    tempRes['reportType'] = jobDetails.reportType if jobDetails.reportType != '' else type
    if jobSchRecurence.execution_time :
        tempRes['rec_start_from_time'] = jobSchRecurence.execution_time.strftime('%H:%M:00') if jobSchRecurence.execution_time != '' else findNearestMettingTime() 
    tempRes['recurrence_pattern'] = jobDetails.scheduleType if jobDetails.scheduleType != '' else 'Daily'
    tempRes['emailIds'] = jobDetails.emailIds
    if jobSchRecurence.daily_everyaftergivendaycount != '' or jobSchRecurence.daily_iseveryweekday :
        if jobSchRecurence.daily_everyaftergivendaycount > 0 :
            tempRes['rad_opt_daily'] = 'every_n_day'
            tempRes['daily_every_n_day'] = jobSchRecurence.daily_everyaftergivendaycount
        else :
            tempRes['rad_opt_daily'] = 'every_weekday'
    else :
        tempRes['rad_opt_daily'] = 'every_n_day'
        tempRes['daily_every_n_day'] = 1
    tempRes['weekly_rec_every_n_week'] = jobSchRecurence.weekly_recu_every_given_week if jobSchRecurence.weekly_recu_every_given_week != '' else 1
    weekDays = ['Mon','Tue','Wed','Thur','Fri','Sat','Sun']
    weekDay = datetime.now().weekday()
    tempRes['weekly_rec_weekdays'] = jobSchRecurence.weekly_weekdays if jobSchRecurence.weekly_weekdays !='' else weekDays[weekDay]
    tempRes['monthly_rec_repeat_day'] = datetime.now().day
    if jobSchRecurence.monthly_rptDay != '' or jobSchRecurence.monthly_theDay != '' :
        if jobSchRecurence.monthly_rptDay > 0 :
            tempRes['rad_opt_monthly'] = 'every_n_day'
            tempRes['monthly_rec_repeat_day'] = jobSchRecurence.monthly_rptDay
        else :
            tempRes['rad_opt_monthly'] = 'the_day'
            if jobSchRecurence.monthly_theDay :
                theDayArray = jobSchRecurence.monthly_theDay.split('|')
                tempRes['monthly_rec_the_day'] = theDayArray[0]
                if len(theDayArray) > 1 :
                    tempRes['monthly_rec_the_weekday'] = theDayArray[1]
    if jobSchRecurence.recu_from :
        tempRes['rec_start_from_date'] = jobSchRecurence.recu_from.strftime('%m/%d/%Y') if jobSchRecurence.recu_from != '' else datetime.now().strftime('%m/%d/%Y')
    if jobSchRecurence.isnoenddate == 1 :
        tempRes['rad_opt_range_rec_pattern'] = 'no_end_date'
    elif jobSchRecurence.endafter :
        tempRes['rad_opt_range_rec_pattern'] = 'end_after'
        tempRes['end_after'] = jobSchRecurence.endafter
    elif jobSchRecurence.recu_end :
        tempRes['rad_opt_range_rec_pattern'] = 'end_by'
        tempRes['rec_end_by'] = jobSchRecurence.recu_end.strftime('%m/%d/%Y')
    else :
        curDTime = datetime.now()
        endYear = curDTime.year+3
        tempRes['rec_end_by'] = curDTime.strftime('%m/%d/')+str(endYear)
    tempRes['checked'] = 'checked'
    timeArray = getTimeArray()
    monWeek = OrderedDict([('First','First'),('Second','Second'),('Third','Third'),('Fourth','Fourth'),('Last','Last')])
    weekD = OrderedDict([('Day','Day'),('weekday','weekday'),('weekend day','weekend day'),('Sun','Sunday'),('Mon','Monday'),('Tue','Tuesday'),('Wed','Wednesday'),('Thu','Thursday'),('Fri','Friday'),('Sat','Saturday')])
    dates = {}
    os.environ["TZ"]="Asia/Kolkata"
    curDTime = datetime.now()
    endYear = curDTime.year+3
    dates['start'] = curDTime.strftime('%Y-%m-%d %H:%M:00')
    dates['end'] = str(endYear)+curDTime.strftime('-%m-%d %H:%M:%S')
    dates = comObj.convertDateUTC(dates,'IST')
    dates = comObj.convertDateReq(dates,'PDT')
    dates['start'] = datetime.strptime(dates['start'],'%Y-%m-%d %H:%M:%S').strftime('%m/%d/%Y %H:%M:00')
    dates['end'] = datetime.strptime(dates['end'],'%Y-%m-%d %H:%M:%S').strftime('%m/%d/%Y %H:%M:%S')
    dateRes = dates['start'].split(' ')
    dates['start'] = dateRes[0]
    dates['end'] = dates['end'].split(' ')[0]
    dates['email'] = jobDetails.emailIds
    dates['day'] = curDTime.day
    staffInfo = nrstaff_obj.getStaffInfo()
    staffInfo = simplejson.dumps(staffInfo)
    return render_to_response('loadSchTemp.html',{'tempRes':tempRes,'timeArray':timeArray,'monWeek':monWeek,'weekD':weekD,'dates':dates,'staffInfo':staffInfo},context_instance=RequestContext(request))
def unsubscribeJob(request):
    uid = request.session['uId']
    jobIds = request.GET.get('jobIds')
    jobIds = jobIds.split(',')
    email = request.session['uName']
    for job in jobIds :
        jobDetails = NncSchJobs.objects.using('rosterRead').only('JobId','createdby','emailIds').get(JobId=job)
        if jobDetails :
            if int(jobDetails.createdby) == uid :
                NncSchJobs.objects.using('rosterWrite').filter(JobId=job).delete()
                NncJobSchRecurence.objects.using('rosterWrite').filter(JobId=job).delete()
            else :
                emails = jobDetails.emailIds.split(',')
                if email in emails :
                    emails.remove(email)
                    if emails :
                        jobDetails.emailIds = ",".join(emails)
                        jobDetails.save()
                    else :
                        NncSchJobs.objects.using('rosterWrite').filter(JobId=job).delete()
                        NncJobSchRecurence.objects.using('rosterWrite').filter(JobId=job).delete()
    responce = showSchTemp(request)
    return responce
def logfiletesting(request):
    import logging
    log  = logging.getLogger('NNCPortal')
    log.error('tesing log file functionality')
    return render_to_response('slamResults.html',{})

def getTimeArray():
    timeArray = OrderedDict()
    hours = 24
    for hour in range(hours):
        keyHours = '0'+str(hour) if hour<10 else hour
        if hour > 12 and hour < 22 :
            disHours = '0'+str(hour-12)
        elif hour > 21 :
            disHours = hour-12
        elif hour == 0 :
            disHours = 12;
        else :
            disHours = keyHours
        minutes = 2
        for minut in range(minutes) :
            mins = '0'+str(minut) if minut <1 else minut+29
            keyTime = str(keyHours)+':'+str(mins)+':00'
            disTime = str(disHours)+':'+str(mins)+' AM' if hour < 12 else str(disHours)+':'+str(mins)+' PM'
            timeArray[keyTime] = disTime
        hour+=1
    return timeArray
def findNearestMettingTime():
    curDateTime = datetime.now()
    minuts = int(curDateTime.minute)
    if minuts <= 15 :
        min = 30
        hour = curDateTime.hour
    elif minuts >= 45 :
        min = 30
        hour = int(curDateTime.hour)+1
    else :
        min = '00'
        hour = int(curDateTime.hour)+1
        hour = '00' if hour == 24 else '0'+str(hour) if hour < 10 else hour
    return str(hour)+':'+str(min)+':00'

def emailSearch(request):
    print 'implement'
    return render_to_response('test.html',{})
