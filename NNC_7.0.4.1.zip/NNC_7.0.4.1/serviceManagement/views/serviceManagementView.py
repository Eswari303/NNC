"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
import base64
import collections
import datetime as dt
import json as simplejson
import logging
import os
import re
import requests
import string
import time
from calendar import timegm
from collections import defaultdict
from datetime import datetime, timedelta
from random import choice
from string import ascii_uppercase

from django.core.cache import caches
from django.db import connections
from django.http import HttpResponse
from django.shortcuts import HttpResponseRedirect
from django.shortcuts import render_to_response
from django.template import RequestContext
from django.template.defaulttags import register

from NNCPortal.commonMethods import commonMethods
from NNCPortal.commonModels.IncidentData import IncidentData
from NNCPortal.commonModels.NrStaff import NrStaff
from NNCPortal.commonModels.NtsDeviceType import NtsDeviceType
from NNCPortal.commonModels.NtsIncidentTags import NtsIncidentTags
from NNCPortal.commonModels.Ntschannel import Ntschannel
from NNCPortal.commonModels.Ntsmspclients import Ntsmspclients
from NNCPortal.commonModels.Ntsmspnocs import Ntsmspnocs
from NNCPortal.commonModels.Ntsmsps import Ntsmsps
from NNCPortal.commonModels.SlaMgntCustomColumns import SlaMgntCustomColumns
from NNCPortal.commonModels.SwcustomFieldValues import SwcustomFieldValues
from NNCPortal.commonModels.Swdepartments import Swdepartments
from NNCPortal.commonModels.Swticketpriorities import Swticketpriorities
from NNCPortal.commonModels.Swticketstatus import Swticketstatus
from NNCPortal.commonModels.swcustomFields import swcustomFields
from NNCPortal.configfile import ConfigManager
from serviceManagement.forms import ServiceManagementForm
from serviceManagement.models.NncJobSchRecurence import NncJobSchRecurence
from serviceManagement.models.NncSchJobs import NncSchJobs
from serviceManagement.models.NtsTicketType import Ntstickettype
from serviceManagement.models.Ntsstatussla import Ntsstatussla
from serviceManagement.models.PsaTicketTrackDetails import PsaTicketTrackDetails
from serviceManagement.models.Sku import Sku
from serviceManagement.models.SwStaff import Swstaff
from serviceManagement.models.TicketbrowserTemplates import TicketbrowserTemplates
from serviceManagement.models.commonModel import CommonServiceModel
from serviceManagement.models.serviceManagementQuerys import SlamResultQuerys
from ticket.models.commonModel import CommonTicketModel

# import calendar
# import urlparse

Salmquey = SlamResultQuerys()
comObj = commonMethods()
comMObj = CommonServiceModel()
configobj = ConfigManager()
mem_cache = caches['memcached']
log = logging.getLogger('NNCPortal')
swtktstatus_obj = Swticketstatus()
swtktprior_obj = Swticketpriorities()
incdata_obj = IncidentData()
ntsmspclient_obj = Ntsmspclients()
msp_obj = Ntsmsps()
nrstaff_obj = NrStaff()
tkttype_obj = Ntstickettype()
swstaff_obj = Swstaff()
tktbrwsr_obj = TicketbrowserTemplates()
customcols_obj = SlaMgntCustomColumns()
swdept_obj = Swdepartments()
devtype_obj = NtsDeviceType()
swcustomflds_obj = swcustomFields()
inctag_obj = NtsIncidentTags()
sku_obj = Sku()
psatrack_obj = PsaTicketTrackDetails()
sw_cus_fval_obj = SwcustomFieldValues()
nocdata_obj = Ntsmspnocs()
swpriorities_obj = Swticketpriorities()
channel_obj = Ntschannel()
# randomNumber = randint(100, 1000)
env = configobj.getCommConfigValue(configobj.app_env)
priorityClass = {8: 'newlabel P0', 9: 'newlabel P1', 10: 'newlabel P2', 11: 'newlabel P3', 21: '', 13: '', 15: '',
                 17: '', 19: ''}
IncidentResolutionSla = {'1': "(id.resol_due between 0 AND 3600)", '2': " id.resol_due > 3600",
                         '3': " id.resol_due < 0", }
statusSlaFlag = False
nullList = [None, False, [u''], '']
""" Method which loads at first while selection of the Advanced search in service Management Tab """


def loadMockup(request):
    os.environ["TZ"] = "US/Pacific"
    if request.method == 'POST':
        pass
    else:
        authRes = comObj.checkAuthentication(request)
        if authRes == True:
            tb_admin = request.session['tb_admin']
            form = ServiceManagementForm()
            """ Getting partner(MSP) details from the table using ORM """
            msps = msp_obj.getMSPSdata()
            #msps = mem_cache.get('msps')
            #if not msps:
               #msps = Ntsmsps.objects.using('ticketRead').only('mspname', 'mspid').filter(status=1).order_by('mspname')
               #mem_cache.set('msps', msps, 3600)
            """ Getting Noc details from Nocdetials"""
            nocs = nocdata_obj.getNocdata()
            #nocs = mem_cache.get('nocs')
            #if not nocs:
                #nocs = Nocdetails.objects.using('mspDB').all().order_by('name')
                #mem_cache.set('nocs', nocs, 3600)

            clients = defaultdict(dict)
            clients = ntsmspclient_obj.showPartnerClients()
            #clients = mem_cache.get('clients')
            #if not clients:
                #clients = mspclnt_obj.showpatclient()

            #departments = mem_cache.get('departments_new')
            #if not departments:
            departments = swdept_obj.departments()
                #departments = Swdepartments.objects.using('ticketRead').only('title', 'departmentid').order_by('title')
                #mem_cache.set('departments_new', departments, 86400)

            #tktstatus = mem_cache.get('newStatus')
            #if not tktstatus:
            tktstatus = swtktstatus_obj.getNewStatus()
            priorities = swpriorities_obj.getPriority()
            #priorities = mem_cache.get('priorities')
            #if not priorities:
                #priorities = Swticketpriorities.objects.using('ticketRead').only('display_text', 'priorityid').order_by('priorityid')
                #mem_cache.set('priorities', priorities, 86400)

            #selectTags = mem_cache.get('selectTags')
            #if not selectTags:
                #selectTags = inctag_obj.getSearchTags()
            selectTags = inctag_obj.getSearchTags()
            channels = channel_obj.getChanneldata()
            #channels = mem_cache.get('channels')
            #if not channels:
                #channels = Ntschannel.objects.using('ticketRead').only('name', 'id').order_by('name')
                #mem_cache.set('channels', channels, 86400)

            swStaff = nrstaff_obj.getSwStaffByRoster()
            #ticketType = mem_cache.get('ticketType')
            #if not ticketType:
                #ticketType = Ntstickettype.objects.using('ticketRead').only('typeid', 'typename').order_by('typename')
                #mem_cache.set('ticketType', ticketType, 86400)
            ticketType = tkttype_obj.getAllTicketTypes()
            finalCustomFields = customcols_obj.getSlamCustomColumns()
            #finalCustomFields = mem_cache.get('finalCustomFields')
            displayList = customcols_obj.getDefaultCustomFields()
            #displayList = mem_cache.get('displayList')
            dispLis = mem_cache.get('dispLis'+env)
            if not dispLis:
                dispLis = {}
                for displayLis in displayList:
                    dispLis[displayLis['column_name']] = displayLis['column_name']
                dispLis = ','.join(str(e) for e in dispLis.keys())
                mem_cache.set('dispLis'+env, dispLis, 86400)

            serviceTypes = defaultdict(dict)
            #serviceTypes = mem_cache.get('serviceTypes')
            #if not serviceTypes:
                #serviceTypes = comObj.getAllServiceTypes()
            serviceTypes = comObj.getAllServiceTypes()

            serviceLevels = defaultdict(dict)
            serviceLevels = sku_obj.getAllServiceLevels()
            #serviceLevels = mem_cache.get('serviceLevels')
            #if not serviceLevels:
                #serviceLevels = sku_obj.getAllServiceLevels()

            devices = defaultdict(dict)
            days = range(1, 31)
            deviceTypes = defaultdict(dict)
            deviceTypes = devtype_obj.getDeviceTypes()
            curDTime = datetime.now()
            toDate = curDTime.strftime('%m/%d/%Y  %H:%M')
            yesDate = curDTime - timedelta(days=10)
            fromDate = yesDate.strftime('%m/%d/%Y %H:%M')
            if 'uName' in request.session:
                userName = request.session['uName'].split('@')
                userName = str(userName[0][0:14]) + '...'
            else:
                userName = 'TestUser'

            ActiveStatus = swtktstatus_obj.getActiveStatus()
            InActiveStatus = swtktstatus_obj.getInActiveStatus()
            closed = swtktstatus_obj.getClosedStatus()
            ActiveStatus = ','.join(str(e) for e in ActiveStatus.keys())
            InActiveStatus = ','.join(str(e) for e in InActiveStatus.keys())

            closed = ','.join(str(e) for e in closed.keys())
            allS = ActiveStatus + ',' + InActiveStatus + ',' + closed
            templatelist = getTemplateList(request, reportType='')
            allStatuses = {'active': ActiveStatus, 'inactive': InActiveStatus, 'closed': closed, 'all': allS}
            all_nocdetails = mem_cache.get('NocDeviceTreeView0'+env, 'has expired')
            template_validation = tktbrwsr_obj.getTemplatenames()
            sort_tktstatus = swtktstatus_obj.newOrderStatus()
            return render_to_response('serviceMockup.html',
                                      {'form': form, 'msps': msps, 'channels': channels, 'selectTags': selectTags,
                                       'tktstatus': tktstatus, 'sort_tktstatus': sort_tktstatus,
                                       'priorities': priorities, 'clients': clients, 'nocs': nocs,
                                       'departments': departments, 'toDate': toDate,
                                       'fromDate': fromDate,
                                       'userName': userName, 'swStaff': swStaff, 'ticketType': ticketType,
                                       'finalCustomFields': finalCustomFields, 'displayList': displayList,
                                       'serviceTypes': serviceTypes, 'serviceLevels': serviceLevels,
                                       'allStatuses': allStatuses, 'templates1': templatelist['templates1'],
                                       'mytickets': templatelist['mytickets'],
                                       'myteamtickets': templatelist['myteamtickets'], 'all_nocdetails': all_nocdetails,
                                       'deviceTypes': deviceTypes, 'devices': devices, 'days': days,
                                       'tb_admin': tb_admin, 'template_validation': template_validation,
                                       'dispLis': dispLis},
                                      context_instance=RequestContext(request))
        else:
            return authRes


def getNocAjax(request):
    partners = []
    clients = []
    if request.method == "POST":
        finResult = request.POST
        res = dict(finResult.lists())
        if request.POST.get('res_pat[]', False):
            for nocid in res['res_pat[]']:
                pat = msp_obj.getpartners(nocid)
                cli = ntsmspclient_obj.getClients(nocid)
                if pat:
                    partners = partners + pat
                if cli:
                    clients = clients + cli
        else:
            partners = msp_obj.getpartners()
            clients = ntsmspclient_obj.getClients()
    jsonData = simplejson.dumps({'msps': partners, 'clients': clients})
    return HttpResponse(jsonData, content_type="application/json")


def getPatClients(request):
    if request.method == "POST":
        search_text = request.POST.getlist('res_cli[]', '')
        if len(search_text) > 1:
            search_text = ','.join(str(e) for e in search_text)
        else:
            search_text = search_text[0]
    else:
        search_text = ''
    cli = ntsmspclient_obj.getClientsOfPartner(search_text)
    jsonData = simplejson.dumps({'clients': cli})
    return HttpResponse(jsonData, content_type="application/json")


def getChannelAjax(request):
    partners = []
    clients = []
    if request.method == "POST":
        finResult = request.POST
        res = dict(finResult.lists())
        if request.POST.get('res_pat[]', False):
            for channelId in res['res_pat[]']:
                pat = msp_obj.getChannelPartners(channelId)
                cli = ntsmspclient_obj.getChannelClients(channelId)
                if pat:
                    partners = partners + pat
                if cli:
                    clients = clients + cli
        else:
            partners = msp_obj.getChannelPartners()
            clients = ntsmspclient_obj.getChannelClients()
    jsonData = simplejson.dumps({'msps': partners, 'clients': clients})
    return HttpResponse(jsonData, content_type="application/json")


def getTemplateListDetail(request):
    if 'uName' in request.session:
        uid = request.session['uId']
    temp1 = {}
    temp = {}
    templates1 = {}
    templates1.setdefault('private', {})
    templates1.setdefault('public', {})
    pr = 0
    pb = 0
    mytickets = 'slamResults?view=' + str(base64.b64encode(str(getTemplateId('My Tickets'))))
    myteamtickets = 'slamResults?view=' + str(base64.b64encode(str(getTemplateId('My Team Tickets'))))
    records = tktbrwsr_obj.getUserTemplatesAndPublicTemplates(uid, 'TB')
    for record in records:
        if int(record['templatetype']) != 0:
            temp1.setdefault('templateid', record['templateid'])
            temp1['templatename'] = record['templatename']
            temp1['templateuserid'] = record['templateuserid']
            temp1['lastdate'] = record['lastdate']
            pr += 1
            templates1['private'][pr] = temp1
            temp1 = {}
        else:
            temp.setdefault('templateid', record['templateid'])
            temp['templatename'] = record['templatename']
            temp['templateuserid'] = record['templateuserid']
            temp['lastdate'] = record['lastdate']
            pb += 1
            templates1['public'][pb] = temp
            temp = {}
    templates1['private']['count'] = pr
    templates1['public']['count'] = pb
    return render_to_response('templatelist.html',
                              {'templates1': templates1, 'mytickets': mytickets, 'myteamtickets': myteamtickets},
                              context_instance=RequestContext(request))


def getTemplateList(request, reportType=''):
    if 'uName' in request.session:
        uid = request.session['uId']
    temp1 = {}
    temp = {}
    templates1 = {}
    templates1.setdefault('private', {})
    templates1.setdefault('public', {})
    pr = 0
    pb = 0

    mytickets = 'slamResults?view=' + str(base64.b64encode(str(getTemplateId('My Tickets'))))
    myteamtickets = 'slamResults?view=' + str(base64.b64encode(str(getTemplateId('My Team Tickets'))))
    records = tktbrwsr_obj.getUserTemplatesAndPublicTemplates(uid, 'TB')
    for record in records:
        if int(record['templatetype']) != 0:
            temp1.setdefault('templateid', record['templateid'])
            temp1['templatename'] = record['templatename']
            temp1['templateuserid'] = record['templateuserid']
            temp1['lastdate'] = record['lastdate']
            temp1['enTid'] = 'slamResults?view=' + str(base64.b64encode(str(record['templateid'])))
            pr += 1
            """obj1 = NrStaff.objects.using('rosterRead').filter(id=record['templateuserid'])
            for obj in obj1:
                firstname = obj.staff_fname
                lastname = obj.staff_lname
                username = firstname + " " + lastname"""
            temp1['username'] = record['username']
            templates1['private'][pr] = temp1
            temp1 = {}
        else:
            temp.setdefault('templateid', record['templateid'])
            temp['templatename'] = record['templatename']
            temp['templateuserid'] = record['templateuserid']
            temp['lastdate'] = record['lastdate']
            temp['enTid'] = 'slamResults?view=' + str(base64.b64encode(str(record['templateid'])))
            pb += 1
            """obj1 = NrStaff.objects.using('rosterRead').filter(id=record['templateuserid'])
            for obj in obj1:
                firstname = obj.staff_fname
                lastname = obj.staff_lname
                username = firstname + " " + lastname"""
            temp['username'] = record['username']
            templates1['public'][pb] = temp
            temp = {}
    templates1['private']['count'] = pr
    templates1['public']['count'] = pb
    tmplist = {'templates1': templates1, 'mytickets': mytickets, 'myteamtickets': myteamtickets}
    return tmplist


def getTemplateId(templateName):
    obj = TicketbrowserTemplates.objects.using('rosterRead').get(templatename=templateName)
    return obj.templateid


def deleteTemplateById(id):
    obj = TicketbrowserTemplates.objects.using('rosterWrite').get(templateid=id)
    result = obj.delete()
    obj1 = NncSchJobs.objects.using('rosterRead').filter(templateid=id)
    if obj1:
        for job in obj1:
            nncrec = NncJobSchRecurence.objects.using('rosterWrite').get(JobId=(job.JobId))
            nncrec.delete()
    return 1


def deleteTemplate(request):
    id = request.GET.get('id')
    templatename = request.GET.get('templatename')
    reportType = ''
    if id <= 0:
        return False
    result = deleteTemplateById(id)
    return HttpResponse(result, content_type="application/json")


def deviceCacheCounts(request):
    Final = []
    tkType = request.POST.get('tkType')
    if tkType != '':
        temp = mem_cache.get('DeviceTypeId_TreeCount'+env, 'has expired')
        if temp.has_key(int(tkType)):
            typeIdWise = temp[int(tkType)]
        else:
            typeIdWise = {}
    else:
        typeIdWise = mem_cache.get('NocDeviceTreeView0'+env, 'has expired')
    Final = displayTree(typeIdWise)
    jsonData = simplejson.dumps({'finalTree': Final})
    return HttpResponse(jsonData, content_type="application/json")


def departmentCacheCounts(request):
    Final = []
    nocT = request.POST.get('ticketType')
    if nocT != '':
        temp = mem_cache.get('TicketType_Tree'+env, 'has expired')
        if temp.has_key(int(nocT)):
            typeIdWise = temp[int(nocT)]
        else:
            typeIdWise = {}
    else:
        typeIdWise = mem_cache.get('DeptResult0'+env, 'has expired')
    Final = displayTree(typeIdWise)
    jsonData = simplejson.dumps({'finalTree': Final})
    return HttpResponse(jsonData, content_type="application/json")


"""def getNewStatus():
    newStatus = {}
    status = Salmquey.getSwticketstatus()
    oldStatus = {}
    for stat in status:
        oldStatus[stat['ticketstatusid']] = stat['display_text']
        if int(stat['parent_id']) == 0:
            newStatus[stat['ticketstatusid']] = stat['display_text']
    for stat in status:
        if int(stat['parent_id']) == 18:
            newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']]) + ' - ' + str(stat['display_text'])
        elif int(stat['parent_id']) == 2:
            newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']]) + ' - ' + str(stat['display_text'])
        elif int(stat['parent_id']) == 3:
            newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']]) + ' - ' + str(stat['display_text'])
        elif int(stat['parent_id']) == 5:
            newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']]) + ' - ' + str(stat['display_text'])
        elif int(stat['parent_id']) == 19:
            newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']]) + ' - ' + str(stat['display_text'])
        elif int(stat['parent_id']) == 1:
            newStatus[stat['ticketstatusid']] = str(oldStatus[stat['parent_id']]) + ' - ' + str(stat['display_text'])
    mem_cache.set('newStatus', newStatus, 86400)
"""


def displayTree(inputArray):
    Final = []
    if inputArray:
        for k, dept in inputArray.iteritems():
            if dept.has_key('TotalCount'):
                parent = {}
                parent['tags'] = [dept['TotalCount']]
                parent['text'] = dept['title']
                parent['href'] = dept['title']
                parent['nodes'] = []

                for ke, res in dept.iteritems():
                    if ke == 'statusType':
                        for key1, statustype in res.iteritems():
                            if statustype['statusCount']:
                                child = {}
                                child['tags'] = [statustype['statusCount']]
                                child['text'] = key1
                                child['href'] = key1 + '_' + dept['title']
                                child['nodes'] = []

                                for key2, status in statustype.iteritems():
                                    if key2 == 'status':
                                        for key3, counts in status.iteritems():
                                            grandChild = {}
                                            grandChild['tags'] = [counts['count']]
                                            grandChild['text'] = counts['statusname']
                                            grandChild['href'] = str(counts['statusid']) + '_' + counts['statusname']
                                            child['nodes'].append(grandChild)

                                parent['nodes'].append(child)

                Final.append(parent)
            else:
                pass
    Final = sorted(Final, key=lambda x: x['text'])
    return Final


def slamFilterConvertTicketsStringToArray(convert):
    pattern = '[^0-9]'
    datas = re.split(pattern, convert)
    result = [x for x in datas if x]
    return result


def prepareIncidentTicketsQuery(post):
    os.environ["TZ"] = "US/Pacific"
    flagSearchByTicketIdOrAlertId = True
    condtion = " WHERE 1=1 "
    if post['date'] == "DAYS":
        lastdays = post['daysValue']
        if (lastdays == None) or (lastdays == ""):
            lastdays = 10
        elif int(lastdays) == 0:
            lastdays = 90
        lastdays = int(lastdays)
        curDTime = datetime.now()
        toDate = curDTime.strftime('%m/%d/%Y')
        yesDate = curDTime - timedelta(days=lastdays)
        formtdateUnix = yesDate.strftime('%m/%d/%Y')
        todateUnix = toDate


    elif post['date'] == "DATE":

        formtdateUnix = int(time.mktime(datetime.strptime(str(post['fromDate']), "%m/%d/%Y %H:%M").timetuple()))
        todateUnix = int(time.mktime(datetime.strptime(str(post['toDate']), "%m/%d/%Y %H:%M").timetuple()))

    else:
        if post['date'] == "OTHERS":
            value = post['optionSelected']
            if str(value) != "LD":
                TimeStamp = comMObj.unixtime(value)
                formtdateUnix = int(TimeStamp[0])
                todateUnix = int(TimeStamp[1])
    if post['idType']:
        if post['idTypeValue']:
            convert = post['idTypeValue']
            serchValues = slamFilterConvertTicketsStringToArray(convert)
            tids = ','.join(serchValues)
            if post['idType'] == 'ticketid':
                flagSearchByTicketIdOrAlertId = False
                if (len(serchValues) > 1):
                    condtion += " AND id.ticketid IN (" + tids + ")"
                else:
                    condtion += " AND id.ticketid = '" + tids + "'"

            elif post['idType'] == 'alertid':
                flagSearchByTicketIdOrAlertId = False
                if (len(serchValues) > 1):
                    condtion += ' AND id.sccalertid IN (' + tids + ')'
                else:
                    condtion += ' AND id.sccalertid ="' + tids + '"'
            elif post['idType'] == 'psaid':
                pasticketid = re.sub('[^a-zA-Z\d\s:,.]', '', convert)
                pasticketId = pasticketid.replace(",'", ' ')
                flagSearchByTicketIdOrAlertId = False
                pasid = pasticketId.split(' ')
                resultItsm = [x for x in pasid if x]
                ids = ','.join(resultItsm)
                ids = ids.replace(',', "','")
                if (len(pasid) > 1):
                    condtion += " AND tktint.mspticketid IN ('" + ids + "') "
                else:
                    condtion += " AND tktint.mspticketid IN ('" + ids + "') "

            elif post['idType'] == 'vistaraid':
                vistaraId = re.sub('[^a-zA-Z\d\s:,]', '', convert)
                vistaraId = vistaraId.replace(',', ' ')

                flagSearchByTicketIdOrAlertId = False
                itsmId = vistaraId.split(' ')
                resultItsm = [x for x in itsmId if x]
                ids = "','".join(resultItsm)
                condtion += " AND  vist_itsm.incidentid IN ('" + ids + "')"

            elif str(post['idType']) == 'subject' or str(post['idType']) is None:
                if post['daysValue']:
                    flagSearchByTicketIdOrAlertId = False
                    dataList = post.getlist('CM')
                    condtion += " AND id.subject like '%" + convert + "%'"
                    datecondition = ''
                if post['date'] == 'DAYS':
                    dataList = post.getlist('CM')
                    if len(dataList) > 0:
                        modifiedcondn = '(id.lastactivity >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL ' + str(
                            post['daysValue']) + ' DAY)))'
                        datecondition = 'AND ' + modifiedcondn
                        condtion += datecondition
                    else:
                        createdcondn = '(id.created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL ' + str(
                            post['daysValue']) + ' DAY)))'
                        datecondition = " AND " + createdcondn
                        condtion += datecondition
                elif post['date'] == 'DATE':
                    if int(dataList[1]) == 1:
                        modifiedcondn = '(id.lastactivity >= ' + str(formtdateUnix) + ' AND id.lastactivity <= ' + str(
                            todateUnix) + ')'
                        datecondition = 'AND ' + modifiedcondn
                        modifiStatus = 1
                        if int(dataList[0]) == 0:
                            createdcondn = '(id.created_dt >= ' + str(formtdateUnix) + ' AND id.created_dt <= ' + str(
                                todateUnix) + ')'
                            datecondition = " AND " + createdcondn
                            if int(modifiStatus) > 0:
                                datecondition = " AND (" + modifiedcondn + " OR " + createdcondn + ")"
                        condtion += datecondition
                    else:
                        ticketId = dataList[0]
                        if int(ticketId) > 0:
                            modifiedcondn = '(id.lastactivity >= ' + str(
                                formtdateUnix) + ' AND id.lastactivity <= ' + str(todateUnix) + ')'
                            datecondition = 'AND ' + modifiedcondn
                        else:
                            createdcondn = '(id.created_dt >= ' + str(formtdateUnix) + ' AND id.created_dt <= ' + str(
                                todateUnix) + ')'
                            datecondition = " AND " + createdcondn
                        condtion += datecondition
                elif post['date'] == 'OTHERS':

                    dataList = post.getlist('CM')
                    options = post.getlist("optionSelected", False)
                    ticketId = dataList[0]
                    if int(ticketId) >= 1:
                        if str(options) == 'LD':
                            modifiedcondn = " (id.lastactivity >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL 1 DAY)))"
                        else:
                            modifiedcondn = '(id.lastactivity >= ' + str(
                                formtdateUnix) + ' AND id.lastactivity <= ' + str(todateUnix) + ')'
                        datecondition = 'AND  ' + modifiedcondn

                    else:
                        pass

                    if str(options[0]) == 'LD':
                        createdcondn = " (id.created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL 1 DAY)))"
                    else:
                        createdcondn = '(id.created_dt >= ' + str(formtdateUnix) + ' AND id.created_dt <= ' + str(
                            todateUnix) + ')'
                    datecondition = " AND " + createdcondn

                condtion += datecondition


            else:
                flagSearchByTicketIdOrAlertId = False

    if flagSearchByTicketIdOrAlertId == True:

        if post['date'] == 'DAYS':

            if post['daysValue']:
                dataList = post.getlist('CM')
                if dataList == [u'0,1']:
                    dataList[0] = '0'
                    dataList.append('1')
                datecondition = ''
                if len(dataList) > 1:

                    if int(dataList[1]) == 1:
                        modifiedcondn = '(id.lastactivity >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL ' + str(
                            lastdays) + ' DAY)))'
                        datecondition = 'AND ' + modifiedcondn
                        modifiStatus = 1

                    if int(dataList[0]) == 0:
                        createdcondn = '(id.created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL ' + str(
                            lastdays) + ' DAY)))'
                        datecondition = " AND " + createdcondn
                        if int(modifiStatus) > 0:
                            datecondition = " AND (" + modifiedcondn + " OR " + createdcondn + ")"
                else:
                    flagSearchByTicketIdOrAlertId = False
                    ticketId = dataList[0]
                    if int(ticketId) > 0:
                        modifiedcondn = '(id.lastactivity >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL ' + str(
                            lastdays) + ' DAY)))'
                        datecondition = 'AND ' + modifiedcondn
                    else:

                        createdcondn = '(id.created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL ' + str(
                            lastdays) + ' DAY)))'
                        datecondition = " AND " + createdcondn

                condtion += datecondition

        elif post['date'] == 'DATE':
            dataList = post.getlist('CM')
            datecondition = ''
            if len(dataList) > 1:

                if int(dataList[1]) == 1:
                    modifiedcondn = '(id.lastactivity >= ' + str(formtdateUnix) + ' AND id.lastactivity <= ' + str(
                        todateUnix) + ')'
                    datecondition = 'AND ' + modifiedcondn
                    modifiStatus = 1

                if int(dataList[0]) == 0:
                    createdcondn = '(id.created_dt >= ' + str(formtdateUnix) + ' AND id.created_dt <= ' + str(
                        todateUnix) + ')'
                    datecondition = " AND " + createdcondn
                    if int(modifiStatus) > 0:
                        datecondition = " AND (" + modifiedcondn + " OR " + createdcondn + ")"
                condtion += datecondition
            else:

                ticketId = dataList[0]
                if isinstance(ticketId,int):
                    modifiedcondn = '(id.lastactivity >= ' + str(formtdateUnix) + ' AND id.lastactivity <= ' + str(
                        todateUnix) + ')'
                    datecondition = 'AND ' + modifiedcondn
                else:
                    createdcondn = '(id.created_dt >= ' + str(formtdateUnix) + ' AND id.created_dt <= ' + str(
                        todateUnix) + ')'
                    datecondition = " AND " + createdcondn
                condtion += datecondition

        elif post['date'] == 'OTHERS':
            dataList = post.getlist('CM')
            options = post.getlist("optionSelected", False)

            if len(dataList) == 2:

                if int(dataList[1]) == 1:
                    if options != False:

                        if str(options[0]) == 'LD':
                            modifiedcondn = " (id.lastactivity >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL 1 DAY)))"
                        else:
                            modifiedcondn = '(id.lastactivity >= ' + str(
                                formtdateUnix) + ' AND id.lastactivity <= ' + str(todateUnix) + ')'
                        datecondition = 'AND ' + modifiedcondn
                        modifiStatus = 1

                if int(dataList[0]) == 0:
                    if options != False:
                        if options[0] == 'LD':
                            createdcondn = " (id.created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL 1 DAY)))"
                        else:
                            createdcondn = '(id.created_dt >= ' + str(formtdateUnix) + ' AND id.created_dt <= ' + str(
                                todateUnix) + ')'
                        datecondition = " AND " + createdcondn
                        if int(modifiStatus) > 0:
                            datecondition = " AND (" + modifiedcondn + " OR " + createdcondn + ")"
                condtion += datecondition
            else:

                CreatedOrMod = dataList[0]

                if int(CreatedOrMod) == 1:

                    if str(options[0]) == 'LD':

                        modifiedcondn = " (id.lastactivity >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL 1 DAY)))"
                    else:
                        modifiedcondn = '(id.lastactivity >= ' + str(formtdateUnix) + ' AND id.lastactivity <= ' + str(
                            todateUnix) + ')'
                    datecondition = 'AND  ' + modifiedcondn

                else:
                    if str(options[0]) == 'LD':
                        createdcondn = " (id.created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL 1 DAY)))"
                    else:
                        createdcondn = '(id.created_dt >= ' + str(formtdateUnix) + ' AND id.created_dt <= ' + str(
                            todateUnix) + ')'
                    datecondition = " AND " + createdcondn

                condtion += datecondition

        ticketTypes = post.getlist('ticketTypes', False)
        if ticketTypes != False and ticketTypes != [u'']:
            tKts = post.getlist('ticketTypes', False)
            tktsType = ','.join(tKts)
            condtion += " AND id.typeid IN (" + tktsType + ")"

        serviceTypes = post.getlist('serviceTypes', False)
        if serviceTypes != False and serviceTypes != [u'']:
            service = post.getlist('serviceTypes')
            serType = '","'.join(service)
            condtion += ' AND id.service_type  IN ("' + serType + '")'
        serviceLevel = post.getlist('serviceLevel', False)
        if serviceLevel != False and serviceLevel != [u'']:
            serLevel = '","'.join(serviceLevel)
            condtion += ' AND id.service_level IN ("' + serLevel + '") '

        deviceTypes = post.getlist('deviceType', False)
        if deviceTypes != False and deviceTypes != [u''] and str(deviceTypes) != 'NULL':
            devType = ','.join(deviceTypes)
            condtion += " AND id.devicetypeid IN (" + devType + ")"
        #else:
            #condtion += " AND id.deptid != 1";

        devies = post.getlist('devices', False)
        if devies != False and devies != [u'']:
            dev = ','.join(devies)
            condtion += " AND id.did IN (" + dev + ")"
        else:
            clients = post.getlist('clients', False)
            partnersId = post.getlist('partners', False)
            if clients not in nullList:
                clients = ','.join(clients)
                condtion += " AND id.cid IN (" + clients + ")"

            elif partnersId not in nullList:
                patners = ','.join(partnersId)
                condtion += " AND id.mid IN (" + patners + ")"

            nocs = post.getlist('nocs', False)
            if clients in nullList and nocs not in nullList:
                nocs = ','.join(nocs)
                condtion += " AND id.nid IN (" + nocs + ")"

            channels = post.getlist('channel', False)
            if clients in nullList and channels not in nullList:
                channel = ','.join(channels)
                condtion += " AND id.channelid IN (" + channel + ")"

            departmentIds = post.getlist('department', False)
            if departmentIds not in nullList:
                dept = ','.join(departmentIds)
                condtion += " AND id.deptid IN (" + dept + ")"

            tags = post.getlist('tags', False)
            if tags != False and tags != [u'']:
                tag = " or id.tags like ".join('"%' + e + '%"' for e in tags)
                condtion += " AND (id.tags like " + tag + ")"

        statusType = post.get('statusType')
        selectedStatuses = post.getlist('selectedStatuses', False)
        statusCondition = auditLogCondition = ''
        if str(statusType) == 'current':
            if selectedStatuses != False and selectedStatuses != [u'']:
                selectedStatuses = ','.join(selectedStatuses)
                condtion += " AND id.statusid IN (" + selectedStatuses + ")"
        else:
            if selectedStatuses and len(selectedStatuses) > 0:

                glue = ''
                if selectedStatuses[0].find(',') >= 0:
                    selectedStatuses = selectedStatuses[0].split(',')
                for statusid in selectedStatuses:
                    if int(statusid) == 9:  # HMSP
                        auditLogCondition += glue + 'id.hmsp_count > 0'
                        glue = ' OR '
                    if int(statusid) == 46:  # WFCI
                        auditLogCondition += glue + 'id.wfci_count > 0'
                        glue = ' OR '
                if auditLogCondition:
                    condtion += " AND (" + auditLogCondition + ")"

        staff = post.getlist('assignto', False)
        if staff != False and staff != [u'']:
            staffs = ','.join(staff)
            condtion += " AND id.staffid IN (" + staffs + ")"
        priorty = post.getlist('selectedPriorities', False)

        if priorty != False and priorty != [u'']:
            priortyIds = ','.join(priorty)
            condtion += " AND id.priorityid IN (" + priortyIds + ")"

        fromPrio = post.getlist('frmPriority', False)
        if (fromPrio != False and fromPrio != [u'']):
            fromPrio = fromPrio[0]

        toPrio = post.getlist('toPriority', False)
        glue = ''
        opt_priority_to = ''
        if toPrio != False and toPrio != [u'']:
            if len(toPrio) > 0:
                for i in toPrio:
                    opt_priority_to += glue + "ntalog.to_id = " + i
                    glue = ' OR '

                condtion += " AND  ntalog.from_id = " + str(fromPrio) + "  AND (" + str(
                    opt_priority_to) + ")  AND  ntalog.stsRpts = 2 "

    if condtion == "WHERE 1=1  AND id.deptid NOT IN (0,1,2)":
        activeStatus = '1,18,19,21,7,12,22,23'
        condtion += " AND (id.created_dt >= UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL 10 DAY))) AND id.statusid IN (1,18,19,21,7,12,22,23) "

    return condtion


def getIncidentSelectFields(post, usePurgeTable):
    spSla = ''
    selectedStat = ''
    selectedStatuses = post.getlist('selectedStatuses', '')
    if isinstance(selectedStatuses, list):
        if selectedStatuses[0].find(',') > 0:  # when statuses are like 20,9,1,2,18,23
            selectedStat = selectedStatuses
            selectedStatuses = selectedStatuses[0].split(',')
        else:
            selectedStat = ','.join(selectedStatuses)
    if (len(selectedStatuses) == 1) and selectedStat != '':

        NtsstatusslaRes = Ntsstatussla.objects.using('ticketRead').only('sla_value').filter(
            ticketstatusid=int(selectedStat))
        if (NtsstatusslaRes):
            spSla = "getntsstatussladue(id.ticketid," + selectedStat + ") As sladue, "

    selectFields = " (SELECT SQL_CALC_FOUND_ROWS "
    incidentTable = "incident_data"
    usePurgeTable = False
    if (usePurgeTable is True):
        selectFields = " UNION  (SELECT "
        incidentTable = "incident_data_purg"

    selectFields += """ DISTINCT(id.ticketid),
                     id.sla_tooltip as tooltip,
                     resol_sla as resolutionsla,   
                     resol_due AS resolutiondue,
                     """ + spSla + """
                    id.resol_sec as resolutiontime,
                    id.resp_sec as responsetime,
                    id.resp_sla as responsesla,
                    id.resp_sec as responsedue,               
                    """

    selectFields += """
                id.statusid as ticketstatusid,
                id.priorityid,
                id.deptid as departmentid,
                id.mid as mspid,
                id.cid as clientid,
                id.client as 'MSP Client',
                id.noc as 'NOC Name',
                id.channelid as channel_id,
                id.sccalertid,
                id.did as deviceid,
                id.device as devicename, 
                id.devicetype as 'Device Type',    
                id.firstpost,
                id.first_post_user,
                id.lastpost,
                id.last_post_user,
                id.last_post_time,
                id.tags,
                id.resolve_time,
                id.first_resp_time,
                id.automation_flag as 'af',
                id.subject as 'Subject',
                id.timeworked as 'Time Worked',
                id.fullname as 'Full Name',
                id.email as 'E-mail Address',
                id.created_dt as 'Created Date',
                DATE_FORMAT(CONVERT_TZ(FROM_UNIXTIME(id.created_dt),'UTC','US/Pacific'),'%d %b %Y %T') as createDate,
                id.lastactivity as 'Last Activity',
                DATE_FORMAT(CONVERT_TZ(FROM_UNIXTIME(id.lastactivity),'UTC','US/Pacific'),'%d %b %Y %T') as lastUpDate,
                id.staffid as ownerstaffid,
                id.userid,
                id.msp as mspname
                """
    #selectFields += """
                #st.timeworked as 'Time Worked',
#                 #st.subject as 'Subject',
#                 st.fullname as 'Full Name',
#                 st.email as 'E-mail Address',
#                 st.dateline as 'Created Date',
#                 DATE_FORMAT(CONVERT_TZ(FROM_UNIXTIME(st.dateline),'UTC','US/Pacific'),'%d %b %Y %T') as createDate,
#                 st.lastactivity as 'Last Activity',
#                 DATE_FORMAT(CONVERT_TZ(FROM_UNIXTIME(st.lastactivity),'UTC','US/Pacific'),'%d %b %Y %T') as lastUpDate,
#                 st.duetime as 'Due Time',
#                 st.lastuserreplytime as 'Last User Reply',
#                 st.laststaffreplytime as 'Last Staff Reply',
#                 st.isphonecall as 'Phone Ticket',
#                 st.hasattachments as 'Has Attachments',
#                 st.hasnotes as 'Has Notes',
#                 st.isemailed as 'Is E-mailed',
#                 st.hasbilling as 'Has Billing Notes',
#                 st.userid,
#                 st.ownerstaffid,
#                 st.slaplanid ,
#                 st.totalreplies AS 'Total Replies',
#                 st.lastreplier
#                """
    selectFields += ' FROM ' + incidentTable + ' id '
 #               JOIN swtickets AS st ON st.ticketid=id.ticketid'

    return selectFields

'''
def getIncident_data_prug_SelectFields(post):
    spSla = '';
    IsSLAResolution = '';
    rslaOvd = '';
    selectedStatuses = post.getlist('selectedStatuses', False)
    selectedStat = ','.join(selectedStatuses)
    if selectedStat != False:
        pass
    selectFields = " UNION (SELECT "
    selectFields += """  DISTINCT(id.ticketid),
                     id.sla_tooltip as tooltip,
                     resol_sla as resolutionsla,   
                     resol_due AS resolutiondue,
                     """ + spSla + """
                    id.resol_sec as resolutiontime,
                    id.resp_sec as responsetime,                    
                    """

    selectFields += """
                id.statusid as ticketstatusid,
                id.priorityid,
                id.deptid as departmentid,
                id.mid as mspid,
                id.cid as clientid,
                id.client as 'MSP Client',
                id.noc as 'NOC Name',
                id.channelid as channel_id,
                id.sccalertid,
                id.did as deviceid,
                id.device as devicename, 
                id.devicetype as 'Device Type',    
                id.firstpost,
                id.first_post_user,
                id.lastpost,
                id.last_post_user,
                id.last_post_time,
                id.resolve_time,
                id.first_resp_time,
                id.automation_flag as 'af',
                """
    selectFields += """
                st.timeworked as 'Time Worked',
                st.subject as 'Subject',
                st.fullname as 'Full Name',
                st.email as 'E-mail Address',
                st.dateline as 'Created Date',
                DATE_FORMAT(CONVERT_TZ(FROM_UNIXTIME(st.dateline),'UTC','US/Pacific'),'%d %b %Y %T') as createDate,
                st.lastactivity as 'Last Activity',
                DATE_FORMAT(CONVERT_TZ(FROM_UNIXTIME(st.lastactivity),'UTC','US/Pacific'),'%d %b %Y %T') as lastUpDate,
                st.duetime as 'Due Time',
                st.lastuserreplytime as 'Last User Reply',
                st.laststaffreplytime as 'Last Staff Reply',
                st.isphonecall as 'Phone Ticket',
                st.hasattachments as 'Has Attachments',
                st.hasnotes as 'Has Notes',
                st.isemailed as 'Is E-mailed',
                st.hasbilling as 'Has Billing Notes',
                st.userid,
                st.ownerstaffid,
                st.slaplanid ,
                st.totalreplies AS 'Total Replies',
                st.lastreplier"""
    selectFields += ' FROM incident_data_purg id \
                JOIN swtickets AS st ON st.ticketid=id.ticketid'

    return selectFields
'''

def getIncidentSelectJoins(post):
    selectJoins = ''
    ticketTypes = post.getlist('ticketTypes', False)
    #if ticketTypes != False and ticketTypes != [u'']:
        #selectJoins += " JOIN ntsclienttickets AS ntsct ON id.ticketid=ntsct.ticketid "
    if post['idType'] == 'psaid':
        selectJoins += 'LEFT JOIN ticket_integration AS tktint ON tktint.ticketid=id.ticketid '

    if post['idType'] == 'vistaraid':
        selectJoins += 'LEFT JOIN vistara_itsm_integration AS vist_itsm ON vist_itsm.ticketid=id.ticketid '
    statusType = post['statusType']
    toPrio = post.getlist('toPriority', False)

    fromPrio = post.getlist('frmPriority', False)
    if toPrio != False and toPrio != [u'']:
        selectJoins += " JOIN neticketauditlog ntalog ON  ntalog.ticketid = id.ticketid "

    return selectJoins


def convert(data):
    if isinstance(data, basestring):
        return str(data.encode('utf-8'))
    elif isinstance(data, collections.Mapping):
        return dict(map(convert, data.iteritems()))
    elif isinstance(data, collections.Iterable):
        return type(data)(map(convert, data))
    else:
        return data

from htmlmin.decorators import minified_response
@minified_response
def slamResults(request):
    post = {}
    global IncidentResolutionSla, statusSlaFlag
    ticketCountsQueryString = request.GET
    rsl = 0
    if ticketCountsQueryString.has_key('rals'):
        rsl = ticketCountsQueryString['rals']
    excel = 0
    if ticketCountsQueryString.has_key('excel'):
        excel = 1
    threshold = configobj.getCommConfigValue(configobj.threshold)
    purgFlag = False
    AlertTicketStatus = True
    mytIcketsRsla = ''
    if request.GET and rsl == 0 and excel == 0:
        view = request.GET['view']
        id = base64.b64decode(view)
        templateModel = tktbrwsr_obj.getTemplateDetails(int(id))
        for temModel in templateModel:
            post = request.GET.copy()
            post1 = temModel
            rsla = post1['resolution_sla'] if post1.has_key('resolution_sla') else ''
            post['templateId'] = str(id) if id else ''
            post['templatename'] = post1['templatename']

            if request.session['uId'] > 0:

                if post['templatename'] == "My Tickets":
                    mytIcketsRsla = 0
                    post['assignto'] = str(request.session['swstaffId'])
                    if request.session['isManager'] == 1:
                        depatments = swdept_obj.getDepatmentIs(request.session['uId'])
                    else:
                        depatments = swdept_obj.getDepatmentIs(request.session['repMangId'])
                    deptList = ''
                    for did in depatments:
                        deptList += str(did['kayako_deptid']) + ','
                    post['department'] = str(deptList[:-1])
                elif (post['templatename'] == "My Team Tickets"):
                    mytIcketsRsla = 0
                    if request.session['isManager'] == 1:

                        depatments = swdept_obj.getDepatmentIs(request.session['uId'])
                        reportingPersonData = NrStaff.objects.using('rosterRead').only('swstaff_id').filter(
                            reporting_manager_id=request.session['uId']).filter(is_active=1).exclude(swstaff_id=None)
                    else:

                        reportingPersonData = NrStaff.objects.using('rosterRead').only('swstaff_id').filter(
                            reporting_manager_id=request.session['repMangId']).filter(is_active=1).exclude(
                            swstaff_id=None)
                        depatments = swdept_obj.getDepatmentIs(request.session['repMangId'])
                    deptList = ''
                    for did in depatments:
                        deptList += str(did['kayako_deptid']) + ','
                    post['department'] = str(deptList[:-1])
                    swstaffID = ''
                    for person in reportingPersonData:
                        swstaffID += str(person.swstaff_id) + ','
                    if request.session['isManager'] == 1:
                        swstaffID += str(request.session['swstaffId']) + ','
                    else:
                        mngr = NrStaff.objects.using('rosterRead').only('swstaff_id').filter(
                            id=request.session['repMangId']).exclude(swstaff_id=None)
                        for mgr in mngr:
                            mgr_swID = mgr.swstaff_id
                        swstaffID += str(mgr_swID) + ','
                    post['assignto'] = str(swstaffID[:-1])
                else:
                    post['assignto'] = str(post1['staff'])
                    post['department'] = str(post1['departments'])

            else:
                return HttpResponseRedirect('/NNCPortal/Login/')

            post['CM'] = comObj.convertTemplateFieldsToString(
                post1['is_modified_tickets'])

            post['channel'] = comObj.convertTemplateFieldsToString(
                post1['channel'])

            post['ticketTypes'] = comObj.convertTemplateFieldsToString(
                post1['ticket_type'])

            post['serviceType'] = comObj.convertTemplateFieldsToString(
                post1['service_type'])

            post['serviceLevel'] = comObj.convertTemplateFieldsToString(
                post1['service_level'])

            post['deviceType'] = comObj.convertTemplateFieldsToString(
                post1['devicetypes'])

            post['selectedStatuses'] = comObj.convertTemplateFieldsToString(
                post1['statuses'])
            post['selectedPriorities'] = comObj.convertTemplateFieldsToString(
                post1['priorities'])
            post['custom'] = comObj.convertTemplateFieldsToString(
                post1['display_columns'])
            post['resSla'] = comObj.convertTemplateFieldsToString(
                post1['resolution_sla'])
            post['date'] = comObj.convertTemplateFieldsToString(post1['opt_dateselection'])
            post['idType'] = ''
            post['idTypeValue'] = ''
            if post['date'] == 'DAYS':
                post['optionSelected'] = ''
                post['daysValue'] = comObj.convertTemplateFieldsToString(
                    post1['days'])

                if post['daysValue'] == 0 or post['daysValue'] == '0' or post['daysValue'] == '' or post[
                    'daysValue'] == None:
                    post['date'] = ''

            elif post['date'] == 'DATE':
                os.environ["TZ"] = "US/Pacific"
                post['optionSelected'] = ''
                post1['fromdate'] = comObj.convertTemplateFieldsToString(post1['fromdate'])
                if post1['fromdate']:
                    post['fromDate'] = str(datetime.fromtimestamp(int(post1['fromdate'])).strftime('%m/%d/%Y %H:%M'))
                else:
                    post['fromDate'] = None
                post1['todate'] = comObj.convertTemplateFieldsToString(post1['todate'])

                if post1['todate']:
                    post['toDate'] = str(datetime.fromtimestamp(int(post1['todate'])).strftime('%m/%d/%Y %H:%M'))
                else:
                    post['toDate'] = None
            elif post['date'] == 'OTHERS':
                post['optionSelected'] = comObj.convertTemplateFieldsToString(post1['other_opt'])

            post['frmPriority'] = ''
            post['toPriority'] = ''
            post['devices'] = comObj.convertTemplateFieldsToString(
                post1['devices'])
            post['clients'] = comObj.convertTemplateFieldsToString(
                post1['clients'])
            post['partners'] = comObj.convertTemplateFieldsToString(
                post1['partners'])
            post['nocs'] = comObj.convertTemplateFieldsToString(
                post1['nocs'])
            post['statusType'] = 'current' if post1['is_auditlog_status'] == 0 else 'auditlog'
            rsla = post1['resolution_sla'] if post1.has_key('resolution_sla') else ''
            post['resSla'] = comObj.convertTemplateFieldsToString(rsla)

            if rsla == '':
                rsla = ''

    if request.method == "POST" or request.method == "GET":
        curDTime = datetime.now()
        stp = time.time()
        lastupdated = dt.datetime.fromtimestamp(int(stp)).strftime('%b %d,%Y')
        if len(request.POST) > 0:
            post = request.POST.copy()

        if post == '' or post == None or len(post) == 0:
            return False
        # FOR ALL CASES SKIPPING DATE RANGES CONDITIONS
        if post['date'] == 'DAYS':
            if post['daysValue'] == 0 or post['daysValue'] == '0' or post['daysValue'] == '' or post[
                'daysValue'] == None:
                post['date'] = ''

        thresHoldsec = int(timegm(datetime.utcnow().utctimetuple())) - (int(threshold) * 86400)

        if post.get('fromDate', False) and post.has_key('fromDate') and str(post['fromDate']) != '0' and post[
            'fromDate'].find('/') < 0:
            formtdate = int(time.mktime(datetime.strptime(str(post['fromDate']), "%m/%d/%Y %H:%M").timetuple()))

        else:
            formtdate = 0

        if post:
            query = prepareIncidentTicketsQuery(post)
            selectedFeilds = getIncidentSelectFields(post, usePurgeTable=False)
            joins = getIncidentSelectJoins(post)
            sql = selectedFeilds + " " + joins + " " + query
            Countsuery = joins + " " + query
            if rsl != 0:
                rsla = rsl
            else:
                rsla = post.getlist('resSla', False)

            if rsla != False and rsla != [u'']:
                rsla = ','.join(rsla)
                rsla = rsla.split(',')
                if len(rsla) > 0:
                    glue = ''
                    append = ''
                    for t in rsla:
                        append += glue + IncidentResolutionSla[t]

                        glue = " OR """
                    slaCondition = " AND (" + append + ")"
                    sql += slaCondition
        if post.get('date', '') == 'DATE' or post.get('idType', '') == 'ticketid' or post.get('idType',
                                                                                              '') == 'alertid' or post.get(
            'idType', '') == 'psaid' or str(post.get('idType', '')) == 'subject' or post.get('idType',
                                                                                             '') == 0 or post.get(
            'idType', '') == 'vistaraid':

            if post.get('idType', '') == '':
                AlertTicketStatus = False

            if post.get('idType', '') == 0:
                AlertTicketStatus = True

            if formtdate > thresHoldsec:

                AlertTicketStatus = False
                purgFlag = True
                query = prepareIncidentTicketsQuery(post)
                selectedFeilds = getIncidentSelectFields(post,
                                                         usePurgeTable=True)
                joins = getIncidentSelectJoins(post)
                #sql_purg = selectedFeilds + " " + joins + " " + query
                rsla = post.getlist('resSla', False)
                if rsla != False and rsla != [u''] and rsla != None:
                    rsla = ','.join(rsla)
                    rsla = rsla.split(',')
                    if len(rsla) > 0:
                        glue = ''
                        append = ''
                        for i in rsla:
                            append += glue + IncidentResolutionSla[i]

                            glue = " OR """
                        slaCondition = " AND (" + append + ")"
                        #sql_purg += slaCondition

            if post['idTypeValue'] != "" or post['optionSelected'] == 'LQ':

                if AlertTicketStatus == True:
                    purgFlag = True

                    query = prepareIncidentTicketsQuery(post)

                    selectedFeilds = getIncidentSelectFields(post,
                                                             usePurgeTable=True)  # getIncident_data_prug_SelectFields(post)
                    joins = getIncidentSelectJoins(post)
                    #sql_purg = selectedFeilds + " " + joins + " " + query
                    rsla = post.getlist('resSla', False)

                    if rsla != False and rsla != [u'']:
                        rsla = ','.join(rsla)
                        rsla = rsla.split(',')
                        if len(rsla) > 0:
                            glue = ''
                            append = ''
                            for i in rsla:
                                append += glue + IncidentResolutionSla[i]

                                glue = " OR """
                            slaCondition = " AND (" + append + ")"
                            #sql_purg += slaCondition

        sqlsets = ''
        if (post.get('idType', '') == 'alertid' and post.get('idTypeValue', '') != '') or (
                        post.get('idType', '') == 'ticketid' and post.get('idTypeValue', '') != ''):

            if excel > 0:
                sqlsets += " LIMIT 500 OFFSET 0 )"
            else:
                sqlsets += " LIMIT 50 OFFSET 0 )"
        else:
            customValues = post.getlist('custom', '')
            if len(customValues) > 1:
                pass
            else:

                customValues = customValues[0].split(',')

            if ('getntsstatussladue' in selectedFeilds):
                sqlsets += " ORDER BY sladue ASC "
            else:
                matching = [s for s in customValues if "SLA Resolution" in s]
                if len(matching) > 0:
                    sqlsets += " ORDER BY id.resol_due, id.ticketid ASC "

                else:
                    sqlsets += " ORDER BY id.ticketid ASC "
            if excel > 0:
                sqlsets += " LIMIT 500 OFFSET 0 ) "
            else:
                sqlsets += " LIMIT 50 OFFSET 0 ) "

        sql += sqlsets
        #if purgFlag == True:
        #    sql_purg += sqlsets
        #    sql += sql_purg

        customFields = post.getlist('custom', '')
        if len(customFields) > 1:
            pass
        else:
            customFields = customFields[0].split(',')

        result = tktbrwsr_obj.ticketBrowserResults(sql)
        data = prepareTicketBrowserResults(result, customFields)
        if rsl != 0:
            resSla_list = rsl
        else:

            resSla_list = post.getlist('resSla')

        resSla_list = ','.join(resSla_list)
        uiDisplaydataOfRsl = resSla_list
        resSla_list = resSla_list.split(',')

        resSla_list_count = 0
        if mytIcketsRsla == 0:
            resSla_list_count = 0


        elif resSla_list == [u'']:
            mytIcketsRsla = 0


        else:
            resSla_list_count = len(resSla_list)

            if resSla_list_count == 0:
                mytIcketsRsla = 0
        if excel != 1:
            TotalCounts = incdata_obj.getCountOfIncidentTicketsBySLA(Countsuery, resSla_list, mytIcketsRsla)
            if rsl != 0:
                firstRecordCounts = TotalCounts[int(rsl)]
            else:
                firstRecordCounts = int(TotalCounts[1]) + int(TotalCounts[2]) + int(TotalCounts[3])

            Totaltickets = 0

            for key, value in TotalCounts.iteritems():
                Totaltickets = Totaltickets + int(value)
        else:
            Totaltickets = 0
        custofieldstrings = ','.join(customFields)
        postDict = dict(post)
        monitoringUrl = configobj.getCommConfigValue(configobj.Monitoringurl)
        if excel > 0:
            titles = data['HeaderField']
            contentData = data['results']
            templateName = post['templatename'].replace(' ', '_')
            filename = str(templateName) + '.xlsx'
            response = HttpResponse(content_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
            response['Content-Disposition'] = 'attachment; filename=' + filename
            xlsx_data = comObj.ExcelDwdFor500Below(titles, contentData)
            response.write(xlsx_data)
            return response

        else:
            return render_to_response('slamResults.html',
                                      {'result': data['results'], 'query': sql, 'heading': data['HeaderField'],
                                       'Tooltips': data['Titles'], 'stingData': custofieldstrings,
                                       'TotalCounts': Totaltickets, 'resSla_list_count': resSla_list_count,
                                       'countResl': TotalCounts, 'latdupd': lastupdated,
                                       'Templatename': post['templatename'], 'post': postDict,
                                       'countsQuery': Countsuery, 'resSla_list': uiDisplaydataOfRsl,
                                       'mytIcketsRsla': mytIcketsRsla, 'reslTicketCount': firstRecordCounts,
                                       'monitoringUrl': monitoringUrl, 'statusSlaFlag': statusSlaFlag},
                                      context_instance=RequestContext(request))


def getClientAjax(request):
    devices = []
    if request.method == "POST":
        finResult = request.POST
        res = dict(finResult.lists())
        if request.POST.get('res_devices[]', False):
            for clientId in res['res_devices[]']:
                dev = comMObj.getDevices(clientId)
                if dev:
                    devices = devices + dev
        else:
            devices = comMObj.getDevices(client_id='')
    jsonData = simplejson.dumps({'devices': devices})
    return HttpResponse(jsonData, content_type="application/json")


def loadTemplate(request):
    os.environ["TZ"] = "US/Pacific"
    id = request.GET.get('id')
    prioritiesAll = ''
    templateModel = tktbrwsr_obj.getTemplateDetails(id)
    tb_admin = request.session['tb_admin']

    for tempModel in templateModel:
        if tempModel['fromdate'] and tempModel.has_key('fromdate') and tempModel['todate'] and tempModel.has_key(
                'todate'):
            fromDate = datetime.fromtimestamp(int(tempModel['fromdate'])).strftime('%m/%d/%Y %H:%M')
            toDate = datetime.fromtimestamp(int(tempModel['todate'])).strftime('%m/%d/%Y %H:%M')
        else:
            fromDate = ''
            toDate = ''
    jsonData = simplejson.dumps({'is_modified_tickets': tempModel['is_modified_tickets'], 'templateId': id,
                                 'templatename': tempModel['templatename'], 'templateType': tempModel['templatetype'],
                                 'statuses': tempModel['statuses'], 'departments': tempModel['departments'],
                                 'ticketType': tempModel['ticket_type'], 'channel': tempModel['channel'],
                                 'nocs': tempModel['nocs'], 'partners': tempModel['partners'],
                                 'clients': tempModel['clients'], 'staff': tempModel['staff'],
                                 'serviceType': tempModel['service_type'], 'serviceLevel': tempModel['service_level'],
                                 'devices': tempModel['devices'], 'deviceType': tempModel['device_types'],
                                 'priorities': tempModel['priorities'], 'resSla': tempModel['resolution_sla'],
                                 'displayColumns': tempModel['display_columns'],
                                 'optDateSelection': tempModel['opt_dateselection'], 'fDate': fromDate, 'tDate': toDate,
                                 'otherOption': tempModel['other_opt'], 'days': tempModel['days'],
                                 'prioritiesAll': prioritiesAll, 'tb_admin': tb_admin,
                                 'ticketid': tempModel['ticketid'], 'alertid': tempModel['sccalertid'],
                                 'psaid': tempModel['psa_id'], 'subject': tempModel['searchstring'],
                                 'is_auditlog_status': tempModel['is_auditlog_status'], 'tags': tempModel['tags']})
    return HttpResponse(jsonData, content_type="application/json")


def prepareTicketBrowserResults(results, displayFields):
    global priorityClass, statusSlaFlag

    if 'Ticket Id' not in displayFields:
        displayFields.insert(0, 'Ticket Id')

    swstaff = swstaff_obj.ownersStaffid()
    partnerName = msp_obj.partnerName()
    reslutdata = {}
    titleDisplay = {}
    countVlaue = 0
    customClounsDefalutList = list(displayFields)

    for customField in displayFields:
        if customField.find('cust_fld_'):
            pass
        else:
            customFieldPos = displayFields.index(customField)
            customId = string.replace(customField, 'cust_fld_', '')
            fieldnames = swcustomflds_obj.getCustomFields_SM()
            customClounsDefalutList[customFieldPos] = fieldnames[int(customId)]

    recordPostion = 0
    resultTantList = {}
    statusSlaFlag = False
    if len(results) > 0:
        count = 0
        for i in results:
            count = count + 1

            resultTitles = {}
            resultsData = {}
            customFieldOrder = 0
            for customField in displayFields:
                data = {}
                if customField.find('cust_fld_'):

                    if customField == 'Status':
                        scheduledOrderFlag = 0
                        newstatus = mem_cache.get('newStatus')
                        if not newstatus:
                            newstatus = swtktstatus_obj.getNewStatus()

                        if i.has_key('sladue'):
                            statusSlaFlag = True
                            data['display'] = ''
                            if int(i['ticketstatusid']) == 19:
                                data['display'] = 'RD '
                            if int(i['ticketstatusid']) == 16:
                                data['display'] = 'Scheduled '

                            if i['sladue'] is None:
                                slaDue = 0
                                data['display'] += '(TL: -)'  # when scheduled time was not given
                                scheduledOrderFlag = 1
                                data['Order'] = -1
                            else:
                                slaDue = int(i['sladue'])
                                dateFormat = Salmquey.getHours(slaDue)
                                res = Salmquey.getSLADisplayColumns(slaDue, dateFormat)
                                data['display'] += '(' + res['resolutionDueText'] + ')'
                                scheduledOrderFlag = 1
                                data['Order'] = slaDue
                            slaTime = 3600  # This should come from ntsstatussla table
                            if slaDue < 0:
                                data['classcode'] = 'OD sorting_1'
                            elif slaDue > 0 and slaDue < slaTime:
                                data['classcode'] = 'spec-red sorting_1'
                            else:
                                data['classcode'] = 'TL1 sorting_1'
                            data['slaTime'] = slaTime
                            data['Tooltip'] = 'SLA: ' + Salmquey.getHours(slaTime)
                            # data['Order'] = slaDue
                            data['style'] = 'font-weight: bold;'
                            data['fieldType'] = 'sladue'
                            data['status_order'] = scheduledOrderFlag


                        else:
                            statusData = ''
                            if i.has_key('ticketstatusid'):
                                if newstatus.has_key(i['ticketstatusid']):
                                    statusData = newstatus[i['ticketstatusid']]
                            data['display'] = statusData
                            data['status_order'] = scheduledOrderFlag
                        resultsData[customField] = data

                    if customField == 'Client Name':
                        data = {}
                        data['display'] = i['MSP Client']
                        data['Tooltip'] = i['MSP Client']
                        data['clientid'] = i['clientid']
                        data['cUrl'] = comObj.generateVistaraClientUrl(i['clientid'])
                        resultsData[customField] = data

                    if customField == 'Device Name':
                        data = {}
                        deviceName = str(i['devicename']).strip()
                        if deviceName in [None, '']:
                            if i['sccalertid'] > 0:
                                deviceName = Salmquey.getDeviceNameFromCumulativeAlerts(i['sccalertid'])
                                data['display'] = str(deviceName) 
                            else:
                                data['display'] = '(Not found)'

                            data['deviceid'] = 0
                        else:
                            data['display'] = deviceName
                            data['deviceid'] = str(i['deviceid'])
                            data['dUrl'] = comObj.generateVistaraDeviceUrl(i['clientid'], i['deviceid'])
                        resultsData[customField] = data

                    if customField == 'Partner Name':
                        data['display'] = i['mspname']
                        data['partnerid'] = i['mspid']
                        data['pUrl'] = comObj.generateVistaraPartnerUrl(i['mspid'])
                        #data['vis'] = configobj.getCommConfigValue(configobj.vistaraUrls)
                        #data['urls']= incdata_obj.vistarUrls('partners')
                        #print data
                        resultsData[customField] = data

                    if customField == 'Created Date (PDT)':
                        data['display'] = i['createDate']
                        data['Order'] = int(i['Created Date'])
                        resultsData[customField] = data

                    if customField == 'Time Worked (Min)':
                        timeWorked = Salmquey.getMinutesFormatFromSeconds(i['Time Worked'])
                        data['display'] = timeWorked
                        resultsData[customField] = data

                    if customField == 'SLA Resolution':

                        dateFormat = Salmquey.getHours(i['resolutiondue'])
                        res = Salmquey.getSLADisplayColumns(i['resolutiondue'], dateFormat)
                        data['display'] = res['resolutionDueText']

                        if i.has_key('tooltip'):
                            if i['tooltip'] !=None and i['tooltip'] !='None'  and  i['tooltip'] != '' :
                                tooltip = str(i['tooltip'].encode('utf-8'))
                                strSlaValue = str(tooltip).lower().split('sla:')[-1].strip()
                                if strSlaValue == 'no sla':
                                    data['Tooltip'] = tooltip
                                else:
                                    if  strSlaValue != 'None' and strSlaValue != 'none' and  strSlaValue != None:
                                        slaValue = Salmquey.getHours(int(strSlaValue))
                                        tooltip = tooltip.replace(strSlaValue, slaValue)
                                    else:
                                        tooltip = ''
                                    data['Tooltip'] = tooltip
                            else:
                                data['Tooltip'] = ''

                        data['Order'] = i['resolutiondue'] if i.has_key('resolutiondue') else ''
                        data['style'] = res['resolutionSlaBgColor']
                        data['classcode'] = res['classcode']
                        resultsData[customField] = data

                    if customField == 'Last Update (PDT)':
                        data['display'] = i['lastUpDate']
                        data['Order'] = 0 if i['Last Activity'] is None else int(i['Last Activity'])
                        resultsData[customField] = data

                    if customField == 'Priority':
                        priortyData = ''
                        priorityClassData = ''
                        pirtoyName = swtktprior_obj.priorty()  # changed calling
                        if i.has_key('priorityid'):
                            if pirtoyName.has_key(int(i['priorityid'])):
                                priortyData = pirtoyName[int(i['priorityid'])]

                        data['display'] = priortyData
                        data['Order'] = i['priorityid']
                        if priorityClass.has_key(int(i['priorityid'])):
                            priorityClassData = priorityClass[int(i['priorityid'])]
                        data['classcode'] = priorityClassData
                        resultsData[customField] = data

                    if customField == 'Department':

                        DepatmentName = swdept_obj.departments()
                        if i['departmentid'] > 0:

                            if DepatmentName.has_key(i['departmentid']):
                                data['display'] = DepatmentName[int(i['departmentid'])]
                            else:
                                data['display'] = ''

                        else:
                            data['display'] = ''

                        resultsData[customField] = data

                    if customField == 'Ticket Id':
                        data['display'] = i['ticketid']
                        data['af'] = i['af']

                        resultsData[customField] = data

                    if customField == 'Requester':
                        """if len(i['Full Name']) > 14:
                            fullname = str(i['Full Name'][0:14]) + '...'
                            data['display'] = fullname
                            data['Tooltip'] = i['Full Name']
                        else:
                            data['display'] = i['Full Name']

                        resultsData[customField] = data
                    """

                        data['Tooltip'] = i['Full Name']
                        data['display'] = i['Full Name']
                        resultsData[customField] = data

                    if customField == 'Owner':
                        staffId = int(i['ownerstaffid'])
                        if staffId == 0:
                            data['display'] = 'Un-Assigned'
                            data['classcode'] = 'label label-danger'
                        elif swstaff.has_key(staffId):
                            data['display'] = swstaff[staffId]
                        resultsData[customField] = data

                    if customField == 'Subject':
                        #emailname = re.sub(u"(\u2018|\u2019)", "'", i['Subject'].encode('utf-8'))
                        emailname = i['Subject'] if i['Subject'] is None else i['Subject'].encode('utf-8')
                        subject = str(emailname) + '...'
                        data['display'] = i['Subject']
                        data['subject'] = i['Subject']
                        data['Tooltip'] = emailname
                        resultsData[customField] = data

                    if customField == 'Resolved Time (PDT)':
                        '''data1 = Salmquey.ResolvedTime(i['ticketid'])

                        if len(data1) > 0:
                            if (data1['resolved_date'] != None):
                                data['display'] = Salmquey.getLocalDate(data1['resolved_date'])
                                resultsData[customField] = data
                            else:
                                data['display'] = ''
                                resultsData[customField] = data
                        else:
                            data['display'] = ''
                            resultsData[customField] = data
                        '''

                        data['display'] = str(
                            datetime.fromtimestamp(int(i['resolve_time'])).strftime('%d %b %Y %H:%M')) if i[
                                                                                                              'resolve_time'] != 0  else ''
                        resultsData[customField] = data

                    if customField == 'Last Post':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'Business HRS End Time':
                        BusinessHoursStart = Salmquey.BusinessHoursStart(i['ticketid'])
                        data['display'] = BusinessHoursStart['BussinesDay']
                        resultsData[customField] = data

                    if customField == 'Status Changed By':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'Second Post Content':

                        if i['lastpost']:
                            #lastpostdata = re.sub(u"(\u2018|\u2019)", "'", i['lastpost'])
                            lastpost = str(i['lastpost'][0:30].encode('utf-8')) + '...'
                            tooltip = i['lastpost']
                            data['display'] = lastpost
                            data['Tooltip'] = tooltip
                            resultsData[customField] = data
                        else:
                            data['display'] = ''
                            resultsData[customField] = data

                    if customField == 'Last Replier':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'First Post Content':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'Created In Business Hrs?':
                        created = Salmquey.getBusinessHours(i['ticketid'])
                        data['display'] = created['BusinessHours']
                        resultsData[customField] = data

                    if customField == 'Has Billing Notes':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'Has Notes':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'Last Staff Reply':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'Second Response Date':
                        data1 = Salmquey.secondPostResponse(i['ticketid'])
                        if len(data1) > 1:
                            data['display'] = Salmquey.getLocalDate(data1[1]['date'])
                            resultsData[customField] = data
                        else:
                            data['display'] = ''
                            resultsData[customField] = ''

                    if customField == 'Scheduled Time':
                        data['display'] = Salmquey.getScheduledTime(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'Closed Time (PDT)':

                        data1 = Salmquey.getClosedDateTime(i['ticketid'])
                        if len(data1) > 0:
                            if data1['closed_date'] != None:
                                data['display'] = Salmquey.getLocalDate(data1['closed_date'])
                                resultsData[customField] = data
                            else:
                                data['display'] = ''
                                resultsData[customField] = data
                        else:
                            data['display'] = ''
                            resultsData[customField] = data

                    if customField == 'Is E-mailed':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'Last User Reply':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'First Response Date':
                        # data1 = Salmquey.secondPostResponse(i['ticketid'])
                        data['display'] = str(datetime.fromtimestamp(int(i['Created Date'])).strftime('%d %b %Y %H:%M'))
                        resultsData[customField] = data

                    if customField == 'Service Type':
                        data['display'] = Salmquey.getServiceType(i['deviceid'])
                        resultsData[customField] = data

                    if customField == 'Total Updates':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'Time Billable (Min)':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'User Replies':
                        data1 = Salmquey.userreplies(i['ticketid'])
                        data['display'] = data1['count']
                        resultsData[customField] = data

                    if customField == 'Business HRS Start Time':
                        bussinessday = Salmquey.BusinessHoursStart(i['ticketid'])
                        data['display'] = bussinessday['BussinesDay']
                        resultsData[customField] = data

                    if customField == 'Due Time':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'Ticket Type':
                        id = Salmquey.getTicketInfo(i['ticketid'])
                        ticketTypes = tkttype_obj.getAllTicketTypes()
                        try:
                            data['display'] = ticketTypes[id]['typename']
                            resultsData[customField] = data
                        except Exception as e:
                            data['display'] = ''
                            resultsData[customField] = data

                    if customField == 'Duration':
                        data['display'] = ''
                        resultsData[customField] = data
                        
                    if customField == 'Has Attachments':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'Phone Ticket':
                        data['display'] = ''
                        resultsData[customField] = data

                    if customField == 'Status Changed Time (PDT)':
                        data['display'] = ''
                        resultsData[customField] = data
                    if customField == 'SKU':
                        data1 = sku_obj.skuDetails(i['deviceid'])
                        if len(data1) > 0:
                            data['display'] = data1
                            resultsData[customField] = data
                        else:
                            data['display'] = 0
                            resultsData[customField] = data

                    if customField == 'E-mail Address':
                        if len(i['E-mail Address']) > 14:
                            emailname = str(i['E-mail Address'][0:14]) + '...'
                            data['display'] = emailname
                            data['Tooltip'] = i['E-mail Address']
                        else:
                            data['display'] = i['E-mail Address']

                        resultsData[customField] = data

                    if customField == 'Device Site':
                        data['display'] = Salmquey.deviceSite(i['deviceid'])
                        resultsData[customField] = data

                    if customField == 'Device Group':
                        data['display'] = Salmquey.deviceGroup(i['deviceid'])
                        resultsData[customField] = data

                    if customField == 'Service Category':
                        data['display'] = Salmquey.servicecategory(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'Device Category':
                        data['display'] = Salmquey.devicecategory(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'Device Type':
                        data['display'] = Salmquey.deviceType(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'Package':
                        data1 = sku_obj.packages(i['deviceid'])
                        if len(data1) > 0:
                            data['display'] = data1
                            resultsData[customField] = data

                        else:
                            data['display'] = 0
                            resultsData[customField] = data

                    if customField == 'Full Name':
                        if len(i['Full Name']) > 14:
                            fullname = str(i['Full Name'][0:14]) + '...'
                            data['display'] = fullname
                            data['Tooltip'] = i['Full Name']
                        else:
                            data['display'] = i['Full Name']

                        resultsData[customField] = data

                    if customField == 'In-coming Alert Time':
                        data['display'] = '-'
                        resultsData[customField] = data

                    if customField == 'Count of Healed Alert(s)':
                        data['display'] = Salmquey.countofhealedalert(i['ticketid'])
                        resultsData[customField] = data
                    if customField == 'SCC Alert Id':
                        data['display'] = i['sccalertid']
                        resultsData[customField] = data

                    if customField == 'Total Count of Alert(s)':
                        data['display'] = Salmquey.totalcountofalert(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'Vistara AB Ticket Status':
                        data['display'] = Salmquey.vistaraabticketstatus(i['sccalertid'], i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'Technology':
                        data['display'] = Salmquey.technology(i['clientid'], i['deviceid'])
                        resultsData[customField] = data

                    if customField == 'NOC Name':
                        data['display'] = i['NOC Name']
                        resultsData[customField] = data

                    if customField == 'Service Level':
                        data['display'] = sku_obj.servicelevel(i['deviceid'])
                        resultsData[customField] = data

                    if customField == 'PSA Service Board Matched?':
                        data['display'] = psatrack_obj.psaserviceboardmatched(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'PSA Data Captured On (PDT)':
                        data['display'] = psatrack_obj.psadatacapturedon(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'PSA Q or Service Board Name':
                        data['display'] = psatrack_obj.serviceBoardName(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'Integration Type':
                        data['display'] = ''
                        resultsData[customField] = data
                    if customField == 'PSA Post Count':
                        data['display'] = psatrack_obj.psapostcount(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'PSA Current Status':
                        data['display'] = psatrack_obj.psacurrentstatus(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'PSA Status Matched?':
                        data['display'] = psatrack_obj.is_status_matched(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'PSA Last Update (PSA TZ)':
                        data['display'] = psatrack_obj.psa_lastactivity_date(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'Client Timezone':
                        if i['clientid']:
                            data['display'] = Salmquey.csatrequest(i['clientid'])
                            resultsData[customField] = data

                        else:
                            data['display'] = ''
                            resultsData[customField] = data

                    ''' 
                    Csat Resonse field for,
                    How do you rate your satisfaction with the technical support 
                    you received from Global NOC on this ticket?
                    '''
                    if customField == 'Csat Response':
                        dbData = comObj.getCSAT(i['ticketid'])
                        if dbData.has_key('satisfaction'):
                            data['display'] = dbData['satisfaction']
                            resultsData[customField] = data
                        else:
                            data['display'] = ''
                            resultsData[customField] = data

                    if customField == 'Csat Request':
                        data['display'] = Salmquey.csatrequest(i['ticketid'])
                        resultsData[customField] = data

                    if customField == 'Response Interval (Min)':
                        if i['responsetime'] > 0:
                            data['display'] = Salmquey.getMinutesFormatFromSeconds(i['responsetime'])
                            resultsData[customField] = data

                        else:
                            data['display'] = 0
                            resultsData[customField] = data

                    if customField == 'Var Notification Time (PDT)':
                        if i['ticketid']:

                            data1 = Salmquey.varnotificationTime(i['ticketid'])
                            if data1 != '':
                                data['display'] = Salmquey.getLocalDate(data1)
                                resultsData[customField] = data

                            else:
                                data['display'] = '-'
                                resultsData[customField] = data

                    if customField == 'Primary Contact Email Id':
                        if i['mspid']:
                            data['display'] = Salmquey.PrimaryNotification(i['mspid'])
                            resultsData[customField] = data
                        else:
                            data['display'] = ''
                            resultsData[customField] = data
                    if customField == 'Resolution Interval(Min)':
                        if i['resolutiontime'] > 0:
                            data['display'] = Salmquey.getMinutesFormatFromSeconds(i['resolutiontime'])
                            resultsData[customField] = data

                        else:
                            data['display'] = 0
                            resultsData[customField] = data
                    if customField == 'Channel':

                        channaleName = Salmquey.channalNmae(i['ticketid'])
                        try:
                            data['display'] = channaleName[int(i['channel_id'])]
                            resultsData[customField] = data

                        except Exception as e:
                            data['display'] = ''
                            resultsData[customField] = data

                    if customField == 'Response SLA Met':
                        if str(i['responsesla']) != 'NO SLA' and i['responsesla'] != None:
                            if i['responsedue'] != None:
                                if int(i['responsedue']) < int(i['responsesla']):
                                    data['display'] = 'Yes'
                                else:
                                    data['display'] = 'No'
                            else:
                                data['display'] = 'Yes'
                        else:
                            data['display'] = 'Yes'

                        resultsData[customField] = data

                    if customField == 'SLA Resolution(%)':
                        data['display'] = Salmquey.slaresolution(i['ticketid'], i['responsetime'])
                        resultsData[customField] = data

                    if customField == 'Response Time (H:M:S)':

                        if i['responsetime'] > 0:
                            data['display'] = Salmquey.convertSecoandToTime(i['responsetime'])
                            resultsData[customField] = data

                        else:
                            data['display'] = 0
                            resultsData[customField] = data

                    if customField == 'Resolution SLA Met':

                        if i['resolutiondue'] > 0:
                            data['display'] = 'Yes'
                            resultsData[customField] = data

                        else:
                            data['display'] = 'NO'
                            resultsData[customField] = data

                    if customField == 'Calendar Time':
                        if i['Created Date']:
                            data['display'] = Salmquey.getLocalDate(i['Created Date'])
                            resultsData[customField] = data

                        else:
                            data['display'] = 0
                            resultsData[customField] = data
                    if customField == 'Resolution Time (H:M:S)':
                        if i['resolutiontime'] > 0:
                            data['display'] = Salmquey.convertSecoandToTime(i['resolutiontime'])
                            resultsData[customField] = data

                        else:
                            data['display'] = 0
                            resultsData[customField] = data
                    if customField == 'Tags':
                        if i['tags']:
                            data['display'] = i['tags']
                            resultsData[customField] = data
                        else:
                            data['display'] = ''
                            resultsData[customField] = data
                    if customField == 'First Response Time (HH:MM:SS)':
                        if i['first_resp_time'] > 0:
                            data['display'] = Salmquey.convertSecoandToTime(i['first_resp_time'])
                            resultsData[customField] = data

                        else:
                            data['display'] = 0
                            resultsData[customField] = data

                else:
                    customFieldPos = displayFields.index(customField)
                    customId = string.replace(customField, 'cust_fld_', '')
                    fieldnames = swcustomflds_obj.getCustomFields_SM()
                    ticketId = i['ticketid']
                    displayData = sw_cus_fval_obj.getCustomFieldValue(customId, ticketId)
                    data['display'] = displayData
                    if (customId == 3):
                        if displayData != '0000':
                            data['display'] = Salmquey.ticket_url(i['mspid'])
                        else:
                            data['display'] = ''
                    resultsData[fieldnames[int(customId)]] = data
            countVlaue = 1 + countVlaue
            resultTantList[countVlaue] = resultsData
        reslutdata['results'] = resultTantList
        reslutdata['HeaderField'] = customClounsDefalutList
        reslutdata['Titles'] = titleDisplay
        reslutdata['displayFields'] = displayFields
    else:

        reslutdata['results'] = resultTantList
        reslutdata['HeaderField'] = customClounsDefalutList
        reslutdata['Titles'] = titleDisplay
        reslutdata['displayFields'] = displayFields
    return reslutdata


def saveOrUpdateTemplate(request):
    if request.method == "POST":
        response_data = {}
        finResult = request.POST
        finalResult = defaultdict(dict)
        finalResult = dict(finResult)
        if 'uName' in request.session:
            uid = request.session['uId']
        returnId = tktbrwsr_obj.saveTemplate(finalResult, uid)
        response_data['id'] = returnId
        return HttpResponseRedirect('/')


"""
 For Partner Or client base tickets counts on departmentwise in LeftPanel
"""


def getPatcliCount(request):
    Final = []
    try:
        if request.method == "POST":
            finResult = request.POST
            res = dict(finResult.lists())
            if request.POST.get('res_p', None) or request.POST.get('res_c[]', None):
                partner = request.POST.get('res_p', None)
                client = request.POST.getlist('res_c[]', None)
                client = ','.join(client)
                result = incdata_obj.getMspClientTicketsData(partner, client)
                Final = displayTree(result)
                jsonData = simplejson.dumps({'finalTree': Final})
                return HttpResponse(jsonData, content_type="application/json")
            else:
                jsonData = simplejson.dumps({'finalTree': Final})
                return HttpResponse(jsonData, content_type="application/json")
    except Exception as e:
        import logging
        log = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in getPatcliCount is -> %s' % str(e))
        return HttpResponse({}, content_type="application/json")


def departmentNocCacheCounts(request):
    Final = []
    nocT = request.POST.get('nocT')
    if nocT != '':
        temp = mem_cache.get('Noc_Tree'+env, 'has expired')
        if temp.has_key(int(nocT)):
            typeIdWise = temp[int(nocT)]
        else:
            typeIdWise = {}
    else:
        typeIdWise = mem_cache.get('DeptResult0'+env, 'has expired')
    Final = displayTree(typeIdWise)
    jsonData = simplejson.dumps({'finalTree': Final})
    return HttpResponse(jsonData, content_type="application/json")


def slamPaginations(request):
    post = request.POST
    offset = post.getlist('offset', False)
    offset = offset[0]
    offset = int(offset)
    lfSting = 'LIMIT 50 OFFSET ' + str(offset)
    sql = post.getlist('sql', False)
    sql = sql[0].replace("\n", "")
    finalQuery = ''
    iters = 1
    if "UNION" in sql:
        queries = sql.split('UNION')
        for query in queries:
            res = query.split('LIMIT')
            if iters == 1:
                finalQuery = finalQuery + str(res[0]) + ' repStr ) UNION '
            else:
                finalQuery = finalQuery + str(res[0]) + ' repStr )  '
            iters = iters + 1

    else:
        res = sql.split('LIMIT')
        finalQuery = finalQuery + str(res[0]) + ' repStr )'

    queryResult = finalQuery.replace('repStr', lfSting)
    customFields = post.getlist('customColums', False)

    customFilesdko = customFields[0].split(',')

    result = tktbrwsr_obj.ticketBrowserResults(queryResult)

    data = prepareTicketBrowserResults(result, customFilesdko)
    jsonData = simplejson.dumps({'finalData': data, 'customFields': customFilesdko})
    return HttpResponse(jsonData, content_type="application/json")


def autoRefresh(request):
    post = request.POST
    sql = post.getlist('sql', False)
    sql = sql[0].replace("\n", "")
    """offset = post.getlist('offset',False)
    
    finalQuery = []
    if "UNION" in sql:
        queries = sql.split('UNION')
        for query in queries :
            tempList = query.split('OFFSET')
            tempStr = str(tempList[0])
            tempStr += ' OFFSET '+str(offset[0])+')'
            finalQuery.append(tempStr)
    sql = ' UNION '.join(finalQuery)
    """
    customFields = post.getlist('customColums', False)
    customFilesdko = customFields[0].split(',')
    result = tktbrwsr_obj.ticketBrowserResults(sql)
    data = prepareTicketBrowserResults(result, customFilesdko)
    jsonData = simplejson.dumps({'finalData': data, 'customFields': customFilesdko})
    return HttpResponse(jsonData, content_type="application/json")


def excelDownload(request):
    response = {}
    post = request.POST.copy()
    if 'uName' in request.session:
        uid = request.session['uId']
        post['display_template'] = 0
        post['templateId'] = 'null'
        post['templatename'] = str(uid) + '_' + post['templatename'] + str(datetime.utcnow().strftime('%Y%m%d_%H%M%S'))

        finalResult = dict(post)

        templateId = tktbrwsr_obj.saveTemplate(finalResult, uid)
        nowTime = str(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        uName = str(request.session['uName'])
        sql = 'insert into nnc_sch_jobs (JobName,reportType,scheduleType,IsPublic,templateId,createdDate,createdBy,emailIds) values('
        sql += "'" + str(post['templatename']) + "','TB','RunNow',1," + str(templateId) + ",'" + str(
            nowTime) + "'," + str(uid) + ", '" + str(uName) + "')"

        cursor = connections['rosterWrite'].cursor()
        cursor.execute(sql)
        schedularJobId = cursor.lastrowid
        cursor.close()

        response['status'] = 'success'
        response['templateId'] = templateId
        response['schedularJobId'] = schedularJobId
    else:
        response['status'] = 'fail'
        response['message'] = 'Session Expired!'

    jsonData = simplejson.dumps(response)
    return HttpResponse(jsonData, content_type="application/json")


def getWidgetTickets(request):
    searchAttribute = '='
    dept = request.POST['departments']
    wdg = int(request.POST['wdg_type'])
    if len(dept.split(',')) > 1:
        searchAttribute = 'IN'
    """
    if wdg == 1:
        sql = "select ticketid from incident_data where priorityid = 8 and resol_due >= 0 and resol_due <= 1800 and statusid not in (5 ,3,17,20,32 ,41) and  deptid " + searchAttribute + " (" + dept + ")"
    elif wdg == 2:
        sql = "select ticketid from incident_data where statusid in (1,7,12,18,19,21,22,23) and priorityid = 8 and unix_timestamp(now())-lastactivity > 1800 and  deptid " + searchAttribute + " (" + dept + ")"
    elif wdg == 3:
        sql = 'SELECT ticketid as count from incident_data i Join swcustomfieldvalues scfv where i.ticketid = scfv.typeid and scfv.customfieldid=12 and scfv.fieldvalue like "%-%-% %:%:%" and CONVERT_TZ(scfv.fieldvalue,"US/Pacific","UTC") between now() and date_add(now(), interval 30 minute)  and i.statusid not in (5 ,3 ,17 ,20 ,32 ,41) and i.deptid ' + searchAttribute + ' (' + dept + ')';
    elif wdg == 4:
        sql = "select i.ticketid  from incident_data i join swcustomfieldvalues scfv on i.ticketid = scfv.typeid where i.statusid = 9  and scfv.customfieldid = 3 and fieldvalue = ' ' and i.deptid " + searchAttribute + " (" + dept + ")"
    elif wdg == 5:
        sql = "select i.ticketid from incident_data i join swtickets st on st.ticketid=i.ticketid where unix_timestamp(now())-i.lastactivity>1800 and i.statusid not in  (5 ,3,17 ,20,32,41) and st.ownerstaffid=0 and i.deptid " + searchAttribute + " (" + dept + ")"
    elif wdg == 6:
        sql = "select ticketid from incident_data where statusid=1 and unix_timestamp(now())-lastactivity>3600 and deptid " + searchAttribute + " (" + dept + ")"
    elif wdg == 7:
        sql = "select ticketid from incident_data where statusid=19 and unix_timestamp(now())-lastactivity>1800 and deptid " + searchAttribute + " (" + dept + ")"
    elif wdg == 8:
        sql = "select ticketid from incident_data where priorityid = 9 and resol_due >= 0 and resol_due <= 1800 and statusid not in (5 ,3,17,20,32 ,41) and  deptid " + searchAttribute + " (" + dept + ")"
    elif wdg == 9:
        sql = "select ticketid from incident_data where statusid in (1,7,12,18,19,21,22,23) and priorityid = 9 and unix_timestamp(now())-lastactivity > 1800 and  deptid " + searchAttribute + " (" + dept + ")"
    cursor = connections['ticketRead'].cursor()
    cursor.execute(sql)
    tickets = cursor.fetchall()
    cursor.close()
    """
    tickets = incdata_obj.getWidgetTickets_SM(searchAttribute, dept, wdg)
    data = ""
    for i in tickets:
        data += str(i[0]) + ","
    return HttpResponse(data[0:len(data) - 1])


def testUl(request, pk):
    now = datetime.now()
    formtdateUnix = int(time.mktime(datetime.strptime(str(pk) + ' 02:30:00', "%m-%d-%Y %H:%M:%S").timetuple()))
    todateUnix = int(time.mktime(datetime.strptime('06/17/2016  23:59:59', "%m/%d/%Y %H:%M:%S").timetuple()))
    data = {}
    data['fomc'] = formtdateUnix
    data['totime'] = todateUnix
    data['now'] = now

    return render_to_response('date.html', {'data': data}, context_instance=RequestContext(request))


@register.filter('get_value_from_dict')
def get_value_from_dict(dict_data, key):
    """
    usage example {{ your_dict|get_value_from_dict:your_key }}
    """
    if key:
        return dict_data.get(key)


@register.filter('getResolutionSLAStyle')
def getResolutionSLAStyle(dict_data):
    data = dict_data.get('SLA Resolution')
    if data:
        return data.get('style')
    else:
        return ''


def getTicketBreachCountsrefresh(request):
    """ Breach tickets counts """
    result = 0
    try:
        if request.method == "POST":
            post = request.POST
            ticketSLACount = post.getlist('ticketSla', False)
            resSLAList = ','.join(ticketSLACount)
            resSLAList = resSLAList.split(',')
            countQuerys = post.getlist('countQuerys', False)
            if len(countQuerys) > 0:
                countQuerys = countQuerys[0]
                ticketSla = post.getlist('myTicketsCount', '')
                if ticketSla != [u'']:
                    ticketSla = int(ticketSla[0])
                else:
                    ticketSla = 1
                result = incdata_obj.getCountOfIncidentTicketsBySLA(countQuerys, resSLAList, ticketSla)

            else:
                raise ValueError("Data is not comming for  breached Counts ")
    except ValueError as ev:
        log.info(ev)
    jsonData = simplejson.dumps({'results': result})
    return HttpResponse(jsonData, content_type="application/json")


def getCacheInfo(request):
    cacheData = {}
    if request.method == "GET":
        key = request.GET['key']
        # cacheData = mem_cache.get(str(key))
        columns = customcols_obj.getSlamCustomColumns()
        # jsonData = simplejson.dumps({'cacheData':cacheData})
        return render_to_response('test.html', {'cacheData': cacheData}, context_instance=RequestContext(request))


def massUpdateView(request):
    ticketId = request.GET['tikIds']
    ticketModelObj = CommonTicketModel()
    predefReplies = ticketModelObj.predefinedReplies()
    knowledgebase = ticketModelObj.getKnowledgeBase()
    kbarticles = ticketModelObj.getKbArticles()
    swStaff = nrstaff_obj.getSwStaffByRoster()
    departments = Swdepartments.objects.using('ticketRead').only('title', 'departmentid').order_by('title')
    tktstatus = swtktstatus_obj.getNewStatus()
    priorities = Swticketpriorities.objects.using('ticketRead').only('display_text', 'priorityid').order_by(
        'priorityid')
    randomString = ''.join(choice(ascii_uppercase) for i in range(8))
    data = {
        'staff': swStaff,
        'dept': departments,
        'status': tktstatus,
        'priorty': priorities,
        'ticketId': ticketId
    }
    return render_to_response('massUpdate.html',
                              {'data': data, 'PredefinedReplies': predefReplies, 'knowledgebase': knowledgebase,
                               'kbarticles': kbarticles, 'randomString': randomString},
                              context_instance=RequestContext(request))


def getPredefinedReplyData(request):
    predefid = request.POST.get('predefid')
    ticketModelObj = CommonTicketModel()
    predefineddata = ticketModelObj.getPredefinedReplyData(predefid)
    return HttpResponse(predefineddata)


def getKbaReplyData(request):
    kbaid = request.POST.get('kbaid')
    ticketModelObj = CommonTicketModel()
    kbadata = ticketModelObj.getKbaReplyData(kbaid)
    return HttpResponse(kbadata)


def uploadAttachment(request):
    attDynamic = request.POST.get('attDynamic')
    handle_uploaded_file(request.FILES['uploadFile'], attDynamic.encode('utf-8'))
    return HttpResponse(request.FILES['uploadFile'].name)


def handle_uploaded_file(upfile, attDynamic):
    # attUrl = str(configobj.getCommConfigValue(configobj.attUrl))
    rootPath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    attPath = rootPath.rsplit('/', 1)
    if attDynamic:
        attUrl = str(attPath[0]) + '/static/files/' + str(attDynamic.encode('utf-8')) + '/'
        if not os.path.exists(attUrl):
            os.makedirs(attUrl)
            os.chmod(attUrl, 777)
    destination = open(attUrl + str(upfile.name), 'wb+')
    for chunk in upfile.chunks():
        destination.write(chunk)
    destination.close()


def deleteAttached(request):
    if request.method == 'POST':
        fname = str(request.POST['fname'].encode('utf-8'))
        attDynamic = request.POST.get('attDynamic')
        # attUrl = str(configobj.getCommConfigValue(configobj.attUrl))
        rootPath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        attPath = rootPath.rsplit('/', 1)
        attUrl = str(attPath[0]) + '/static/files/' + str(attDynamic.encode('utf-8')) + '/'
        os.remove(attUrl + fname)
        return HttpResponse('deleted')


def massUpdateSave(request):
    post = request.POST
    url = comObj.ticketingUrls() + "/organizations/844/ticketmassupdate"
    apiData = {}

    apiData['tId'] = post['ticketId'] if len(post['ticketId']) > 0 else ''
    if len(post['status']) > 0:
        apiData['tsId'] = int(post['status'])
    if len(post['deptments']) > 0:
        apiData['deptId'] = int(post['deptments'])
    if len(post['priorty']) > 0:
        apiData['pId'] = int(post['priorty'])
    if len(post['owners']) > 0:
        apiData['osId'] = int(post['owners'])
    apiData['stId'] = request.session['swstaffId']
    apiData['email'] = request.session['uName']
    if len(post['postContent']) > 0:
        apiData['content'] = post['postContent'].replace('<br />', '')
    if len(post['timeworkedout']) > 0:
        apiData['wTime'] = int(post['timeworkedout'])
    if len(post['billabletime']) > 0:
        apiData['bTime'] = int(post['billabletime'])

    fileAtt = request.POST.getlist('attachments[]', False)
    attachFiles = {}
    if fileAtt:
        attDynamic = str(request.POST.get('attDynamic', False))
        rootPath = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        attPath = rootPath.rsplit('/', 1)
        attUrl = str(attPath[0]) + '/static/files/' + attDynamic + '/'
        for att in fileAtt:
            if att:
                attachFiles['attchmnt[' + str(fileAtt.index(att)) + ']'] = open(attUrl + str(att), 'rb')

    token = comObj.getAuthToken('ticket')
    resHed = {'TOKEN': token}


    apiResponce = requests.post(url, data=apiData, files=attachFiles, headers=resHed,verify = False).json()


    html = ''
    if apiResponce['HTTP Response Code'] == '200 OK':
        html = 'success'
    jsonData = simplejson.dumps({'results': html})
    return HttpResponse(jsonData, content_type="application/json")
