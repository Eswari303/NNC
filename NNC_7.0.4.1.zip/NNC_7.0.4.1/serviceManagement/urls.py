"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """

'''
Created on Jan 2, 2016

@author: pradeep.thatavarthi
'''
import serviceManagement
"""NNCPortal URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Import the include() function: from django.conf.urls import url, include
    3. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import url
import serviceManagement.views.serviceManagementView
import serviceManagement.views.scheduleTemplatesView
# from django.contrib import admin
# from django.conf.urls import include, url, patterns, slamResults

urlpatterns = [
    url(r'^index/$',serviceManagement.views.serviceManagementView.loadMockup),
    url(r'^channelAjax$',serviceManagement.views.serviceManagementView.getChannelAjax),
    url(r'^nocAjax$',serviceManagement.views.serviceManagementView.getNocAjax),
    url(r'^partnerAjax$',serviceManagement.views.serviceManagementView.getPatClients),  
    url(r'^getTemplates/$',serviceManagement.views.serviceManagementView.getTemplateList),
    url(r'^delete/$',serviceManagement.views.serviceManagementView.deleteTemplate),
    url(r'^deviceCount/$',serviceManagement.views.serviceManagementView.deviceCacheCounts), 
    url(r'^deptCount/$',serviceManagement.views.serviceManagementView.departmentCacheCounts),
    url(r'^slamResults/$',serviceManagement.views.serviceManagementView.slamResults),
    url(r'^showSchTemp/$',serviceManagement.views.scheduleTemplatesView.showSchTemp),
    url(r'^addSchTemp/$',serviceManagement.views.scheduleTemplatesView.addSchTemp),
    url(r'^addNewTemp/$',serviceManagement.views.scheduleTemplatesView.addNewTemp),
    url(r'^clientAjax$',serviceManagement.views.serviceManagementView.getClientAjax),
    url(r'^loadTemplate$',serviceManagement.views.serviceManagementView.loadTemplate),
    url(r'^loadSchTemp/$',serviceManagement.views.scheduleTemplatesView.loadSchTemp),
    url(r'^logTest/$',serviceManagement.views.scheduleTemplatesView.logfiletesting),
    url(r'^emailSearch/$',serviceManagement.views.scheduleTemplatesView.emailSearch),
    url(r'^unsubscribeJob$',serviceManagement.views.scheduleTemplatesView.unsubscribeJob),
    url(r'^saveOrUpdTmp/$',serviceManagement.views.serviceManagementView.saveOrUpdateTemplate),
    url(r'^pcCountAjax$',serviceManagement.views.serviceManagementView.getPatcliCount),
    url(r'^deptNocCount/$',serviceManagement.views.serviceManagementView.departmentNocCacheCounts),
    url(r'^pagination/$',serviceManagement.views.serviceManagementView.slamPaginations),
    url(r'^excelDownload/$',serviceManagement.views.serviceManagementView.excelDownload),
    url(r'^autoRefresh/$',serviceManagement.views.serviceManagementView.autoRefresh),
    url(r'^TemplateList/$',serviceManagement.views.serviceManagementView.getTemplateListDetail),
    url(r'^getwidgetTickets/$',serviceManagement.views.serviceManagementView.getWidgetTickets),
    url(r'^datesissue/(?P<pk>[0-9A-Za-z-]+)$',serviceManagement.views.serviceManagementView.testUl),
    url(r'^ticketCountRefresh/$',serviceManagement.views.serviceManagementView.getTicketBreachCountsrefresh),
    url(r'^massUpdateView/$',serviceManagement.views.serviceManagementView.massUpdateView),
    url(r'^predefinedReplyData/$',serviceManagement.views.serviceManagementView.getPredefinedReplyData),
    url(r'^kbaReplyData/$',serviceManagement.views.serviceManagementView.getKbaReplyData),
    url(r'^addattachment$', serviceManagement.views.serviceManagementView.uploadAttachment),
    url(r'^delattachment$',serviceManagement.views.serviceManagementView.deleteAttached),
    url(r'^massUpdate$',serviceManagement.views.serviceManagementView.massUpdateSave),
    
]

