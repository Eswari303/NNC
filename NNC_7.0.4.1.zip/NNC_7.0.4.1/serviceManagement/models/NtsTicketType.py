"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import models,connections
from django.core.cache import caches
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)

class Ntstickettype(models.Model):
    typeid = models.AutoField(primary_key=True)
    typename = models.CharField(max_length=45)
    
    class Meta:
        db_table = 'ntstickettype'
        app_label = 'serviceManagement'
    
    def getAllTicketTypes(self):
        ticketType = mem_cache.get('ticketType'+env)
        if not ticketType:
            cursor = connections['ticketRead'].cursor()
            sql = "select typeid, typename from ntstickettype"
            cursor.execute(sql)
            result = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('ticketType'+env,result,86400)
        return ticketType
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
