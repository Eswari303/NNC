"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import models,connections

class Swstaff(models.Model):
    staffid = models.AutoField(primary_key=True)
    fullname = models.CharField(max_length=100)
    username = models.CharField(max_length=30)
    password = models.CharField(max_length=32)
    staffgroupid = models.IntegerField()
    email = models.CharField(max_length=150)
    mobilenumber = models.CharField(max_length=20)
    lastvisit = models.IntegerField()
    lastvisit2 = models.IntegerField()
    lastactivity = models.IntegerField()
    enabledst = models.SmallIntegerField()
    startofweek = models.IntegerField()
    pmunread = models.IntegerField()
    groupassigns = models.SmallIntegerField()
    enablepmalerts = models.SmallIntegerField()
    enablepmjsalerts = models.SmallIntegerField()
    ticketviewid = models.IntegerField()
    timezonephp = models.CharField(max_length=100)
    
    class Meta:
        db_table = 'swstaff'
        app_label = 'serviceManagement'
        
    def ownersStaffid(self):
        cursor = connections['ticketRead'].cursor()
        sql = 'SELECT staffid, fullname FROM swstaff  WHERE staffgroupid != 41 ORDER BY fullname'
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        SwaffIdSet = {}
        for i in result:
            SwaffIdSet[i['staffid']] = i['fullname']
        return SwaffIdSet
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]