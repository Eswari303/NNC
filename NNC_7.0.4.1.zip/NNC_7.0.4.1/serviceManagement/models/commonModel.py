"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import connections
from django.core.cache import caches
from django.shortcuts import HttpResponse
from _collections import defaultdict
from operator import itemgetter
from datetime import datetime
from NNCPortal.commonMethods import commonMethods
from NNCPortal.commonModels.Swticketstatus import Swticketstatus
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
import time
import re
import math
import os

comObj = commonMethods()
swtktstatus_obj = Swticketstatus()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)


class CommonServiceModel(object):   
    def getpartners(self,nocid = 0):
        cursor = connections['ticketRead'].cursor()
        if nocid :
            nocIDPartners = 'nocID-'+str(nocid)+'partner'+env
            partners = mem_cache.get(nocIDPartners)
            if not partners :     
                sql = 'select distinct t.mspid, t.mspname from ntsmsps t join ntsmspclients ntsc on t.mspid = ntsc.mspid where ntsc.status = 1 and ntsc.nocid = '+str(nocid)+' order by t.mspname'
                cursor.execute(sql)
                partners = comObj.dictfetchall(cursor)
                mem_cache.set('nocID-'+str(nocid)+'partner'+env, partners, 86400)
        else :
            partners = mem_cache.get('nocID-'+str(nocid)+'partner'+env)
            if not partners :         
                sql = 'select distinct t.mspid, t.mspname from ntsmsps t join ntsmspclients ntsc on t.mspid = ntsc.mspid where ntsc.status = 1 order by t.mspname'
                cursor.execute(sql)
                partners = comObj.dictfetchall(cursor)
                mem_cache.set('nocID-'+str(nocid)+'partner'+env, partners, 86400)
        cursor.close()
        return partners
    
    def getClients(self, nocid=0):
        cursor = connections['ticketRead'].cursor()
        if nocid :
            clients = mem_cache.get('nocID-' + str(nocid) + 'clients'+env)
            if not clients :        
                sql = 'select mspclientid, clientname from ntsmspclients where status = 1 and nocid = '+str(nocid)+' order by clientname'
                cursor.execute(sql)
                clients = comObj.dictfetchall(cursor)
                mem_cache.set('nocID-' + str(nocid) + 'clients'+env, clients, 86400)
        else :     
            clients = mem_cache.get('nocID-' + str(nocid) + 'clients'+env)
            if not clients:   
                sql = 'select mspclientid, clientname from ntsmspclients where status = 1 order by clientname'
                cursor.execute(sql)
                clients = comObj.dictfetchall(cursor)
                mem_cache.set('nocID-' + str(nocid) + 'clients'+env, clients, 86400)
        cursor.close()
        return clients
    
    def getClientsofPat(self,pid):
        cursor = connections['ticketRead'].cursor()
        clients =[]
        if pid :
            if pid.find(',') == -1:
                clients = mem_cache.get(pid)
            if not clients :        
                sql = 'select msp.mspname,cli.clientname,cli.mspid,cli.mspclientid from ntsmspclients cli JOIN ntsmsps msp ON (cli.mspid = msp.mspid) where cli.status = 1 and  cli.mspid IN( '+str(pid)+') order by clientname';
                cursor.execute(sql)
                clients = comObj.dictfetchall(cursor)
                mem_cache.set(pid, clients, 86400)
        else :
            clients = mem_cache.get('all')
            if not clients :       
                sql = 'select msp.mspname,cli.clientname,cli.mspid,cli.mspclientid from ntsmspclients cli JOIN ntsmsps msp ON (cli.mspid = msp.mspid) where cli.status = 1 order by clientname';
                cursor.execute(sql)
                clients = comObj.dictfetchall(cursor)
                mem_cache.set('all', clients, 86400)
        cursor.close()
        return clients
    
    
    def getChannelPartners(self,channelId = 0):
        cursor = connections['ticketRead'].cursor()
        if channelId :
            partners = mem_cache.get('channelID-'+str(channelId)+'partners'+env)
            if not partners :   
                sql = 'select distinct t.mspid, t.mspname from ntsmsps t join ntsmspclients ntsc on t.mspid = ntsc.mspid where ntsc.status = 1 and ntsc.channel_id = '+str(channelId)+' order by t.mspname'
                cursor.execute(sql)
                partners = comObj.dictfetchall(cursor)
                mem_cache.set('channelID-'+str(channelId)+'partners'+env, partners, 86400)
        else :
            partners = mem_cache.get('channelID-'+str(channelId)+'partners'+env)
            if not partners :         
                sql = 'select distinct t.mspid, t.mspname from ntsmsps t join ntsmspclients ntsc on t.mspid = ntsc.mspid where ntsc.status = 1 order by t.mspname'
                cursor.execute(sql)
                partners = comObj.dictfetchall(cursor)
                mem_cache.set('channelID-'+str(channelId)+'partners'+env, partners, 86400)
        cursor.close()
        return partners
    
    
    def getChannelClients(self,channelId = 0):
        cursor = connections['ticketRead'].cursor()
        if channelId :
            clients = mem_cache.get('channelID-' + str(channelId) + 'clients'+env)
            if not clients :         
                sql = 'select mspclientid, clientname from ntsmspclients where status = 1 and nocid = '+str(channelId)+' order by clientname'
                cursor.execute(sql)
                clients = comObj.dictfetchall(cursor)
                mem_cache.set('channelID-' + str(channelId) + 'clients'+env, clients, 86400)
        else :         
            clients = mem_cache.get('channelID-' + str(channelId) + 'clients'+env)
            if not clients:
                sql = 'select mspclientid, clientname from ntsmspclients where status = 1 order by clientname'
                cursor.execute(sql)
                clients = comObj.dictfetchall(cursor)
                mem_cache.set('channelID-' + str(channelId) + 'clients'+env, clients, 86400)
        cursor.close()
        return clients
    
    def getUserTemplatesAndPublicTemplates (self, userId=0, reportType=''):
        cursor = connections['rosterRead'].cursor()
        sql = 'SELECT templateid, templatename, templatetype, templateuserid, lastdate FROM ticketbrowser_templates'
        sql += ' WHERE ((templatetype = "1" AND display_template = 1 AND templateuserid ='+str(userId)+')'
        sql += ' OR (templatetype = "0"))'
        if reportType != '':
            sql += ' AND reportType ="'+reportType+'"'
        
        if reportType == 'TB':
            sql += " AND templatename NOT IN ('My Tickets','My Team Tickets')"
               
        sql += ' order by templatename'
       
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    '''Below methods regarding Devices informatin in Cache data'''
    def getIncidentMspClientTicketQuery(self,clients,partner):       
        cursor = connections['ticketRead'].cursor()
        mspCond = ''
        sql =''
        ClientCond = ''
        ClientCond = " and cid in ("+ str(clients) +")" if (clients and clients !='' and clients != None) else ''
        mspCond = " and mid = ("+partner+") " if (partner and  partner!='' and partner!=None) else ''
        sql = "select count(ticketid) as count,sws.statustype,sws.title as status,sws.ticketstatusid,incident.deptid,swd.title as dept from incident_data incident join swdepartments swd on (swd.departmentid = incident.deptid) join swticketstatus sws on(sws.ticketstatusid = incident.statusid) where 1=1 "+mspCond + ClientCond+" and incident.deptid not in (0,1,2) group by incident.statusid,incident.deptid order by swd.title,sws.statustype";
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result

    "Ticket counts for all devices"   
    def getIncidentDeviceTypedata(self):
        nocCond =''
        nocCond = 'where devicetypeid != 0 and incident.deptid not in (0,1,2) group by devicetype,incident.statusid'
        sql = "select count(incident.ticketid) as count,devicetype,devicetypeid,sws.title as status,sws.ticketstatusid,sws.statustype "
        sql += "from incident_data incident join swticketstatus sws on(sws.ticketstatusid = incident.statusid) "
        sql += ""+nocCond+" order by devicetype,sws.statustype"
       
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    "Ticket counts based on ticket type for all devices"
    def getByTicketTypeDeviceCountQuery(self):
        nocCond =''
        nocCond = 'where devicetypeid != 0 and incident.deptid not in (0,1,2)  group by nts.typeid,incident.statusid,devicetype'
        sql = "select count(incident.ticketid) as count,nts.typeid,devicetype,devicetypeid,sws.title as status,sws.ticketstatusid,sws.statustype "
        sql += "from incident_data incident join swticketstatus sws on(sws.ticketstatusid = incident.statusid) "
        sql += "join ntsclienttickets nts on (nts.ticketid = incident.ticketid) "+nocCond+" order by nts.typeid,devicetype,sws.statustype"
       
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    "Ticket counts for all departments"
    def getPrepareNocDeptQuery(self):
        cursor = connections['ticketRead'].cursor()
        sql = 'select count(ticketid) as count,sws.statustype,sws.title as status,sws.ticketstatusid,incident.deptid,swd.title as dept '
        sql += 'from incident_data incident '
        sql += 'join swdepartments swd on (swd.departmentid = incident.deptid) '
        sql += 'join swticketstatus sws on (sws.ticketstatusid = incident.statusid) '
        sql += 'where 1=1 and swd.departmentid not in (0,1,2) '
        sql += 'group by incident.statusid,swd.departmentid '
        sql += 'order by swd.title,sws.statustype'
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    ''' Department wise staff list '''
    def getSwStaffByRoster(self):
        sql = "SELECT DISTINCT(staff.id), staff.staff_fname, staff.staff_lname, concat(staff.staff_fname,' ', staff.staff_lname) as staff_fullname, staff.employee_id, addept.dept_name, rosterdept.dept_name AS roster, staff.user_name as samaccountname, staff.staff_email, staff.swstaff_id FROM nr_staff staff LEFT JOIN nr_departments addept ON (addept.id = staff.dept_id) LEFT JOIN nr_departments rosterdept ON (rosterdept.id = staff.roster_id) WHERE staff.is_active = 1 AND staff.is_found = 1 AND swstaff_id > 0 ORDER BY roster,staff.staff_fname, staff.staff_lname"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    def getSlamCustomColumns(self):
        columns = {}
        #columns = mem_cache.get('slamCustomColumns')
        if not columns:
            cursor = connections['rosterRead'].cursor()
            sql = "SELECT id,column_name FROM sla_mgnt_custom_columns WHERE parent_id= 0 AND is_display = 1"
            cursor.execute(sql)
            parentColumnsResult = comObj.dictfetchall(cursor)
            for parentColumns in parentColumnsResult:
                sql = "SELECT SQL_CALC_FOUND_ROWS column_name FROM sla_mgnt_custom_columns WHERE parent_id= "+str(parentColumns['id'])+" AND  is_default_field= 0  AND is_display = 1"
                cursor.execute(sql)
                childColumnsResult = comObj.dictfetchall(cursor)
                childColumnsDict = {}
                for childColumns in childColumnsResult:
                    childColumnsDict[childColumns['column_name']] = childColumns['column_name']
                
                if childColumnsDict:
                    columns[parentColumns['column_name']] = childColumnsDict                
            
            dbCustomFields = self.getCustomFields()
            for customField in dbCustomFields:
                if columns.has_key(customField['custom_field_group']):
                    columns[str(customField['custom_field_group'])]['cust_fld_'+str(customField['customfieldid'])] = customField['title']
                else:
                    columns[customField['custom_field_group']] = {}
                    columns[str(customField['custom_field_group'])]['cust_fld_'+str(customField['customfieldid'])] = customField['title']                    
                    
            #mem_cache.set('slamCustomColumns', columns, 86400)
            cursor.close()
        return columns
    
    def getCustomCoulmnFields(self, parent_id = 0, columns = defaultdict(dict), parent_column=''):
        cursor = connections['rosterRead'].cursor()
        sql = "SELECT * FROM sla_mgnt_custom_columns WHERE parent_id= "+str(parent_id)+" AND  is_default_field= 0  AND is_display = 1"
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        for res in result:
            sql = "SELECT COUNT(*) as count FROM sla_mgnt_custom_columns WHERE parent_id="+str(res['id'])+" AND  is_default_field= 0"
            cursor.execute(sql)
            count = comObj.dictfetchall(cursor)
            for cnt in count:
                childColumnsCount = cnt['count']
            if childColumnsCount > 0:
                columns = self.getCustomCoulmnFields(res['id'], columns, res['column_name'])
                
            else:
                if parent_column != '':
                    columns[parent_column][res['column_name']] = res['column_name'];
                else:
                    columns = res['column_name']
        cursor.close()
        return columns
    
    def getCustomFields(self):
        sql = "SELECT swcustfldgrp.title as custom_field_group, swcustfld.customfieldid, swcustfld.title FROM swcustomfields AS swcustfld JOIN swcustomfieldgroups AS swcustfldgrp ON swcustfldgrp.customfieldgroupid=swcustfld.customfieldgroupid WHERE swcustfld.title != 'LPI Ticket ID' ORDER BY swcustfldgrp.title, swcustfld.title"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    def getDefaultCustomFields(self, columns = defaultdict(dict)):
        defaultCustomFields = mem_cache.get('defaultCustomFields')
        if not defaultCustomFields:
            sql = "SELECT * FROM sla_mgnt_custom_columns_old WHERE is_default_field= 1 and is_display = 1 ORDER BY display_order"
            cursor = connections['rosterRead'].cursor()
            cursor.execute(sql)
            defaultCustomFields = comObj.dictfetchall(cursor)
            mem_cache.set('defaultCustomFields', defaultCustomFields, 86400)
       
        return defaultCustomFields
    
    def getAllServiceTypes (self):
        cursor = connections['ticketRead'].cursor()
        sql = 'SELECT DISTINCT name as service_type FROM ntsviewdevice_service_map ORDER BY name ASC'
       
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    def getAllServiceLevels (self):
        cursor = connections['mspDB'].cursor()
        sql = 'select DISTINCT service_level from sku ORDER BY service_level ASC'
       
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    def showPartnerClient (self):
        cursor = connections['ticketRead'].cursor()
        sql = 'select msp.mspname,cli.mspclientid,cli.clientname,cli.mspid from ntsmspclients cli JOIN ntsmsps msp ON (cli.mspid = msp.mspid) where cli.status = 1  order by clientname'       
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    def getDeviceTypes (self):
        cursor = connections['ticketRead'].cursor()
        sql = 'select id, path, devicetype from ntsdevice_type order by path'       
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    def getDevices (self, client_id = ''):
        cursor = connections['ticketRead'].cursor()
        condition = ''
        if client_id != '':
            condition = " AND client_id IN ("+str(client_id)+") "
       
            sql = "select id, device_name from ntsmspdevicedata where (state IS NULL OR state IN('','active','deleted-active')) "+condition+" order by device_name"
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
        else:
            result = {}
        return result
    
    def getNtsstatussla(self,statusId =0):
        cursor = connections['ticketRead'].cursor()
        if statusId > 0 :
            sql = "SELECT ticketstatusid, sla_value FROM ntsstatussla WHERE ticketstatusid ="+statusId+" ORDER BY ticketstatusid"
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
        else :
            sql = "SELECT ticketstatusid, sla_value FROM ntsstatussla ORDER BY ticketstatusid";
            cursor.execte(sql)
            result = comObj.dictfetchall(cursor)
            
        cursor.close()
        return result
        
    def getTemplateDetails (self, templateId):
        cursor = connections['rosterRead'].cursor()
        result = {}
        if templateId != '':
            sql = "select * from ticketbrowser_templates where templateid = "+str(templateId)
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
        return result
    def unixtime(self,thresholdVlaue):
        cursor = connections['rosterRead'].cursor()
        if thresholdVlaue == "LW":
            sql = "select fn_Dates('LW','S') as one ,fn_Dates('LW','E') as two"
        if thresholdVlaue == "LWD":
            sql = "select fn_Dates('LWD','S') as one ,fn_Dates('LWD','E') as two"
        if thresholdVlaue == "LM":
            sql = "select fn_Dates('LM','S') as one ,fn_Dates('LM','E') as two"
        if thresholdVlaue == "LMD":
            sql = "select fn_Dates('LMD','S') as one ,fn_Dates('LMD','E') as two"
        if thresholdVlaue == "LQ":
            sql = "select fn_Dates('LQ','S') as one ,fn_Dates('LQ','E') as two"
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return [result[0]["one"], result[0]["two"]]
    
    def thresHoldUnixtimestam(self, thresholdVlaue):
        cursor = connections['ticketRead'].cursor()
        sql = "select UNIX_TIMESTAMP(DATE_SUB(NOW(),INTERVAL 100 DAY)) as ThresHoldUnix_timestamp"
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
        
    def ticketBrowserResults(self,sql):
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result

    " ticket counts for all departments based on each tickettype"
    def getByTicketTypeDeptCountQuery(self):
        cursor = connections['ticketRead'].cursor()
        sql = "select count(incident.ticketid) as count,nts.typeid,sws.statustype,sws.title as status,sws.ticketstatusid,incident.deptid,swd.title as dept "  
        sql += "from incident_data incident join swdepartments swd on (swd.departmentid = incident.deptid) "
        sql += "join swticketstatus sws on (sws.ticketstatusid = incident.statusid) "  
        sql += "join ntsclienttickets nts on (nts.ticketid = incident.ticketid)  " 
        sql += "where 1=1  and swd.departmentid not in (0,1,2)  group by nts.typeid,incident.statusid,swd.departmentid  order by nts.typeid,swd.title,sws.statustype"
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    "tickets counts based on msp,client "
    def getMspClientTicketsData(self,partner,clients):
        newStatues = swtktstatus_obj.getNewStatus()
        StatusTypes = comObj.getGroupStausName()
        Query = ''; result = {}; data= {};k=0;
        Query = self.getIncidentMspClientTicketQuery(clients, partner)
        if(Query != ''):
            for res in Query:
                if not data.has_key(res['deptid']):
                    data.setdefault(res['deptid'],{})
                data[res['deptid']]['title'] = res['dept'];
                if res['statustype'] != 3:
                    if data[res['deptid']].has_key('TotalCount'):
                        data[res['deptid']]['TotalCount'] += res['count']
                    else:
                        data[res['deptid']].setdefault('TotalCount', defaultdict(int))
                        data[res['deptid']]['TotalCount'] = res['count']
                res['statustype'] = StatusTypes[res['ticketstatusid']];
                if not data[res['deptid']].has_key('statusType'):
                    data[res['deptid']].setdefault('statusType',{})
                if not data[res['deptid']]['statusType'].has_key(res['statustype']):
                    data[res['deptid']]['statusType'].setdefault(res['statustype'],{})
                if data[res['deptid']]['statusType'][res['statustype']].has_key('statusCount'):
                    data[res['deptid']]['statusType'][res['statustype']]['statusCount'] += res['count'];
                else:
                    data[res['deptid']]['statusType'][res['statustype']].setdefault('statusCount',defaultdict(int));
                    data[res['deptid']]['statusType'][res['statustype']]['statusCount'] = res['count'];
                if  not data[res['deptid']]['statusType'][res['statustype']].has_key('status'):
                    data[res['deptid']]['statusType'][res['statustype']].setdefault('status',{})
                data[res['deptid']]['statusType'][res['statustype']]['status'].setdefault(k,{})
                data[res['deptid']]['statusType'][res['statustype']]['status'][k]['statusid'] = res['ticketstatusid'];
                data[res['deptid']]['statusType'][res['statustype']]['status'][k]['statusname'] = newStatues[res['ticketstatusid']];
                data[res['deptid']]['statusType'][res['statustype']]['status'][k]['count'] = res['count'];
                k = k+1
        return data
    
    "ticket counts for all departments based on nocid"
    def getByNocTypeDeptQuery(self):
        cursor = connections['ticketRead'].cursor()
        sql = 'select count(ticketid) as count,incident.nid as nocid,sws.statustype,sws.title as status,sws.ticketstatusid,incident.deptid,swd.title as dept '
        sql += 'from incident_data incident '
        sql += 'join swdepartments swd on (swd.departmentid = incident.deptid) ' 
        sql += 'join swticketstatus sws on (sws.ticketstatusid = incident.statusid) '
        sql += 'where 1=1 and swd.departmentid not in (0,1,2) ' 
        sql += 'group by incident.nid,incident.statusid,swd.departmentid order by incident.nid,swd.title,sws.statustype'        
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result
    
    def saveTemplate(self, tempDetails, uid):
        cursor = connections['rosterWrite'].cursor()
        templateDict = {}
        keys = values = ''
        
        templateDict['reportType'] = "'"+str('TB')+"'"
        
        if tempDetails.has_key('templatename'):
            templateDict['templatename'] = "'"+str(tempDetails['templatename'][0])+"'"
        else:
            templateDict['templatename'] = "'"+str(uid)+'_'+str(datetime.utcnow().strftime('%Y%m%d_%H%M%S'))+"'"
        
        
        if tempDetails.has_key('templatetype'):
            templateDict['templatetype'] = "'"+str(tempDetails['templatetype'][0])+"'"
        else:
            templateDict['templatetype'] = "'"+str(0)+"'"
        
           
        templateDict['templateuserid'] = uid
        
        templateDict['resultquery'] = "'"+str('')+"'"
        
       
        if tempDetails['idType'][0] and tempDetails['idTypeValue'][0]:
            if tempDetails['idType'][0] == 'ticketid':
                templateDict['ticketid'] = "'"+str(tempDetails['idTypeValue'][0])+"'"
            if tempDetails['idType'][0] == 'alertid':
                templateDict['sccalertid'] = "'"+str(tempDetails['idTypeValue'][0])+"'"
            if tempDetails['idType'][0] == 'psaid':
                templateDict['psa_id'] = "'"+str(tempDetails['idTypeValue'][0])+"'"
            if tempDetails['idType'][0] == 'subject':
                templateDict['searchstring'] = "'"+str(tempDetails['idTypeValue'][0])+"'"
            if tempDetails['idType'][0] == 'vistaraid':
                templateDict['ticketid'] = "'"+str(tempDetails['idTypeValue'][0])+"'"        
        
        
        if tempDetails.has_key('CM'):
            templateDict['is_modified_tickets'] = "'"+str(','.join(tempDetails['CM']))+"'"
        else:
            templateDict['is_modified_tickets'] = "'"+str(0)+"'"
        
        os.environ["TZ"] = "US/Pacific"
        if tempDetails.has_key('date'):
            if tempDetails['date'][0] == 'DAYS':
                templateDict['opt_dateselection'] = "'"+str("DAYS")+"'"
                templateDict['days'] = "'"+tempDetails['daysValue'][0]+"'"
            if tempDetails['date'][0] == 'DATE':
                templateDict['opt_dateselection'] = "'"+str("DATE")+"'"
           
                if tempDetails.has_key('fromDate'):
                    templateDict['fromdate'] = int(time.mktime(datetime.strptime(str(tempDetails['fromDate'][0]), "%m/%d/%Y %H:%M").timetuple()))
                else:
                    templateDict['fromdate'] = "'"+str('')+"'"                    
           
                if tempDetails.has_key('toDate'):
                    templateDict['todate'] = int(time.mktime(datetime.strptime(str(tempDetails['toDate'][0]), "%m/%d/%Y %H:%M").timetuple()))
                else:
                    templateDict['todate'] = "'"+str('')+"'"
            if tempDetails['date'][0] == 'OTHERS':
                templateDict['opt_dateselection'] = "'"+str("OTHERS")+"'"
                templateDict['other_opt'] = "'"+str(tempDetails['optionSelected'][0])+"'"
        
       
        if tempDetails.has_key('channel'):
            templateDict['channel'] = "'"+str(','.join(tempDetails['channel']))+"'"
        else:
            templateDict['channel'] = "'"+str('')+"'"
        
        #nocs
        if tempDetails.has_key('nocs'):
            templateDict['nocs'] = "'"+str(','.join(tempDetails['nocs']))+"'"
        else:
            templateDict['nocs'] = "'"+str('')+"'"
        
        #partners
        if tempDetails.has_key('partners'):
            templateDict['partners'] = "'"+str(','.join(tempDetails['partners']))+"'"
        else:
            templateDict['partners'] = "'"+str('')+"'"
        
        #clients    
        if tempDetails.has_key('clients'):
            templateDict['clients'] = "'"+str(','.join(tempDetails['clients']))+"'"
        else:
            templateDict['clients'] = "'"+str('')+"'"
        
        #departments    
        if tempDetails.has_key('department'):
            templateDict['departments'] = "'"+str(','.join(tempDetails['department']))+"'"
        else:
            templateDict['departments'] = "'"+str('')+"'"
            
        #ticket type    
        if tempDetails.has_key('ticketTypes'):
            templateDict['ticket_type'] = "'"+str(','.join(tempDetails['ticketTypes']))+"'"
        else:
            templateDict['ticket_type'] = "'"+str('')+"'"
            
        #staff    
        if tempDetails.has_key('assignto'):
            templateDict['staff'] = "'"+str(','.join(tempDetails['assignto']))+"'"
        else:
            templateDict['staff'] = "'"+str('')+"'"
            
        #service type    
        if tempDetails.has_key('serviceTypes'):
            templateDict['service_type'] = "'"+str(','.join(tempDetails['serviceTypes']))+"'"
        else:
            templateDict['service_type'] = "'"+str('')+"'"
        
        #service level    
        if tempDetails.has_key('serviceLevel'):
            templateDict['service_level'] = "'"+str(','.join(tempDetails['serviceLevel']))+"'"
        else:
            templateDict['service_level'] = "'"+str('')+"'"            
            
        #devices    
        if tempDetails.has_key('devices'):
            templateDict['devices'] = "'"+str(','.join(tempDetails['devices']))+"'"
        else:
            templateDict['devices'] = "'"+str('')+"'"
        
        #devices type
        if tempDetails.has_key('deviceType'):
            templateDict['device_types'] = "'"+str(','.join(tempDetails['deviceType']))+"'"
        else:
            templateDict['device_types'] = "'"+str('')+"'"
        
        #statuses    
        if tempDetails.has_key('selectedStatuses'):
            templateDict['statuses'] = "'"+str(','.join(tempDetails['selectedStatuses']))+"'"
        else:
            templateDict['statuses'] = "'"+str('')+"'"      
        #priorities    
        if tempDetails.has_key('selectedPriorities'):
            templateDict['priorities'] = "'"+str(','.join(tempDetails['selectedPriorities']))+"'"
        else:
            templateDict['priorities'] = "'"+str('')+"'"
        #custom columns
        if tempDetails.has_key('custom'):
            templateDict['display_columns'] = "'"+str(','.join(tempDetails['custom']))+"'"
        else:
            templateDict['display_columns'] = "'"+str('')+"'"
            
        #resolution sla
        if tempDetails.has_key('resSla'):
            templateDict['resolution_sla'] = "'"+str(','.join(tempDetails['resSla']))+"'"
        else:
            templateDict['resolution_sla'] = "'"+str('')+"'"
            
        if tempDetails.has_key('display_template'):
            templateDict['display_template'] = int(tempDetails['display_template'][0])
        else:
            templateDict['display_template'] = "'"+str(1)+"'"
            
        #tags
        if tempDetails.has_key('tags'):
            templateDict['tags'] = "'"+str(','.join(tempDetails['tags']))+"'"
        else:
            templateDict['tags'] = "'"+str('')+"'"

            
        if tempDetails.has_key('statusType'):
            value = str(','.join(tempDetails['statusType']))
            if value == 'auditlog':
                templateDict['is_auditlog_status'] = 1
        else:
            templateDict['is_auditlog_status'] = "'"+str('')+"'"      

        templateId = ','.join(tempDetails['templateId'])
        if templateId == 'null' or templateId == str(17974):#17974=Reset Template
            glue = ''
            for key, value in templateDict.iteritems():
                keys = '%s%s%s' % (keys,glue,str(key))
                values = '%s%s%s' % (values,glue,value)# if value > 0 else "%s%s%s" % (values,glue,"'"+str(value)+"'")
                glue = ','
            sql = "insert into ticketbrowser_templates ("+keys+") values("+values+")"
        else:        
            updateQuery = []
            glue = ''
            for key, value in templateDict.iteritems():
                updateQuery.append('%s=%s' % (key,value))
                glue = ','
                
            updateQuery = ', '.join(updateQuery)            
            sql = 'update ticketbrowser_templates set '+updateQuery+' where templateid="'+str(templateId)+'"'
        
        cursor = connections['rosterWrite'].cursor()
        cursor.execute(sql)
        lastId = cursor.lastrowid
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return lastId
        
    def getTemplatenames(self):   
        cursor = connections['rosterRead'].cursor()
        sql = "SELECT  templatename FROM ticketbrowser_templates WHERE reportType = 'TB' AND display_template = 1";
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result


    # calling getPackageBasedQMInfo to get employee number working mins, tickets closed count, touched count
    def getPackageBasedQMInfo(self, fromdate, todate, staff, priorities, time_worked, flag, manage, aid, smartescalate):
        try:
            
            # splitting date based on space delimiter
            fromdatetimelist = fromdate.split(" ")
            todatetimelist = todate.split(" ")
            #  splitting date 0th index on / delimiter
            fdatelist = fromdatetimelist[0].split("/")
            tdatelist = todatetimelist[0].split("/")
            # formatting the given date to datetime format
            formatted_fromdate = str(fdatelist[2]) + "-" + str(fdatelist[0] + "-" + str(fdatelist[1])) + " 00:00:00"
            formatted_todate = str(tdatelist[2]) + "-" + str(tdatelist[0] + "-" + str(tdatelist[1])) + " 23:59:59"

            # if staff len is not equal to zero we do nothing else initializing staff to 0
            if len(staff):
                pass
            else:
                staff = 0

            # if priorities len is not equal to zero we do nothing else initializing priorities to 0
            if len(priorities):
                pass
            else:
                priorities = 0

            # initializing package empty list
            package = []

            # if manage is checked append manage to package list
            if str(manage) == "on":
                package.append("manage")

            # if aid is checked append aid to package list
            if str(aid) == "on":
                package.append("aid")

            # if smartescalate is checked append smartescalate to package list
            if str(smartescalate) == "on":
                package.append("smartescalate")

            # if package len is 0 append NA to package list
            if len(package) == 0:
                package.append("NA")
                finalpackage = "NA"
            # if package len is not 0, creating the packages string using package list elements
            else:
                finalpackage = ",".join(package)

            #  here creating employees string looping through staff list elements
            staff_str = ",".join(emp.strip() for emp in staff)
            #  here creating priorities string using priorities list elements
            priorities = ",".join(priorities)

            try:
                # creating cursor object
                cursor = connections['ticketRead'].cursor()
                #  creating arguments list
                args = [str(formatted_fromdate), str(
                    formatted_todate), str(staff_str), str(priorities), str(
                    time_worked), str(0), str(finalpackage)]
                #  here we are calling procedure using callproc method
                cursor.callproc('proc_quality_metric_pkg', args)
                # fetching all query set objects using
                result = cursor.fetchall()
                # closing the cursor
                cursor.close()
                # returning final result
                return result

            #  if something goes wrong we raise exception
            except Exception as e:
                return e
        # if something goes wrong we raise exception
        except Exception as e:
            return e

    #  function to fetch the productivity of employee based on swstaffid
    def getStaffTotalProductivityBySwStaffId(self, staff, fromdate, todate):
        
        ''' creating staff string and replacing occurrence of character "E" nothing so that we get only employee id'''
        staff = ",".join(re.sub('[E]', "", emp).strip() for emp in staff)
        ''' splitting from date with empty space '''
        fromdatetimelist = fromdate.split(" ")
        ''' splitting to date with empty space '''
        todatetimelist = todate.split(" ")
        ''' again splitting fromdatetimelist using / '''
        fdatelist = fromdatetimelist[0].split("/")
        ''' again splitting todatetimelist using / '''
        tdatelist = todatetimelist[0].split("/")
        ''' reformatting the given input date to datetime format'''
        formatted_fromdate = str(fdatelist[2]) + "-" + str(fdatelist[0] + "-" + str(fdatelist[1])) + " 00:00:00"
        formatted_todate = str(tdatelist[2]) + "-" + str(tdatelist[0] + "-" + str(tdatelist[1])) + " 23:59:59"

        ''' we are  splitting staff list by ,  '''
        stafflist = staff.split(",")

        try:
            ''' here preparing sql query with the given inputs formatted_fromdate, formatted_todate, staff'''
            sql = "SELECT ns.id AS nrstaff_id, ns.swstaff_id, ns.staff_email, " \
                  "IFNULL(SUM(closed_tickets), 0) AS closed_tickets, " \
                  "IFNULL(SUM(replies), 0) AS replies, IFNULL(SUM(kyk_mins_worked), 0) AS kyk_mins_worked, " \
                  "IFNULL(SUM(review_time), 0) AS review_time, SUM(hr_calendar_day) AS working_days " \
                  "FROM staff_productivity_metrics spm JOIN nr_staff ns ON ns.id=spm.staff_id " \
                  "WHERE DATE(CONVERT_TZ(shift_date, '+00:00', '+05:30')) >= '" + str(formatted_fromdate) +\
                  "' AND DATE(CONVERT_TZ(shift_date, '+00:00', '+05:30')) <= '" + str(formatted_todate) + \
                  "' AND ns.swstaff_id IN (" + staff + ") GROUP BY spm.staff_id;"

            ''' creating cursor object '''
            cursor = connections['rosterRead'].cursor()
            ''' executing the prepared sql query '''
            cursor.execute(sql)
            ''' fetching all the queryset objects '''
            result = cursor.fetchall()
            ''' closing the cursor object'''
            cursor.close()
            ''' here we are creating empty staff productivity dictionary to maintain the respective employee data'''
            staffProdInfo = {}
            for emp in stafflist:
                staffProdInfo[str(emp)] = {}

            '''' here looping through the each employee details to create respective employee data'''
            for prod_data in result:
                staffProdInfo[str(prod_data[1])]['working_days'] = str(prod_data[7])
                staffProdInfo[str(prod_data[1])]['kyk_mins_worked'] = str(prod_data[5])
                staffProdInfo[str(prod_data[1])]['review_time'] = str(prod_data[6])
                ''' if number of working of employee are greater than zero if block is executed '''
                if int(prod_data[7]) > 0:
                    ''' here are converting working days into minutes '''
                    sum_of_rt_kmw = (int(prod_data[5]) + int(prod_data[6]))
                    mins_conversion = (int(prod_data[7]) * 480)
                    utilization = (sum_of_rt_kmw / float(mins_conversion)) * 100
                    ''' finally assigning the data to utilization key'''
                    staffProdInfo[str(prod_data[1])]['utilization'] = math.ceil(utilization)

                else:
                    '''if number of working days is 0 then else block will be executed,
                    and zero will be assigned to utilization key '''
                    staffProdInfo[str(prod_data[1])]['utilization'] = 0
            ''' returning final data set'''
            return staffProdInfo

        # if something goes wrong raise an exception
        except Exception as e:
            return e

    def prepareQualityMetricReportConditions(self, fromdate, todate, staff, partners, clients, reviewer, reviewmetric, qualityrating):

        sql = "SELECT  SQL_CALC_FOUND_ROWS id.ticketid, " \
              "(CASE WHEN (pr.post_id IS NULL OR pr.post_id = 0) THEN 'Ticket Level' ELSE 'Post Level' END) as review_type, " \
              "pr.reviewer_id, " \
              "pr.review_date, " \
              "pr.proc_rating, " \
              "pr.tech_rating, " \
              "pr.comm_rating, " \
              "pr.time_rating, " \
              "pr.customer_value_rating, " \
              "pr.comments as reviewer_comments, " \
              "pr.review_time, pr.mail_sent_to," \
              " swtp.contents, " \
              "swtp.dateline as swtp_dateline, " \
              "id.priorityid, " \
              "id.deptid, " \
              "id.statusid, " \
              "id.staffid, " \
              "id.subject, " \
              "id.mid, " \
              "id.client, " \
              "id.did, " \
              "id.cid " \
              "FROM post_reviews pr    " \
              " LEFT JOIN incident_data id ON pr.ticket_id = id.ticketid " \
              " LEFT JOIN swticketposts swtp " \
              "ON (swtp.ticketid = pr.ticket_id AND swtp.ticketpostid = pr.post_id) "

        condition = " WHERE 1 = 1"
        fromdatetime_list = fromdate.split(" ")
        todatetime_list = todate.split(" ")
        fromdate_list = fromdatetime_list[0].split("/")
        todate_list = todatetime_list[0].split("/")
        fromdatetime = datetime(int(fromdate_list[2]), int(fromdate_list[0]), int(fromdate_list[1]), 0, 0, 0)
        todatetime = datetime(int(todate_list[2]), int(todate_list[0]), int(todate_list[1]), 23, 59, 59)

        if fromdatetime > todatetime:
            return HttpResponse("From Date should be less than To Date", status=500)
        else:
            condition += " AND (pr.review_date >= UNIX_TIMESTAMP('%s') AND pr.review_date <= UNIX_TIMESTAMP('%s'))" % (fromdatetime, todatetime)

        if staff:
            condition += " AND swtp.staffid IN (%s)" % staff
        else:
            condition += ""

        if reviewer:
            condition += " AND pr.reviewer_id IN (%s) " % reviewer
        else:
            condition += ""

        if len(qualityrating):
            condition1 = glue1 = ""
            for review in reviewmetric:
                condition2 = glue2 = " "
                for quality in qualityrating:
                    if qualityrating.index(quality) == len(qualityrating) - 1:
                        condition2 += glue2 + "pr." + str(review) + "=" + str(quality)
                    else:
                        if qualityrating.index(quality) == 0:
                            condition2 += glue2 + "pr." + str(review) + "=" + str(quality) + " OR "
                        else:
                            condition2 += glue2 + "pr." + str(review) + "=" + str(quality) + " OR "
                if reviewmetric.index(review) == len(reviewmetric) - 1:
                    condition1 += glue1 + condition2
                else:
                    condition1 += glue1 + condition2 + " OR "
            if condition1:
                condition += " AND " + "(" + condition1 + ")"
        else:
            condition += " "

        sql += condition

        if partners:
            sql += " AND id.mid  IN (%s)" % partners
        else:
            sql += ""

        if clients:
            sql += " AND id.cid IN (%s)" % clients
        else:
            sql += ""

        # sql += " LIMIT 50 OFFSET 0"
        return sql
    
    def getDeviceById(self, deviceid):
        try:
            if int(deviceid) == 0:
                return [{"device_name": "Unknown"}]
            else:
                cursor = connections['ticketRead'].cursor()
                sql = "select id, device_name from ntsmspdevicedata where id =%s" %deviceid
                cursor.execute(sql)
                device_data = comObj.dictfetchall(cursor)
                cursor.close()
                return device_data
        except Exception as e:
            return e.message
        
    def getSearchTags(self):    
        result = mem_cache.get('searchTags'+env)
        if not result:  
            sql= "select tag_id,tag_name from nts_incident_tags order by tag_name asc"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor) 
            cursor.close()
            mem_cache.set('searchTags'+env,result,86400)
        return result
