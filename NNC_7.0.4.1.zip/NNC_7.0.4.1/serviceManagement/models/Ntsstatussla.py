"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import models,connections


class Ntsstatussla(models.Model):
    ticketstatusid = models.IntegerField(primary_key=True)
    sla_value = models.IntegerField()
    sla_type = models.CharField(max_length=6)

    class Meta:
        db_table = 'ntsstatussla'
        
    def getNtsstatussla(self,statusId =0):
        cursor = connections['ticketRead'].cursor()
        if statusId > 0 :
            sql = "SELECT ticketstatusid, sla_value FROM ntsstatussla WHERE ticketstatusid ="+statusId+" ORDER BY ticketstatusid"
            cursor.execute(sql)
            result = self.dictfetchall(cursor)
        else :
            sql = "SELECT ticketstatusid, sla_value FROM ntsstatussla ORDER BY ticketstatusid";
            cursor.execte(sql)
            result = self.dictfetchall(cursor)
            
        cursor.close()
        return result
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]