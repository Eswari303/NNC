"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import models,connections
from django.core.cache import caches
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)

class Sku(object):
    def skuDetails(self,deviceId):
        cursor = connections['mspDB'].cursor()
        sql = "select sk.sku as sku  from sku as sk  inner join sku_device_utilisation_item as skudvut on skudvut.sku_id = sk.id  where skudvut.device_id ="+str(deviceId) 
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['sku'] = i['sku']
            result =resultSet['sku'] 
        else:
            result =""        
        return result
    
    def packages(self,deviceId):
        cursor = connections['mspDB'].cursor()
        sql ="select skuctg.display_name  from sku as sk  inner join sku_device_utilisation_item as skudvut on skudvut.sku_id = sk.id  inner join sku_service_category as skuctg on skuctg.id = sk.service_category_id where skudvut.device_id ="+str(deviceId);
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['display_name'] = i['display_name']
            result =resultSet['display_name'] 
        else:
            result =""
        return result
    
    def servicelevel(self,deviceId):
        cursor = connections['mspDB'].cursor()
        sql = "select sk.service_level  from sku as sk  inner join sku_device_utilisation_item as skudvut on skudvut.sku_id = sk.id  where skudvut.device_id ="+str(deviceId)
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['service_level'] = i['service_level']
            result =resultSet['service_level'] 
        else:
            result =""
        return result
    
    def getAllServiceLevels (self):
        serviceLevels = mem_cache.get('serviceLevels'+env)
        if not serviceLevels:
            cursor = connections['mspDB'].cursor()
            sql = 'select DISTINCT service_level from sku ORDER BY service_level ASC'
            cursor.execute(sql)
            result = self.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('serviceLevels'+env, serviceLevels, 86400)
        return result
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
        
