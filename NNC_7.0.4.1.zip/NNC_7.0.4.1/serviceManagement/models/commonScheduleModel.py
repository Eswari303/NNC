"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import connection, connections
from django.core.cache import caches
from NNCPortal.commonMethods import commonMethods
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
comObj = commonMethods()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)

class CommonScheduleModel(object):
    def getTemplateList(self,userId):
        sql = "select templateid, templatename, templatetype, templateuserid,reportType from ticketbrowser_templates where (templatetype='1' AND display_template=1 AND templateuserid= "+str(userId)+") or templatetype = '0' and reportType = 'TB' and templatename NOT IN ('My Tickets','My Team Tickets')"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        finResult = comObj.dictfetchall(cursor)
        cursor.close()
        return finResult
    
    def getJobDetailsByTemplateIdAndUserId(self,userId,tType,templateId=0):
        sql = """SELECT j.JobId, j.JobName, j.reportType, j.scheduleType, j.LastRunTime, j.templateId, CONCAT(staff.staff_fname, ' ', staff.staff_lname)AS staff_name, tb.templateuserid, tb.lastdate, rec.* 
        FROM nnc_sch_jobs AS j JOIN nnc_job_sch_recurence AS rec ON rec.jobId = j.JobId JOIN ticketbrowser_templates tb ON tb.templateid = j.templateId LEFT JOIN nr_staff staff ON tb.templateuserid = staff.id 
        WHERE j.createdBy = """+str(userId)+""" AND j.scheduleType != 'RunNow' AND j.reportType = '"""+str(tType)+"""'"""
        if templateId > 0 :
            sql = sql + 'AND j.templateId = '+str(templateId)
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result

    def getStaffInfo(self):
        staffEmails = mem_cache.get('staffEmails'+env)
        if not staffEmails:
            sql = "select user_name as label,staff_email as value from nr_staff where is_active = 1"
            cursor = connections['rosterRead'].cursor()
            cursor.execute(sql)
            staffEmails = comObj.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('staffEmails'+env, staffEmails, 86400)
        return staffEmails
