"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import models,connections
from django.core.cache import caches
from datetime import datetime
import time
import os
mem_cache = caches['memcached']

class TicketbrowserTemplates(models.Model):
    templateid = models.AutoField(primary_key=True)
    templatename = models.CharField(unique=True, max_length=50)
    templatetype = models.CharField(max_length=1, blank=True, null=True)
    templateuserid = models.IntegerField(blank=True, null=True)
    resultquery = models.TextField()
    nocs = models.TextField()
    partners = models.TextField()
    clients = models.TextField()
    devices = models.TextField()
    departments = models.TextField()
    statuses = models.TextField()
    staff = models.TextField()
    priorities = models.CharField(max_length=50, blank=True, null=True)
    fromdate = models.IntegerField(blank=True, null=True)
    todate = models.IntegerField(blank=True, null=True)
    ticketid = models.TextField(blank=True, null=True)
    sccalertid = models.TextField(blank=True, null=True)
    days = models.IntegerField(blank=True, null=True)
    devicetypes = models.TextField(blank=True, null=True)
    devicegroups = models.TextField(blank=True, null=True)
    locations = models.TextField(blank=True, null=True)
    staffgroups = models.TextField(blank=True, null=True)
    lastdate = models.DateTimeField()
    resolution_sla = models.CharField(max_length=10, blank=True, null=True)
    psa_id = models.TextField(blank=True, null=True)
    device_types = models.TextField(blank=True, null=True)
    device_groups = models.TextField(blank=True, null=True)
    device_sites = models.TextField(blank=True, null=True)
    display_columns = models.TextField(blank=True, null=True)
    is_modified_tickets = models.CharField(max_length=50, blank=True, null=True)
    reporttype = models.CharField(db_column='reportType', max_length=2, blank=True, null=True)  # Field name made lowercase.
    display_template = models.IntegerField(blank=True, null=True)
    opt_dateselection = models.CharField(max_length=6, blank=True, null=True)
    other_opt = models.CharField(max_length=10, blank=True, null=True)
    channel = models.TextField(blank=True, null=True)
    ad_department = models.TextField(blank=True, null=True)
    roster = models.TextField(blank=True, null=True)
    reviewer = models.TextField(blank=True, null=True)
    review_metric = models.CharField(max_length=500, blank=True, null=True)
    quality_rate = models.CharField(max_length=500, blank=True, null=True)
    is_auditlog_status = models.IntegerField(blank=True, null=True)
    opt_priority_from = models.CharField(max_length=2, blank=True, null=True)
    opt_priority_to = models.CharField(max_length=20, blank=True, null=True)
    searchstring = models.CharField(max_length=50, blank=True, null=True)
    ticket_type = models.TextField(blank=True, null=True)
    service_type = models.CharField(max_length=255, blank=True, null=True)
    service_level = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        db_table = 'ticketbrowser_templates'
        
    def getTemplateList(self,userId):
        sql = "select templateid, templatename, templatetype, templateuserid,reportType from ticketbrowser_templates where (templatetype='1' AND display_template=1 AND templateuserid= "+str(userId)+") or templatetype = '0' and reportType = 'TB' and templatename NOT IN ('My Tickets','My Team Tickets')"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        finResult = self.dictfetchall(cursor)
        cursor.close()
        return finResult
    
    def ticketBrowserResults(self,sql):
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result
    
    def saveTemplate(self, tempDetails, uid):
        cursor = connections['rosterWrite'].cursor()
        templateDict = {}
        keys = values = ''
        
        templateDict['reportType'] = "'"+str('TB')+"'"
        
        if tempDetails.has_key('templatename'):
            templateDict['templatename'] = "'"+str(tempDetails['templatename'][0])+"'"
        else:
            templateDict['templatename'] = "'"+str(uid)+'_'+str(datetime.utcnow().strftime('%Y%m%d_%H%M%S'))+"'"
        
        
        if tempDetails.has_key('templatetype'):
            templateDict['templatetype'] = "'"+str(tempDetails['templatetype'][0])+"'"
        else:
            templateDict['templatetype'] = "'"+str(0)+"'"
        
           
        templateDict['templateuserid'] = uid
        
        templateDict['resultquery'] = "'"+str('')+"'"
        
       
        if tempDetails['idType'][0] and tempDetails['idTypeValue'][0]:
            if tempDetails['idType'][0] == 'ticketid':
                templateDict['ticketid'] = "'"+str(tempDetails['idTypeValue'][0])+"'"
            if tempDetails['idType'][0] == 'alertid':
                templateDict['sccalertid'] = "'"+str(tempDetails['idTypeValue'][0])+"'"
            if tempDetails['idType'][0] == 'psaid':
                templateDict['psa_id'] = "'"+str(tempDetails['idTypeValue'][0])+"'"
            if tempDetails['idType'][0] == 'subject':
                templateDict['searchstring'] = "'"+str(tempDetails['idTypeValue'][0])+"'"
            if tempDetails['idType'][0] == 'vistaraid':
                templateDict['ticketid'] = "'"+str(tempDetails['idTypeValue'][0])+"'"        
        
        
        if tempDetails.has_key('CM'):
            templateDict['is_modified_tickets'] = "'"+str(','.join(tempDetails['CM']))+"'"
        else:
            templateDict['is_modified_tickets'] = "'"+str(0)+"'"
        
        os.environ["TZ"] = "US/Pacific"
        if tempDetails.has_key('date'):
            if tempDetails['date'][0] == 'DAYS':
                templateDict['opt_dateselection'] = "'"+str("DAYS")+"'"
                templateDict['days'] = "'"+tempDetails['daysValue'][0]+"'"
            if tempDetails['date'][0] == 'DATE':
                templateDict['opt_dateselection'] = "'"+str("DATE")+"'"
           
                if tempDetails.has_key('fromDate'):
                    templateDict['fromdate'] = int(time.mktime(datetime.strptime(str(tempDetails['fromDate'][0]), "%m/%d/%Y %H:%M").timetuple()))
                else:
                    templateDict['fromdate'] = "'"+str('')+"'"                    
           
                if tempDetails.has_key('toDate'):
                    templateDict['todate'] = int(time.mktime(datetime.strptime(str(tempDetails['toDate'][0]), "%m/%d/%Y %H:%M").timetuple()))
                else:
                    templateDict['todate'] = "'"+str('')+"'"
            if tempDetails['date'][0] == 'OTHERS':
                templateDict['opt_dateselection'] = "'"+str("OTHERS")+"'"
                templateDict['other_opt'] = "'"+str(tempDetails['optionSelected'][0])+"'"
        
       
        if tempDetails.has_key('channel'):
            templateDict['channel'] = "'"+str(','.join(tempDetails['channel']))+"'"
        else:
            templateDict['channel'] = "'"+str('')+"'"
        
        #nocs
        if tempDetails.has_key('nocs'):
            templateDict['nocs'] = "'"+str(','.join(tempDetails['nocs']))+"'"
        else:
            templateDict['nocs'] = "'"+str('')+"'"
        
        #partners
        if tempDetails.has_key('partners'):
            templateDict['partners'] = "'"+str(','.join(tempDetails['partners']))+"'"
        else:
            templateDict['partners'] = "'"+str('')+"'"
        
        #clients    
        if tempDetails.has_key('clients'):
            templateDict['clients'] = "'"+str(','.join(tempDetails['clients']))+"'"
        else:
            templateDict['clients'] = "'"+str('')+"'"
        
        #departments    
        if tempDetails.has_key('department'):
            templateDict['departments'] = "'"+str(','.join(tempDetails['department']))+"'"
        else:
            templateDict['departments'] = "'"+str('')+"'"
            
        #ticket type    
        if tempDetails.has_key('ticketTypes'):
            templateDict['ticket_type'] = "'"+str(','.join(tempDetails['ticketTypes']))+"'"
        else:
            templateDict['ticket_type'] = "'"+str('')+"'"
            
        #staff    
        if tempDetails.has_key('assignto'):
            templateDict['staff'] = "'"+str(','.join(tempDetails['assignto']))+"'"
        else:
            templateDict['staff'] = "'"+str('')+"'"
            
        #service type    
        if tempDetails.has_key('serviceTypes'):
            templateDict['service_type'] = "'"+str(','.join(tempDetails['serviceTypes']))+"'"
        else:
            templateDict['service_type'] = "'"+str('')+"'"
        
        #service level    
        if tempDetails.has_key('serviceLevel'):
            templateDict['service_level'] = "'"+str(','.join(tempDetails['serviceLevel']))+"'"
        else:
            templateDict['service_level'] = "'"+str('')+"'"            
            
        #devices    
        if tempDetails.has_key('devices'):
            templateDict['devices'] = "'"+str(','.join(tempDetails['devices']))+"'"
        else:
            templateDict['devices'] = "'"+str('')+"'"
        
        #devices type
        if tempDetails.has_key('deviceType'):
            templateDict['device_types'] = "'"+str(','.join(tempDetails['deviceType']))+"'"
        else:
            templateDict['device_types'] = "'"+str('')+"'"
        
        #statuses    
        if tempDetails.has_key('selectedStatuses'):
            templateDict['statuses'] = "'"+str(','.join(tempDetails['selectedStatuses']))+"'"
        else:
            templateDict['statuses'] = "'"+str('')+"'"      
        #priorities    
        if tempDetails.has_key('selectedPriorities'):
            templateDict['priorities'] = "'"+str(','.join(tempDetails['selectedPriorities']))+"'"
        else:
            templateDict['priorities'] = "'"+str('')+"'"
        #custom columns
        if tempDetails.has_key('custom'):
            templateDict['display_columns'] = "'"+str(','.join(tempDetails['custom']))+"'"
        else:
            templateDict['display_columns'] = "'"+str('')+"'"
            
        #resolution sla
        if tempDetails.has_key('resSla'):
            templateDict['resolution_sla'] = "'"+str(','.join(tempDetails['resSla']))+"'"
        else:
            templateDict['resolution_sla'] = "'"+str('')+"'"
            
        if tempDetails.has_key('display_template'):
            templateDict['display_template'] = int(tempDetails['display_template'][0])
        else:
            templateDict['display_template'] = "'"+str(1)+"'"
            
        #tags
        if tempDetails.has_key('tags'):
            templateDict['tags'] = "'"+str(','.join(tempDetails['tags']))+"'"
        else:
            templateDict['tags'] = "'"+str('')+"'"

            
        if tempDetails.has_key('statusType'):
            value = str(','.join(tempDetails['statusType']))
            if value == 'auditlog':
                templateDict['is_auditlog_status'] = 1
        else:
            templateDict['is_auditlog_status'] = "'"+str('')+"'"      

        templateId = ','.join(tempDetails['templateId'])
        if templateId == 'null' or templateId == str(17974):#17974=Reset Template
            glue = ''
            for key, value in templateDict.iteritems():
                keys = '%s%s%s' % (keys,glue,str(key))
                values = '%s%s%s' % (values,glue,value)# if value > 0 else "%s%s%s" % (values,glue,"'"+str(value)+"'")
                glue = ','
            sql = "insert into ticketbrowser_templates ("+keys+") values("+values+")"
        else:        
            updateQuery = []
            glue = ''
            for key, value in templateDict.iteritems():
                updateQuery.append('%s=%s' % (key,value))
                glue = ','
                
            updateQuery = ', '.join(updateQuery)            
            sql = 'update ticketbrowser_templates set '+updateQuery+' where templateid="'+str(templateId)+'"'
        
        cursor = connections['rosterWrite'].cursor()
        cursor.execute(sql)
        lastId = cursor.lastrowid
        result = self.dictfetchall(cursor)
        cursor.close()
        return lastId
    
    def getUserTemplatesAndPublicTemplates (self, userId=0, reportType=''):
        cursor = connections['rosterRead'].cursor()
        #sql = 'SELECT templateid, templatename, templatetype, templateuserid, lastdate FROM ticketbrowser_templates'
        sql = 'SELECT temp.templateid, temp.templatename, temp.templatetype, temp.templateuserid, temp.lastdate, CONCAT(staff.staff_fname," ",staff.staff_lname) AS username '
        sql += 'FROM ticketbrowser_templates temp JOIN nr_staff staff on staff.id = temp.templateuserid'
        sql += ' WHERE ((temp.templatetype = "1" AND temp.display_template = 1 AND temp.templateuserid ='+str(userId)+')'        
        sql += ' OR (temp.templatetype = "0" AND temp.display_template = 1))'
        if reportType != '':
            sql += ' AND temp.reportType ="'+reportType+'"'        
        if reportType == 'TB':
            sql += " AND temp.templatename NOT IN ('My Tickets','My Team Tickets')"               
        sql += ' order by temp.templatename'
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result
    
    def getTemplateDetails (self, templateId):
        cursor = connections['rosterRead'].cursor()
        result = {}
        if templateId != '':
            sql = "select * from ticketbrowser_templates where templateid = "+str(templateId)
            cursor.execute(sql)
            result = self.dictfetchall(cursor)
            cursor.close()
        return result    
    
    def getTemplatenames(self):
        cursor = connections['rosterRead'].cursor()
        sql = "SELECT  templatename FROM ticketbrowser_templates WHERE reportType = 'TB' AND display_template = 1";
        cursor.execute(sql)
        templatenames = self.dictfetchall(cursor)
        cursor.close()        
        return templatenames    
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]
