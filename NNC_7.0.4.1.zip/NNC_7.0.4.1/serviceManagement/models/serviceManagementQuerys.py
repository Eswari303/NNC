"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import connection,connections
from django.core.cache import caches
from _collections import defaultdict
mem_cache = caches['memcached']
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
from NNCPortal.commonMethods import commonMethods
import datetime as dt
from datetime import datetime, timedelta
comObj = commonMethods()
cursor = connections['ticketRead'].cursor()
env = configobj.getCommConfigValue(configobj.app_env)
IncidentResolutionSla = {
                                '1' : "(id.resol_due between 0 AND 3600)",
                                '2' : " id.resol_due > 3600",
                                '3' : " id.resol_due < 0",
                                }  

class SlamResultQuerys(object):
    def ownersStaffid(self):
        cursor = connections['ticketRead'].cursor()
        sql = 'SELECT staffid, fullname FROM swstaff  WHERE staffgroupid != 41 ORDER BY fullname'
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        SwaffIdSet = {}
        for i in result:
            SwaffIdSet[i['staffid']] = i['fullname']
        return SwaffIdSet
    
    def partnerName(self):
        cursor = connections['ticketRead'].cursor()
        sql = 'select distinct t.mspid, t.mspname from  ntsmsps t JOIN ntsmspclients ntsc ON t.mspid=ntsc.mspid   where  ntsc.status=1  order by  t.mspname '
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        partnersList = {}
        for i in result:
            partnersList[i['mspid']] = i['mspname']
        return partnersList        
    
    def getDeviceNameFromCumulativeAlerts(self,alertId):
        cursor = connections['ticketRead'].cursor()
        sql = "select host_name from view_cumulative_alerts_info where id = "+str(alertId);
        
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        
        cursor.close()
        resultset = {}
        if result:
            for i in result:
                resultset['host_name'] =i['host_name']
        else:
            resultset['host_name']= ''  
        return resultset['host_name']    
    
    def getMinutesFormatFromSeconds(self,seconds):
        value = seconds / 60;
        return int(value)        
   
    def getLocalDate(self,timeStamp):
        result =dt.datetime.fromtimestamp(int(timeStamp)).strftime('%Y-%m-%d %H:%M:%S')
        return result
    
    def userreplies(self,ticket):
        cursor = connections['ticketRead'].cursor()
        sql = "select count(*) as count from swticketposts where ticketid ='"+str(ticket)+"' and userid!=53"
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        for i in result:
        
            resultSet['count'] =i['count']
        return resultSet
    
    def skuDetails(self,deviceId):
        cursor = connections['mspDB'].cursor()
        sql = "select sk.sku as sku  from sku as sk  inner join sku_device_utilisation_item as skudvut on skudvut.sku_id = sk.id  where skudvut.device_id ="+str(deviceId) 
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['sku'] = i['sku']
            result =resultSet['sku'] 
        else:
            result =""
        
        return result
    
        
    def servicelevel(self,deviceId):
        cursor = connections['mspDB'].cursor()
        sql = "select sk.service_level  from sku as sk  inner join sku_device_utilisation_item as skudvut on skudvut.sku_id = sk.id  where skudvut.device_id ="+str(deviceId)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['service_level'] = i['service_level']
            result =resultSet['service_level'] 
        else:
            result =""
        return result
    def packages(self,deviceId):
        cursor = connections['mspDB'].cursor()
        sql ="select skuctg.display_name  from sku as sk  inner join sku_device_utilisation_item as skudvut on skudvut.sku_id = sk.id  inner join sku_service_category as skuctg on skuctg.id = sk.service_category_id where skudvut.device_id ="+str(deviceId);
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['display_name'] = i['display_name']
            result =resultSet['display_name'] 
        else:
            result =""
        return result
        
    def psa_lastactivity_date(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  psa_lastactivity_date FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['psa_lastactivity_date'] = i['psa_lastactivity_date']
            result =resultSet['psa_lastactivity_date']
        
             
        else:
            result =""
        return result
    
    def serviceBoardName(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  kyk_serviceboard FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId) 
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['kyk_serviceboard'] = i['kyk_serviceboard']
            result =resultSet['kyk_serviceboard'] 
        else:
            result =""
        return result
    
    def is_status_matched(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  is_status_matched FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId) 
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['is_status_matched'] = i['is_status_matched']
            result =resultSet['is_status_matched'] 
        else:
            result =""        
        return result
    
    def psaserviceboardmatched(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  kyk_serviceboard FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId) 
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()        
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['kyk_serviceboard'] = i['kyk_serviceboard']
            result =resultSet['kyk_serviceboard'] 
        else:
            result =""
        
        return result
    
    def psacurrentstatus(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  psa_status FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId) 
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['psa_status'] = i['psa_status']
            result =resultSet['psa_status'] 
        else:
            result =""
        return result
    
    def psapostcount(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  psa_post_count FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId) 
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['psa_post_count'] = i['psa_post_count']
            result =resultSet['psa_post_count'] 
        else:
            result =""
        return result
    
    def psadatacapturedon(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  script_pulleddate as 'psadata_as_on' FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId) 
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['psadata_as_on'] = i['psadata_as_on']
            result =resultSet['psadata_as_on'] 
        else:
            result =""
        return result
        
    def convertSecoandToTime(self,seconds):
        m, s = divmod(seconds, 60)
        h, m = divmod(m, 60)
        return "%d:%02d:%02d" % (h, m, s)
    
    def responceSlaMet(self,ticketId,responsetime=0):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  @responseslavalue :=substring_index(getsla('"+str(ticketId)+"','response'),':',-1) as res "
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        reslt = result[0]
        if (int(reslt['res']) > int(responsetime)):
            results = 'No'
        else:
            results = 'Yes'        
        return results        
        
    def channalNmae(self,id):
        cursor = connections['mspDB'].cursor()
        sql ="select id,name from channel order by name"
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        for i in result:
            resultSet[i['id']] = i['name']
        
        return resultSet
    
    def PrimaryNotification(self,mspId):
        cursor = connections['mspDB'].cursor()
        sql = "select u.email as mailid from users u join organizations o on (u.org_id = o.id and u.id = o.primary_admin_id) where o.class_code = 'msp' and o.activated = 1 and o.id = "+str(mspId)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        return result[0]['mailid']
    
    def varnotificationTime(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql = "select dateline ,actionmsg from swauditlogs  where actiontype = 12 and actionmsg like '%To email address%' and  ticketid= '"+str(ticketId)+"' order by dateline desc";
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        newdateline =''
        if len(result)>0:
            for i in result:
                split1 = i['actionmsg'].split('- To email address:')
                Split2 = split1[1].split('- Email Subject:')
                Split3 = Split2[0].split(',')
                countList =len(Split3)
                for i in range(countList):
                    Split4 = Split3[i].split('@')
                    if (Split4[1]) != "netenrich.com":
        
                        break
        return  newdateline
    
    def csatrequest(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql = "SELECT user_id,ticketid FROM csat_users where user_id not in (1) and ticketid ="+str(ticketId)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        if len(result) >0:
            result = 'Yes'
        else:
            result = 'NO'
        return result
    
    def clienttimezone(self,clientId):
        cursor = connections['ticketRead'].cursor()
        sql = "select time_zone  from organizations where id ="+str(clientId)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        for i in result:
            resultSet['time_zone']= i['time_zone']
        return resultSet['time_zone'] 

    def vistaraabticketstatus(self,sccalertid,ticketId):
        resultData =''
        if sccalertid !='':
            cursor = connections['ticketRead'].cursor()
            sql = "SELECT ticket_status FROM view_cumulative_alerts_info WHERE id = "+str(sccalertid)+" AND ticketid ="+str(ticketId)        
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            resultSet ={}
            if len(result)>0:
                for i in result:
                    resultSet['ticket_status']= i['ticket_status']
                if resultSet['ticket_status'] == 5:
                    
                    resultData = 'Closed'
                elif resultSet['ticket_status'] == 17:
                    resultData = 'Closed'
                elif resultSet['ticket_status'] == 20:
                    resultData = 'Closed'
                elif resultSet['ticket_status'] == 3:
                    resultData = 'Closed'
                else:
                    resultData = 'Open'
            else:
                resultData ='-'
                
        return resultData
    
    def secondPostResponse(self,ticketId):
        try:
            cursor = connections['ticketRead'].cursor()
            sql = "SELECT dateline,contents FROM swticketposts WHERE ticketid = '"+str(ticketId)+"' ORDER BY ticketpostid limit 2";
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            resultTotal = {}
            countlist = 0
            for i in result:
                resultSet = {}
                resultSet['date'] =i['dateline']
                resultSet['content'] =i['contents']
                resultTotal[countlist] =resultSet
                countlist = countlist +1
            return resultTotal
        except Exception as inst:
        
            pass
    def technology(self,clientId,deviceId):
        cursor = connections['ticketRead'].cursor()
        sql = "SELECT technology  FROM ntstechnologies where clientid ="+str(clientId)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        for i in result:
            resultSet['technology'] =i['technology']
        
        link = '<a target="_blank" class="hyperlinks" href="https://www.mspnocsupport.com/devicePage.do?id='+str(deviceId)+' title="Open In Vistara ">'+str(resultSet['technology'])+'</a>'
        return link
    
    def getBusinessHours(self,ticketid):
        cursor = connections['ticketRead'].cursor()
        sql = "SELECT  fn_BusinessHrs(ticketid) as BusinessHours from swtickets where ticketid = "+str(ticketid)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        for i in result:
            resultSet['BusinessHours'] = i['BusinessHours']
        
        return resultSet
    def BusinessHoursStart(self,ticketid):
        cursor = connections['ticketRead'].cursor()
        sql = "SELECT  fn_BusinessDay(ticketid) as BussinesDay from swtickets where ticketid = "+str(ticketid)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        for i in result:
            resultSet['BussinesDay'] = i['BussinesDay']
        return resultSet
    
    def slaresolution(self,ticketId,responsetime):
         
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  @responseslavalue :=substring_index(getsla('"+str(ticketId)+"','response'),':',-1) as res "
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        data = result
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['res'] = i['res']
            result =resultSet['res']
            if(responsetime!=0 ):
                if resultSet['res'] !='NO SLA':
                    
                    if int(resultSet['res']) > responsetime:
                        
                        calucation = int(resultSet['res']) / responsetime
                        result =int(calucation *100)
                        if (result <25):
                            result ='SLA Level in the range of 0-25%'
                        elif (result < 50):
                            result = 'SLA leavel in the range of 26%-50%'
                        elif (result < 75):
                            result = 'SLA leavel in the range of 26%-50%'
                        else :
                             result ='SLA level in the range of 75%-100%'
                    else:
                        result = 'Breached'
                else:
                    result = 'NO SLA'
        else:
            result =''
        return result
            
    def priorty(self):
        cursor = connections['ticketRead'].cursor()
        sql = "select priorityid, display_text as title from swticketpriorities order by title"
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        for i in result:
            resultSet[i['priorityid']] = i['title']
        
        return resultSet
    
    
    def departments(self):
        cursor = connections['ticketRead'].cursor()
        sql = "SELECT departmentid,title FROM swdepartments WHERE departmentid NOT IN (0,1,2) ORDER BY title"
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        for i in result:
            resultSet[i['departmentid']] = i['title']
        
        return resultSet
        
    def ResolvedTime(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql = "(SELECT max(dateline) as resolved_date FROM swauditlogs WHERE ticketid="+str(ticketId)+" AND actionmsg LIKE '%To: Resolved' AND actiontype=8)"
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        for i in result:
            resultSet['resolved_date'] = i['resolved_date']
        
        return resultSet
    def getClosedDateTime(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql = "(SELECT max(dateline) as closed_date FROM swauditlogs WHERE ticketid="+str(ticketId)+" AND actionmsg LIKE '%To: Closed' AND actiontype=8)"
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        for i in result:
            resultSet['closed_date'] = i['closed_date']
        
        return resultSet
    
    def getTicketInfo(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql = "select * from ntsclienttickets where ticketid="+str(ticketId)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        for i in result:
            resultSet['typeId'] = i['typeid']
        
        return resultSet['typeId']
    
    def getAllTicketTypes(self):
        cursor = connections['ticketRead'].cursor()
        sql = "select typeid, typename from ntstickettype"
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        for i in result:
            resultSet[i['typeid']] = i['typename']
        
        return resultSet
        
        
    def deviceSite(self,deviceid):
        cursor = connections['ticketRead'].cursor()
        sql = "select ntsloc.name from ntsmspdevicedata ntsmspd join ntslocation ntsloc on ntsmspd.location_id=ntsloc.id where ntsmspd.id="+str(deviceid);
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)        
        cursor.close()
        resultSet={}
        if (len(result) >0):
            for i in result:
                resultSet['name'] = i['name']
        else:
            resultSet['name']=''        
        return resultSet['name']
    
    def deviceType(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql = "SELECT devicetype FROM ntsclienttickets ntsct JOIN ntsmspdevicedata dd ON dd.id = ntsct.deviceid WHERE ntsct.ticketid = "+str(ticketId);
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        if(len(result)>0):
            for i in result:
                resultSet['devicetype'] = i['devicetype'] 
        else:
            resultSet['devicetype'] = ''       
        devicetypeId = resultSet['devicetype']
        if devicetypeId !='':
            
            cursor = connections['ticketRead'].cursor()
            sql = "select devicetype from ntsdevice_type where id = "+str(devicetypeId)
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            resultSet={}
            if(len(result)>0):
                for i in result:
                    resultSet['devicetype'] = i['devicetype']
            else:
                resultSet['devicetype'] = ''
            
        return resultSet['devicetype']
        
    
    
    def deviceGroup(self,deviceid):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  ntsdg.name  FROM ntsdevice_group_mappings as ntsdgm LEFT JOIN ntsdevice_groups as ntsdg ON ntsdgm.groupid=ntsdg.id where ntsdgm.deviceid ="+str(deviceid);
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        if(len(result)>0):
            for i in result:
                resultSet['name'] = i['name']
        else:
            resultSet['name']=''
        return resultSet['name']
    
    def servicecategory(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql = "select * from ntsclienttickets where ticketid="+str(ticketId)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        if(len(result)>0):
            for i in result:
                resultSet['servicecatid'] = i['servicecatid']        
        servicecatid = resultSet['servicecatid']
        if servicecatid !='':
            
            cursor = connections['ticketRead'].cursor()
            sql = "select servicecatid, servicecatname from ntsservicecategories where servicecatid = "+str(servicecatid)
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            resultSet={}
            if(len(result)>0):
                for i in result:
                    resultSet['servicecatname'] = i['servicecatname']     
            else:
                resultSet['servicecatname'] = '' 
        return resultSet['servicecatname']
    
    
    def devicecategory(self,ticketId):
            
            cursor = connections['ticketRead'].cursor()
            sql = "select * from ntsclienttickets where ticketid="+str(ticketId)
            cursor.execute(sql)
            result = comObj.dictfetchall(cursor)
            cursor.close()
            resultSet={}
            for i in result:
                resultSet['devicecatid'] = i['devicecatid']
            
            devicecatid = resultSet['devicecatid']
            if devicecatid !='':
                
                cursor = connections['ticketRead'].cursor()
                sql = "select  devicecatname from ntsdevicecategories where devicecatid = "+str(devicecatid)
                cursor.execute(sql)
                result = comObj.dictfetchall(cursor)
                cursor.close()
                resultSet={}
                if(len(result)>0):
                    for i in result:
                        resultSet['devicecatname'] = i['devicecatname']
                else:
                    resultSet['devicecatname'] = ''
            return resultSet['devicecatname']
        
    def countofhealedalert(self,ticketid):
        cursor = connections['ticketRead'].cursor()
        sql = "select count(art) as count  from view_cumulative_alerts_info where art is not null and ticketid ="+str(ticketid)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        for i in result:
            resultSet['count'] = i['count']
            
        return resultSet['count']
    
    def totalcountofalert(self,ticketid):
        cursor = connections['ticketRead'].cursor()
        sql = "select count(id) as count  from view_cumulative_alerts_info where art is not null and ticketid ="+str(ticketid)
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        resultSet={}
        for i in result:
            resultSet['count'] = i['count']
            
            
        return resultSet['count']    
    
    
    def ticketId(self,ticketId):
        
        return ticketId

    def getHours(self,total):
        total = int(total)
        if(total == None): 
            return '-';
        if total < 0:
            total= -1 *total
        else :
            total= total    
        s = (total%60)
        m = (total/60)%60
        h = (total/3600)%24
        d = (total/86400)
        showtime=''
        if (d >0):
            showtime += ' '+str(d)+'d'
        if (h >0): 
            showtime += ' '+str(h)+'h'
        if (m >0):
            showtime += ' '+str(m)+'m'
        if(len(showtime)<=0):
            if (s>0):
                showtime += ' '+str(s)+'s'
            return showtime
        else:
            return showtime
        
    def getSLADisplayColumns(self,resolutionDue="",resolutionTimeInMins="",tStatus=""):
        
        slaDisplayColumns ={}
        responseDueText =""
        classs =''
        resolutionDueText = ""
        resolutionSlaState = ""
        overDueText = "Overdue"
        
        
        if(resolutionDue < 0):
            overDueText = 'OD:'
            resolutionDueText = overDueText +str(resolutionTimeInMins) ;
            resolutionSlaState = "UnMet";
            
        else:
            overDueText = "Time Left";
            overDueText = 'TL:';
            resolutionDueText = overDueText +str(resolutionTimeInMins)
            resolutionSlaState = "";
            
        slaDisplayColumns['resolutionDueText'] = resolutionDueText;
        slaDisplayColumns['resolutionSlaState'] = resolutionSlaState;
        #/* Background Colors Based On SLA Time */
        resolutionSlaBgColor = "";
        if overDueText == 'OD:':
            resolutionSlaBgColor = "background-color:#ffe8b2";
            classs = "OD"
        elif overDueText == 'TL:':
            
            total = int(resolutionDue);
                
            if(total == None):
                total=0;
            
            mins = int(total/60)
            if(mins <= 60):  #{// The Resolution Time Left is Less Than Or Equal To 60 Mins
                resolutionSlaBgColor = "background-color:#ffe8b2";
                classs = "spec-red";
            else:
                resolutionSlaBgColor = "background-color:#e6ee9c";
                classs = "TL1";
        else :
            resolutionSlaBgColor = "white";  
    
        slaDisplayColumns['resolutionSlaBgColor'] = resolutionSlaBgColor
        slaDisplayColumns['classcode'] = classs
        return slaDisplayColumns 
    # BREACHED TICKETS COUNTS      
    def getCountOfIncidentTicketsBySLA(self,prepareIncidentConditions,rsla,myticketFlag):       
        global IncidentResolutionSla                     
        sql = 'SELECT SQL_CALC_FOUND_ROWS DISTINCT(id.ticketid) FROM incident_data id  JOIN swtickets AS st ON st.ticketid=id.ticketid %s ' % (prepareIncidentConditions)     
        flag = False
        countresutl = {}
        countresutl[1] = countresutl[2] = countresutl[3] ="0"
        rslacount = 0 if myticketFlag == 0 else len(rsla)        
        sqlForSLACount = sql           
        if (rslacount == 0):
            if (flag == False):                
                sql = ' %s and  (id.resol_due between 0 AND 3600)  limit 1 ' % (sqlForSLACount)
                count1 = self.executeQueryGetCount(sql)
                flag = True          
                countresutl[1] = int(count1)                
            if (flag):
                sql = ' %s and  id.resol_due > 3600  limit 1 ' % (sqlForSLACount)
                count2 = self.executeQueryGetCount(sql)
                flag = True
                countresutl[2] = int(count2)               
                
            if (flag):
                sql = ' %s and  id.resol_due < 0  limit 1 ' % (sqlForSLACount)
                count3 = self.executeQueryGetCount(sql)                
                countresutl[3] = int(count3)        
        else:             
            for i in rsla:                             
                if (i == "1"):
                    sql = ' %s  and  (id.resol_due between 0 AND 3600)  limit 1 ' % (sqlForSLACount)
                    count1 = self.executeQueryGetCount(sql)           
                    countresutl[1] = int(count1)                    
                elif (i == "2"):
                    sql = ' %s and  id.resol_due > 3600  limit 1 ' % (sqlForSLACount)
                    count2 = self.executeQueryGetCount(sql)
                    countresutl[2] = int(count2)                                    
                elif (i == "3"):
                    sql = ' %s and  id.resol_due < 0  limit 1 ' % (sqlForSLACount)
                    count3 = self.executeQueryGetCount(sql)
                    countresutl[3] = int(count3)
        return countresutl

    def executeQueryGetCount(self, query): #TODO
        cursor = connections['ticketRead'].cursor()
        cursor.execute(query)
        count1 = comObj.dictfetchall(cursor)                
        cursor.close()  
        cursor = connections['ticketRead'].cursor()
        sql = 'select found_rows() as cnt'
        cursor.execute(sql)
        count1 = comObj.dictfetchall(cursor)                    
        cursor.close()            
        return count1[0]['cnt']

    def executeQuery(self, query): #TODO
        cursor = connections['ticketRead'].cursor()
        cursor.execute(query)
        result = comObj.dictfetchall(cursor)
        cursor.close()  
        return result
    
    def  getCustomFieldValue(self,customFieldId, ticketId):        
        sql = "SELECT fieldvalue FROM swcustomfieldvalues WHERE customfieldid='"+str(customFieldId)+"' AND typeid='"+str(ticketId)+"'";
        result = self.executeQuery(sql)
        data =''
        if len(result)>0:
            data =result[0]['fieldvalue']            
        return data
            
    def getCustomFields(self):
        swCustomFields = mem_cache.get('swCustomFields'+env)
        if not swCustomFields:
            cursor = connections['ticketRead'].cursor()
            sql = "SELECT \
                               swcustfld.customfieldid, \
                               swcustfld.title   \
                        FROM swcustomfields AS swcustfld \
                        JOIN swcustomfieldgroups AS swcustfldgrp ON swcustfldgrp.customfieldgroupid=swcustfld.customfieldgroupid \
                        WHERE swcustfld.title != 'LPI Ticket ID'    \
                        ORDER BY swcustfldgrp.title,  \
                                 swcustfld.title"
            cursor = connections['ticketRead'].cursor()
            cursor.execute(sql)
            customColuns  = comObj.dictfetchall(cursor)
            cursor.close()
            swCustomFields ={}
            for i  in customColuns:
                swCustomFields[i['customfieldid']] = i['title']
            mem_cache.set('swCustomFields'+env, swCustomFields, 86400)
        
        return swCustomFields
    
    def getDefaultCustomOrderBy(self):
        columns ={}
        sql = "SELECT * FROM sla_mgnt_custom_columns_old WHERE is_default_field= 1 and is_display = 1 order by display_order Asc"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        for res in result:
            columns[res['display_order']] = res['column_name']
        return columns
    
    

    def ticket_url(self,mspid):
        cursor = connections['ticketRead'].cursor()
        sql="SELECT ticket_url from nts_at_wsdlurl WHERE msp_id="+mspid;        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        customColuns  = comObj.dictfetchall(cursor)
        cursor.close()
        return customColuns
    
    "Ignorable method..NOT USING Present.."
    def getCountOfIncidentTicketsBySLA_GET(self,prepareIncidentConditions,templateid):
        resolutionSLACounts = {}    
        IncidentResolutionSla = {
                    '1' : "(id.resol_due between 0 AND 3600)",
                    '2' : " id.resol_due > 3600",
                    '3' : " id.resol_due < 0",
                }            
                      
       
        if prepareIncidentConditions.find('as a') > 0:
            sql = 'SELECT SQL_CALC_FOUND_ROWS DISTINCT(a.ticketid) FROM ' 
        else:
            sql = 'SELECT SQL_CALC_FOUND_ROWS DISTINCT(id.ticketid) FROM '
        
        sql += prepareIncidentConditions

        
        flag = False
        countresutl ={}
        sqlForSLACount = sql
        
        
        if(flag == False):
            cursor = connections['ticketRead'].cursor()
            k = sql.rfind("WHERE 1=1")
            if prepareIncidentConditions.find('incident_data') < 0:
                sql1 = sql[:k] + " JOIN incident_data id ON st.ticketid = id.ticketid WHERE 1=1 AND (id.resol_due between 0 AND 3600) " + sql[k+9:]
            else:
                sql1 = sql[:k] + " WHERE 1=1 AND (id.resol_due between 0 AND 3600) " + sql[k+9:]
        
            cursor.execute(sql1)
            result1 = comObj.dictfetchall(cursor)
            
            c1_sql = 'select found_rows() as cnt'
            cursor.execute(c1_sql)
            count1 = comObj.dictfetchall(cursor)
        
            cursor.close()
            flag = True
            countresutl[1] = count1[0]['cnt']
            
        if (flag):
            
            cursor = connections['ticketRead'].cursor()
            k = sql.rfind("WHERE 1=1")
            if prepareIncidentConditions.find('incident_data') < 0:
                sql2 = sql[:k] + " JOIN incident_data id ON st.ticketid = id.ticketid WHERE 1=1 AND id.resol_due > 3600 " + sql[k+9:]
            else:
                sql2 = sql[:k] + " WHERE 1=1 AND id.resol_due > 3600 " + sql[k+9:]
            
            cursor.execute(sql2)
            result2 = comObj.dictfetchall(cursor)
            
            c2_sql = 'select found_rows() as cnt'
            cursor.execute(c2_sql)
            count1 = comObj.dictfetchall(cursor)
            
            cursor.close()
            countresutl[2] = count1[0]['cnt']
            
            flag = True
        if (flag):
            
            cursor = connections['ticketRead'].cursor()
            k = sql.rfind("WHERE 1=1")
            if prepareIncidentConditions.find('incident_data') < 0:
                sql3 = sql[:k] + " JOIN incident_data id ON st.ticketid = id.ticketid WHERE 1=1 AND id.resol_due < 0 " + sql[k+9:]
            else:
                sql3 = sql[:k] + " WHERE 1=1 AND id.resol_due < 0 " + sql[k+9:]
            
            cursor.execute(sql3)
            result3 = comObj.dictfetchall(cursor)
            
            c3_sql = 'select found_rows() as cnt'
            cursor.execute(c3_sql)
            count1 = comObj.dictfetchall(cursor)
            
            cursor.close()
            countresutl[3] = count1[0]['cnt']
            
        return countresutl
    
    def getCustomFieldData(self, ticketId, custFieldId):
        cursor = connections['ticketRead'].cursor()
        sql = "SELECT swcustfld.title, swcustfldval.fieldvalue \
        FROM swcustomfieldvalues swcustfldval \
        JOIN swcustomfields AS swcustfld \
        ON swcustfld.customfieldid = swcustfldval.customfieldid \
        WHERE swcustfldval.typeid="+str(ticketId)+" \
        AND swcustfldval.customfieldid="+str(custFieldId)        
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        customColumnData  = comObj.dictfetchall(cursor)
        cursor.close()
        return customColumnData
    
    def getServiceType(self, deviceid):
        cursor = connections['ticketRead'].cursor()
        sql = "SELECT name as service_type FROM ntsviewdevice_service_map WHERE device_id='"+str(deviceid)+"'"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        serviceType = ''
        for res in result:
            serviceType = res['service_type']
        return serviceType
    
    def getScheduledTime(self,ticketid):
        sql = "select fieldvalue as scheduledTime from swcustomfieldvalues where customfieldid=12 and typeid='"+str(ticketid)+"'"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = comObj.dictfetchall(cursor)
        cursor.close()
        scheduledTime = ''
        for res in result:
            scheduledTime = res['scheduledTime']
        return scheduledTime
