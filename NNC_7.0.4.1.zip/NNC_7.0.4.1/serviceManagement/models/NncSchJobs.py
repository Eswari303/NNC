"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import models,connections


class NncSchJobs(models.Model):
    JobId = models.BigIntegerField(db_column='JobId', primary_key=True)  # Field name made lowercase.
    JobName = models.CharField(db_column='JobName', max_length=125, blank=True, null=True)  # Field name made lowercase.
    reportType = models.CharField(db_column='reportType', max_length=2, blank=True, null=True)  # Field name made lowercase.
    scheduleType = models.CharField(db_column='scheduleType', max_length=7, blank=True, null=True)  # Field name made lowercase.
    ispublic = models.IntegerField(db_column='IsPublic', blank=True, null=True)  # Field name made lowercase.
    templateid = models.BigIntegerField(db_column='templateId', blank=True, null=True)  # Field name made lowercase.
    createddate = models.DateTimeField(db_column='createdDate', blank=True, null=True)  # Field name made lowercase.
    createdby = models.BigIntegerField(db_column='createdBy', blank=True, null=True)  # Field name made lowercase.
    nextrunqueuetime = models.DateTimeField(db_column='NextRunQueueTime', blank=True, null=True)  # Field name made lowercase.
    lastruntime = models.DateTimeField(db_column='LastRunTime', blank=True, null=True)  # Field name made lowercase.
    laststatus = models.CharField(db_column='LastStatus', max_length=10, blank=True, null=True)  # Field name made lowercase.
    emailIds = models.CharField(db_column='emailIds', max_length=250, blank=True, null=True)  # Field name made lowercase.

    class Meta:
        db_table = 'nnc_sch_jobs'
        
    def getJobDetailsByTemplateIdAndUserId(self,userId,tType,templateId=0):
        sql = """SELECT j.JobId, j.JobName, j.reportType, j.scheduleType, j.LastRunTime, j.templateId, CONCAT(staff.staff_fname, ' ', staff.staff_lname)AS staff_name, tb.templateuserid, tb.lastdate, rec.* 
        FROM nnc_sch_jobs AS j JOIN nnc_job_sch_recurence AS rec ON rec.jobId = j.JobId JOIN ticketbrowser_templates tb ON tb.templateid = j.templateId LEFT JOIN nr_staff staff ON tb.templateuserid = staff.id 
        WHERE j.createdBy = """+str(userId)+""" AND j.scheduleType != 'RunNow' AND j.reportType = '"""+str(tType)+"""'"""
        if templateId > 0 :
            sql = sql + 'AND j.templateId = '+str(templateId)
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        return result
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]