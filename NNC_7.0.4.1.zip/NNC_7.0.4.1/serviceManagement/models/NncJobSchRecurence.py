"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import models

class NncJobSchRecurence(models.Model):
    JobId = models.IntegerField(db_column='jobId', primary_key=True)  # Field name made lowercase.
    recu_from = models.DateTimeField(blank=True, null=True)
    isnoenddate = models.IntegerField(blank=True, null=True)
    endafter = models.IntegerField(blank=True, null=True)
    recu_end = models.DateTimeField(blank=True, null=True)
    daily_iseveryweekday = models.IntegerField(blank=True, null=True)
    daily_everyaftergivendaycount = models.IntegerField(blank=True, null=True)
    weekly_recu_every_given_week = models.IntegerField(blank=True, null=True)
    weekly_weekdays = models.CharField(max_length=50, blank=True, null=True)
    monthly_rptDay = models.IntegerField(db_column='monthly_rptDay', blank=True, null=True)  # Field name made lowercase.
    monthly_theDay = models.CharField(db_column='monthly_theDay', max_length=50, blank=True, null=True)  # Field name made lowercase.
    execution_time = models.TimeField(blank=True, null=True)

    class Meta:
        db_table = 'nnc_job_sch_recurence'