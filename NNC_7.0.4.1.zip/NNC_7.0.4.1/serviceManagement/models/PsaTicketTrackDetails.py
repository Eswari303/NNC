"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import models,connections

class PsaTicketTrackDetails(object):
    
    def psa_lastactivity_date(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  psa_lastactivity_date FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId)
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['psa_lastactivity_date'] = i['psa_lastactivity_date']
            result =resultSet['psa_lastactivity_date']                  
        else:
            result =""
        return result
    
    def serviceBoardName(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  kyk_serviceboard FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId) 
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['kyk_serviceboard'] = i['kyk_serviceboard']
            result =resultSet['kyk_serviceboard'] 
        else:
            result =""
        return result
    
    def is_status_matched(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  is_status_matched FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId) 
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['is_status_matched'] = i['is_status_matched']
            result =resultSet['is_status_matched'] 
        else:
            result =""        
        return result
    
    def psaserviceboardmatched(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  kyk_serviceboard FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId) 
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()        
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['kyk_serviceboard'] = i['kyk_serviceboard']
            result =resultSet['kyk_serviceboard'] 
        else:
            result =""
        
        return result
    
    def psacurrentstatus(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  psa_status FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId) 
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['psa_status'] = i['psa_status']
            result =resultSet['psa_status'] 
        else:
            result =""
        return result
    
    def psapostcount(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  psa_post_count FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId) 
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['psa_post_count'] = i['psa_post_count']
            result =resultSet['psa_post_count'] 
        else:
            result =""
        return result
    
    def psadatacapturedon(self,ticketId):
        cursor = connections['ticketRead'].cursor()
        sql ="SELECT  script_pulleddate as 'psadata_as_on' FROM psa_ticket_track_details WHERE kyk_id ="+str(ticketId) 
        cursor.execute(sql)
        result = self.dictfetchall(cursor)
        cursor.close()
        resultSet ={}
        if len(result)>0:
            for i in result:
                resultSet['psadata_as_on'] = i['psadata_as_on']
            result =resultSet['psadata_as_on'] 
        else:
            result =""
        return result
    
    def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
                dict(zip([col[0] for col in desc], row)) 
                for row in cursor.fetchall() 
        ]