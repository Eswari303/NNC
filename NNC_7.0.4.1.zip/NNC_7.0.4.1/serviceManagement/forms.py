"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django import forms

class ServiceManagementForm(forms.Form):
    inputPat = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple)
    inputNoc = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple)
    inputCli = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple)
    inputSel = forms.MultipleChoiceField(widget=forms.CheckboxSelectMultiple)
class loadScheduleTemp(forms.Form):
    JobId = forms.IntegerField()
    recu_from = forms.DateTimeField()
    isnoenddate = forms.IntegerField()
    endafter = forms.IntegerField()
    recu_end = forms.DateTimeField()
    daily_iseveryweekday = forms.IntegerField()
    daily_everyaftergivendaycount = forms.IntegerField()
    weekly_recu_every_given_week = forms.IntegerField()
    weekly_weekdays = forms.CharField()
    monthly_rptDay = forms.IntegerField()
    monthly_theDay = forms.CharField()
    execution_time = forms.TimeField()
    JobName = forms.CharField()
    reportType = forms.CharField()
    scheduleType = forms.CharField()
    ispublic = forms.IntegerField()
    templateid = forms.IntegerField()
    createddate = forms.DateTimeField()
    createdby = forms.IntegerField()
    nextrunqueuetime = forms.DateTimeField()
    lastruntime = forms.DateTimeField()
    laststatus = forms.CharField()
    emailIds = forms.CharField()
    
    