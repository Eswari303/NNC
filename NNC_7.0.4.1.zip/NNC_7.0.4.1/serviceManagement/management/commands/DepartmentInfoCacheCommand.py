from django.core.management.base import BaseCommand
from django.core.cache import caches
from collections import defaultdict
#from NNCPortal.commonMethods import commonMethods
from NNCPortal.commonModels.Swticketstatus import Swticketstatus
from NNCPortal.commonModels.IncidentData import IncidentData
from serviceManagement.models.NtsNocDept import NtsNocDept
from serviceManagement.models.NtsTicketType import Ntstickettype
#from serviceManagement.models.commonModel import CommonServiceModel
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
#commobj = CommonServiceModel()
#comObj = commonMethods()
mem_cache = caches['memcached']
swtktstatus_obj = Swticketstatus()
incdata_obj = IncidentData()
env = configobj.getCommConfigValue(configobj.app_env)

class Command(BaseCommand):
    #args = 'Arguments is not needed'
    help = 'Django admin custom command poc.'
 
    def handle(self, *args, **options):
        self.stdout.write("\n Dept Counts Started \n\n")
        all_details={}
        all_details = self.getIncidentDeptdata_Result()     
        mem_cache.set('DeptResult0'+env, all_details, 86400)
        typeTree_details = self.getIncidentTicketTypeDeptdata_Result()
        nocTree = self.getIncidentNocTypeDeptdata_Result()
        #fnAr ={}
        #for key,eachTypeId in typeTree_details.iteritems():
            #print '************************* new 2nd ARRAY Started ********************************'
            #print key,'-----****-----',eachTypeId
       
    def getIncidentDeptdata_Result(self): 
        result = ''
        StatusTypes = {1 : "Active", 2: "Inactive", 3: "Closed"}
        #print "*********************** ch *************************************"
        newStatues = swtktstatus_obj.getNewStatus()
        result= incdata_obj.getPrepareNocDeptQuery()
        status_types=swtktstatus_obj.getGroupStausName()
        
        '''Below code to Display the data'''
        cacheData = {}
        typeArray = {}
        k = 0
        for results in result:
            cacheData.setdefault(results['deptid'], {})
            cacheData[results['deptid']].setdefault('title', results['dept'])
            if(results['statustype'] != 3):
                if cacheData[results['deptid']].has_key('TotalCount'): 
                    cacheData[results['deptid']]['TotalCount'] += results['count']
                else:
                    cacheData[results['deptid']].setdefault('TotalCount', defaultdict(int)) 
                    cacheData[results['deptid']]['TotalCount'] = results['count']
            results['statustype1'] = ''   
            results['statustype1'] = status_types[results['ticketstatusid']]
            cacheData[results['deptid']].setdefault('statusType', {})
            cacheData[results['deptid']]['statusType'].setdefault(results['statustype1'], {})
            
            #if cacheData[results['deptid']].has_key('statusType'):
            if cacheData[results['deptid']]['statusType'][results['statustype1']].has_key('statusCount'):
                cacheData[results['deptid']]['statusType'][results['statustype1']]['statusCount'] += results['count']    
            else:
                cacheData[results['deptid']]['statusType'][results['statustype1']].setdefault('statusCount', defaultdict(int))
                cacheData[results['deptid']]['statusType'][results['statustype1']]['statusCount'] = results['count']
            cacheData[results['deptid']]['statusType'][results['statustype1']].setdefault('status', {})
            cacheData[results['deptid']]['statusType'][results['statustype1']]['status'].setdefault(k, {})
            cacheData[results['deptid']]['statusType'][results['statustype1']]['status'][k].setdefault('statusid', results['ticketstatusid'])
            cacheData[results['deptid']]['statusType'][results['statustype1']]['status'][k].setdefault('statusname', newStatues[results['ticketstatusid']])
            cacheData[results['deptid']]['statusType'][results['statustype1']]['status'][k].setdefault('count', results['count'])
            k = k+1
        return cacheData
    
    def getIncidentTicketTypeDeptdata_Result(self):  
        result = ''
        StatusTypes = {1 : "Active", 2: "Inactive", 3: "Closed"}
        #print "***************************************************7h*****************************"
        newStatues = swtktstatus_obj.getNewStatus()
        result= incdata_obj.getByTicketTypeDeptCountQuery()
        status_types=swtktstatus_obj.getGroupStausName()
        '''Below code to Display the data'''
        k = 0
        temp ={}
        for results in result:    
            temp.setdefault(results['typeid'], {})
            temp[results['typeid']].setdefault(results['deptid'], {})
            temp[results['typeid']][results['deptid']].setdefault('title', results['dept'])
            if(results['statustype'] != 3):
                if temp[results['typeid']][results['deptid']].has_key('TotalCount'):
                    temp[results['typeid']][results['deptid']]['TotalCount'] += results['count']
                else:
                    temp[results['typeid']][results['deptid']].setdefault('TotalCount', defaultdict(int))
                    temp[results['typeid']][results['deptid']]['TotalCount'] = results['count']
            results['statustype1'] = ''  
            results['statustype1'] = status_types[results['ticketstatusid']]
            temp[results['typeid']][results['deptid']].setdefault('statusType', {})
            temp[results['typeid']][results['deptid']]['statusType'].setdefault(results['statustype1'], {})
            if temp[results['typeid']][results['deptid']]['statusType'][results['statustype1']].has_key('statusCount'):
                temp[results['typeid']][results['deptid']]['statusType'][results['statustype1']]['statusCount'] += results['count']
            else:
                temp[results['typeid']][results['deptid']]['statusType'][results['statustype1']].setdefault('statusCount',defaultdict(int))
                temp[results['typeid']][results['deptid']]['statusType'][results['statustype1']]['statusCount'] = results['count']
            
            temp[results['typeid']][results['deptid']]['statusType'][results['statustype1']].setdefault('status', {})
            temp[results['typeid']][results['deptid']]['statusType'][results['statustype1']]['status'].setdefault(k, {})
            temp[results['typeid']][results['deptid']]['statusType'][results['statustype1']]['status'][k].setdefault('statusid', results['ticketstatusid'])
            temp[results['typeid']][results['deptid']]['statusType'][results['statustype1']]['status'][k].setdefault('statusname', newStatues[results['ticketstatusid']])
            status_count = 0
            if temp[results['typeid']][results['deptid']]['statusType'][results['statustype1']]['status']:
                for kk,vv in temp[results['typeid']][results['deptid']]['statusType'][results['statustype1']]['status'].iteritems():
                    status_count = 0
                    countF =0
                    statusF =0
                    for k1,v1 in vv.iteritems():
                        if (k1 == 'count'):
                            countF = 1
                            status_count = v1
                            status_count = status_count+results['count']
                        if (k1 == 'statusid' and v1 == results['ticketstatusid']):
                            statusF = 1
            if status_count and statusF and countF:
                temp[results['typeid']][results['deptid']]['statusType'][results['statustype1']]['status'][k].setdefault('count', status_count) 
            else:
                temp[results['typeid']][results['deptid']]['statusType'][results['statustype1']]['status'][k].setdefault('count', results['count'])
            k=k+1
        mem_cache.set('TicketType_Tree'+env, temp, 86400)
        return temp
    
    
    def getIncidentNocTypeDeptdata_Result(self):  
        #result = mem_cache.get('result')
        result = ''
        StatusTypes = {1 : "Active", 2: "Inactive", 3: "Closed"}
        newStatues = swtktstatus_obj.getNewStatus()
        result = incdata_obj.getByNocTypeDeptQuery()
        status_types=swtktstatus_obj.getGroupStausName()    
        '''Below code to Display the data'''
        k = 0
        temp ={}
        for results in result:    
            temp.setdefault(results['nocid'], {})
            temp[results['nocid']].setdefault(results['deptid'], {})
            temp[results['nocid']][results['deptid']].setdefault('title', results['dept'])
            if(results['statustype'] != 3):
                if temp[results['nocid']][results['deptid']].has_key('TotalCount'):
                    temp[results['nocid']][results['deptid']]['TotalCount'] += results['count']
                else:
                    temp[results['nocid']][results['deptid']].setdefault('TotalCount', defaultdict(int))
                    temp[results['nocid']][results['deptid']]['TotalCount'] = results['count']
            results['statustype1'] = ''   
            results['statustype1'] = status_types[results['ticketstatusid']]
            temp[results['nocid']][results['deptid']].setdefault('statusType', {})
            temp[results['nocid']][results['deptid']]['statusType'].setdefault(results['statustype1'], {})
            if temp[results['nocid']][results['deptid']]['statusType'][results['statustype1']].has_key('statusCount'):
                temp[results['nocid']][results['deptid']]['statusType'][results['statustype1']]['statusCount'] += results['count']
            else:
                temp[results['nocid']][results['deptid']]['statusType'][results['statustype1']].setdefault('statusCount',defaultdict(int))
                temp[results['nocid']][results['deptid']]['statusType'][results['statustype1']]['statusCount'] = results['count']
            
            temp[results['nocid']][results['deptid']]['statusType'][results['statustype1']].setdefault('status', {})
            temp[results['nocid']][results['deptid']]['statusType'][results['statustype1']]['status'].setdefault(k, {})
            temp[results['nocid']][results['deptid']]['statusType'][results['statustype1']]['status'][k].setdefault('statusid', results['ticketstatusid'])
            temp[results['nocid']][results['deptid']]['statusType'][results['statustype1']]['status'][k].setdefault('statusname', newStatues[results['ticketstatusid']])
            status_count = 0
            if temp[results['nocid']][results['deptid']]['statusType'][results['statustype1']]['status']:
                for kk,vv in temp[results['nocid']][results['deptid']]['statusType'][results['statustype1']]['status'].iteritems():
                    status_count = 0
                    countF =0
                    statusF =0
                    for k1,v1 in vv.iteritems():
                        if (k1 == 'count'):
                            countF = 1
                            status_count = v1
                            status_count = status_count+results['count']
                        if (k1 == 'statusid' and v1 == results['ticketstatusid']):
                            statusF = 1
            if status_count and statusF and countF:
                temp[results['nocid']][results['deptid']]['statusType'][results['statustype1']]['status'][k].setdefault('count', status_count) 
            else:
                temp[results['nocid']][results['deptid']]['statusType'][results['statustype1']]['status'][k].setdefault('count', results['count'])
            k=k+1
        mem_cache.set('Noc_Tree'+env, temp, 86400)
        return temp

