from django.core.management import BaseCommand
from django.db import connection,connections
from django.core.cache import caches
from collections import defaultdict
#from NNCPortal.commonMethods import commonMethods
from NNCPortal.commonModels.Nocdetails import Nocdetails
from NNCPortal.commonModels.IncidentData import IncidentData
from NNCPortal.commonModels.Swticketstatus import Swticketstatus
#from serviceManagement.models.commonModel import CommonServiceModel
from NNCPortal.commonModels.IncidentData import IncidentData
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
#comobj = CommonServiceModel()
#comObj = commonMethods()
swtktstatus_obj = Swticketstatus()
incdata_obj= IncidentData()
mem_cache = caches['memcached']
env = configobj.getCommConfigValue(configobj.app_env)
    #The class must be named Command, and subclass BaseCommand
class Command(BaseCommand):
    # Show this when the user types help
    help = "My test command"

    # A command must define handle()
    def handle(self, *args, **options):
        #self.stdout.write("Doing All The Things!")
        self.stdout.write("\nList of NOCs \n\n")
        
        all_nocdetails={}
        #all_nocdetails = mem_cache.get('NocDeviceTreeView0')
        
        if not all_nocdetails:
            #print 'all noc details from db'
            all_nocdetails = self.getIncidentNocdeviceTypedata_Result()
            mem_cache.set('NocDeviceTreeView0'+env, all_nocdetails, 86400)
        #else:
            #print 'all noc details from chache'
        #result1 = self.getIncidentNocdeviceTypedata_Result('')
        #for key,each_item in all_nocdetails.items():
            #print '*************************ARRAY Started********************************'
            #print key,'---',each_item
        #print '+++++++++++++++++++++++  stopped   ++++++++++++++++++++++++++'
        typeTree_details = self.getIncidentNocdeviceTypedata_Result2()
        #for key,eachTypeId in typeTree_details.iteritems():
            #print '************************* new 2nd ARRAY Started ********************************'
            #print key,'-----****-----',eachTypeId
       
    def getIncidentNocdeviceTypedata_Result(self):
        ic = IncidentData()
        result = {}
        newStatues = swtktstatus_obj.getNewStatus()
        result = incdata_obj.getIncidentDeviceTypedata()
        StatusTypes = { 1 : 'Active', 2 : 'InActive', 3 : 'Closed'}
        data = {}
        status_types=swtktstatus_obj.getGroupStausName()
        k=1 
        for item in result:
    
            summ = 0
            allcount = 0
            data.setdefault(item['devicetypeid'],{})
            if(item['devicetypeid'] != ''):
                title = item['devicetype'] if(item['devicetype'] !='') else 'Defualt'
                data[item['devicetypeid']].setdefault('title', title)
            if(item['statustype'] != 3):
                #summ = summ +item['count']
                if data[item['devicetypeid']].has_key('TotalCount'): 
                    data[item['devicetypeid']]['TotalCount'] += item['count']
                else:
                    data[item['devicetypeid']].setdefault('TotalCount', defaultdict(int)) 
                    data[item['devicetypeid']]['TotalCount'] = item['count']
            #allcount = allcount + item['count'] 
            item['statustype1'] =''       
            item['statustype1'] = status_types[item['ticketstatusid']]
          
            data[item['devicetypeid']].setdefault('statusType', {})
            data[item['devicetypeid']]['statusType'].setdefault(item['statustype1'], {})
            
            if data[item['devicetypeid']]['statusType'][item['statustype1']].has_key('statusCount'):
                data[item['devicetypeid']]['statusType'][item['statustype1']]['statusCount'] += item['count']    
            else:
                data[item['devicetypeid']]['statusType'][item['statustype1']].setdefault('statusCount', defaultdict(int))
                data[item['devicetypeid']]['statusType'][item['statustype1']]['statusCount'] = item['count']
            #data[item['devicetypeid']]['statusType'][item['statustype1']].setdefault('statusCount', allcount)
            data[item['devicetypeid']]['statusType'][item['statustype1']].setdefault('status', {})
            data[item['devicetypeid']]['statusType'][item['statustype1']]['status'].setdefault(k, {})
            data[item['devicetypeid']]['statusType'][item['statustype1']]['status'][k].setdefault('statusid', item['ticketstatusid'])
            data[item['devicetypeid']]['statusType'][item['statustype1']]['status'][k].setdefault('statusname', newStatues[item['ticketstatusid']])
            data[item['devicetypeid']]['statusType'][item['statustype1']]['status'][k].setdefault('count', item['count'])
            k = k+1
        
        return data
    
    def getIncidentNocdeviceTypedata_Result2(self):  
        result = ''
        StatusTypes = {1 : "Active", 2: "Inactive", 3: "Closed"}
        #print "********************** 2nd *****************************"
        newStatues = swtktstatus_obj.getNewStatus()
        result= incdata_obj.getByTicketTypeDeviceCountQuery()
        status_types=swtktstatus_obj.getGroupStausName() 
        '''Below code to Display the data'''
        k = 0
        temp ={}
        for results in result:    
            temp.setdefault(results['typeid'], {})
            temp[results['typeid']].setdefault(results['devicetypeid'], {})
            temp[results['typeid']][results['devicetypeid']].setdefault('title', results['devicetype'])
            if(results['statustype'] != 3):
                if temp[results['typeid']][results['devicetypeid']].has_key('TotalCount'):
                    temp[results['typeid']][results['devicetypeid']]['TotalCount'] += results['count']
                else:
                    temp[results['typeid']][results['devicetypeid']].setdefault('TotalCount', defaultdict(int))
                    temp[results['typeid']][results['devicetypeid']]['TotalCount'] = results['count']
            results['statustype1'] = ''  
            results['statustype1'] = status_types[results['ticketstatusid']] 
            #results['statustype1'] = StatusTypes[results['statustype']]
            temp[results['typeid']][results['devicetypeid']].setdefault('statusType', {})
            temp[results['typeid']][results['devicetypeid']]['statusType'].setdefault(results['statustype1'], {})
            if temp[results['typeid']][results['devicetypeid']]['statusType'][results['statustype1']].has_key('statusCount'):
                temp[results['typeid']][results['devicetypeid']]['statusType'][results['statustype1']]['statusCount'] += results['count']
            else:
                temp[results['typeid']][results['devicetypeid']]['statusType'][results['statustype1']].setdefault('statusCount',defaultdict(int))
                temp[results['typeid']][results['devicetypeid']]['statusType'][results['statustype1']]['statusCount'] = results['count']
            
            temp[results['typeid']][results['devicetypeid']]['statusType'][results['statustype1']].setdefault('status', {})
            temp[results['typeid']][results['devicetypeid']]['statusType'][results['statustype1']]['status'].setdefault(k, {})
            temp[results['typeid']][results['devicetypeid']]['statusType'][results['statustype1']]['status'][k].setdefault('statusid', results['ticketstatusid'])
            temp[results['typeid']][results['devicetypeid']]['statusType'][results['statustype1']]['status'][k].setdefault('statusname', newStatues[results['ticketstatusid']])
            status_count = 0
            if temp[results['typeid']][results['devicetypeid']]['statusType'][results['statustype1']]['status']:
                for kk,vv in temp[results['typeid']][results['devicetypeid']]['statusType'][results['statustype1']]['status'].iteritems():
                    status_count = 0
                    countF =0
                    statusF =0
                    for k1,v1 in vv.iteritems():
                        if (k1 == 'count'):
                            countF = 1
                            status_count = v1
                            status_count = status_count+results['count']
                        if (k1 == 'statusid' and v1 == results['ticketstatusid']):
                            statusF = 1
            if status_count and statusF and countF:
                temp[results['typeid']][results['devicetypeid']]['statusType'][results['statustype1']]['status'][k].setdefault('count', status_count) 
            else:
                temp[results['typeid']][results['devicetypeid']]['statusType'][results['statustype1']]['status'][k].setdefault('count', results['count'])
            k=k+1
        mem_cache.set('DeviceTypeId_TreeCount'+env, temp, 86400)
        return temp
    
    """def dictfetchall(self,cursor): 
        "Returns all rows from a cursor as a dict" 
        desc = cursor.description 
        return [
            dict(zip([col[0] for col in desc], row)) 
            for row in cursor.fetchall() 
        ] """
