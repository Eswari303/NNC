from django.core.cache import caches
from django.core.management import BaseCommand
mem_cache = caches['memcached']
import sys
class Command(BaseCommand):
    def handle(self, *args, **options):
        #self.stdout.write("Please choose your choice... ", ending='')
        self.stdout.write("\n1. Clear all memcache data", ending='')
        self.stdout.write("\n2. Enter memcache key to get Vallue", ending='')
        self.stdout.write("\n3. Enter memcache key to flush", ending='')
        self.stdout.write("\n4. get aLL keys", ending='')
        input_var = raw_input("\nPlease choose your choice...\n")
        if int(input_var) == 1:
            print 'ALLClear()'
            self.ALLClear()
        if int(input_var) == 2:
            print 'calling getMemcacheValue(key)...'
            print self.getMemcacheValue()
        if int(input_var) == 3:
            print 'calling flushMemcacheValue(key)...'
            print self.flushMemcacheValue()
        if int(input_var) == 4:
            temp = self.get_all_memcached_keys(host='127.0.0.1', port=11211)
            for tt in temp:
                print '_____________________',tt.split(':')[2],'______________________'
        
    def ALLClear(self):
        #caches._caches.flush_all()
        self.stdout.write(" All memcache data cleared ", ending='')
        return mem_cache.clear()

    def getMemcacheValue(self):
        mkey = raw_input("Please enter key...\n")
        if mem_cache.has_key(str(mkey)):
            return mem_cache.get(str(mkey))
        else:
            self.stdout.write(" Key not existed in memcache", ending='')
    
    def flushMemcacheValue(self):
        mkey = raw_input("Please enter key...\n")
        if mem_cache.has_key(str(mkey)):
            return mem_cache.set(str(mkey), None, 0)
        else:
            self.stdout.write(" Key not existed in memcache", ending='')

    def get_all_memcached_keys(self,host='127.0.0.1', port=11211):
        import telnetlib
        t = telnetlib.Telnet(host, port)
        t.write('stats items STAT items:0:number 0 END\n')
        items = t.read_until('END').split('\r\n')
        keys = set()
        for item in items:
            parts = item.split(':')
            if not len(parts) >= 3:
                continue
            slab = parts[1]
            t.write('stats cachedump {} 200000 ITEM views.decorators.cache.cache_header..cc7d9 [6 b; 1256056128 s] END\n'.format(slab))
            cachelines = t.read_until('END').split('\r\n')
            for line in cachelines:
                parts = line.split(' ')
                if not len(parts) >= 3:
                    continue
                keys.add(parts[1])
        t.close()
        return keys