"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved."""
 
from django.shortcuts import render_to_response,render,HttpResponseRedirect
from django.template import loader,Context
from django.template import RequestContext
from NNCPortal.commonModels.NrStaff import NrStaff
nrstaff_obj = NrStaff()
from django.http import HttpResponse
from NNCPortal.commonModels.Swdepartments import Swdepartments
swdept_obj = Swdepartments()
from NNCPortal.commonModels.Swticketpriorities import Swticketpriorities
swpriorities_obj = Swticketpriorities()
from serviceManagement.models.commonModel import CommonServiceModel
comMObj=CommonServiceModel()
from NNCPortal.commonMethods import commonMethods
comObj = commonMethods()
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
import time,os,re,collections,string,requests
import json,sys
from NNCPortal.commonModels.Swticketpriorities import Swticketpriorities
from NNCPortal.commonModels.Swdepartments import Swdepartments
from NNCPortal.commonModels.Swticketstatus import Swticketstatus
from django.core.cache import caches
mem_cache = caches['memcached']
import os
os.environ["TZ"] = 'UTC'
import json as simplejson
import urlparse,ast
import urllib
from datetime import timedelta,datetime
import pytz,time
from pytz import timezone
swtktstatus_obj = Swticketstatus()

def ciscoUI(request):
    return render_to_response('testNEBOT.html', {},context_instance=RequestContext(request))
##################################### For Getting owner staffid #################################
def swSwaffId(ownerName):     
        
        # checking wheather proper command is given or not
        #if "@owner" in str(msglists[0]):
        if ownerName != '':
            #  fetching swstaff id based on employee username
            swstaff_id = NrStaff.objects.using('rosterRead').filter(user_name = str(ownerName))
            #return swstaff_id
            #  checking wheather user available or not
            if swstaff_id:
                #  if swstaff id is none sending not available response
                if swstaff_id[0].swstaff_id is None:
                    return HttpResponse('Owner not available')
                # if swstaff id is available executing below block
                else:
                    #message = str(msg[0]) +":"+str(swstaff_id[0].swstaff_id)
                    swStaffIdIs= swstaff_id[0].swstaff_id
                    return swStaffIdIs,True
                    #message = message.replace(str(ownerName),str(swstaff_id[0].swstaff_id))
                    #data_hub = message
            # if not available  return this response
            else:
                #print '**********************'
                msg = 'Invalid Owner name'
                return msg,False
        else:
            #data_hub = message
            #return HttpResponse('Please provide valid owner name')
            msg = 'Please provide valid owner name'
            return msg,False
            ''' end of finding owner '''
##############################################################################################

def search_fun(request):
    try:
        if request.method=='POST' and request.POST['ele']!='':
            message = request.POST['ele']
            HubotMessage = message
            #print 'HubotMessage',HubotMessage
            #return HttpResponse('sample data')
            #################### getting Uname,uid ans staffid from session######################
            uid = request.session['uId']
            uName = request.session['uName']
            userEmail = uName[:-14]
            userName = userEmail.split('.')
            loggedUser = str(userName[0])
            staffID  = request.session['swstaffId']
            dic = {}
            dic['operation_key'] = message
            dic['inputCmd'] = message
            dic['userName'] = uName
            dic['userId']=uid
            dic['staffID']=staffID
            sampleDict = {}
            ODict = {}
            res = []
            #######################prepare dicts for fetching ids ############################
            UDdict = {}
            Ddict = {'Ignore Tickets':1,'General':2,'CBU-Windows':3,'CBU-Network':5,'CBU-RSA Projects':6,'Smart Escalate':7,'MSP Tools':8,'CBU-PM-Desktops':9,'CBU-Patching':10,'CBU-Onboarding':11,'CBU-Escalations':12,'CBU-New Service Tickets':13,'Database':26,'Linux':28,'IT':34,'Auto Ticket':38,'CBU-Customer Reviews':44,'CBU-SBS-Windows':48,'EBU-KAR':51,'Order Admin':61,'CBU-Client Services':91,'EBU-GP':96,'CBU-AID1-Windows':126,'EBU-Windows':131,'EBU-Network':141,'EBU-Storage':151,'EBU-Virtualization':156,'EBU-PM-Desktops':181,'EBU-PM-Servers':191,'CBU-Manage2-Windows':201,'EBU-Transitions':211,'EBU-QoS':221,'NNC':231,'Automations':241,'Windows-Escalations':251,'Service Desk':261,'EBU-Backups':271,'VoIP':281,'Templates':291,'EBU-Citrix':301,'MSS':311,'Azure Services':331,'Azure Projects':341,'all':'all'}
            for key,value in Ddict.iteritems():
                UDdict[key.upper()] = value
                #print 'uddaya',value
                #print ("upper dept dict : ",Udict)
            
            UPdict = {}
            Pdict = {'Critical': 8, 'High': 9, 'Medium': 10, 'Low': 11, 'p0': 8, 'p1': 9, 'p2': 10, 'p3': 11}
            for key,value in Pdict.iteritems():
                UPdict[key.upper()] = value
            
            UPStatusDict = {}
            Statusdict = {'New':1,'On Hold':2,'Closed':3,'Resolved':5,'Work In Progress':7,'Handed Over to MSP':9,'Reviewed':11,'Under Observation':12,'Scheduled':16,'Completed':17,'Open':18,'Response due':19,'Alert Closed':20,'Self Heal':21,'Order Validation':22,'Order Accepted':23,'Start of Services':32,'Smart Escalate':41,'Waiting for Customer Inputs':46,'all':'all','active':'active','inactive':'inactive'}
            for key,value in Statusdict.iteritems():
                UPStatusDict[key.upper()] = value
            
            #####################searching with @ in input string####################
            if '@' in str(HubotMessage):
                HubotMessageList = HubotMessage.split("@")
                operation_key = HubotMessageList[0]
                if int(len(HubotMessageList)) > 1 and 'TICKET-COUNT' == str(HubotMessageList[1].upper()).strip():
                    sampleDict['ticket-count'] = "none"
                    HubotMessageList.remove(str(HubotMessageList[1]))
                dic['operation_key'] = operation_key
                HubotMessageList.remove(HubotMessageList[0])
                if int(len(sampleDict)) != 0 :     
                    dic['input_Json'] = str(sampleDict)
                if int(len(HubotMessageList)) >= 1  and ':' in str(HubotMessage):
                    for msg in HubotMessageList:
                        msgList = msg.split(':')          
                        sampleDict[str(msgList[0].strip())] = str(msgList[1].strip())
                        #if input string contains owner name, we are calling swSwaffId method and getting related swaffid
                        if 'owner' in  msgList[0]:
                            userstaffID,UserStatus = swSwaffId(msgList[1])
                            if UserStatus == False :
                                print '&&&&&&&&&&&&&&&&&&&&&&&&',userstaffID,UserStatus
                                #return HttpResponse('sample data')
                                return HttpResponse(userstaffID)
                            msgList[1] = userstaffID
                            #print '^^^^^^^^^^^^^^^^^',msgList[1]
                            sampleDict[((str(msgList[0])).strip())] = ((str(msgList[1])).strip())
                            ####################################getting related id's for keys from dept list, priority list and status list###############
                    DictLength = len(sampleDict)
                    try:
                        if DictLength != 0 :
                            for key, value in sampleDict.iteritems() :
                                #print "KeyValues : "+str(key)
                                #key =str(key).upper()
                                value = str(value).upper()
                                tempVal = str(value)
                                if ',' in str(value):
                                    #values = []
                                    value = value.split(',')
                                if type(value) is str : 
                                    if ('DEPT' in str(key).upper()) and (str(value) in Dep for Dep in UDdict):
                                        DeptId = UDdict[str(value).upper()]
                                        #print "Department ID :"+str(DeptId)+" for "+str(value)+" department..." 
                                        sampleDict[key] = DeptId
                                    elif ('PRIORITY' in str(key).upper()) and (str(value) in Pr for Pr in UPdict):
                                        PId = UPdict[str(value)]
                                        #print "Priority ID :"+str(PId)+" for "+str(value)+" priority..." 
                                        sampleDict[key] = PId
                                    elif 'TICKETID' in str(key).upper():
                                        sampleDict[key] = value
                                    elif 'STAFF' in str(key).upper():
                                        sampleDict[key] = value
                                    elif 'STATUS' in str(key).upper():
                                        sId = UPStatusDict[str(value.upper())]
                                        #print key,"status :::::::::::::::::::::",sId
                                        sampleDict[key] = sId
                                    elif 'RESOL' in str(key).upper():
                                        #print 'resol key,value********',key,value
                                        sampleDict[key] = int(value)*60
                                    else:    
                                        sampleDict[key]= str(value)
                                elif type(value) is list:
                                    tempVal = ''
                                    for val in value :
                                        if ('DEPT' in str(key).upper()) and (str(val).upper() in Dep for Dep in UDdict):
                                            tempVal += str(UDdict[str(val).upper()]) +","
                                        elif 'STATUS' in str(key).upper():
                                            #print "status condigtion    #######",UPStatusDict[str(val).upper()]
                                            tempVal += str(UPStatusDict[str(val).upper()]) +","
                                        elif 'TICKETID' in str(key).upper():
                                            tempVal += str(val) +","
                                        elif 'PRIORITY' in str(key).upper():
                                            tempVal += str(UPdict[str(val).upper()]) +","
                                    tempVal = tempVal[:-1]
                                    sampleDict[key] = tempVal
                    except Exception as msg:
                            return HttpResponse("<b>Invalid key :</b>Please provide valid keys.<font size='2' color='blue'><b>#get-help</b></font> for more info")  
                dic['input_Json'] = str(sampleDict)
                configobj = ConfigManager()
                r=requests.post(configobj.getCommConfigValue(configobj.HUBOTURL),data=dic)
                sample= r.content
                FDict = json.loads(str(sample))
                if type(FDict['Result']) is unicode :
                    res = ast.literal_eval(FDict['Result'])
                else:
                    res = FDict['Result']
                    ########################################## Hi or Hello string in HubotMessage###########
            elif 'HI' == str(HubotMessage.upper()) or 'HELLO' == str(HubotMessage.upper()):
                ODict["Hello "+str(loggedUser)] = "<br>Please enter <b>#get-help</b> for more info</br>"   
                ###############################################Get-help string found in HubotMessage #################################
            elif "#GET-HELP" in str(HubotMessage.upper()):
                ODict[" NEBOT helps you to get information for top 10 tickets, and also <u>update/post</u> a ticket by using put cmd"] = "<br> <u><b>Command:</b></u> #get @&lt;KEY&gt;:&lt;VALUE&gt; @&lt;KEY&gt;:&lt;VALUE&gt; <br> <b><u>ex:</u></b> #get @dept:CBU-Windows @resol:60 <br> <b><u>Command:</u></b> #get @ticket-count:today/now/yesterday/last week/last month/dd-mm-yyyy <br> <b><u>ex:</u></b> #get @ticket-count:today @status:new @dept:NNC <br> <b><u>Command:</u></b> #put-ticket @&lt;KEY&gt;:&lt;VALUE&gt; @&lt;KEY&gt;:&lt;VALUE&gt; <br> <b><u>ex:</u></b> #put-ticket @ticketid:1234567  @status:open @priority:p2 @owner:abc.xyz <br> #put-ticket @ticketid:123456  @status:new @priority:p2 @owner:abc.xyz @email:abc.xyz@netenrich.com @ccemail:abc.xyz@netenrich.com @post:test ticket pls ignore it<br><b><u>Available KEYs (PUT/GET):</u></b> <br>@ticketid (Text) (P/G)<br>@dept (Text) (P/G)<br>@priority (Text) (P/G)<br>@resol_due(Number in minutes)(G)<br>@owner (Text) (P/G) <br>@status (Text) (P/G)<br>@email (Email) (P)<br>@ccemail (Email) (P)<br>@post (Text) (P)<br> For Number fields you can use '<'(less than) <br> <b><u>Available LISTs:</u></b> <br>#get-depts<br>#get-priorities<br>#get-statuslist <br>#get-history<br>#get-history all<br> <b><u><font color='red'>NOTE</font></u></b>: you can click on ticketid to get more details. <br> for more queries please ping on skype to <b>nnc.ne.bot</b>" 
                ##################################get-Dept string found in HubotMessage #############################################
            elif '#GET-DEPTS' in str(HubotMessage.upper()):
                depts = ''
                for dept in sorted(Ddict):
                    depts += "<br>"+str(dept)
                ODict["Department List"] = str(depts)
                ################################get-PRIORITIES string found in HubotMessage ###################################
            elif "#GET-PRIORITIES" in str(HubotMessage.upper()):
                prioritys = ''
                for prt in sorted(Pdict) :
                    prioritys += "<br>"+str(prt)
                ODict["Priority List"] = str(prioritys)
                ##################################GET-StatusList found in HubotMessage ########################################
            elif "#GET-STATUSLIST" in str(HubotMessage.upper()):
                statusList = ''
                for sta in sorted(Statusdict) :
                    statusList += "<br>"+str(sta)
                ODict["Status List "] = str(statusList)
            elif ("#GET-HISTORY" in str(HubotMessage.upper()) ) or ( "#GET-HISTORY ALL" in str(HubotMessage.upper()) ) : 
                configobj = ConfigManager()
                r=requests.post(configobj.getCommConfigValue(configobj.HUBOTURL),data=dic)
                sample= r.content
                FDict = json.loads(str(sample))
                if type(FDict['Result']) is unicode :
                    res = ast.literal_eval(FDict['Result'])
                else:
                    res = FDict['Result']
            elif ("#GET-TEST" in str(HubotMessage.upper())): 
                configobj = ConfigManager()
                r=requests.post(configobj.getCommConfigValue(configobj.HUBOTURL),data=dic)
                userResponse = r.content
                print userResponse
                userCasualCmd = json.loads(str(userResponse))
                print '@@@@@@@@@@@@',type(userCasualCmd),userCasualCmd
                print '&&&&&&&&&&&&&&&&',res
                res = ''
                if type(userCasualCmd) is dict:
                    # res = ast.literal_eval(userCasualCmd['Result'])
                    print '^^^^^^^^^^^^^',type(userCasualCmd['Result'][0]),userCasualCmd['Result'][0]
                    for k,v in (userCasualCmd['Result'][0]).iteritems():
                            res += '<b>'+str(k)+':</b>'+str(v)+'<br>'
                    print '$$$$$$$$$',res
                    return HttpResponse(res)
                else:
                    print 'else part',res
                    res = FDict['Result']
                    print res
            else:
                return HttpResponse("Request not allowed<br>please #enter <font size='2' color='blue'><b>#get-help</b></font>")
            ##########################################sending data to coffee and getting data from python script########################################################
            try:
                #resultJson =len(sampleDict)
                #if resultJson != 0 or '#get-history' in dic.values() or '#get-history all' in dic.values() :
                #    #jsonInfo = json.dumps(dic)
                
                temp = ""
                def prepareHtml(res):
                    i = 0
                    html = ''
                    while i < int(len(res)):
                        tckInfois = res[i]
                        #if results contains ticketid we are preparing edit button here
                        if 'TicketId' in tckInfois.keys():
                            html += '<b>Ticket:</b>'
                            html += '<a target="_blank" href="/ticket/view/'+str(tckInfois['TicketId'])+'">'+str(tckInfois['TicketId'])+'</a>'
                            html += '<a href="javascript:void(0)" id="NBticketUpInfo" data-TicketId="'+str(tckInfois['TicketId'])+'"  data-Department="'+str(tckInfois['Department'])+'" data-Status="'+str(tckInfois['Status'])+'" data-Priority="'+str(tckInfois['Priority'])+'" data-Owner="'+str(tckInfois['Owner'])+'" ><i class="fa fa-pencil bs"></i></a>'
                            html += '<br>'
                            html += "<b>SLA Resolution:</b>"+str(tckInfois['SLA Resolution'])
                            html += '<br>'
                            html += "<b>Subj:</b>"+str(tckInfois['Subject'])
                            html += '<br>'
                            html += '<br>'
                            html += '<span id="quickeditinfo_'+str(tckInfois['TicketId'])+'op"></span>'
                        i = i + 1
                    return str(html)
                if (int(len(res)) <= 1) :
                    if int(len(ODict)) != 0:
                        ODict = ODict
                    elif 'TicketId' not in res[0].keys():
                        ODict = res[0]
                    else:
                        temp = prepareHtml(res)   
                    if temp == '': 
                        for k,v in (ODict).iteritems():
                            temp += '<b>'+str(k)+':</b>'+str(v)+'<br>'
                    return HttpResponse(temp)
                else:
                    temp = prepareHtml(res)
                    return HttpResponse(temp)
            except Exception as msg:
                return HttpResponse('Unable to pull the data')
        else:
            return HttpResponse("Request not********* allowed<br>please #enter <font size='2' color='blue'><b>#get-help</b></font>")
    except Exception as msg:
        return HttpResponse("Request not !!!!!!!!!!!!!!!!allowed<br>please #enter <font size='2' color='blue'><b>#get-help</b></font>")
def fistView(request):
    qucikInfo ={}
    statuslist = request.POST.get('status')
    qucikInfo['TicketId'] = request.POST.get('TicketId')
    qucikInfo['statusIs'] = request.POST.get('status')
    qucikInfo['departmentIs'] = request.POST.get('Department')
    qucikInfo['PriorityIs'] = request.POST.get('Priority')
    qucikInfo['ownerIs'] = request.POST.get('Owner')
    ####################getting status list from cache###################################
    #poststatus = mem_cache.get('newStatus')
    #if not poststatus:
    poststatus = swtktstatus_obj.getNewStatus()    
    #####################getting priorities list from cache#################################
    priorities = swpriorities_obj.getPriority()
    #priorities = mem_cache.get('priorities')
    #if not priorities:
            #priorities = Swticketpriorities.objects.using('ticketRead').only('priorityid').order_by('displayorder')
            #mem_cache.set('priorities', priorities, 86400)
    #########################getting departmnets list from cache###############################
    departments = swdept_obj.departments()
    #departments = mem_cache.get('departments')    
    #if not departments:
        #departments = Swdepartments.objects.using('ticketRead').only('title','departmentid').order_by('title')
        #mem_cache.set('departments', departments, 86400)
    ####################getting stafid from cache#######################
    #swStaff = mem_cache.get('swStaff')
    #if not swStaff:
    swStaff = nrstaff_obj.getSwStaffByRoster()
      #mem_cache.set('swStaff', swStaff, 86400)
    return render_to_response('testNEBOT.html',{'qucikInfo':qucikInfo,'swStaff':swStaff,'sampletext':'india','poststatus':poststatus,'departments':departments,'priorities':priorities},context_instance=RequestContext(request))
    
def qucikUpdateBot(request):
    quickInfoList ={}
    quickInfoList['userName'] = request.session['uName']
    quickInfoList['userId'] = request.session['uId']
    quickInfoList['staffID']  = request.session['swstaffId']
    quickInfoList['operation_key'] = 'put-ticket'
    quickInfoList['inputCmd'] = 'put-ticket'
    finalData = {}
    #############getting data from jquery and send data to hubot##########
    finalData['TicketId']=request.POST.get('ticketid',False)
    finalData['priority']=request.POST.get('priority',False)
    finalData['status']=request.POST.get('status',False)
    finalData['dept']=request.POST.get('departmentid',False)
    finalData['owner']=request.POST.get('ownerid',False)
    quickInfoList['input_Json']=str(finalData)
    #configobj = ConfigManager()
    r=requests.post(configobj.getCommConfigValue(configobj.HUBOTURL),data= quickInfoList)
    ticketUpdateInfo= r.content
    ticketStatus = json.loads(ticketUpdateInfo)
    temp =''
    FinalTktStatus = ticketStatus['Result']
    if type(FinalTktStatus) is unicode:
        finalUpdateResult = ast.literal_eval(FinalTktStatus)
    else:
        finalUpdateResult = FinalTktStatus
    for k,v in finalUpdateResult[0].iteritems():
        temp += '<b>'+str(k)+':</b>'+str(v)+'<br>'
    return HttpResponse(temp)
def employeePriorityinfoBot(request):
    
    quickInfoListNB ={}
    quickListNB = {}
    quickInfoListNB['userName'] = request.session['uName']
    quickInfoListNB['userId'] = request.session['uId']
    quickInfoListNB['staffID'] = request.session['swstaffId']
    quickInfoListNB['inputCmd'] = "GET_MYTICKET_INFO"
    quickInfoListNB['operation_key'] = "#get"
    quickListNB['priority'] =8  
    quickListNB['status'] = 18
    quickListNB['ticket-count'] = "Today" 
    #print '*************&&&&&&&&&&&&&',quickListNB,type(quickListNB)
    quickInfoListNB['input_Json'] = str(quickListNB)
    r=requests.post(configobj.getCommConfigValue(configobj.HUBOTURL),data= quickInfoListNB)
    ticketP0Info= r.content
    prioritystatus = json.loads(ticketP0Info)
    #print '*******************',type(prioritystatus),prioritystatus
    #sample ={}
    heading = "Tickets starts/breaches in 30minutes"
    sample = ''
    html = ''
    html += '<head><p style="font-size:22px;"><br>'+str(heading)+'</br></head>'
    prioritystatusInfo = prioritystatus['Result']
    #print '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@',type(prioritystatusInfo),prioritystatusInfo
    if type(prioritystatusInfo) is unicode:
        finalPriorityInfo = ast.literal_eval(prioritystatusInfo)
        #print '@@@@@@@@@@',type(finalPriorityInfo),finalPriorityInfo
    else:
        finalPriorityInfo = prioritystatusInfo
        print 'type of prioroty',type(finalPriorityInfo),finalPriorityInfo
        #print 'else part',finalPriorityInfo[0]
    for key,value in finalPriorityInfo[0].iteritems():
        #print '!!!!!!!!!!!!!!!!!!!!!!!!!!!',type(value)
        html += '<p style="font-size:18px;"><font color ="blue"><br>'+str(key)+'</br></font></p>'
        #print '^^^^^^^^^^^^^^^^^^^^^^^^^^^',value
        if isinstance(value,dict):
            for k,v in value.iteritems():
                #html += 
                testcase = '<b>'+str(k)+':</b>'+str(v)+'<br>'
                #print '********************',testcase
                sample = str(v)
                displayKeys = str(k)
                #sample = 2
                if sample == "No Records Found": 
                    sample = '0'
                    #print 'norecords found'
                    html += '<ul>'
                    html += '<li> <p style="font-size:14px;"><a href="#">'+str(displayKeys)+":"+" "+" "+" "+'<span class="badge badge-red" id=nbload>'+str(sample)+'</span></a></p></li>'
                    html +=  '</ul>'
                    #return HttpResponse(html)
                else:
                    html +='<ul>'
                    html += '<li> <p style="font-size:14px;"><a href="#">'+str(displayKeys)+":"+" "+" "+" "+'<span class="badge badge-red" id=nbload>'+str(sample)+'</span></a></p></li>'
                    html += '</ul>'
                #return HttpResponse(html)
    return HttpResponse(html)
''' ..................url encode function...................'''
def urlEncode(queryString,inputUrl,orderByField):
    try:
        url_params = urllib.quote(str(queryString))
        #print "#############order by : ",orderByField
        encodedUrl = inputUrl + url_params
        if orderByField != None : 
            encodedUrl += str('&'+orderByField)
        #print '****************getUrl!!!!!!!!!!!!!!!!!***********',encodedUrl
        resp = requests.get(encodedUrl)
        jsonData = str(resp.content)
        jsonData = json.loads(jsonData)
        return jsonData
    except Exception as msg:
        ex1Dict = {}
        FinalDict = {}
        PostDict = []
        ex1Dict['Error '] = str("While getting response from api"+str(msg))
        PostDict.append(ex1Dict)
        FinalDict['Result'] = PostDict
        FinalOp = json.dumps(FinalDict)
        print FinalOp
        sys.exit()
def popupWindowMsg(request):
    newTickcetInfo = {}
    UserEmail= request.session['uName']
    UserName = UserEmail[:-14]
    Users = UserName.split('.')
    LoggedUser = str(Users[0])#+" "+str(Users[1])
    newTickcetInfo['userName']  = LoggedUser
    
    #inputsec = 30
    getDBTime = requests.get("http://172.23.120.116:8000/v1/ticket/showcurrenttime")
    gettimefromAPI = str(getDBTime.content)
    convertData = json.loads(gettimefromAPI)
    for convertData1 in convertData['Result']:
        apitime= convertData1['curr_time']
    limitNB  = (int(apitime) - 30)
    userStaffIDNB = request.session['swstaffId']
    queryString = 'tableName:incident_data+staffid:'+str(userStaffIDNB)+'+created_dt:>'+str(limitNB)+'+selectFields:(ticketid,subject,priority)'
    inputUrl = "http://172.23.120.116:8000/v1/ticket/ticketingdata/?queryString="
    orderByField = None
    currentp0Info = urlEncode(queryString,inputUrl,orderByField)
    if "No Records Found" not in str(currentp0Info['Result']):
        for key,value in currentp0Info['Result'][0].iteritems():
            newTickcetInfo['flag'] = 1
            if "subject" in key:
                newTickcetInfo['subject'] = value
            elif "priority" in key:
                newTickcetInfo['priority'] = value
            elif "ticketid" in key:
                newTickcetInfo['ticketid'] = value
    else:
                 
        newTickcetInfo['flag'] = 0
    return HttpResponse(simplejson.dumps(newTickcetInfo),content_type="application/json")
    
        
