"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 * NetEnrich, Inc.
"""

from NNCPortal.commonModels.Ntsmspclients import Ntsmspclients
from ticket.models.commonModel import CommonTicketModel
ticketModelObj = CommonTicketModel()
from models.NeSdmtPlannedValueAdds import NeSdmtPlannedValueAdds
from models.NeSdmtPipeline import NeSdmtPipeline
from models.NeSdmtCancelDetails import NeSdmtCancelDetails
from models.NeSdmtPcancelDetails import NeSdmtPcancelDetails
from models.NeSdmtCommitments import NeSdmtCommitments
from models.NeSdmtReview import NeSdmtReview
from models.NeSdmtWklyTouchPoint import NeSdmtWklyTouchPoint
from models.NeSdmtPatLvlSummary import NeSdmtPatLvlSummary
from models.Ntsmsps import Ntsmsps1
from models.NeSdmtEsc import NeSdmtEsc
from models.NeSdmtKeyEngContacts import NeSdmtKeyEngContacts
from models.NeSdmtValueAdds import NeSdmtValueAdds
from models.NeSdmtActionItems import NeSdmtActionItems
from models.commonModel import SdmModel
sdmComObj = SdmModel()
from NNCPortal.commonModels.commonModelMethods import CommonModelMethods
insObj = CommonModelMethods()
from pytz import timezone
import pytz, os
from datetime import datetime
from NNCPortal.commonMethods import commonMethods
comObj = commonMethods()
import time

''' class for SDM Tracker services'''
class SDMTrackerService():
    currentMkTime = 0
    
    def __init__(self):
        currentTime = sdmComObj.curPst()
        currentMkTime = currentTime[0]['currentUnixTimestamp']
        self.currentMkTime = currentMkTime
        
    '''Method to prepare escalation tracker data'''
    def escTrackerResult(self, patId, saveData, edtData, recId, data):
        '''Preparing escalationg tracker results to display'''
        priorityImpact = {0:'Low', 1:'Medium', 2:'High'}
        curStatus = {0:'Active', 1:'WIP', 2:'Closed'}
        escTrackerData = {}
        escTrackerResults = NeSdmtEsc.objects.using('ticketRead').filter(mspid = patId)
        i = 0
        for escTrackerRes in escTrackerResults:
            escalationTrackerData = {}
            escalationTrackerData['escId'] = escTrackerRes.id
            os.environ["TZ"]="US/Pacific"
            escalationTrackerData['esc_date'] = str(datetime.fromtimestamp(int(escTrackerRes.esc_date)).strftime('%d %b %Y'))
            partnerName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = escTrackerRes.mspid).order_by('mspname')
            for partner in partnerName:
                escalationTrackerData['partner'] = partner.mspname
            clientName = Ntsmspclients.objects.using('ticketRead').filter(mspclientid = escTrackerRes.clientid).order_by('clientname')
            for client in clientName:
                escalationTrackerData['client'] = client.clientname
            escalationTrackerData['details_of_esc'] = escTrackerRes.details_of_esc
            escalationTrackerData['reported_by'] = escTrackerRes.reported_by
            escalationTrackerData['owner'] = escTrackerRes.owner
            escalationTrackerData['resolution_provided'] = escTrackerRes.resolution_provided
            escalationTrackerData['root_cause'] = escTrackerRes.root_cause
            for key, value in priorityImpact.iteritems():
                if key == escTrackerRes.priority_impact:
                    escalationTrackerData['priority_impact'] = value
            for key, value in curStatus.iteritems():
                if key == escTrackerRes.current_status:
                    escalationTrackerData['current_status'] = value
            escalationTrackerData['status_notes'] = escTrackerRes.status_notes
            escTrackerData[i] = escalationTrackerData
            i = i+1
        
        if saveData != None:
            '''Preparing data to insert record to database'''
            escTracker = {}
            esc_date = self.dateConversion(str(data.get('esc_date')))
            escTracker['esc_date'] = int(esc_date)
            escTracker['mspid'] = data.get('partner')
            escTracker['clientid'] = int(data.get('endClient'))
            escTracker['details_of_esc'] = data.get('detailsOfEsc')
            escTracker['reported_by'] = data.get('reportedByNam')
            escTracker['owner'] = data.get('owner')
            escTracker['resolution_provided'] = data.get('resolProvided')
            escTracker['root_cause'] = data.get('rootCause')
            escTracker['priority_impact'] = int(data.get('impact'))
            escTracker['current_status'] = int(data.get('currentStatus'))
            escTracker['status_notes'] = data.get('statusNotes')
            escTracker['last_modified'] = int(self.currentMkTime)
    
            '''Inserting the record to database'''
            insObj.insertRecord(escTracker, 'ne_sdmt_esc', 'ticketWrite')
        
        elif edtData != None:
            '''Preparing data to update record to database'''
            escTrackerEdit = {}
            esc_date = self.dateConversion(str(data.get('esc_date')))
            escTrackerEdit['esc_date'] = int(esc_date)
            escTrackerEdit['clientid'] = int(data.get('endClient'))
            escTrackerEdit['details_of_esc'] = data.get('detailsOfEsc')
            escTrackerEdit['reported_by'] = data.get('reportedByNam')
            escTrackerEdit['owner'] = data.get('owner')
            escTrackerEdit['resolution_provided'] = data.get('resolProvided')
            escTrackerEdit['root_cause'] = data.get('rootCause')
            escTrackerEdit['priority_impact'] = int(data.get('impact'))
            escTrackerEdit['current_status'] = int(data.get('currentStatus'))
            escTrackerEdit['status_notes'] = data.get('statusNotes')
            escTrackerEdit['last_modified'] = int(self.currentMkTime)
            
            cond = "id = "+edtData
            '''Updating the record to database'''
            insObj.updateRecord(escTrackerEdit, 'ne_sdmt_esc', cond, 'ticketWrite')
        
        elif recId != None:
            '''Deleting the record to database'''
            escTrackerRes = NeSdmtEsc.objects.using('ticketWrite').filter(id = recId)
            escTrackerRes.delete()
        return escTrackerData
    
    '''Method to prepare Key engagements contacts data'''
    def engContactDetailsResult(self, patId, saveData, edtData, kecId, data):
        '''Preparing escalationg tracker results to display'''
        engContactDetData = {}
        engContDetailsResults = NeSdmtKeyEngContacts.objects.using('ticketRead').filter(mspid = patId)
        i = 0
        for engContDetailsRes in engContDetailsResults:
            engContactDetailsData = {}
            engContactDetailsData['kecId'] = engContDetailsRes.id
            partnerName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = engContDetailsRes.mspid).order_by('mspname')
            for partner in partnerName:
                engContactDetailsData['partner'] = partner.mspname
            clientName = Ntsmspclients.objects.using('ticketRead').filter(mspclientid = engContDetailsRes.clientid).order_by('clientname')
            for client in clientName:
                engContactDetailsData['client'] = client.clientname
            engContactDetailsData['contact_person'] = engContDetailsRes.contact_person
            engContactDetailsData['contact_designation'] = engContDetailsRes.contact_designation
            engContactDetailsData['email'] = engContDetailsRes.email
            engContactDetailsData['phone'] = engContDetailsRes.phone
            engContactDetailsData['role'] = engContDetailsRes.role
            #engContactDetailsData['created_date'] = engContDetailsRes.created_date
            os.environ["TZ"]="US/Pacific"
            engContactDetailsData['created_date'] = str(datetime.fromtimestamp(int(engContDetailsRes.created_date)).strftime('%d %b %Y'))
            engContactDetailsData['impact'] = engContDetailsRes.impact
            engContactDetData[i] = engContactDetailsData
            i = i+1
        if saveData != None:
            '''Preparing data to insert record to database'''
            engConRes = {}
            engConRes['mspid'] = data.get('partner')
            engConRes['clientid'] = int(data.get('endClient'))
            engConRes['contact_person'] = data.get('contact_persn')
            engConRes['contact_designation'] = data.get('cont_des')
            engConRes['email'] = data.get('email_adr')
            engConRes['phone'] = data.get('phone_num')
            engConRes['role'] = data.get('role')
            date_crtd = self.dateConversion(str(data.get('date_crtd')))
            engConRes['created_date'] = int(date_crtd)
            engConRes['impact'] = data.get('imp_reltnshp')
            engConRes['last_modified'] = int(self.currentMkTime)
            
            '''Inserting the record to database'''
            insObj.insertRecord(engConRes, 'ne_sdmt_key_eng_contacts', 'ticketWrite')
            
        elif edtData != None:
            '''Preparing data to update record to database'''
            engConResEdit = {}
            #escTrackerEdit['mspid'] = request.POST.get('partner')
            engConResEdit['clientid'] = int(data.get('endClient'))
            engConResEdit['contact_person'] = data.get('contact_persn')
            engConResEdit['contact_designation'] = data.get('cont_des')
            engConResEdit['email'] = data.get('email_adr')
            engConResEdit['phone'] = data.get('phone_num')
            engConResEdit['role'] = data.get('role')
            date_crtd = self.dateConversion(str(data.get('date_crtd')))
            engConResEdit['created_date'] = int(date_crtd)
            engConResEdit['impact'] = data.get('imp_reltnshp')
            engConResEdit['last_modified'] = int(self.currentMkTime)
            
            cond = "id = "+edtData
            
            '''Updating the record to database'''
            insObj.updateRecord(engConResEdit, 'ne_sdmt_key_eng_contacts', cond, 'ticketWrite')
        
        elif kecId != None:
            '''Deleting the record to database'''
            kecRes = NeSdmtKeyEngContacts.objects.using('ticketWrite').filter(id = kecId)
            kecRes.delete()
        return engContactDetData
    
    '''Method to prepare Value Adds data'''
    def vafDetailsResult(self, patId, saveData, edtData, kecId, data):
        '''Preparing Value added results to display'''
        vafDetData = {}
        vafDetailsResults = NeSdmtValueAdds.objects.using('ticketRead').filter(mspid = patId)
        i = 0
        for vafDetailsRes in vafDetailsResults:
            vafContactDetailsData = {}
            vafContactDetailsData['vafId'] = vafDetailsRes.id
            partnerName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = vafDetailsRes.mspid).order_by('mspname')
            for partner in partnerName:
                vafContactDetailsData['partner'] = partner.mspname
            clientName = Ntsmspclients.objects.using('ticketRead').filter(mspclientid = vafDetailsRes.clientid).order_by('clientname')
            for client in clientName:
                vafContactDetailsData['client'] = client.clientname
            vafContactDetailsData['value_add_details'] = vafDetailsRes.value_add_details
            #vafContactDetailsData['implemented_date'] = vafDetailsRes.implemented_date
            os.environ["TZ"]="US/Pacific"
            vafContactDetailsData['implemented_date'] = str(datetime.fromtimestamp(int(vafDetailsRes.implemented_date)).strftime('%d %b %Y'))
            vafContactDetailsData['impact_val_add'] = vafDetailsRes.impact_val_add
            vafContactDetailsData['acknowledged_by'] = vafDetailsRes.acknowledged_by
            vafContactDetailsData['replication'] = vafDetailsRes.replication
            vafDetData[i] = vafContactDetailsData
            i = i+1
        if saveData != None:
            '''Preparing data to insert record to database'''
            vafRes = {}
            vafRes['mspid'] = data.get('partner')
            vafRes['clientid'] = int(data.get('endClient'))
            vafRes['value_add_details'] = data.get('val_add_details')
            implemented_date = self.dateConversion(str(data.get('impDate')))
            vafRes['implemented_date'] = int(implemented_date)
            vafRes['impact_val_add'] = data.get('impact_benefit')
            vafRes['acknowledged_by'] = data.get('acknolwedgedBy')
            vafRes['replication'] = data.get('replication')
            vafRes['last_modified'] = int(self.currentMkTime)
    
            '''Inserting the record to database'''
            insObj.insertRecord(vafRes, 'ne_sdmt_value_adds', 'ticketWrite')
            
        elif edtData != None:
            '''Preparing data to update record to database'''
            vafResEdit = {}
            #escTrackerEdit['mspid'] = request.POST.get('partner')
            vafResEdit['clientid'] = int(data.get('endClient'))
            vafResEdit['value_add_details'] = data.get('val_add_details')
            implemented_date = self.dateConversion(str(data.get('impDate')))
            vafResEdit['implemented_date'] = int(implemented_date)
            vafResEdit['impact_val_add'] = data.get('impact_benefit')
            vafResEdit['acknowledged_by'] = data.get('acknolwedgedBy')
            vafResEdit['replication'] = data.get('replication')
            vafResEdit['last_modified'] = int(self.currentMkTime)
            
            cond = "id = "+edtData

            '''Updating the record to database'''
            insObj.updateRecord(vafResEdit, 'ne_sdmt_value_adds', cond, 'ticketWrite')
        
        elif kecId != None:
            '''Deleting the record to database'''
            vafRes = NeSdmtValueAdds.objects.using('ticketWrite').filter(id = kecId)
            vafRes.delete()
        return vafDetData
    
    '''Method to prepare Planned Value Adds data'''
    def pvaDetailsResult(self, patId, saveData, edtData, kecId, data):
        '''Preparing Planned Value Adds results to display'''
        pvaDetData = {}
        pvaDetailsResults = NeSdmtPlannedValueAdds.objects.using('ticketRead').filter(mspid = patId)
        i = 0
        for pvaDetailsRes in pvaDetailsResults:
            pvaContactDetailsData = {}
            pvaContactDetailsData['pvaId'] = pvaDetailsRes.id
            partnerName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = pvaDetailsRes.mspid).order_by('mspname')
            for partner in partnerName:
                pvaContactDetailsData['partner'] = partner.mspname
            clientName = Ntsmspclients.objects.using('ticketRead').filter(mspclientid = pvaDetailsRes.clientid).order_by('clientname')
            for client in clientName:
                pvaContactDetailsData['client'] = client.clientname
            pvaContactDetailsData['value_add_details'] = pvaDetailsRes.value_add_details
            os.environ["TZ"]="US/Pacific"
            pvaContactDetailsData['pro_imp_date'] = str(datetime.fromtimestamp(int(pvaDetailsRes.pro_imp_date)).strftime('%d %b %Y'))
            pvaContactDetailsData['impact'] = pvaDetailsRes.impact
            pvaContactDetailsData['quantified_benefit'] = pvaDetailsRes.quantified_benefit
            pvaContactDetailsData['owner_ne'] = pvaDetailsRes.owner_ne
            pvaContactDetailsData['partner_contact'] = pvaDetailsRes.partner_contact
            pvaContactDetailsData['replication'] = pvaDetailsRes.replication   
            pvaDetData[i] = pvaContactDetailsData
            i = i+1
        
        if saveData != None:
            '''Preparing data to insert record to database'''
            vafRes = {}
            vafRes['mspid'] = data.get('partner')
            vafRes['clientid'] = data.get('endClient')
            vafRes['value_add_details'] = data.get('val_add_det')
            propImpDate = self.dateConversion(str(data.get('propImpDate')))
            vafRes['pro_imp_date'] = int(propImpDate)
            vafRes['impact'] = data.get('impactPfa')
            vafRes['quantified_benefit'] = data.get('quanBenifit')
            vafRes['owner_ne'] = data.get('ownerNe')
            vafRes['partner_contact'] = data.get('patContact')
            vafRes['replication'] = data.get('replication')
            vafRes['last_modified'] = int(self.currentMkTime)
    
            '''Inserting the record to database'''
            insObj.insertRecord(vafRes, 'ne_sdmt_planned_value_adds', 'ticketWrite')
            
        elif edtData != None:
            '''Preparing data to update record to database'''
            vafResEdit = {}
            #escTrackerEdit['mspid'] = request.POST.get('partner')
            vafResEdit['clientid'] = int(data.get('endClient'))
            vafResEdit['value_add_details'] = data.get('val_add_det')
            propImpDate = self.dateConversion(str(data.get('propImpDate')))
            vafResEdit['pro_imp_date'] = int(propImpDate)
            vafResEdit['impact'] = data.get('impactPfa')
            vafResEdit['quantified_benefit'] = data.get('quanBenifit')
            vafResEdit['owner_ne'] = data.get('ownerNe')
            vafResEdit['partner_contact'] = data.get('patContact')
            vafResEdit['replication'] = data.get('replication')
            vafResEdit['last_modified'] = int(self.currentMkTime)
            
            cond = "id = "+edtData

            '''Updating the record to database'''
            insObj.updateRecord(vafResEdit, 'ne_sdmt_planned_value_adds', cond, 'ticketWrite')
        
        elif kecId != None:
            '''Deleting the record to database'''
            pvaRes = NeSdmtPlannedValueAdds.objects.using('ticketWrite').filter(id = kecId)
            pvaRes.delete()
        return pvaDetData

    def aitDetailsResult(self, patId, saveData, edtData, kecId, data):
        '''Preparing Planned Value Adds results to display'''
        aitDetData = {}
        aitDetailsResults = NeSdmtActionItems.objects.using('ticketRead').filter(mspid = patId)
        i = 0
        for aitDetailsRes in aitDetailsResults:
            aitContactDetailsData = {}
            aitContactDetailsData['aitId'] = aitDetailsRes.id
            partnerName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = aitDetailsRes.mspid).order_by('mspname')
            for partner in partnerName:
                aitContactDetailsData['partner'] = partner.mspname
            clientName = Ntsmspclients.objects.using('ticketRead').filter(mspclientid = aitDetailsRes.clientid).order_by('clientname')
            for client in clientName:
                aitContactDetailsData['client'] = client.clientname
            os.environ["TZ"]="US/Pacific"
            aitContactDetailsData['created_date'] = str(datetime.fromtimestamp(int(aitDetailsRes.created_date)).strftime('%d %b %Y'))
            aitContactDetailsData['action_item_desc'] = aitDetailsRes.action_item_desc
            aitContactDetailsData['int_or_ext'] = aitDetailsRes.int_or_ext
            aitContactDetailsData['owner'] = aitDetailsRes.owner
            aitContactDetailsData['status'] = aitDetailsRes.status
            aitContactDetailsData['prop_end_date'] = str(datetime.fromtimestamp(int(aitDetailsRes.prop_end_date)).strftime('%d %b %Y'))
            aitContactDetailsData['target_comp_date'] = str(datetime.fromtimestamp(int(aitDetailsRes.target_comp_date)).strftime('%d %b %Y'))
            aitContactDetailsData['impact'] = aitDetailsRes.impact 
            aitDetData[i] = aitContactDetailsData
            i = i+1
        
        if saveData != None:
            '''Preparing data to insert record to database'''
            aitRes = {}
            aitRes['mspid'] = data.get('partner')
            aitRes['clientid'] = data.get('endClient')
            aitDate = self.dateConversion(str(data.get('aitDate')))
            aitRes['created_date'] = int(aitDate)
            aitRes['action_item_desc'] = data.get('aitDesc')
            aitRes['int_or_ext'] = data.get('intOrExt')
            aitRes['owner'] = data.get('aitOwnerPNe')
            aitRes['status'] = data.get('aitStatus')
            aitPropEndDat = self.dateConversion(str(data.get('aitPropEndDat')))
            aitRes['prop_end_date'] = int(aitPropEndDat)
            tgtCompDate = self.dateConversion(str(data.get('tgtCompDate')))
            aitRes['target_comp_date'] = int(tgtCompDate)
            aitRes['impact'] = data.get('impEngmnt')
            aitRes['last_modified'] = int(self.currentMkTime)
    
            '''Inserting the record to database'''
            insObj.insertRecord(aitRes, 'ne_sdmt_action_items', 'ticketWrite')
            
        elif edtData != None:
            '''Preparing data to update record to database'''
            aitResEdit = {}
            #escTrackerEdit['mspid'] = request.POST.get('partner')
            aitResEdit['clientid'] = int(data.get('endClient'))
            aitDate = self.dateConversion(str(data.get('aitDate')))
            aitResEdit['created_date'] = int(aitDate)
            aitResEdit['action_item_desc'] = data.get('aitDesc')
            aitResEdit['int_or_ext'] = data.get('intOrExt')
            aitResEdit['owner'] = data.get('aitOwnerPNe')
            aitResEdit['status'] = data.get('aitStatus')
            aitPropEndDat = self.dateConversion(str(data.get('aitPropEndDat')))
            aitResEdit['prop_end_date'] = int(aitPropEndDat)
            tgtCompDate = self.dateConversion(str(data.get('tgtCompDate')))
            aitResEdit['target_comp_date'] = int(tgtCompDate)
            aitResEdit['impact'] = data.get('impEngmnt')
            aitResEdit['last_modified'] = int(self.currentMkTime)
            
            cond = "id = "+edtData
            
            '''Updating the record to database'''
            insObj.updateRecord(aitResEdit, 'ne_sdmt_action_items', cond, 'ticketWrite')
        
        elif kecId != None:
            '''Deleting the record to database'''
            pplRes = NeSdmtActionItems.objects.using('ticketWrite').filter(id = kecId)
            pplRes.delete()
        return aitDetData
        
    def pplDetailsResult(self, patId, saveData, edtData, kecId, data):
        '''Preparing Planned Value Adds results to display'''
        pplDetData = {}
        pplDetailsResults = NeSdmtPipeline.objects.using('ticketRead').filter(mspid = patId)
        i = 0
        for pplDetailsRes in pplDetailsResults:
            pplContactDetailsData = {}
            pplContactDetailsData['pplId'] = pplDetailsRes.id
            partnerName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = pplDetailsRes.mspid).order_by('mspname')
            for partner in partnerName:
                pplContactDetailsData['partner'] = partner.mspname
            clientName = Ntsmspclients.objects.using('ticketRead').filter(mspclientid = pplDetailsRes.clientid).order_by('clientname')
            for client in clientName:
                pplContactDetailsData['client'] = client.clientname
            pplContactDetailsData['pipeline_description'] = pplDetailsRes.pipeline_description
            pplContactDetailsData['pipeline_amt'] = pplDetailsRes.pipeline_amt
            pplContactDetailsData['date_created'] = str(datetime.fromtimestamp(int(pplDetailsRes.date_created)).strftime('%d %b %Y'))
            pplContactDetailsData['ne_owner'] = pplDetailsRes.ne_owner
            pplContactDetailsData['pat_cli_owner'] = pplDetailsRes.pat_cli_owner
            pplContactDetailsData['est_close_date'] = str(datetime.fromtimestamp(int(pplDetailsRes.est_close_date)).strftime('%d %b %Y'))
            pplContactDetailsData['cur_status'] = pplDetailsRes.cur_status   
            pplDetData[i] = pplContactDetailsData
            i = i+1
        
        if saveData != None:
            '''Preparing data to insert record to database'''
            pplRes = {}
            pplRes['mspid'] = data.get('partner')
            pplRes['clientid'] = data.get('endClient')
            pplRes['pipeline_description'] = data.get('pipelineDesc')
            pplRes['pipeline_amt'] = data.get('pipelineAmt')
            pplCrtdDate = self.dateConversion(str(data.get('pplCrtdDate')))
            pplRes['date_created'] = int(pplCrtdDate)
            pplRes['ne_owner'] = data.get('pplNeOwner')
            pplRes['pat_cli_owner'] = data.get('patCliOwnr')
            estCloseDate = self.dateConversion(str(data.get('estCloseDate')))
            pplRes['est_close_date'] = int(estCloseDate)
            pplRes['cur_status'] = data.get('pplCurStatus')
            pplRes['last_modified'] = int(self.currentMkTime)
            
            '''Inserting the record to database'''
            insObj.insertRecord(pplRes, 'ne_sdmt_pipeline', 'ticketWrite')
            
        elif edtData != None:
            '''Preparing data to update record to database'''
            pplResEdit = {}
            #escTrackerEdit['mspid'] = request.POST.get('partner')
            pplResEdit['clientid'] = int(data.get('endClient'))
            pplResEdit['pipeline_description'] = data.get('pipelineDesc')
            pplResEdit['pipeline_amt'] = data.get('pipelineAmt')
            pplCrtdDate = self.dateConversion(str(data.get('pplCrtdDate')))
            pplResEdit['date_created'] = int(pplCrtdDate)
            pplResEdit['ne_owner'] = data.get('pplNeOwner')
            pplResEdit['pat_cli_owner'] = data.get('patCliOwnr')
            estCloseDate = self.dateConversion(str(data.get('estCloseDate')))
            pplResEdit['est_close_date'] = int(estCloseDate)
            pplResEdit['cur_status'] = data.get('pplCurStatus')
            pplResEdit['last_modified'] = int(self.currentMkTime)
            
            cond = "id = "+edtData
    
            '''Updating the record to database'''
            insObj.updateRecord(pplResEdit, 'ne_sdmt_pipeline', cond, 'ticketWrite')
        
        elif kecId != None:
            '''Deleting the record to database'''
            pplRes = NeSdmtPipeline.objects.using('ticketWrite').filter(id = kecId)
            pplRes.delete()
        return pplDetData
    
    '''Preparing results for Cancellation Details'''
    def canDetailsResult(self, patId, saveData, edtData, kecId, data):
        '''Preparing Planned Value Adds results to display'''
        canDetData = {}
        canDetailsResults = NeSdmtCancelDetails.objects.using('ticketRead').filter(mspid = patId)
        i = 0
        for canDetailsRes in canDetailsResults:
            canContactDetailsData = {}
            canContactDetailsData['canId'] = canDetailsRes.id
            partnerName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = canDetailsRes.mspid).order_by('mspname')
            for partner in partnerName:
                canContactDetailsData['partner'] = partner.mspname
            clientName = Ntsmspclients.objects.using('ticketRead').filter(mspclientid = canDetailsRes.clientid).order_by('clientname')
            for client in clientName:
                canContactDetailsData['client'] = client.clientname
            canContactDetailsData['date_of_cancellation'] = str(datetime.fromtimestamp(int(canDetailsRes.date_of_cancellation)).strftime('%d %b %Y'))
            canContactDetailsData['reason_for_cancellation'] = canDetailsRes.reason_for_cancellation
            canContactDetailsData['actions_to_prevent'] = canDetailsRes.actions_to_prevent
            canContactDetailsData['loss_value_acv'] = canDetailsRes.loss_value_acv  
            canDetData[i] = canContactDetailsData
            i = i+1
        
        if saveData != None:
            '''Preparing data to insert record to database'''
            pplRes = {}
            pplRes['mspid'] = data.get('partner')
            pplRes['clientid'] = data.get('endClient')
            cancDate = self.dateConversion(str(data.get('cancDate')))
            pplRes['date_of_cancellation'] = int(cancDate)
            pplRes['reason_for_cancellation'] = data.get('cancReason')
            pplRes['actions_to_prevent'] = data.get('actionsCan')
            pplRes['loss_value_acv'] = data.get('losValAcv')
            pplRes['last_modified'] = int(self.currentMkTime)
    
            '''Inserting the record to database'''
            insObj.insertRecord(pplRes, 'ne_sdmt_cancel_details', 'ticketWrite')
            
        elif edtData != None:
            '''Preparing data to update record to database'''
            canResEdit = {}
            #escTrackerEdit['mspid'] = request.POST.get('partner')
            canResEdit['clientid'] = int(data.get('endClient'))
            cancDate = self.dateConversion(str(data.get('cancDate')))
            canResEdit['date_of_cancellation'] = int(cancDate)
            canResEdit['reason_for_cancellation'] = data.get('cancReason')
            canResEdit['actions_to_prevent'] = data.get('actionsCan')
            canResEdit['loss_value_acv'] = data.get('losValAcv')
            canResEdit['last_modified'] = int(self.currentMkTime)
            
            cond = "id = "+edtData
    
            '''Updating the record to database'''
            insObj.updateRecord(canResEdit, 'ne_sdmt_cancel_details', cond, 'ticketWrite')
        
        elif kecId != None:
            '''Deleting the record to database'''
            pplRes = NeSdmtCancelDetails.objects.using('ticketWrite').filter(id = kecId)
            pplRes.delete()
        return canDetData
    
    '''Preparing results for Potential Cancellation Details'''
    def ptcDetailsResult(self, patId, saveData, edtData, kecId, data):
        '''Preparing Planned Value Adds results to display'''
        ptcDetData = {}
        ptcDetailsResults = NeSdmtPcancelDetails.objects.using('ticketRead').filter(mspid = patId)
        i = 0
        for ptcDetailsRes in ptcDetailsResults:
            ptcContactDetailsData = {}
            ptcContactDetailsData['ptcId'] = ptcDetailsRes.id
            partnerName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = ptcDetailsRes.mspid).order_by('mspname')
            for partner in partnerName:
                ptcContactDetailsData['partner'] = partner.mspname
            clientName = Ntsmspclients.objects.using('ticketRead').filter(mspclientid = ptcDetailsRes.clientid).order_by('clientname')
            for client in clientName:
                ptcContactDetailsData['client'] = client.clientname
            ptcContactDetailsData['threat_idntfd_date'] = str(datetime.fromtimestamp(int(ptcDetailsRes.threat_idntfd_date)).strftime('%d %b %Y'))
            ptcContactDetailsData['actions_identified'] = ptcDetailsRes.actions_identified
            ptcContactDetailsData['owner_ech_itm'] = ptcDetailsRes.owner_ech_itm
            ptcContactDetailsData['impacted_acv'] = ptcDetailsRes.impacted_acv
            ptcDetData[i] = ptcContactDetailsData
            i = i+1
        
        if saveData != None:
            '''Preparing data to insert record to database'''
            pplRes = {}
            pplRes['mspid'] = data.get('partner')
            pplRes['clientid'] = data.get('endClient')
            thrtIdntfdDate = self.dateConversion(str(data.get('thrtIdntfdDate')))
            pplRes['threat_idntfd_date'] = int(thrtIdntfdDate)
            pplRes['actions_identified'] = data.get('actionPrvntCanc')
            pplRes['owner_ech_itm'] = data.get('ownrEchItm')
            pplRes['impacted_acv'] = data.get('impctdAcv')
            pplRes['last_modified'] = int(self.currentMkTime)
    
            '''Inserting the record to database'''
            insObj.insertRecord(pplRes, 'ne_sdmt_pcancel_details', 'ticketWrite')
            
        elif edtData != None:
            '''Preparing data to update record to database'''
            ptcResEdit = {}
            #escTrackerEdit['mspid'] = request.POST.get('partner')
            ptcResEdit['clientid'] = int(data.get('endClient'))
            thrtIdntfdDate = self.dateConversion(str(data.get('thrtIdntfdDate')))
            ptcResEdit['threat_idntfd_date'] = int(thrtIdntfdDate)
            ptcResEdit['actions_identified'] = data.get('actionPrvntCanc')
            ptcResEdit['owner_ech_itm'] = data.get('ownrEchItm')
            ptcResEdit['impacted_acv'] = data.get('impctdAcv')
            ptcResEdit['last_modified'] = int(self.currentMkTime)
            
            cond = "id = "+edtData
    
            '''Updating the record to database'''
            insObj.updateRecord(ptcResEdit, 'ne_sdmt_pcancel_details', cond, 'ticketWrite')
        
        elif kecId != None:
            '''Deleting the record to database'''
            ptcRes = NeSdmtPcancelDetails.objects.using('ticketWrite').filter(id = kecId)
            ptcRes.delete()
        return ptcDetData
    
    '''Preparing results for Commitments tracker'''
    def cmtDetailsResult(self, patId, saveData, edtData, kecId, data):
        '''Preparing Planned Value Adds results to display'''
        cmtDetData = {}
        cmtDetailsResults = NeSdmtCommitments.objects.using('ticketRead').filter(mspid = patId)
        i = 0
        for cmtDetailsRes in cmtDetailsResults:
            cmtContactDetailsData = {}
            cmtContactDetailsData['cmtId'] = cmtDetailsRes.id
            partnerName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = cmtDetailsRes.mspid).order_by('mspname')
            for partner in partnerName:
                cmtContactDetailsData['partner'] = partner.mspname
            clientName = Ntsmspclients.objects.using('ticketRead').filter(mspclientid = cmtDetailsRes.clientid).order_by('clientname')
            for client in clientName:
                cmtContactDetailsData['client'] = client.clientname
            os.environ["TZ"]="US/Pacific"
            cmtContactDetailsData['week'] = str(datetime.fromtimestamp(int(cmtDetailsRes.week)).strftime('%d %b %Y'))
            cmtContactDetailsData['dedicated_resources'] = cmtDetailsRes.dedicated_resources
            cmtContactDetailsData['resp_sla'] = cmtDetailsRes.resp_sla
            cmtContactDetailsData['resol_sla'] = cmtDetailsRes.resol_sla
            cmtContactDetailsData['antivirus'] = cmtDetailsRes.antivirus
            cmtContactDetailsData['patchig'] = cmtDetailsRes.patchig
            cmtContactDetailsData['reason_if_red'] = cmtDetailsRes.reason_if_red
            cmtContactDetailsData['reports'] = cmtDetailsRes.reports   
            cmtDetData[i] = cmtContactDetailsData
            i = i+1
        
        if saveData != None:
            '''Preparing data to insert record to database'''
            cmtRes = {}
            cmtRes['mspid'] = data.get('partner')
            cmtRes['clientid'] = data.get('endClient')
            cmtWeek = self.dateConversion(str(data.get('cmtWeek')))
            cmtRes['week'] = int(cmtWeek)
            cmtRes['dedicated_resources'] = data.get('dedicated_resources')
            cmtRes['resp_sla'] = data.get('resp_sla')
            cmtRes['resol_sla'] = data.get('resol_sla')
            cmtRes['antivirus'] = data.get('antivirus')
            cmtRes['patchig'] = data.get('patchig')
            cmtRes['reports'] = data.get('reports')
            cmtRes['reason_if_red'] = data.get('reason_if_red')
            cmtRes['last_modified'] = int(self.currentMkTime)
    
            '''Inserting the record to database'''
            insObj.insertRecord(cmtRes, 'ne_sdmt_commitments', 'ticketWrite')
            
        elif edtData != None:
            '''Preparing data to update record to database'''
            cmtResEdit = {}
            #escTrackerEdit['mspid'] = request.POST.get('partner')
            cmtResEdit['clientid'] = data.get('endClient')
            cmtWeek = self.dateConversion(str(data.get('cmtWeek')))
            cmtResEdit['week'] = int(cmtWeek)
            cmtResEdit['dedicated_resources'] = data.get('dedicated_resources')
            cmtResEdit['resp_sla'] = data.get('resp_sla')
            cmtResEdit['resol_sla'] = data.get('resol_sla')
            cmtResEdit['antivirus'] = data.get('antivirus')
            cmtResEdit['patchig'] = data.get('patchig')
            cmtResEdit['reports'] = data.get('reports')
            cmtResEdit['reason_if_red'] = data.get('reason_if_red')
            cmtResEdit['last_modified'] = int(self.currentMkTime)
            
            cond = "id = "+edtData
    
            '''Updating the record to database'''
            insObj.updateRecord(cmtResEdit, 'ne_sdmt_commitments', cond, 'ticketWrite')
        
        elif kecId != None:
            '''Deleting the record to database'''
            cmtRes = NeSdmtCommitments.objects.using('ticketWrite').filter(id = kecId)
            cmtRes.delete()
        return cmtDetData
    
    '''Preparing results for Review tracker'''
    def rvtDetailsResult(self, patId, saveData, edtData, kecId, data):
        '''Preparing Planned Value Adds results to display'''
        rvtDetData = {}
        rvtDetailsResults = NeSdmtReview.objects.using('ticketRead').filter(mspid = patId)
        i = 0
        for rvtDetailsRes in rvtDetailsResults:
            rvtContactDetailsData = {}
            rvtContactDetailsData['rvtId'] = rvtDetailsRes.id
            partnerName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = rvtDetailsRes.mspid).order_by('mspname')
            for partner in partnerName:
                rvtContactDetailsData['partner'] = partner.mspname
            clientName = Ntsmspclients.objects.using('ticketRead').filter(mspclientid = rvtDetailsRes.clientid).order_by('clientname')
            for client in clientName:
                rvtContactDetailsData['client'] = client.clientname
            rvtContactDetailsData['weekly_review'] = rvtDetailsRes.weekly_review
            rvtContactDetailsData['monthly_review'] = rvtDetailsRes.monthly_review
            rvtContactDetailsData['quarterly_review'] = rvtDetailsRes.quarterly_review  
            rvtDetData[i] = rvtContactDetailsData
            i = i+1
        
        if saveData != None:
            '''Preparing data to insert record to database'''
            rvtRes = {}
            rvtRes['mspid'] = data.get('partner')
            rvtRes['clientid'] = data.get('endClient')
            rvtRes['weekly_review'] = data.get('weekly_review')
            rvtRes['monthly_review'] = data.get('monthly_review')
            rvtRes['quarterly_review'] = data.get('quarterly_review')
            rvtRes['last_modified'] = int(self.currentMkTime)
    
            '''Inserting the record to database'''
            insObj.insertRecord(rvtRes, 'ne_sdmt_review', 'ticketWrite')
            
        elif edtData != None:
            '''Preparing data to update record to database'''
            rvtResEdit = {}
            #escTrackerEdit['mspid'] = request.POST.get('partner')
            rvtResEdit['clientid'] = data.get('endClient')
            rvtResEdit['weekly_review'] = data.get('weekly_review')
            rvtResEdit['monthly_review'] = data.get('monthly_review')
            rvtResEdit['quarterly_review'] = data.get('quarterly_review')
            rvtResEdit['last_modified'] = int(self.currentMkTime)
            
            cond = "id = "+edtData
    
            '''Updating the record to database'''
            insObj.updateRecord(rvtResEdit, 'ne_sdmt_review', cond, 'ticketWrite')
        
        elif kecId != None:
            '''Deleting the record to database'''
            rvtRes = NeSdmtReview.objects.using('ticketWrite').filter(id = kecId)
            rvtRes.delete()
        return rvtDetData

    '''Preparing results for Weekly touch point tracker'''
    def wtpDetailsResult(self, patId, saveData, edtData, kecId, data):
        '''Preparing Planned Value Adds results to display'''
        wtpDetData = {}
        wtpDetailsResults = NeSdmtWklyTouchPoint.objects.using('ticketRead').filter(mspid = patId)
        i = 0
        for wtpDetailsRes in wtpDetailsResults:
            wtpContactDetailsData = {}
            wtpContactDetailsData['wtpId'] = wtpDetailsRes.id
            partnerName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = wtpDetailsRes.mspid).order_by('mspname')
            for partner in partnerName:
                wtpContactDetailsData['partner'] = partner.mspname
            clientName = Ntsmspclients.objects.using('ticketRead').filter(mspclientid = wtpDetailsRes.clientid).order_by('clientname')
            for client in clientName:
                wtpContactDetailsData['client'] = client.clientname 
            os.environ["TZ"]="US/Pacific"
            wtpContactDetailsData['date_of_meeting'] = str(datetime.fromtimestamp(int(wtpDetailsRes.date_of_meeting)).strftime('%d %b %Y'))
            wtpContactDetailsData['contact_name'] = wtpDetailsRes.contact_name
            wtpContactDetailsData['feedback'] = wtpDetailsRes.feedback 
            wtpDetData[i] = wtpContactDetailsData
            i = i+1
        
        if saveData != None:
            '''Preparing data to insert record to database'''
            wtpRes = {}
            wtpRes['mspid'] = data.get('partner')
            wtpRes['clientid'] = data.get('endClient')
            date_of_meeting = self.dateConversion(str(data.get('date_of_meeting')))
            wtpRes['date_of_meeting'] = int(date_of_meeting)
            wtpRes['contact_name'] = data.get('contact_name')
            wtpRes['feedback'] = data.get('feedback')
            wtpRes['last_modified'] = int(self.currentMkTime)
    
            '''Inserting the record to database'''
            insObj.insertRecord(wtpRes, 'ne_sdmt_wkly_touch_point', 'ticketWrite')
            
        elif edtData != None:
            '''Preparing data to update record to database'''
            wtpResEdit = {}
            #escTrackerEdit['mspid'] = request.POST.get('partner')
            wtpResEdit['clientid'] = int(data.get('endClient'))
            date_of_meeting = self.dateConversion(str(data.get('date_of_meeting')))
            wtpResEdit['date_of_meeting'] = int(date_of_meeting)
            wtpResEdit['contact_name'] = data.get('contact_name')
            wtpResEdit['feedback'] = data.get('feedback')
            wtpResEdit['last_modified'] = int(self.currentMkTime)
            
            cond = "id = "+edtData
    
            '''Updating the record to database'''
            insObj.updateRecord(wtpResEdit, 'ne_sdmt_wkly_touch_point', cond, 'ticketWrite')
        
        elif kecId != None:
            '''Deleting the record to database'''
            wtpRes = NeSdmtWklyTouchPoint.objects.using('ticketWrite').filter(id = kecId)
            wtpRes.delete()
        return wtpDetData
    
    '''Preparing results for Partner level summary'''
    def plsDetailsResult(self, patId, saveData, edtData, kecId, data):
        '''Preparing Planned Value Adds results to display'''
        plsDetData = {}
        lastWeek = {'Increased':'Increased', 'Neutral':'Neutral', 'Decreased':'Decreased'}
        plsDetailsResults = NeSdmtPatLvlSummary.objects.using('ticketRead').filter(mspid = patId)
        i = 0
        for plsDetailsRes in plsDetailsResults:
            plsContactDetailsData = {}
            plsContactDetailsData['wtpId'] = plsDetailsRes.id
            partnerName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = plsDetailsRes.mspid).order_by('mspname')
            for partner in partnerName:
                plsContactDetailsData['partner'] = partner.mspname
            plsContactDetailsData['sdm_name'] = plsDetailsRes.sdm_name
            plsContactDetailsData['rs_cur_mrr'] = plsDetailsRes.rs_cur_mrr 
            for key, value in lastWeek.iteritems():
                if key == plsDetailsRes.rs_las_wk:
                    plsContactDetailsData['rs_las_wk'] = value
            plsContactDetailsData['ds_cur'] = plsDetailsRes.ds_cur
            for key, value in lastWeek.iteritems():
                if key == plsDetailsRes.ds_las_wk:
                    plsContactDetailsData['ds_las_wk'] = value           
            plsContactDetailsData['pls_comments'] = plsDetailsRes.pls_comments
            plsDetData[i] = plsContactDetailsData
            i = i+1
        
        if saveData != None:
            '''Preparing data to insert record to database'''
            plsRes = {}
            plsRes['mspid'] = data.get('partner')
            plsRes['sdm_name'] = data.get('sdmName')
            plsRes['rs_cur_mrr'] = data.get('rsCurMrr')
            plsRes['rs_las_wk'] = data.get('rsLasWeek')
            plsRes['ds_cur'] = data.get('dsCurStatus')
            plsRes['ds_las_wk'] = data.get('dsLasWeek')
            plsRes['pls_comments'] = data.get('plsComments')
            plsRes['last_modified'] = int(self.currentMkTime)
            
            '''Inserting the record to database'''
            insObj.insertRecord(plsRes, 'ne_sdmt_pat_lvl_summary', 'ticketWrite')
            
        elif edtData != None:
            '''Preparing data to update record to database'''
            plsResEdit = {}
            #escTrackerEdit['mspid'] = request.POST.get('partner')
            plsResEdit['sdm_name'] = data.get('sdmName')
            plsResEdit['rs_cur_mrr'] = data.get('rsCurMrr')
            plsResEdit['rs_las_wk'] = data.get('rsLasWeek')
            plsResEdit['ds_cur'] = data.get('dsCurStatus')
            plsResEdit['ds_las_wk'] = data.get('dsLasWeek')
            plsResEdit['pls_comments'] = data.get('plsComments')
            plsResEdit['last_modified'] = int(self.currentMkTime)
            
            cond = "id = "+edtData
    
            '''Updating the record to database'''
            insObj.updateRecord(plsResEdit, 'ne_sdmt_pat_lvl_summary', cond, 'ticketWrite')
        
        elif kecId != None:
            '''Deleting the record to database'''
            plsRes = NeSdmtPatLvlSummary.objects.using('ticketWrite').filter(id = kecId)
            plsRes.delete()
        return plsDetData
    
    '''Method to track the SDM Tracker users and to track the functionalities of SDM Tracker'''
    def track_sdmt(self, data, accessString):
        if accessString == 'sdmTracker':
            '''Employee tracking'''
            trackSdmt = {}
            trackSdmt['staff_id'] = data.session['uId']
            trackSdmt['staff_name'] = data.session['fullName']
            date = comObj.timeStampToPST(self.currentMkTime)
            trackSdmt['track_time'] = str(date[0]['pstdate'])
            trkId = insObj.insertRecord(trackSdmt, 'ne_sdmt_emp_tracking', 'ticketWrite')
        else:
            '''Functionality tracking'''
            trackSdmtFun = {}
            trackSdmtFun['staff_id'] = data.session['uId']
            trackSdmtFun['staff_name'] = data.session['fullName']
            trackSdmtFun['fun_name'] = str(accessString)
            date = comObj.timeStampToPST(self.currentMkTime)
            trackSdmtFun['track_time'] = str(date[0]['pstdate'])
            trkId = insObj.insertRecord(trackSdmtFun, 'ne_sdmt_fun_tracking', 'ticketWrite')
        return trkId
    
    '''Method to display last updated date in main page'''
    def lastUpdatedDate(self, lastUpdated):
        lastModfd = ''
        if lastUpdated:
            utc = pytz.utc
            for recd in lastUpdated:   
                w_date = utc.localize(datetime.utcfromtimestamp(int(recd.last_modified)))
                au_tz = timezone('US/Pacific')
                w_date = w_date.astimezone(au_tz)
                lastModfd = w_date.strftime('%m/%d/%Y')
        return lastModfd
    
    '''Method to display parnter name and manager name on results page'''
    def partnerDetailsForTitle(self, partnerId):
        partnerDetails = {}
        patDetails = Ntsmsps1.objects.using('ticketRead').filter(mspid = partnerId)
        for patDet in patDetails:
            partnerDetails['mspname'] = patDet.mspname
            partnerDetails['acc_mngr'] = patDet.acc_mngr
        return partnerDetails
    
    '''Method to prepare excel data for Partner level summary excel genaration'''
    def prepareExcelData(self,titles,data):
        countFormData={}
        for k in titles:
            if k == "Partner Name":
                countFormData.setdefault('Partner Name',str(data['partner']).encode('utf-8'))
            if k == "SDM":
                countFormData.setdefault('SDM',str(data['sdm_name']).encode('utf-8'))
            if k == "Current MRR":
                countFormData.setdefault('Current MRR',str(data['rs_cur_mrr']).encode('utf-8'))
            if k == "Last Week":
                countFormData.setdefault('Last Week',str(data['rs_las_wk']).encode('utf-8'))
            
            '''Below conditions to write particular color string regarding the value'''
            if k == "Current Status":
                if str(data['ds_cur']) == '0':
                    countFormData.setdefault('Current Status', 'Green').encode('utf-8')
                if str(data['ds_cur']) == '1':
                    countFormData.setdefault('Current Status', 'Yellow').encode('utf-8')
                if str(data['ds_cur']) == '2':
                    countFormData.setdefault('Current Status', 'Red').encode('utf-8')
            if k == "Last Week Status":
                countFormData.setdefault('Last Week Status',str(data['ds_las_wk']).encode('utf-8'))
            if k == "Last Week Status":
                countFormData.setdefault('Comments',str(data['pls_comments']).encode('utf-8'))
        return countFormData
    
    '''To store MRR Information'''
    def weeklySumData(self,data, patId, sdm_id):
        currentTime = sdmComObj.curPst()
        currentMkTime = currentTime[0]['currentUnixTimestamp']
        utc = pytz.utc
        w_date = utc.localize(datetime.utcfromtimestamp(int(currentMkTime)))
        au_tz = timezone('US/Pacific')
        w_date = w_date.astimezone(au_tz)
        time = w_date.strftime('%m/%d/%Y')
        wklySum = {}
        wklySum['class_code'] = 'client'
        wklySum['org_id'] = data.POST['pk']
        wklySum['sdm_id'] = sdm_id
        wklySum['month'] = time = w_date.strftime('%m')
        wklySum['year'] = w_date.strftime('%Y')
        wklySum['mrr'] = float(data.POST['value'])
        wklySum['last_modified'] = int(self.currentMkTime)
        wsId = insObj.insertRecord(wklySum, 'ne_mrr_info', 'ticketWrite')
        return wsId
    
    def dateConversion(self, savDate):
        saveDateee = datetime.strptime(savDate, "%m/%d/%Y").strftime('%Y-%m-%d 00:00:00')
        saveDateee = sdmComObj.pstToUTCStamp(saveDateee)
        return saveDateee[0]['pstdate']