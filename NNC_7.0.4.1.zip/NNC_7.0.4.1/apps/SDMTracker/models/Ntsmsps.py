"""
 This computer program is the confidential information and proprietary trade
 secret of NetEnrich, Inc. Possessions and use of this program must
 conform strictly to the license agreement between the user and
 NetEnrich, Inc., and receipt or possession does not convey any rights
 to divulge, reproduce, or allow others to use this program without specific
 written authorization of NetEnrich, Inc.
  
 Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""

from django.db import models

class Ntsmsps1(models.Model):
    id = models.BigIntegerField(primary_key=True)
    mspid = models.BigIntegerField()
    mspname = models.CharField(max_length=255)
    status = models.IntegerField()
    mspcode = models.CharField(max_length=50, blank=True, null=True)
    updated_time = models.DateTimeField(blank=True, null=True)
    channel_id = models.IntegerField(blank=True, null=True)
    ticketing_module = models.IntegerField()
    tcks_support = models.IntegerField(blank=True, null=True)
    ticketing_system_id = models.BigIntegerField(blank=True, null=True)
    sdm_id = models.BigIntegerField(blank=True, null=True)
    acc_mngr = models.CharField(max_length=75, blank=True, null=True)
    acc_mngr_email = models.CharField(max_length=100, blank=True, null=True)
    acc_mngr_phone = models.CharField(max_length=50, blank=True, null=True)
    acc_mngr_address = models.TextField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'ntsmsps'
