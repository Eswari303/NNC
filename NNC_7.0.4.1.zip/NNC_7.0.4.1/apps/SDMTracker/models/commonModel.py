"""
 This computer program is the confidential information and proprietary trade
 secret of NetEnrich, Inc. Possessions and use of this program must
 conform strictly to the license agreement between the user and
 NetEnrich, Inc., and receipt or possession does not convey any rights
 to divulge, reproduce, or allow others to use this program without specific
 written authorization of NetEnrich, Inc.
  
 Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""

from django.db import connection,connections
from django.core.cache import caches
from _collections import defaultdict
from _mysql import NULL
from django.core.management.sql import sql_flush
mem_cache = caches['memcached']
from apps.SDMTracker.models.Ntsmsps import Ntsmsps1 
from apps.SDMTracker.models.NePartnerSummary import NePartnerSummary
import datetime
import pytz
from NNCPortal.commonMethods import commonMethods
common = commonMethods()

class SdmModel:

    def updateOrSaveRecord(self,partnerData):
        try:
            flag=0
            partnerRecord=Ntsmsps1.objects.using('ticketWrite').get(mspid=partnerData['mspid'])
            partnerRecord.sdm_id = partnerData['sdm_id']
            partnerRecord.acc_mngr = partnerData['acc_mngr']
            partnerRecord.acc_mngr_email = partnerData['acc_mngr_email']
            partnerRecord.acc_mngr_phone = partnerData['acc_mngr_phone']
            partnerRecord.acc_mngr_address = partnerData['acc_mngr_address']
            partnerRecord.save()
        except Exception as e:
            flag=1
            import logging
            log  = logging.getLogger('NNCPortal')
            log.info('')
            log.exception(' Exception in updateOrSaveRecord is -> %s'%str(e))
        finally:
            return flag
    
    def updateNePartnerSummary(self,weekDetails):
        try:
            result = NePartnerSummary.objects.using('ticketWrite').update_or_create(msp_id=weekDetails['msp_id'],client_id=weekDetails['client_id'],week_date=weekDetails['week_date'],defaults=weekDetails)
        except Exception as e:
            result = ('Failled')
            import logging
            log  = logging.getLogger('NNCPortal')
            log.info('')
            log.exception(' Exception in updateNePartnerSummary is -> %s'%str(e))
        return result
    
    def utcToPdt(self,utcdate):
        datetimelist = utcdate.split(" ")
        ''' here we are splitting utc datetime if length is > 1
            we split both time and date els only date'''
        if len(datetimelist) > 1:
            datelist = datetimelist[0].split("/")
            timelist = datetimelist[1].split(":")
        else:
            datelist = datetimelist[0].split("/")
            timelist = [0, 0, 0]
        pdt_tz = pytz.timezone("US/Pacific")
        ''' converting utc datetime to pdt time zone '''
        utc_dt = datetime.datetime(int(datelist[2]), int(datelist[0]), int(datelist[1]), int(timelist[0]), int(timelist[1]), 0, 0,pytz.UTC)
        local_dt = utc_dt.replace(tzinfo=pytz.utc).astimezone(pdt_tz)
        ''' returning the pdt time '''
        local_dt_list = str(local_dt).split(" ")
        local_dt_list1 = local_dt_list[1].split("-")
        finaldate = local_dt_list[0]+" "+"00:00"
        return finaldate
    
    def pstToUtc(self,utcdate):
        from time import mktime
        datetimelist = utcdate.split(" ")
        ''' here we are splitting utc datetime if length is > 1
            we split both time and date els only date'''
        if len(datetimelist) > 1:
            datelist = datetimelist[0].split("/")
            timelist = datetimelist[1].split(":")
        else:
            datelist = datetimelist[0].split("/")
            timelist = [0, 0, 0]
        utc_tz = pytz.utc
        pdt_tz = pytz.timezone("US/Pacific")
        ''' converting utc datetime to pdt time zone '''
        utc_dt = datetime.datetime(int(datelist[2]), int(datelist[0]), int(datelist[1]), int(timelist[0]), int(timelist[1]), 0, 0,pytz.UTC)
        local_dt = utc_dt.replace(tzinfo=pdt_tz).astimezone(utc_tz)
        local_dt_list = str(local_dt).split(" ")
        local_dt_list1 = local_dt_list[1].split(":")
        finaldate = local_dt_list[0]+" "+"00:00"
        return finaldate
    
    def stringToUnixTimeStamp(self,weekDate):
        sql = "select unix_timestamp('"+str(weekDate)+"') as timestamp from dual"
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = common.dictfetchall(cursor)
        cursor.close()
        return result
    
    def curPst(self):
        sql = "select UNIX_TIMESTAMP(now()) as currentUnixTimestamp from dual"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = common.dictfetchall(cursor)
        cursor.close()
        return result
    
    """ PST date to Unixtimestamp """
    def pstToUTCStamp(self,PstDate):
        if PstDate:
            sql = "SELECT UNIX_TIMESTAMP(CONVERT_TZ('"+str(PstDate)+"','-08:00','+00:00')) as pstdate FROM dual"
        else:
            return ''
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        pstDate = common.dictfetchall(cursor)
        cursor.close()
        return pstDate
    
    def staffData(self, nrstaffid):
        sql = "SELECT id,swstaff_id,staff_email,staff_fname, staff_lname FROM nr_staff WHERE is_active = 1 AND is_found = 1 AND swstaff_id > 0 AND id = "+str(nrstaffid)
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        staffData = common.dictfetchall(cursor)
        cursor.close()
        return staffData