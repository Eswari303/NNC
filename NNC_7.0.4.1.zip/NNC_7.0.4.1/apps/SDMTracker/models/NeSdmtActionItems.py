"""
 This computer program is the confidential information and proprietary trade
 secret of NetEnrich, Inc. Possessions and use of this program must
 conform strictly to the license agreement between the user and
 NetEnrich, Inc., and receipt or possession does not convey any rights
 to divulge, reproduce, or allow others to use this program without specific
 written authorization of NetEnrich, Inc.
  
 Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""

from django.db import models
class NeSdmtActionItems(models.Model):
    id = models.BigIntegerField(primary_key=True)
    mspid = models.IntegerField(blank=True, null=True)
    clientid = models.IntegerField(blank=True, null=True)
    created_date = models.IntegerField(blank=True, null=True)
    action_item_desc = models.TextField(blank=True, null=True)
    int_or_ext = models.CharField(max_length=20, blank=True, null=True)
    owner = models.TextField(blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    prop_end_date = models.IntegerField(blank=True, null=True)
    target_comp_date = models.IntegerField(blank=True, null=True)
    impact = models.TextField(blank=True, null=True)
    last_modified = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'ne_sdmt_action_items'