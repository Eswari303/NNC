"""
 This computer program is the confidential information and proprietary trade
 secret of NetEnrich, Inc. Possessions and use of this program must
 conform strictly to the license agreement between the user and
 NetEnrich, Inc., and receipt or possession does not convey any rights
 to divulge, reproduce, or allow others to use this program without specific
 written authorization of NetEnrich, Inc.
  
 Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""

from django.db import models
class NeSdmtEsc(models.Model):
    id = models.BigIntegerField(primary_key=True)
    esc_date = models.IntegerField(blank=True, null=True)
    mspid = models.IntegerField(blank=True, null=True)
    clientid = models.IntegerField(blank=True, null=True)
    details_of_esc = models.TextField(blank=True, null=True)
    reported_by = models.CharField(max_length=100, blank=True, null=True)
    owner = models.IntegerField(blank=True, null=True)
    resolution_provided = models.TextField(blank=True, null=True)
    root_cause = models.TextField(blank=True, null=True)
    priority_impact = models.IntegerField(blank=True, null=True)
    current_status = models.IntegerField(blank=True, null=True)
    status_notes = models.TextField(blank=True, null=True)
    last_modified = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'ne_sdmt_esc'