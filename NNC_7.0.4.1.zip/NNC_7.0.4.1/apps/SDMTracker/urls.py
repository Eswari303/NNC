"""
 This computer program is the confidential information and proprietary trade
 secret of NetEnrich, Inc. Possessions and use of this program must
 conform strictly to the license agreement between the user and
 NetEnrich, Inc., and receipt or possession does not convey any rights
 to divulge, reproduce, or allow others to use this program without specific
 written authorization of NetEnrich, Inc.
  
 Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""

"""NNCPortal URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Import the include() function: from django.conf.urls import url, include
    3. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import url,patterns
from views import SDMTrackerView

urlpatterns = patterns('', 
  url(r'^$', SDMTrackerView.SDMTracker),
  url(r'^SDMTracker2', SDMTrackerView.SDMTracker2),
  url(r'^SDMTracker3', SDMTrackerView.SDMTracker3),
  url(r'^SDMTracker3_1', SDMTrackerView.SDMTracker4),
  url(r'^SDMTracker4', SDMTrackerView.SDMTracker4_0),
  url(r'^SDMTracker5', SDMTrackerView.SDMTracker4_1),
  url(r'^SDMTracker6', SDMTrackerView.SDMTracker4_2),
  
  url(r'^savPartnerDetails', SDMTrackerView.savPartnerDetails),
  url(r'^addPartners', SDMTrackerView.addPartners),
  url(r'^showPartners',SDMTrackerView.sdmPartnerDetails),
  url(r'^partnerAjax$',SDMTrackerView.updatedPatnersDetails),
  url(r'^partnerSummary',SDMTrackerView.partnerSummary),
  url(r'^editPartners',SDMTrackerView.editPartners),
  url(r'^addWeekPatSummary', SDMTrackerView.addWeekPatSummary),
  url(r'^savWeekDetails', SDMTrackerView.savWeekDetails),
  
  url(r'^addWeekSummary', SDMTrackerView.weeklySummary),
  url(r'^patnerLevelSummary', SDMTrackerView.partnerLevelResults),
  url(r'^escalationTrackerResults', SDMTrackerView.escalationTrackerResults),
  url(r'^contactsResults', SDMTrackerView.contactsResults),
  url(r'^valueAddsResults', SDMTrackerView.valueAddsResult),
  url(r'^plannedValueAddsResults', SDMTrackerView.plannedValueAddsResults),
  url(r'^actionItemsTrackerResults', SDMTrackerView.actionItemsTrackerResults),
  url(r'^pipelineResults', SDMTrackerView.pipelineResults),
  url(r'^cancellationDetResults', SDMTrackerView.cancellationDetResults),
  url(r'^potCancelDetResults', SDMTrackerView.potCancelDetResults),
  url(r'^commTrackerResults', SDMTrackerView.commTrackerResults),
  url(r'^reviewTrackerResults', SDMTrackerView.reviewTrackerResults),
  url(r'^weeklyTchPntTrkrResults', SDMTrackerView.weekTouchptTrackerResults),

  url(r'^plsExcelDownload', SDMTrackerView.excelDownload),
)