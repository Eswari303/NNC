"""
 This computer program is the confidential information and proprietary trade
 secret of NetEnrich, Inc. Possessions and use of this program must
 conform strictly to the license agreement between the user and
 NetEnrich, Inc., and receipt or possession does not convey any rights
 to divulge, reproduce, or allow others to use this program without specific
 written authorization of NetEnrich, Inc.
  
 Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.shortcuts import render_to_response
from django.template import RequestContext
import json as simplejson
from django.http import HttpResponse
from apps.SDMTracker.models.NeSdmtKeyEngContacts import NeSdmtKeyEngContacts
from apps.SDMTracker.models.NeSdmtValueAdds import NeSdmtValueAdds
from apps.SDMTracker.models.NeSdmtPlannedValueAdds import NeSdmtPlannedValueAdds
from apps.SDMTracker.models.NeSdmtActionItems import NeSdmtActionItems
from apps.SDMTracker.models.NeSdmtPipeline import NeSdmtPipeline
from apps.SDMTracker.models.NeSdmtCancelDetails import NeSdmtCancelDetails
from apps.SDMTracker.models.NeSdmtPcancelDetails import NeSdmtPcancelDetails
from apps.SDMTracker.models.NeSdmtCommitments import NeSdmtCommitments
from apps.SDMTracker.models.NeSdmtWklyTouchPoint import NeSdmtWklyTouchPoint
from apps.SDMTracker.models.NeSdmtPatLvlSummary import NeSdmtPatLvlSummary
from apps.SDMTracker.models.NeSdmtReview import NeSdmtReview
from apps.SDMTracker.models.NeMrrInfo import NeMrrInfo
from django.core.cache import caches
mem_cache = caches['memcached']
from NNCPortal.commonMethods import commonMethods
comObj = commonMethods()
from apps.SDMTracker.models.Ntsmsps import Ntsmsps1
from NNCPortal.commonModels.Ntsmsps import Ntsmsps
msps_obj = Ntsmsps()
from NNCPortal.commonModels.Ntsmspclients import Ntsmspclients
from datetime import datetime
from pytz import timezone
import pytz, os
from ticket.models.commonModel import CommonTicketModel
from apps.SDMTracker.models.commonModel import SdmModel
from apps.SDMTracker.models.NePartnerSummary import NePartnerSummary
from apps.SDMTracker.models.NeSdmtEsc import NeSdmtEsc
import ast
from NNCPortal.commonModels.NrStaff import NrStaff
from django.http import HttpResponseRedirect
comM = SdmModel()
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
from NNCPortal.commonModels.commonModelMethods import CommonModelMethods
insObj = CommonModelMethods()
import collections
from apps.SDMTracker.serviceSDMTracker import SDMTrackerService
sdmtSerObj = SDMTrackerService()
from serviceManagement.models.commonModel import CommonServiceModel
comMObj = CommonServiceModel()
from django.contrib import messages

'''Dict for dropdowns regarding Escalation tracker module'''
priorityImpact = {0:'Low', 1:'Medium', 2:'High'}
currStatus = {0:'Active', 1:'Work In Progress', 2:'Closed'}

''' Below method is to check Mockup html'''
def SDMTracker1(request):
    return render_to_response('SDMTrackerMockup1.html', {},context_instance=RequestContext(request))

''' Below method is to check Mockup html'''
def SDMTracker2(request):
    return render_to_response('SDMTrackerMockup2.html', {},context_instance=RequestContext(request))

''' Below method is to check Mockup html'''
def SDMTracker3(request):
    return render_to_response('3SDMTracker.html', {},context_instance=RequestContext(request))

''' Below method is to check Mockup html'''
def SDMTracker4(request):
    return render_to_response('addWeekPatSummary.html', {},context_instance=RequestContext(request))
    
''' Below method is to check Mockup html'''
def SDMTracker4_0(request):
    return render_to_response('4SDMTracker.html', {},context_instance=RequestContext(request))
    
''' Below method is to check Mockup html'''
def SDMTracker4_1(request):
    return render_to_response('4_1SDMTracker.html', {},context_instance=RequestContext(request))
    
''' Below method is to check Mockup html'''
def SDMTracker4_2(request):
    return render_to_response('4_2SDMTracker.html', {},context_instance=RequestContext(request))



''' Load SDM Tracker '''
def SDMTracker(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                trackSdmt = sdmtSerObj.track_sdmt(request, 'sdmTracker')
                sdmId = request.session['uId']
                sdmMspName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(sdm_id = sdmId).order_by('mspname')
                ownerName = NrStaff.objects.using('rosterRead').only('staff_fname','staff_lname').filter(id = sdmId)
                for ownerNam in ownerName:
                            sdmName = ownerNam.staff_fname+' '+ownerNam.staff_lname
                sdmt_mspId = mem_cache.get('sdmt_mspId')
                if not sdmt_mspId:
                    sdmt_mspId = 0
                return render_to_response('SDMTracker.html', {'sdmMspName': sdmMspName, 'sdmName': sdmName, 'pId': sdmt_mspId},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - SDMTracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/serviceManagement/')
                                    
''' SDM adds his partners, Partners dropdown in color box '''
def addPartners(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            msps = Ntsmsps1.objects.using('ticketRead').only('mspname','mspid','sdm_id').filter(status=1).order_by('mspname')
            mspData = collections.OrderedDict()
            for msp in msps:
                if msp.sdm_id:
                    staffData = comM.staffData(msp.sdm_id)
                    mspData[msp.mspid] = {'mspName': msp.mspname,'staffName':str(staffData[0]['staff_fname']+' '+staffData[0]['staff_lname']), 'sdm_id': msp.sdm_id, 'disabled': 'disabled'}
                else:
                    mspData[msp.mspid] = {'mspName': msp.mspname,'staffName':'', 'disabled': ''}
            return render_to_response('addPartners.html', {'msps': mspData},context_instance=RequestContext(request))
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - addPartners -> %s'%str(e))
        return HttpResponseRedirect('/SDMTracker/')

'''Edit partner details'''
def editPartners(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            msps = msps_obj.getMSPSdata()
            #msps = mem_cache.get('msps')
            #if not msps:
                #msps = Ntsmsps.objects.using('ticketRead').only('mspname','mspid').filter(status=1).order_by('mspname')
                #mem_cache.set('msps', msps, 86400)
            pId = request.GET.get('pId')
            patDetails = Ntsmsps1.objects.using('ticketWrite').filter(mspid = pId)
            partnerData = {}
            
            for patDet in patDetails:
                partnerData['acc_mngr'] = patDet.acc_mngr
                partnerData['acc_mngr_email'] = patDet.acc_mngr_email
                partnerData['acc_mngr_phone'] = patDet.acc_mngr_phone
                partnerData['acc_mngr_address'] = patDet.acc_mngr_address
                partnerData['msp_name'] = patDet.mspname
                partnerData['mspid'] = patDet.mspid
            return render_to_response('addPartners.html',{'partnerData':partnerData,'msps': msps},context_instance=RequestContext(request))   
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - editPartners -> %s'%str(e))
        return HttpResponseRedirect('/SDMTracker/')

''' Saving Partner details, added by SDM '''
def savPartnerDetails(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            mspId = request.POST.getlist('partner')
            partnersData = {}
            partnersData['sdm_id'] = request.session['uId']
            partnersData['mspid'] = mspId[0]
            partnersData['acc_mngr'] = str(request.POST.get('accountMgr'))
            partnersData['acc_mngr_phone'] = str(request.POST.get('phone'))
            partnersData['acc_mngr_email'] = str(request.POST.get('emailAddress'))
            partnersData['acc_mngr_address'] = str(request.POST.get('address'))
            comM.updateOrSaveRecord(partnersData)
            mspName = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = mspId[0], status=1).order_by('mspname')
            for msp in mspName:
                partnersData['mspname'] = msp.mspname
            partnersData['sdm_id'] = request.session['uId']
            patDetails = Ntsmsps1.objects.using('ticketWrite').filter(mspid = mspId[0])
            partnerData = {}
            for patDet in patDetails:
                partnerData['acc_mngr'] = patDet.acc_mngr
                partnerData['acc_mngr_email'] = patDet.acc_mngr_email
                partnerData['acc_mngr_phone'] = patDet.acc_mngr_phone
                partnerData['acc_mngr_address'] = patDet.acc_mngr_address
                partnerData['msp_name'] = patDet.mspname
                partnerData['mspid'] = patDet.mspid
            jsonData = simplejson.dumps({'partnersData': partnersData})
            return HttpResponse(jsonData, content_type="application/json")
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - savPartnerDetails -> %s'%str(e))
        return HttpResponseRedirect('/SDMTracker/')

''' Display Partner details, on selection of Particular partner '''
def sdmPartnerDetails (request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            mspId = request.POST.getlist('patId')
            mem_cache.set('sdmt_mspId', mspId[0], 86400)
            patDetails = Ntsmsps1.objects.using('ticketWrite').filter(mspid = mspId[0])
            partnerDetails = {}
            partnerDetails['msp_id'] = mspId[0]
            mspName = Ntsmsps.objects.using('ticketRead').only('mspname').filter(mspid = mspId[0])
            
            for mspNam in mspName:
                partnerDetails['msp_name'] = mspNam.mspname
            
            for patDet in patDetails:
                partnerDetails['acc_mngr'] = patDet.acc_mngr
                partnerDetails['acc_mngr_email'] = patDet.acc_mngr_email
                partnerDetails['acc_mngr_phone'] = patDet.acc_mngr_phone
                partnerDetails['acc_mngr_address'] = patDet.acc_mngr_address
            
            ''' Last updated time for particular partner on main page '''
            lasUpdtdDetails = {}
            cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = mspId[0]).order_by('clientname')
            for cliDet in cliDetails:
                lastUpdated = NePartnerSummary.objects.using('ticketRead').only('last_modified').filter(msp_id = mspId[0]).order_by('last_modified')
                if lastUpdated:
                    utc = pytz.utc
                    for recd in lastUpdated:   
                        w_date = utc.localize(datetime.utcfromtimestamp(int(recd.last_modified)))
                        au_tz = timezone('US/Pacific')
                        w_date = w_date.astimezone(au_tz)
                        lasUpdtdDetails['lastModfd'] = w_date.strftime('%m/%d/%Y')
                else:
                    lasUpdtdDetails['lastModfd'] = ''
            
            '''To display Partner Level sumary last updated date'''
            plsLastUpdated = NeSdmtPatLvlSummary.objects.using('ticketRead').only('last_modified').filter(mspid = mspId[0]).order_by('last_modified')
            lasUpdtdDetails['plsLastModfd'] = sdmtSerObj.lastUpdatedDate(plsLastUpdated)
            '''To display Escalation tracker last updated date'''
            escLastUpdated = NeSdmtEsc.objects.using('ticketRead').only('last_modified').filter(mspid = mspId[0]).order_by('last_modified')
            lasUpdtdDetails['escLastModfd'] = sdmtSerObj.lastUpdatedDate(escLastUpdated)
            '''To display Key engagement contacts last updated date'''
            kecLastUpdated = NeSdmtKeyEngContacts.objects.using('ticketRead').only('last_modified').filter(mspid = mspId[0]).order_by('last_modified')
            lasUpdtdDetails['kecLastModfd'] = sdmtSerObj.lastUpdatedDate(kecLastUpdated)
            '''To display Value adds last updated date'''
            valLastUpdated = NeSdmtValueAdds.objects.using('ticketRead').only('last_modified').filter(mspid = mspId[0]).order_by('last_modified')
            lasUpdtdDetails['valLastModfd'] = sdmtSerObj.lastUpdatedDate(valLastUpdated)
            '''To display Planned value adds last updated date'''
            pvaLastUpdated = NeSdmtPlannedValueAdds.objects.using('ticketRead').only('last_modified').filter(mspid = mspId[0]).order_by('last_modified')
            lasUpdtdDetails['pvaLastModfd'] = sdmtSerObj.lastUpdatedDate(pvaLastUpdated)
            '''To display action items tracker last updated date'''
            aitLastUpdated = NeSdmtActionItems.objects.using('ticketRead').only('last_modified').filter(mspid = mspId[0]).order_by('last_modified')
            lasUpdtdDetails['aitLastModfd'] = sdmtSerObj.lastUpdatedDate(aitLastUpdated)
            '''To display Pipeline last updated date'''
            pplLastUpdated = NeSdmtPipeline.objects.using('ticketRead').only('last_modified').filter(mspid = mspId[0]).order_by('last_modified')
            lasUpdtdDetails['pplLastModfd'] = sdmtSerObj.lastUpdatedDate(pplLastUpdated)
            '''To display Cancellation details last updated date'''
            canLastUpdated = NeSdmtCancelDetails.objects.using('ticketRead').only('last_modified').filter(mspid = mspId[0]).order_by('last_modified')
            lasUpdtdDetails['canLastModfd'] = sdmtSerObj.lastUpdatedDate(canLastUpdated)
            '''To display Potential cancellation details last updated date'''
            pcaLastUpdated = NeSdmtPcancelDetails.objects.using('ticketRead').only('last_modified').filter(mspid = mspId[0]).order_by('last_modified')
            lasUpdtdDetails['pcaLastModfd'] = sdmtSerObj.lastUpdatedDate(pcaLastUpdated)
            '''To display Commitments tracker last updated date'''
            comLastUpdated = NeSdmtCommitments.objects.using('ticketRead').only('last_modified').filter(mspid = mspId[0]).order_by('last_modified')
            lasUpdtdDetails['comLastModfd'] = sdmtSerObj.lastUpdatedDate(comLastUpdated)
            '''To display Review tracker last updated date'''
            rvwLastUpdated = NeSdmtReview.objects.using('ticketRead').only('last_modified').filter(mspid = mspId[0]).order_by('last_modified')
            lasUpdtdDetails['rvwLastModfd'] = sdmtSerObj.lastUpdatedDate(rvwLastUpdated)
            '''To display Weekly touch point tracker last updated date'''
            wtpLastUpdated = NeSdmtWklyTouchPoint.objects.using('ticketRead').only('last_modified').filter(mspid = mspId[0]).order_by('last_modified')
            lasUpdtdDetails['wtpLastModfd'] = sdmtSerObj.lastUpdatedDate(wtpLastUpdated)
                
            jsonData = simplejson.dumps({'partnerDetails' : partnerDetails, 'lasUpdtdDetails' : lasUpdtdDetails})
            return HttpResponse(jsonData, content_type="application/json")
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - sdmPartnerDetails -> %s'%str(e))
        return HttpResponseRedirect('/SDMTracker/')

'''Method to save and prepare Weekly summary data'''
def partnerSummary(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                partnerId = request.GET.get('patId',False)
                partnerDetails = {}
                configobj = ConfigManager()
                colorArray = configobj.getCommConfigValue(configobj.colorArray)
                colorArray = ast.literal_eval(colorArray) 
                patDetails = Ntsmsps1.objects.using('ticketRead').filter(mspid = partnerId)
                for patDet in patDetails:
                    partnerDetails['mspname'] = patDet.mspname
                    partnerDetails['acc_mngr'] = patDet.acc_mngr
                cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = partnerId).order_by('clientname')
                clientDetails = {}
                mrrInfoVal = {} #Dictionary to display MRR Information
                mspSummary = {}
                for cliDet in cliDetails:
                    tmp = 'details_'+str(cliDet.mspclientid)
                    clientDetails[tmp]={}
                    clientDetails[tmp]['client_id'] = cliDet.mspclientid
                    clientDetails[tmp]['client_name'] = cliDet.clientname
                    clientDetails[tmp]['weekDetails']=[]
                    summary = NePartnerSummary.objects.using('ticketRead').filter(msp_id = partnerId,client_id = cliDet.mspclientid).order_by('week_date')
                    if summary:
                        utc = pytz.utc
                        '''Below for loop to prepare and display Week details'''
                        for recd in summary:
                            clientDetails1 = {}
                            w_date = utc.localize(datetime.utcfromtimestamp(int(recd.week_date)))
                            au_tz = timezone('Asia/Kolkata')
                            w_date = w_date.astimezone(au_tz)
                            clientDetails1['cal_date']= w_date.strftime('%m/%d/%Y')
                            w_date = w_date.strftime("%b %d")
                            clientDetails1['week_date']= w_date
                            clientDetails1['color_code']= recd.color_code
                            clientDetails1['summary']= recd.summary
                            clientDetails1['updated_by']= recd.updated_by
                            clientDetails1['last_modified']= recd.last_modified
                            clientDetails[tmp]['weekDetails'].append(clientDetails1)
                    tmp1 = str(cliDet.mspclientid)
                    mrrInfoVal[tmp1] = {}
                    mrr = NeMrrInfo.objects.using('ticketRead').filter(org_id = cliDet.mspclientid)
                    if mrr:
                        for mrrInfo in mrr:
                                mrrInfoVal[tmp1]['mrrVal'] = int(mrrInfo.mrr) #Loop for displaying MRR Informations=
                    else:
                        mrrInfoVal[tmp1]['mrrVal'] = 0
                return render_to_response('partnerSummary.html', {'partnerDetails': partnerDetails,'cliDetails':cliDetails, 'clientDetails': clientDetails,'colorArray':colorArray, 'partnerId': partnerId,'mrrInfoVal': mrrInfoVal},context_instance=RequestContext(request))
            else:
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')
    
'''Method to update the partner details on Main page'''
def updatedPatnersDetails(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            sdmId = request.session['uId']
            mspDetails = {}
            msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(sdm_id = sdmId).order_by('mspname')
            '''Loop for Msp Details'''
            for msp in msps:
                mspDetails[msp.mspid] = msp.mspname
            jsonData = simplejson.dumps({'msps': mspDetails})
            return HttpResponse(jsonData, content_type="application/json")
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - updatedPatnersDetails -> %s'%str(e))
        return HttpResponse('/SDMTracker/')
  
'''Method for Adding week regarding weekly summary Module'''
def addWeekPatSummary(request):
    try:
        authRes = comObj.checkAuthentication(request)
        disableDate = ''
        if authRes == True :
            clintId = request.GET.get('cliId')
            msp_id = request.GET.get('mspId')
            weekData={}
            if 'tmp' in request.GET.keys():
                tmp = request.GET.getlist('tmp')
                tmp = tmp[0].split(',',3)
                from datetime import datetime
                curDate =  datetime.strptime(tmp[2], "%m/%d/%Y").strftime('%m/%d/%Y')
                weekData['color_code']=tmp[1]
                weekData['summary']=tmp[3]
                disableDate = 'disabled'
            else:
                '''Below date to load Coming Monday on UI Add week datetimepicker'''   
                import datetime
                today = datetime.date.today()
                today = today - datetime.timedelta(days=today.weekday())
                today = today + datetime.timedelta(days=7)
                curDate = datetime.datetime.strptime(str(today), '%Y-%m-%d').strftime('%m/%d/%Y')
            return render_to_response('addWeekPatSummary.html', {'disableDate': disableDate, 'curDate':curDate, 'clintId':clintId, 'msp_id':msp_id,'weekData':weekData},context_instance=RequestContext(request))
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - addWeekPatSummary -> %s'%str(e))
        return HttpResponse('/SDMTracker/')

'''Saving Week details for Weekly summary module'''
def savWeekDetails(request):
    try:
        patId = int(request.POST.get('mspId'))
        ticketModelObj = CommonTicketModel()
        currentMkTime  = ticketModelObj.getCurrentUnixTimestamp()
        sample = {}
        weekDetails = {}
       
        import datetime
        import calendar
        week_date = comM.pstToUtc(str(request.POST['week']))
        week_date = comM.stringToUnixTimeStamp(week_date)
        weekDetails['week_date'] = week_date[0]['timestamp']
        weekDetails['msp_id'] = int(request.POST.get('mspId'))
        weekDetails['client_id'] = int(request.POST.get('clientId'))
        weekDetails['color_code'] = int(request.POST.get('wkColorCode'))
        weekDetails['summary'] = str(request.POST.get('description'))
        weekDetails['updated_by'] =  int(request.session['uId'])
        weekDetails['last_modified'] = int(currentMkTime)
        result = comM.updateNePartnerSummary(weekDetails)
        jsonData = simplejson.dumps({'sample': sample})
    except Exception as e:
            flag=1
            import logging
            log  = logging.getLogger('NNCPortal')
            log.info('')
            jsonData ={}
            log.exception(' Exception in sdmTrcaker-savWeekDetails is -> %s'%str(e))
    return HttpResponseRedirect('/SDMTracker/partnerSummary/?patId='+str(patId))

'''Preparation of Escalation tracker results'''
def escalationTrackerResults(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                '''Tracking Functionality users'''
                sdmtSerObj.track_sdmt(request, 'Escalation Tracker')
                
                partnrId = request.GET.get('partnerId')
                patId = request.GET.get('mspId')
                formId = request.GET.get('frmId')
                edtId = request.GET.get('editId')
                escRecId = request.GET.get('escId')
                if formId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    curDTime = datetime.now()
                    curDTime = curDTime.strftime('%m/%d/%Y')
                    return render_to_response('escalationTrackerForm.html', {'cliDetails': cliDetails, 'msps': msps, 'priorityImpact': priorityImpact, 'currStatus': currStatus, 'curDTime': curDTime},context_instance=RequestContext(request))
                if edtId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    escTrackerResult = NeSdmtEsc.objects.using('ticketRead').filter(id = escRecId)
                    escTrackerResData = {}
                    for escTrackerRes in escTrackerResult:
                        os.environ["TZ"]="US/Pacific"
                        escTrackerResData['id'] = escTrackerRes.id
                        escTrackerResData['esc_date'] = str(datetime.fromtimestamp(int(escTrackerRes.esc_date)).strftime('%m/%d/%Y'))
                        escTrackerResData['mspid'] = escTrackerRes.mspid
                        escTrackerResData['clientid'] = escTrackerRes.clientid
                        escTrackerResData['details_of_esc'] = escTrackerRes.details_of_esc
                        escTrackerResData['reported_by'] = escTrackerRes.reported_by
                        escTrackerResData['owner'] = escTrackerRes.owner
                        escTrackerResData['resolution_provided'] = escTrackerRes.resolution_provided
                        escTrackerResData['root_cause'] = escTrackerRes.root_cause
                        escTrackerResData['priority_impact'] = escTrackerRes.priority_impact
                        escTrackerResData['current_status'] = escTrackerRes.current_status
                        escTrackerResData['status_notes'] = escTrackerRes.status_notes
            
                    return render_to_response('escalationTrackerForm.html',{'cliDetails': cliDetails, 'msps': msps, 'priorityImpact': priorityImpact, 'currStatus': currStatus, 'escTrackerRes':escTrackerResData},context_instance=RequestContext(request))
                else:
                    saveData = request.POST.get('savData')
                    edtData = request.POST.get('editData')
                    recId = request.POST.get('id')
                    escTrackerData = sdmtSerObj.escTrackerResult(partnrId, saveData, edtData, recId, request.POST)
                    patDetails = sdmtSerObj.partnerDetailsForTitle(partnrId)
                    return render_to_response('escalationTrackerResults.html', {'patId': partnrId, 'escTrackerData': escTrackerData,'partnerDetails': patDetails},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')
    

'''Preparation of Key engagement contacts results'''
def contactsResults(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                '''Tracking Functionality users'''
                sdmtSerObj.track_sdmt(request, 'Key Engagement Contacts')
                
                partnrId = request.GET.get('partnerId')
                patId = request.GET.get('mspId')
                formId = request.GET.get('frmId')
                edtId = request.GET.get('editId')
                kecRecId = request.GET.get('kecnId')
                
                if formId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    curDTime = datetime.now()
                    curDTime = curDTime.strftime('%m/%d/%Y')
                    return render_to_response('contactsForm.html', {'cliDetails': cliDetails, 'msps': msps, 'curDTime': curDTime},context_instance=RequestContext(request))
                if edtId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    contDetResult = NeSdmtKeyEngContacts.objects.using('ticketRead').filter(id = kecRecId)
                    conDetResData = {}
                    for contDetRes in contDetResult:
                        conDetResData['id'] = contDetRes.id
                        conDetResData['mspid'] = contDetRes.mspid
                        conDetResData['clientid'] = contDetRes.clientid
                        conDetResData['contact_person'] = contDetRes.contact_person
                        conDetResData['contact_designation'] = contDetRes.contact_designation
                        conDetResData['email'] = contDetRes.email
                        conDetResData['phone'] = contDetRes.phone
                        conDetResData['role'] = contDetRes.role
                        os.environ["TZ"]="US/Pacific"
                        conDetResData['created_date'] = str(datetime.fromtimestamp(int(contDetRes.created_date)).strftime('%m/%d/%Y'))
                        conDetResData['impact'] = contDetRes.impact
                    return render_to_response('contactsForm.html',{'cliDetails': cliDetails, 'msps': msps, 'conDetResData':conDetResData},context_instance=RequestContext(request))
                else:
                    savContDetails = request.POST.get('saveContDetails')
                    edtContDetails = request.POST.get('editContDetails')
                    recId = request.POST.get('id')
                    engContDetails = sdmtSerObj.engContactDetailsResult(partnrId, savContDetails, edtContDetails, recId, request.POST)
                    patDetails = sdmtSerObj.partnerDetailsForTitle(partnrId)
                    return render_to_response('contactsResults.html', {'patId': partnrId, 'engContDetails': engContDetails,'partnerDetails': patDetails},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')
    
'''Preparing results for Value adds form'''
def valueAddsResult(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                '''Tracking Functionality users'''
                sdmtSerObj.track_sdmt(request, 'Value Adds')
                
                partnrId = request.GET.get('partnerId')
                patId = request.GET.get('mspId')
                formId = request.GET.get('frmId')
                edtId = request.GET.get('editId')
                vafRecId = request.GET.get('vafId')
                
                if formId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    curDTime = datetime.now()
                    curDTime = curDTime.strftime('%m/%d/%Y')
                    return render_to_response('valueAddsForm.html', {'cliDetails': cliDetails, 'msps': msps, 'curDTime': curDTime},context_instance=RequestContext(request))
                if edtId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    vafResult = NeSdmtValueAdds.objects.using('ticketRead').filter(id = vafRecId)
                    vafDetResData = {}
                    for vafRes in vafResult:
                        vafDetResData['id'] = vafRes.id
                        vafDetResData['mspid'] = vafRes.mspid
                        vafDetResData['clientid'] = vafRes.clientid
                        vafDetResData['value_add_details'] = vafRes.value_add_details
                        os.environ["TZ"]="US/Pacific"
                        vafDetResData['implemented_date'] = str(datetime.fromtimestamp(int(vafRes.implemented_date)).strftime('%m/%d/%Y'))
                        vafDetResData['impact_val_add'] = vafRes.impact_val_add
                        vafDetResData['acknowledged_by'] = vafRes.acknowledged_by
                        vafDetResData['replication'] = vafRes.replication
                    return render_to_response('valueAddsForm.html',{'cliDetails': cliDetails, 'msps': msps, 'vafDetResData':vafDetResData},context_instance=RequestContext(request))
                else:
                    savContDetails = request.POST.get('savData')
                    edtContDetails = request.POST.get('editData')
                    recId = request.POST.get('id')
            
                    vafDetails = sdmtSerObj.vafDetailsResult(partnrId, savContDetails, edtContDetails, recId, request.POST)
                    patDetails = sdmtSerObj.partnerDetailsForTitle(partnrId)
                    return render_to_response('valueAddsResults.html', {'patId': partnrId, 'vafDetails': vafDetails,'partnerDetails': patDetails},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')
    
'''Preparing results for Planned value adds'''
def plannedValueAddsResults(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                '''Tracking Functionality users'''
                sdmtSerObj.track_sdmt(request, 'Planned Value Adds')
                
                partnrId = request.GET.get('partnerId')
                patId = request.GET.get('mspId')
                fmId = request.GET.get('frmId')
                edtId = request.GET.get('editId')
                pvaRecId = request.GET.get('pvaId')
                if fmId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    curDTime = datetime.now()
                    curDTime = curDTime.strftime('%m/%d/%Y')
                    return render_to_response('plannedValAddsForm.html', {'cliDetails': cliDetails, 'msps': msps, 'curDTime': curDTime},context_instance=RequestContext(request))
                if edtId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    pvaResult = NeSdmtPlannedValueAdds.objects.using('ticketRead').filter(id = pvaRecId)
                    pvaDetResData = {}
                    for pvaRes in pvaResult:
                        pvaDetResData['id'] = pvaRes.id
                        pvaDetResData['mspid'] = pvaRes.mspid
                        pvaDetResData['clientid'] = pvaRes.clientid
                        pvaDetResData['value_add_details'] = pvaRes.value_add_details
                        os.environ["TZ"]="US/Pacific"
                        pvaDetResData['pro_imp_date'] = str(datetime.fromtimestamp(int(pvaRes.pro_imp_date)).strftime('%m/%d/%Y'))
                        pvaDetResData['impact'] = pvaRes.impact
                        pvaDetResData['quantified_benefit'] = pvaRes.quantified_benefit
                        pvaDetResData['owner_ne'] = pvaRes.owner_ne
                        pvaDetResData['partner_contact'] = pvaRes.partner_contact
                        pvaDetResData['replication'] = pvaRes.replication
                    return render_to_response('plannedValAddsForm.html',{'cliDetails': cliDetails, 'msps': msps, 'pvaDetResData': pvaDetResData},context_instance=RequestContext(request))
                else:
                    savContDetails = request.POST.get('savPvaData')
                    edtContDetails = request.POST.get('editPvaData')
                    recId = request.POST.get('id')
                    patDetails = sdmtSerObj.partnerDetailsForTitle(partnrId)
                    pvaDetails = sdmtSerObj.pvaDetailsResult(partnrId, savContDetails, edtContDetails, recId, request.POST)
                    return render_to_response('plannedValueAddsResults.html', {'patId': partnrId, 'pvaDetails': pvaDetails,'partnerDetails': patDetails},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')

'''Preparing results for Action Items Tracker'''
def actionItemsTrackerResults(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                '''Tracking Functionality users'''
                sdmtSerObj.track_sdmt(request, 'Action Items Tracker')
                
                partnrId = request.GET.get('partnerId')
                patId = request.GET.get('mspId')
                fmId = request.GET.get('frmId')
                edtId = request.GET.get('editId')
                aitRecId = request.GET.get('aitId')
            
                if fmId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    curDTime = datetime.now()
                    curDTime = curDTime.strftime('%m/%d/%Y')
                    return render_to_response('actionItemsTrackerForm.html', {'cliDetails': cliDetails, 'msps': msps, 'curDTime': curDTime},context_instance=RequestContext(request))
                if edtId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    aitResult = NeSdmtActionItems.objects.using('ticketRead').filter(id = aitRecId)
                    aitDetResData = {}
                    for aitRes in aitResult:
                        aitDetResData['aitId'] = aitRes.id
                        aitDetResData['mspid'] = aitRes.mspid
                        aitDetResData['clientid'] = aitRes.clientid
                        os.environ["TZ"]="US/Pacific"
                        aitDetResData['created_date'] = str(datetime.fromtimestamp(int(aitRes.created_date)).strftime('%m/%d/%Y'))
                        aitDetResData['action_item_desc'] = aitRes.action_item_desc
                        aitDetResData['int_or_ext'] = aitRes.int_or_ext
                        aitDetResData['owner'] = aitRes.owner
                        aitDetResData['status'] = aitRes.status
                        os.environ["TZ"]="US/Pacific"
                        aitDetResData['prop_end_date'] = str(datetime.fromtimestamp(int(aitRes.prop_end_date)).strftime('%m/%d/%Y'))
                        os.environ["TZ"]="US/Pacific"
                        aitDetResData['target_comp_date'] = str(datetime.fromtimestamp(int(aitRes.target_comp_date)).strftime('%m/%d/%Y'))
                        aitDetResData['impact'] = aitRes.impact
            
                    return render_to_response('actionItemsTrackerForm.html',{'cliDetails': cliDetails, 'msps': msps, 'aitDetResData': aitDetResData},context_instance=RequestContext(request))
                else:
                    savContDetails = request.POST.get('saveAitRec')
                    edtContDetails = request.POST.get('editAitRec')
                    recId = request.POST.get('id')
                    aitDetails = sdmtSerObj.aitDetailsResult(partnrId, savContDetails, edtContDetails, recId, request.POST)
                    patDetails = sdmtSerObj.partnerDetailsForTitle(partnrId)
                    return render_to_response('actionItemsTrackerResults.html', {'patId': partnrId, 'aitDetails': aitDetails,'partnerDetails': patDetails},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')
    
'''Preparing results for Pipeline form'''
def pipelineResults(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                '''Tracking Functionality users'''
                sdmtSerObj.track_sdmt(request, 'Pipeline')
                
                partnrId = request.GET.get('partnerId')
                patId = request.GET.get('mspId')
                fmId = request.GET.get('frmId')
                edtId = request.GET.get('editId')
                pplRecId = request.GET.get('pplId')
                pplnStatus = collections.OrderedDict()
                pplnStatus['In Progress'] = 'In Progress'
                pplnStatus['Lost'] = 'Lost'
                pplnStatus['Won'] = 'Won'
                if fmId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    curDTime = datetime.now()
                    curDTime = curDTime.strftime('%m/%d/%Y')
                    return render_to_response('pipelineForm.html', {'cliDetails': cliDetails, 'msps': msps, 'curDTime': curDTime, 'pplnStatus': pplnStatus},context_instance=RequestContext(request))
                if edtId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    pplResult = NeSdmtPipeline.objects.using('ticketRead').filter(id = pplRecId)
                    pplDetResData = {}
                    for pplRes in pplResult:
                        pplDetResData['pplId'] = pplRes.id
                        pplDetResData['mspid'] = pplRes.mspid
                        pplDetResData['clientid'] = pplRes.clientid
                        pplDetResData['pipeline_description'] = pplRes.pipeline_description
                        pplDetResData['pipeline_amt'] = pplRes.pipeline_amt
                        os.environ["TZ"]="US/Pacific"
                        pplDetResData['date_created'] = str(datetime.fromtimestamp(int(pplRes.date_created)).strftime('%m/%d/%Y'))
                        pplDetResData['ne_owner'] = pplRes.ne_owner
                        pplDetResData['pat_cli_owner'] = pplRes.pat_cli_owner
                        os.environ["TZ"]="US/Pacific"
                        pplDetResData['est_close_date'] = str(datetime.fromtimestamp(int(pplRes.est_close_date)).strftime('%m/%d/%Y'))
                        pplDetResData['cur_status'] = pplRes.cur_status
            
                    return render_to_response('pipelineForm.html',{'cliDetails': cliDetails, 'msps': msps, 'pplDetResData': pplDetResData, 'pplnStatus': pplnStatus},context_instance=RequestContext(request))
                else:
                    savContDetails = request.POST.get('savPplData')
                    edtContDetails = request.POST.get('editPplData')
                    recId = request.POST.get('id')
                    patDetails = sdmtSerObj.partnerDetailsForTitle(partnrId)
                    pplDetails = sdmtSerObj.pplDetailsResult(partnrId, savContDetails, edtContDetails, recId, request.POST)
                    return render_to_response('pipelineResults.html', {'patId': partnrId, 'pplDetails': pplDetails,'partnerDetails': patDetails},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')
    
'''Preparing results for Pipeline form'''
def cancellationDetResults(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                '''Tracking Functionality users'''
                sdmtSerObj.track_sdmt(request, 'Cancellation Details')
                
                partnrId = request.GET.get('partnerId')
                patId = request.GET.get('mspId')
                fmId = request.GET.get('frmId')
                edtId = request.GET.get('editId')
                canRecId = request.GET.get('canId')
                
                if fmId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    curDTime = datetime.now()
                    curDTime = curDTime.strftime('%m/%d/%Y')
                    return render_to_response('cancellationDetForm.html', {'cliDetails': cliDetails, 'msps': msps, 'curDTime': curDTime},context_instance=RequestContext(request))
                if edtId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    canResult = NeSdmtCancelDetails.objects.using('ticketRead').filter(id = canRecId)
                    canDetResData = {}
                    for canRes in canResult:
                        canDetResData['canId'] = canRes.id
                        canDetResData['mspid'] = canRes.mspid
                        canDetResData['clientid'] = canRes.clientid
                        os.environ["TZ"]="US/Pacific"
                        canDetResData['date_of_cancellation'] = str(datetime.fromtimestamp(int(canRes.date_of_cancellation)).strftime('%m/%d/%Y'))
                        canDetResData['reason_for_cancellation'] = canRes.reason_for_cancellation
                        canDetResData['actions_to_prevent'] = canRes.actions_to_prevent
                        canDetResData['loss_value_acv'] = canRes.loss_value_acv
            
                    return render_to_response('cancellationDetForm.html',{'cliDetails': cliDetails, 'msps': msps, 'canDetResData': canDetResData},context_instance=RequestContext(request))
                else:
                    savContDetails = request.POST.get('savCanData')
                    edtContDetails = request.POST.get('editCanData')
                    recId = request.POST.get('id')
                    canDetails = sdmtSerObj.canDetailsResult(partnrId, savContDetails, edtContDetails, recId, request.POST)
                    patDetails = sdmtSerObj.partnerDetailsForTitle(partnrId)
                    return render_to_response('cancellationDetResults.html', {'patId': partnrId, 'canDetails': canDetails,'partnerDetails': patDetails},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')
    
'''Preparation of Potentials cancellation details results'''
def potCancelDetResults(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                '''Tracking Functionality users'''
                sdmtSerObj.track_sdmt(request, 'Potential Cancellation Details')
                
                partnrId = request.GET.get('partnerId')
                patId = request.GET.get('mspId')
                fmId = request.GET.get('frmId')
                edtId = request.GET.get('editId')
                ptcRecId = request.GET.get('ptcId')
            
                if fmId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    curDTime = datetime.now()
                    curDTime = curDTime.strftime('%m/%d/%Y')
                    return render_to_response('potCancelDetForm.html', {'cliDetails': cliDetails, 'msps': msps, 'curDTime': curDTime},context_instance=RequestContext(request))
                if edtId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    ptcResult = NeSdmtPcancelDetails.objects.using('ticketRead').filter(id = ptcRecId)
                    ptcDetResData = {}
                    for ptcRes in ptcResult:
                        ptcDetResData['id'] = ptcRes.id
                        ptcDetResData['mspid'] = ptcRes.mspid
                        ptcDetResData['clientid'] = ptcRes.clientid
                        os.environ["TZ"]="US/Pacific"
                        ptcDetResData['threat_idntfd_date'] = str(datetime.fromtimestamp(int(ptcRes.threat_idntfd_date)).strftime('%m/%d/%Y'))
                        ptcDetResData['actions_identified'] = ptcRes.actions_identified
                        ptcDetResData['owner_ech_itm'] = ptcRes.owner_ech_itm
                        ptcDetResData['impacted_acv'] = ptcRes.impacted_acv
            
                    return render_to_response('potCancelDetForm.html',{'cliDetails': cliDetails, 'msps': msps, 'ptcDetResData': ptcDetResData},context_instance=RequestContext(request))
                else:
                    savContDetails = request.POST.get('savePtcRec')
                    edtContDetails = request.POST.get('editPtcRec')
                    recId = request.POST.get('id')
                    ptcDetails = sdmtSerObj.ptcDetailsResult(partnrId, savContDetails, edtContDetails, recId, request.POST)
                    patDetails = sdmtSerObj.partnerDetailsForTitle(partnrId)
                    return render_to_response('potCancelDetResults.html', {'patId': partnrId, 'ptcDetails': ptcDetails,'partnerDetails': patDetails},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')
    
'''Preparation of Commitments tracker results'''
def commTrackerResults(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                '''Tracking Functionality users'''
                sdmtSerObj.track_sdmt(request, 'Commitments Tracker')
                
                partnrId = request.GET.get('partnerId')
                patId = request.GET.get('mspId')
                fmId = request.GET.get('frmId')
                edtId = request.GET.get('editId')
                cmtRecId = request.GET.get('cmtId')
            
                if fmId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    curDTime = datetime.now()
                    curDTime = curDTime.strftime('%m/%d/%Y')
                    return render_to_response('commTrackerForm.html', {'cliDetails': cliDetails, 'msps': msps, 'curDTime': curDTime},context_instance=RequestContext(request))
                if edtId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    cmtResult = NeSdmtCommitments.objects.using('ticketRead').filter(id = cmtRecId)
                    cmtDetResData = {}
                    for cmtRes in cmtResult:
                        cmtDetResData['id'] = cmtRes.id
                        cmtDetResData['mspid'] = cmtRes.mspid
                        cmtDetResData['clientid'] = cmtRes.clientid
                        os.environ["TZ"]="US/Pacific"
                        cmtDetResData['week'] = str(datetime.fromtimestamp(int(cmtRes.week)).strftime('%m/%d/%Y'))
                        cmtDetResData['dedicated_resources'] = cmtRes.dedicated_resources
                        cmtDetResData['resp_sla'] = cmtRes.resp_sla
                        cmtDetResData['resol_sla'] = cmtRes.resol_sla
                        cmtDetResData['antivirus'] = cmtRes.antivirus
                        cmtDetResData['patchig'] = cmtRes.patchig
                        cmtDetResData['reason_if_red'] = cmtRes.reason_if_red
                        cmtDetResData['reports'] = cmtRes.reports
            
                    return render_to_response('commTrackerForm.html',{'cliDetails': cliDetails, 'msps': msps, 'cmtDetResData': cmtDetResData},context_instance=RequestContext(request))
                else:
                    savContDetails = request.POST.get('saveCmtRec')
                    edtContDetails = request.POST.get('editCmtRec')
                    recId = request.POST.get('id')
                    cmtDetails = sdmtSerObj.cmtDetailsResult(partnrId, savContDetails, edtContDetails, recId, request.POST)
                    patDetails = sdmtSerObj.partnerDetailsForTitle(partnrId)
                    return render_to_response('commTrackerResults.html', {'patId': partnrId, 'cmtDetails': cmtDetails,'partnerDetails': patDetails},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')
            
'''Preparation of Review tracker results'''
def reviewTrackerResults(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                '''Tracking Functionality users'''
                sdmtSerObj.track_sdmt(request, 'Review Tracker')
                
                partnrId = request.GET.get('partnerId')
                patId = request.GET.get('mspId')
                fmId = request.GET.get('frmId')
                edtId = request.GET.get('editId')
                rvtRecId = request.GET.get('rvtId')
                rvtStatus = {'Pending':'Pending', 'Done':'Done'}
                if fmId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    return render_to_response('reviewTrackerForm.html', {'cliDetails': cliDetails, 'msps': msps, 'rvtStatus': rvtStatus},context_instance=RequestContext(request))
                if edtId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    rvtResult = NeSdmtReview.objects.using('ticketRead').filter(id = rvtRecId)
                    rvtDetResData = {}
                    for rvtRes in rvtResult:
                        rvtDetResData['id'] = rvtRes.id
                        rvtDetResData['mspid'] = rvtRes.mspid
                        rvtDetResData['clientid'] = rvtRes.clientid
                        rvtDetResData['weekly_review'] = rvtRes.weekly_review
                        rvtDetResData['monthly_review'] = rvtRes.monthly_review
                        rvtDetResData['quarterly_review'] = rvtRes.quarterly_review
            
                    return render_to_response('reviewTrackerForm.html',{'cliDetails': cliDetails, 'msps': msps, 'rvtDetResData': rvtDetResData, 'rvtStatus': rvtStatus},context_instance=RequestContext(request))
                else:
                    savContDetails = request.POST.get('savRvtData')
                    edtContDetails = request.POST.get('editRvtData')
                    recId = request.POST.get('id')
                    patDetails = sdmtSerObj.partnerDetailsForTitle(partnrId)
                    rvtDetails = sdmtSerObj.rvtDetailsResult(partnrId, savContDetails, edtContDetails, recId, request.POST)
                    return render_to_response('reviewTrackerResults.html', {'patId': partnrId, 'rvtDetails': rvtDetails,'partnerDetails': patDetails},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')
    
'''Preparation of Weekly touch point tracker results'''
def weekTouchptTrackerResults(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                '''Tracking Functionality users'''
                sdmtSerObj.track_sdmt(request, 'Weekly Touch Point tracker')
                
                partnrId = request.GET.get('partnerId')
                patId = request.GET.get('mspId')
                fmId = request.GET.get('frmId')
                edtId = request.GET.get('editId')
                wtpRecId = request.GET.get('wtpId')
                if fmId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    curDTime = datetime.now()
                    curDTime = curDTime.strftime('%m/%d/%Y')
                    return render_to_response('WeekTouchPtTrackerForm.html', {'cliDetails': cliDetails, 'msps': msps, 'curDTime': curDTime},context_instance=RequestContext(request))
                if edtId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    wtpResult = NeSdmtWklyTouchPoint.objects.using('ticketRead').filter(id = wtpRecId)
                    wtpDetResData = {}
                    for wtpRes in wtpResult:
                        wtpDetResData['id'] = wtpRes.id
                        wtpDetResData['mspid'] = wtpRes.mspid
                        wtpDetResData['clientid'] = wtpRes.clientid
                        os.environ["TZ"]="US/Pacific"
                        wtpDetResData['date_of_meeting'] = str(datetime.fromtimestamp(int(wtpRes.date_of_meeting)).strftime('%m/%d/%Y'))
                        wtpDetResData['contact_name'] = wtpRes.contact_name
                        wtpDetResData['feedback'] = wtpRes.feedback
                    return render_to_response('WeekTouchPtTrackerForm.html',{'cliDetails': cliDetails, 'msps': msps, 'wtpDetResData': wtpDetResData},context_instance=RequestContext(request))
                else:
                    savContDetails = request.POST.get('savWtpData')
                    edtContDetails = request.POST.get('editWtpData')
                    recId = request.POST.get('id')
                    patDetails = sdmtSerObj.partnerDetailsForTitle(partnrId)
                    wtpDetails = sdmtSerObj.wtpDetailsResult(partnrId, savContDetails, edtContDetails, recId, request.POST)
                    return render_to_response('WeekTouchPtTrackerResults.html', {'patId': partnrId, 'wtpDetails': wtpDetails,'partnerDetails': patDetails},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')
                
'''Preparation of Partner level summary results'''
def partnerLevelResults(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.session['sdm_access'] == 1:
                '''Tracking Functionality users'''
                sdmtSerObj.track_sdmt(request, 'Weekly Touch Point tracker')
                
                partnrId = request.GET.get('partnerId')
                patId = request.GET.get('mspId')
                fmId = request.GET.get('frmId')
                edtId = request.GET.get('editId')
                plsRecId = request.GET.get('wtpId')
                lastWeek = collections.OrderedDict()
                lastWeek['Decreased'] = 'Decreased'
                lastWeek['Increased'] = 'Increased'
                lastWeek['Neutral'] = 'Neutral'
            
                if fmId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    curDTime = datetime.now()
                    curDTime = curDTime.strftime('%m/%d/%Y')
                    return render_to_response('partnerSummaryForm.html', {'msps': msps, 'curDTime': curDTime, 'sdmName': request.session['fullName'], 'lastWeek': lastWeek},context_instance=RequestContext(request))
                if edtId:
                    msps = Ntsmsps1.objects.using('ticketRead').only('mspid','mspname').filter(mspid = patId).order_by('mspname')
                    cliDetails = Ntsmspclients.objects.using('ticketRead').filter(mspid = patId).order_by('clientname')
                    wtpResult = NeSdmtPatLvlSummary.objects.using('ticketRead').filter(id = plsRecId)
                    wtpDetResData = {}
                    for wtpRes in wtpResult:
                        wtpDetResData['id'] = wtpRes.id
                        wtpDetResData['mspid'] = wtpRes.mspid
                        wtpDetResData['sdm_name'] = wtpRes.sdm_name
                        wtpDetResData['rs_cur_mrr'] = wtpRes.rs_cur_mrr
                        wtpDetResData['rs_las_wk'] = wtpRes.rs_las_wk
                        wtpDetResData['ds_cur'] = wtpRes.ds_cur
                        wtpDetResData['ds_las_wk'] = wtpRes.ds_las_wk
                        wtpDetResData['pls_comments'] = wtpRes.pls_comments
            
                    return render_to_response('partnerSummaryForm.html',{'cliDetails': cliDetails, 'msps': msps, 'wtpDetResData': wtpDetResData, 'lastWeek': lastWeek, 'sdmName': request.session['fullName']},context_instance=RequestContext(request))
                else:
                    savContDetails = request.POST.get('savWtpData')
                    edtContDetails = request.POST.get('editWtpData')
                    recId = request.POST.get('id')
                    wtpDetails = sdmtSerObj.plsDetailsResult(partnrId, savContDetails, edtContDetails, recId, request.POST)
                    patDetails = sdmtSerObj.partnerDetailsForTitle(partnrId)
                    return render_to_response('partnerSummaryResults.html', {'patId': partnrId, 'wtpDetails': wtpDetails,'partnerDetails': patDetails},context_instance=RequestContext(request))
            else:
                    messages.warning(request, 'unauthorized_access',extra_tags='safe')
                    return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in SDMTrcaker - Escalation Tracker -> %s'%str(e))
        messages.error(request, 'sdm_tracker_failed',extra_tags='safe')
        return HttpResponseRedirect('/SDMTracker/')
    
'''Method for Excel download regarding Partner level summary data'''
def excelDownload(request):
    '''Partner id to bring data for Partner level summary for particular partner'''
    partnrId = request.GET.get('partnerId')
    
    '''Below are the parameters to be passed for bring the data'''
    savContDetails = None
    edtContDetails = None
    recId = None
    data = {}
    
    '''Content to be downloaded in Excel sheet'''
    contentData = sdmtSerObj.plsDetailsResult(partnrId, savContDetails, edtContDetails, recId, data)
    
    '''Headings for excel data coloumns'''
    tabHead = ['Partner Name','SDM','Current MRR','Last Week','Current Status','Last Week Status', 'Comments']
    import StringIO, xlsxwriter
    output = StringIO.StringIO()
    workbook = xlsxwriter.Workbook(output)
    worksheet = workbook.add_worksheet()
    row = 0
    
    '''formats for excel sheet preparation'''
    format1 = workbook.add_format({'bold': True, 'bg_color': '#4cae4c','align':'center'})
    format1.set_text_wrap()
    format3 = workbook.add_format({'bold': True, 'bg_color': 'yellow','align':'center'})
    format3.set_text_wrap()
    format4 = workbook.add_format({'bold': True, 'bg_color': 'red','align':'center'})
    format4.set_text_wrap()
    format2 = workbook.add_format({'bold': True, 'bg_color': 'gray','font_color':'white','align':'center'})
    
    '''For loop for header in excel sheet'''
    ti = 0
    for th in tabHead:
        worksheet.set_column(row, ti, 30)
        worksheet.write(row, ti, th,format2)
        ti +=1
    row += 1
    
    '''For loop for writing data to work sheet'''
    for k1,v1 in contentData.iteritems():
        preparedDict = sdmtSerObj.prepareExcelData(tabHead,v1)
        trc = 0
        for th in tabHead:
            worksheet.set_column(row, trc, 30)
            if th == "Current Status" and v1['ds_cur'] == '0':
                worksheet.write(row, trc, str(preparedDict[th]), format1)
            elif th == "Current Status" and v1['ds_cur'] == '1':
                worksheet.write(row, trc, str(preparedDict[th]), format3)
            elif th == "Current Status" and v1['ds_cur'] == '2':
                worksheet.write(row, trc, str(preparedDict[th]), format4)
            else:
                worksheet.write(row, trc, str(preparedDict[th]))
            trc +=1
        row += 1
    currentTime = comM.curPst()
    currentMkTime = currentTime[0]['currentUnixTimestamp']
    
    '''Date for filename'''
    utc = pytz.utc
    w_date = utc.localize(datetime.utcfromtimestamp(int(currentMkTime)))
    au_tz = timezone('US/Pacific')
    w_date = w_date.astimezone(au_tz)
    time = w_date.strftime('%m/%d/%Y')
    
    workbook.close()
    xlsx_data = output.getvalue()
    response = HttpResponse(content_type='application/vnd.ms-excel')
    response['Content-Disposition'] = 'attachment; filename='+'Weekly_Summary_'+time+'.xlsx'
    response.write(xlsx_data)
    return response

'''Method for weekly summary data'''
def weeklySummary(request):

    partnrId = request.GET.get('pId')
    sdm_id = request.session['uId']
    wklySumData = sdmtSerObj.weeklySumData(request, partnrId, sdm_id)
    
    sample = {}
    jsonData = simplejson.dumps({'sample': sample})
    return HttpResponse(jsonData, content_type="application/json")
