"""
 This computer program is the confidential information and proprietary trade
 secret of NetEnrich, Inc. Possessions and use of this program must
 conform strictly to the license agreement between the user and
 NetEnrich, Inc., and receipt or possession does not convey any rights
 to divulge, reproduce, or allow others to use this program without specific
 written authorization of NetEnrich, Inc.
  
 Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""

from django.db import models

class NrRequestform(models.Model):
    id = models.BigIntegerField(primary_key=True)
    requirement_code = models.CharField(max_length=25, blank=True, null=True)
    requester_id = models.IntegerField(blank=True, null=True)
    sponsor = models.CharField(max_length=75, blank=True, null=True)
    priority = models.IntegerField(blank=True, null=True)
    subject = models.CharField(max_length=175, blank=True, null=True)
    category = models.IntegerField(blank=True, null=True)
    cc_list = models.TextField(blank=True, null=True)
    content = models.TextField(blank=True, null=True)
    status = models.IntegerField(blank=True, null=True)
    owner = models.IntegerField(blank=True, null=True)
    created_date = models.IntegerField(blank=True, null=True)
    last_updated = models.IntegerField(blank=True, null=True)
    decision_taken = models.IntegerField(blank=True, null=True)
    comment = models.TextField(blank=True, null=True)
    res_captured = models.TextField(blank=True, null=True) 

    class Meta:
        managed = False
        db_table = 'nr_requestform'
