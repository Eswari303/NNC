"""
 This computer program is the confidential information and proprietary trade
 secret of NetEnrich, Inc. Possessions and use of this program must
 conform strictly to the license agreement between the user and
 NetEnrich, Inc., and receipt or possession does not convey any rights
 to divulge, reproduce, or allow others to use this program without specific
 written authorization of NetEnrich, Inc.
  
 Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""

import json as simplejson
import md5
from django.shortcuts import render_to_response
from NNCPortal.commonModels.commonModelMethods import CommonModelMethods
from serviceManagement.models.commonScheduleModel import CommonScheduleModel
from calendar import timegm
from datetime import datetime
from django.db import connections
from NNCPortal.commonMethods import commonMethods
from apps.requestForm.models.NrRequestform import NrRequestform
comObj = commonMethods()
from apps.requestForm.models.reqFormModel import RequestFormModel
reqComObj = RequestFormModel()
from NNCPortal.commonModels.NrStaff import NrStaff
import time
import pickle
import re
import os
from NNCPortal.configfile import ConfigManager
from ticket.models.commonModel import CommonTicketModel
from collections import OrderedDict

def showRequests(request):
    requests = {}
    decisionTaken = {0:'Decision Pending', 1:'Accepted', 2:'Denied', 3:'On Hold', 4:'Resource Not Available'}
    result = reqComObj.requests()
    i = 0
    for req in result:
        reqstr = req['requester_id']
        onr = req['owner']
        owner = NrStaff.objects.using('rosterRead').only('staff_fname','staff_lname').filter(id = reqstr)
        for ownr in owner:
            req['requester'] = ownr.staff_fname+' '+ownr.staff_lname
        if req['owner'] != 0:
            ownerName = NrStaff.objects.using('rosterRead').only('staff_fname','staff_lname').filter(id = onr)
            for ownerNam in ownerName:
                req['owner'] = ownerNam.staff_fname+' '+ownerNam.staff_lname
        else:
            req['owner'] = '-'
        sponsor = req['sponsor']
        req['sponsors'] = sponsor.split("@")[0]
        requests[i] = req
        for key, value in decisionTaken.iteritems():
            if key == req['decision_taken']:
                req['dec_taken'] = value
        os.environ["TZ"]="Asia/Kolkata"
        req['createdDate'] = str(datetime.fromtimestamp(int(req['created_date'])).strftime('%d %b %Y'))
        req['lastUpdatedDate'] = str(datetime.fromtimestamp(int(req['last_updated'])).strftime('%d %b %Y'))
        i = i+1

    return render_to_response('showRequests.html',{'requests': requests})

'''To submit a new request'''
def addNewRequest(request):
    comSchObj = CommonScheduleModel()
    staffInfo = comSchObj.getStaffInfo()
    staffInfo = simplejson.dumps(staffInfo)
    configobj = ConfigManager()
    sponsorMails = configobj.getCommConfigValue(configobj.RequestFormSponsorEmail)
    ReqFormCategories = configobj.getCommConfigValue(configobj.RequestFormCategories)
    import ast
    sponsorMail = ast.literal_eval(sponsorMails)
    RequestFormCategory = ast.literal_eval(ReqFormCategories)
    return render_to_response('requestForm.html', {'ccMailList': staffInfo, 'sponsorMails': sponsorMail, 'RequestFormCategories': RequestFormCategory})

'''To show a request in detail'''
def showReqDetails(request,reqId):
    reqDetails = NrRequestform.objects.using('rosterRead').filter(id = reqId)
    ownr = 0
    decisionTaken = {0:'Decision Pending', 1:'Accepted', 2:'Denied', 3:'On Hold', 4:'Resource Not Available'}
    statuses = {0:'New', 1:'Work In Progress', 2:'Completed'}
    for reqstDetails in reqDetails:
        requester = NrStaff.objects.using('rosterRead').only('staff_fname','staff_lname').filter(id = reqstDetails.requester_id)
        reqstrId = reqstDetails.requester_id
        os.environ["TZ"]="Asia/Kolkata"
        lastUpdated = str(datetime.fromtimestamp(int(reqstDetails.last_updated)).strftime('%d %b %Y %H:%M'))
        for requster in requester:
            requester = requster.staff_fname+' '+requster.staff_lname
        if reqstDetails.owner >=0:
            owner = NrStaff.objects.using('rosterRead').only('staff_fname','staff_lname').filter(id = reqstDetails.owner)
            for ownr in owner:
                ownr = ownr.staff_fname+' '+ownr.staff_lname
        
        unserContent = pickle.loads(reqstDetails.content)
        resCapturedContent = ''
        res_cap_desc = ''
        if reqstDetails.res_captured:
            resCapturedContent = pickle.loads(reqstDetails.res_captured)
            res_cap = {}
            i = 0
            for key, value in resCapturedContent.iteritems():
                res_cap.setdefault(i, {})
                res_cap[i]['res_cap'] = value['res_cap']
                cap_by = NrStaff.objects.using('rosterRead').only('staff_fname','staff_lname').filter(id = value['res_cap_by'])
                for capBy in cap_by:
                    capBy = capBy.staff_fname+' '+capBy.staff_lname
                res_cap[i]['res_cap_by'] = capBy
                
                os.environ["TZ"]="Asia/Kolkata"
                res_cap[i]['date'] = str(datetime.fromtimestamp(int(value['timeline'])).strftime('%d %b %Y %H:%M'))
                i = i + 1
            res_cap_desc = OrderedDict(sorted(res_cap.items(), reverse=True))  
        reqStatus = reqstDetails.status
        decisionTakn = reqstDetails.decision_taken
        
        reqCode = reqstDetails.requirement_code
        if reqstDetails.comment:
            rfComment = reqstDetails.comment
        else:
            rfComment = ''
        decisionTknFlag = 0
        if reqstDetails.decision_taken == 2 or reqstDetails.decision_taken == 3:
            decisionTknFlag = 1
    loginId = request.session['uId']
    return render_to_response('showReqDetails.html',{'rfComment': rfComment,'reqstDetails': reqDetails, 
                                                     'requester': requester, 'unserContent': unserContent, 
                                                     'owner': ownr, 'reqStatus': reqStatus, 'statuses': statuses, 
                                                     'decisionTaken': decisionTaken, 'decisionTknFlag': decisionTknFlag,
                                                     'decisionTakn': decisionTakn, 'reqCode': reqCode,
                                                     'resCapturedContent': res_cap_desc, 'lastUpdated': lastUpdated,
                                                     'reqstrId': reqstrId, 'loginId': loginId,})

'''Saving the request to Database and sending mail'''
def saveReqDetails(request):
    rf = md5.new(time.strftime('%Y-%m-%d %H:%M:%S')).hexdigest()
    rfCode = rf.upper()
    code = rfCode[5:10]
    contentDict = {}
    contentDict['scopeOfWork'] = str(request.POST.get('scopeOfWork'))
    contentDict['businessJustification'] = str(request.POST.get('businessJustification'))
    contentDict['quantitativeImpact'] = str(request.POST.get('quantitativeImpact'))
    content = pickle.dumps(contentDict)
    
    requestFormData = {}
    requestFormData['sponsor'] = str(request.POST.get('sponsorEmail'))
    requestFormData['cc_list'] = str(request.POST.get('rfCCList'))
    requestFormData['subject'] = str(request.POST.get('subject'))
    requestFormData['category'] = str(request.POST.get('category'))
    requestFormData['content'] = content
    requestFormData['requester_id'] = request.session['uId']
    requestFormData['requirement_code'] = "RF-"+code
    requestFormData['owner'] = 0
    requestFormData['priority'] = str(request.POST.get('priority'))
    ticketModelObj = CommonTicketModel()
    currentMkTime  = ticketModelObj.getCurrentUnixTimestamp()
    requestFormData['created_date'] = int(currentMkTime)
    requestFormData['last_updated'] = int(currentMkTime)
    
    
    commMM = CommonModelMethods()
    reqID = commMM.insertRecord(requestFormData, 'nr_requestform', 'rosterWrite')

    reqstFrmMailData = {}
    uId = request.session['uId']
    submttdBy = NrStaff.objects.using('rosterRead').only('staff_email').filter(id = uId)
    for subBy in submttdBy:
        fromMail = subBy.staff_email
        reqstFrmMailData['submittedBy'] = subBy.staff_email
    reqstFrmMailData['sponsor'] = str(request.POST.get('sponsorEmail'))
    reqstFrmMailData['scopeOfWork'] = str(request.POST.get('scopeOfWork'))
    reqstFrmMailData['businessJustification'] = str(request.POST.get('businessJustification'))
    reqstFrmMailData['quantitativeImpact'] = str(request.POST.get('quantitativeImpact'))
    
    category = int(request.POST.get('category'))
    if category == 0:
        reqstFrmMailData['category'] = "Automations"
    elif category == 1:
        reqstFrmMailData['category'] = "Integrations"
    elif category == 2:
        reqstFrmMailData['category'] = "NNC Portal"
        
    priority = str(request.POST.get('requestPriority'))
    if priority == 0:
        reqstFrmMailData['priority'] = "High"
    else:
        reqstFrmMailData['priority'] = "Medium"
    
    ccMails = str(request.POST.get('rfCCList'))
    ccMail = re.sub(r'\s', '', ccMails).split(',')
    sponsorMail = str(request.POST.get('sponsorEmail'))
    ccMail = ccMail+[fromMail]+[sponsorMail]
    configobj = ConfigManager()
    toMails = configobj.getCommConfigValue(configobj.RequirementFormToEmail)
    import ast
    toMail = ast.literal_eval(toMails)
    toMail = re.sub(r'\s', '', toMail).split(',')
    ''' email '''
    
    inputData = {}
    inputData['templateName'] = 'request_form_mail.html'
    inputData['to'] = toMail
    inputData['bcc'] = ccMail
    inputData['subject'] = "RF-"+code+':'+requestFormData['subject']
    comObj.sendEmail(reqstFrmMailData, inputData)
    
    return render_to_response('showReqDetails.html')

'''Updating the request, which includes status and decision, update can be done anyone'''
def updateReqDetails(request):
    reqId = str(request.POST.get('reqCode'))
    reqDtails = NrRequestform.objects.using('rosterRead').filter(requirement_code = reqId)
    for reqstDtails in reqDtails:
        reqstrId = reqstDtails.requester_id
    usrId = request.session['uId']
    
    requestFormData = {}
    requestFormData['status'] = str(request.POST.get('status'))
    requestFormData['owner'] = request.session['uId']
    if reqstrId == usrId:
        contentDict = {}
        contentDict['scopeOfWork'] = str(request.POST.get('rf_scopeOfWork'))
        contentDict['businessJustification'] = str(request.POST.get('rf_busJust'))
        contentDict['quantitativeImpact'] = str(request.POST.get('rf_quantImpct'))
        content = pickle.dumps(contentDict)
        requestFormData['content'] = content
    ticketModelObj = CommonTicketModel()
    currentMkTime  = ticketModelObj.getCurrentUnixTimestamp()
    requestFormData['last_updated'] = int(currentMkTime)
    requestFormData['decision_taken'] = str(request.POST.get('dec_taken'))
    requestFormData['comment'] = str(request.POST.get('rf_comment'))
    condition = " requirement_code = '"+reqId+"'"
    commMM = CommonModelMethods()
    reqID = commMM.updateRecord(requestFormData, 'nr_requestform', condition, 'rosterWrite')
    return render_to_response('showReqDetails.html')

'''Notes to considered, leaving some notes regarding the usefullness or modifications or suggestions regarding a particular request'''
'''This section is visible only when status of request is in completed'''
def resultsCaptured(request):
    resCapture = str(request.POST.get('resCaptured'))
    reqId = str(request.POST.get('reqCode'))
    reqDetails = NrRequestform.objects.using('rosterRead').filter(requirement_code = reqId)
    ticketModelObj = CommonTicketModel()
    currentMkTime  = ticketModelObj.getCurrentUnixTimestamp()
    for reqstDetails in reqDetails:
        res = str(reqstDetails.res_captured)
        
        i = 0
    if res == "None":
        resultCaptured = {}
        resCapContent = {}
        resCapContent['res_cap'] = str(request.POST.get('resCaptured'))
        resCapContent['timeline'] = int(currentMkTime)
        resCapContent['res_cap_by'] = request.session['uId']
        resultCaptured[i] = resCapContent
        result = {}
        result['res_captured'] = pickle.dumps(resultCaptured)
        condition = " requirement_code = '"+reqId+"'"
        commMM = CommonModelMethods()
        reqID = commMM.updateRecord(result, 'nr_requestform', condition, 'rosterWrite')
    else:
        resultCaptured = {}
        for reqstDetails in reqDetails:
            resCapContent = pickle.loads(reqstDetails.res_captured)
            cnt = len(resCapContent)
        cnt = cnt+1
        resCaptured = {}
        resCapture = {}
        resCapture['res_cap'] = str(request.POST.get('resCaptured'))
        resCapture['timeline'] = int(currentMkTime)
        resCapture['res_cap_by'] = request.session['uId']
        resCaptured[cnt] = resCapture
        resCapContent.update(resCaptured)
        result = {}
        result['res_captured'] = pickle.dumps(resCapContent)
        condition = " requirement_code = '"+reqId+"'"
        commMM = CommonModelMethods()
        reqID = commMM.updateRecord(result, 'nr_requestform', condition, 'rosterWrite')
    
    return render_to_response('showReqDetails.html')
