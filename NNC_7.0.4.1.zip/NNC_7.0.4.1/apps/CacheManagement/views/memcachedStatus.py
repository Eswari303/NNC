from django import http 
from django.http import HttpResponseRedirect,HttpResponse
from django.shortcuts import render_to_response
from django.conf import settings
import datetime, re
from django.template import RequestContext
from apps.CacheManagement.models.commonModel import CommonModel
cacheModel = CommonModel()

def displayAllKeysView(request):
    accessFlag = cacheModel.checkingAccess(request)
    if accessFlag == True:
        allKeys = cacheModel.getAllMemcachedKeys(host='127.0.0.1', port=11211)
        return render_to_response(
            'memcached_status.html', dict(
                allKeys=allKeys,
                time=datetime.datetime.now(),
            ),RequestContext(request))
    else:
        return HttpResponseRedirect('/NNCPortal/Login/')

def clearALLCache(request):
    accessFlag = cacheModel.checkingAccess(request)
    if accessFlag == True:
        result = cacheModel.allClear()
        if result == True:
            return HttpResponse("Successfully Cleared ALL Cache") 
        else:
            return HttpResponse(result)
    else:
        return HttpResponseRedirect('/NNCPortal/Login/')

def getKeyValue(request):
    accessFlag = cacheModel.checkingAccess(request)
    if accessFlag == True:
        if request.method == 'GET' :
            cache_key = str(request.GET.get('cache_key',None))
            if cache_key:
                memcache_value = cacheModel.getMemcacheValue(cache_key)
                return HttpResponse(memcache_value)
            else:
                return HttpResponse(' Key not existed in memcache')
    else:
        return HttpResponseRedirect('/NNCPortal/Login/')
        
def flushKeyValue(request):
    accessFlag = cacheModel.checkingAccess(request)
    if accessFlag == True:
        if request.method == "POST":
            memcache_key = request.POST["memcache_key"]
            memcache_value = False
            if memcache_key:
                memcache_value = cacheModel.flushMemcacheValue(memcache_key)
            if memcache_value == False:
                return HttpResponse(' Key not existed in memcache')
            else:
                return HttpResponse(memcache_value)
    else:
        return HttpResponseRedirect('/NNCPortal/Login/')