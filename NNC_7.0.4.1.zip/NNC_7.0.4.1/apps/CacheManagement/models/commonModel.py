"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.core.cache import caches
from django.shortcuts import HttpResponse
mem_cache = caches['memcached']
default = caches['default']
filecache = caches['filecache']
from django.http import HttpResponseRedirect
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()

class CommonModel(object):
    
    def __init__(self):
        pass
        
    def allClear(self):
        try:
            filecache.clear()
            mem_cache.clear()
            default.clear()
            return True
        except Exception as e:
            return e

    def getMemcacheValue(self,mkey):
        if mem_cache.has_key(str(mkey)):
            return mem_cache.get(str(mkey))
        else:
            return None
    
    def flushMemcacheValue(self,mkey):
        if mem_cache.has_key(str(mkey)):
            print '-------------------------------------------------------------',mkey
            result = {}
            result['before']=self.getMemcacheValue(mkey)
            print result['before']
            print '<--------------------------->'
            mem_cache.set(str(mkey), None, 0)
            result['after']=self.getMemcacheValue(mkey)
            print result['after']
            print '-------------------------------------------------------------'
            return result
        else:
            return False

    def getAllMemcachedKeys(self,host='127.0.0.1', port=11211):
        try:
            import telnetlib
            t = telnetlib.Telnet(host, port)
            t.write('stats items STAT items:0:number 0 END\n')
            items = t.read_until('END').split('\r\n')
            keys = set()
            for item in items:
                parts = item.split(':')
                if not len(parts) >= 3:
                    continue
                slab = parts[1]
                t.write('stats cachedump {} 200000 ITEM views.decorators.cache.cache_header..cc7d9 [6 b; 1256056128 s] END\n'.format(slab))
                cachelines = t.read_until('END').split('\r\n')
                for line in cachelines:
                    parts = line.split(' ')
                    if not len(parts) >= 3:
                        continue
                    keys.add(parts[1].split(':')[2])
            t.close()
            return keys
        except Exception as e:
            return None

    def checkingAccess(self,request):
        if 'uName' in request.session :
            return True
        else :
            logURL = configobj.getConfigValue(configobj.loginurl)
            return HttpResponseRedirect(logURL)