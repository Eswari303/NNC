'''
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
'''

from django.shortcuts import render_to_response, render
from django.template import RequestContext
import json as simplejson
from django.http import HttpResponse, HttpResponseRedirect
from django.core.context_processors import csrf
from apps.HRData.serviceHrData import hrData
hrdObj = hrData()
from NNCPortal.commonMethods import commonMethods
from NNCPortal.configfile import ConfigManager
import re
from django.db import connections
from NNCPortal.commonMethods import commonMethods
comObj = commonMethods()
method_obj = commonMethods()
from django.contrib import messages

def index(request):    
    hrDataHeader = hrdObj.hrDataHeader
    authRes = comObj.checkAuthentication(request)
    if authRes == True :
        
        if request.session['hrdata_access'] == 1:
            if request.method == "GET":
                content = {}
                content.update(csrf(request))
                content['hrDataHeader'] = hrDataHeader
                #messages.warning(request, 'schedular_saved_successfully')
                return render_to_response('hrData.html', content,context_instance=RequestContext(request))
        else:
                return HttpResponseRedirect('/serviceManagement/')
    else:
            return HttpResponseRedirect('/NNCPortal/Login/')

def uploadFile(request):
    response = {}
    response = hrdObj.uploadFile(request)
    if response['status'] == 'success' :
        response = hrdObj.updateExcelToDb(request, response['absPath'])
        if response['diffFound']:
            configobj = ConfigManager()
            toMails = configobj.getCommConfigValue(configobj.HrDataToEmail)
            import ast
            toMail = ast.literal_eval(toMails)
            toMail = re.sub(r'\s', '', toMail).split(',')
            
            inputData = {}
            inputData['templateName'] = 'errorMail.html'
            inputData['to'] = toMail
            inputData['bcc'] = []
            inputData['subject'] = "HR Data modified"
            msg = '<p style="font-family: arial;font-size:13px;">Hi, <br>HR Data has been modified by '
            msg += str(request.session['uName'])
            msg += ' and below are the changes<br></p>'
            msg += response['diffFound']
            
            comObj.sendEmail(msg, inputData)
    jsonData = simplejson.dumps(response)
    return HttpResponse(jsonData, content_type="application/json")

def getStaffInfo(request):
    if request.method == "GET":
        staffInfo = hrdObj.getStaffInfoFromDB()
        jsonData = simplejson.dumps(staffInfo, default=hrdObj.date_handler)
        return HttpResponse(jsonData, content_type="application/json")
    
def deleteStaff(request): 
    response = {}
    if request.method == "POST":
        response = hrdObj.deleteStaff(request)
    jsonData = simplejson.dumps(response)
    return HttpResponse(jsonData, content_type="application/json")


def reportsQueue(request):
    cursor = connections['rosterRead'].cursor()
    sql = "select * from nnc_job_queue where reportType='R' order by JQid"
    cursor.execute(sql)
    queue = method_obj.dictfetchall(cursor)
    cursor.close()
    heading = []
    for heading in queue:
        heading = heading.keys()
    if request.is_ajax():
        jsonData = simplejson.dumps({'json': queue})
        return HttpResponse(jsonData, content_type="application/json")
    else:
        return render(request, 'apiresult.html', {'queue':queue, 'heading': heading})

def reportsScheduledQueue(request):
    cursor = connections['rosterRead'].cursor()
    sql = "select JobId, JobName, emailIds, reportType, templateId, scheduleType, createdBy, IsPublic, LastStatus from nnc_sch_jobs;"
    cursor.execute(sql)
    queueSch = method_obj.dictfetchall(cursor)
    cursor.close()
    if request.is_ajax():
        jsonData = simplejson.dumps({'jsonscheduled': queueSch})
        return HttpResponse(jsonData, content_type="application/json")
    else:
        return render(request, 'apiresult.html', {'queueSch':queueSch })

def mspQueue(request):
    cursor = connections['ticketRead'].cursor()
    sql = "select count(*) from ntspsa_queue"
    cursor.execute(sql)
    mspqueue = cursor.fetchall()
    cursor.close()
    mspqueue = mspqueue[0][0]
    if request.is_ajax():
        jsonDataQueue = simplejson.dumps({'mspqueue': mspqueue})
        return HttpResponse(jsonDataQueue, content_type="application/json")
    else:
        return render(request, 'apiresult.html', {'mspqueue': mspqueue})

from django.views.decorators.csrf import csrf_exempt
@csrf_exempt
def deleteQueue(request):
    if request.POST:
        id = request.POST.get('id')
        cursor = connections['rosterWrite'].cursor()
        sql = "delete from nnc_job_queue where reportType='R' and JQid="+id
        cursor.execute(sql)
        cursor.close()
    return HttpResponse()


@csrf_exempt
def deleteScheduledQueue(request):
    if request.POST:
        id = request.POST.get('id')
        cursor = connections['rosterWrite'].cursor()
        sql = "delete from nnc_sch_jobs where JobId="+id
        cursor.execute(sql)
        cursor.close()
    return HttpResponse()

def dbStatus(request):
    cursor = connections['mspDB'].cursor()
    sql = "SELECT * FROM information_schema.processlist"
    cursor.execute(sql)
    showstatus = method_obj.dictfetchall(cursor)
    cursor.close()
    if request.is_ajax():
        jsonData = simplejson.dumps({'dbStatus': showstatus})
        return HttpResponse(jsonData, content_type="application/json")
    else:
        return render(request, 'apiresult.html', {'showstatus':showstatus })

def dbSlaveStatus(request):
    MYSQL_SHOW_SLAVE_STATUS = 'SHOW SLAVE STATUS'
    cursor = connections['mspDB'].cursor()
    cursor.execute(MYSQL_SHOW_SLAVE_STATUS)
    slavestatus = method_obj.dictfetchall(cursor)
    cursor.close()
    behindMaster = []
    for data in slavestatus:
        behindMaster.append(data['Seconds_Behind_Master'])
    if request.is_ajax():
        jsonData = simplejson.dumps({'slavestatus': behindMaster})
        return HttpResponse(jsonData, content_type="application/json")
    else:
        return render(request, 'apiresult.html', {'slavestatus':behindMaster })

@csrf_exempt
def dbDeleteProcess(request):
    if request.POST:
        id = request.POST.get('id')
        KILL_PROCESS = 'kill'+id
        cursor = connections['mspDB'].cursor()
        cursor.execute(KILL_PROCESS)
        cursor.close()
    return HttpResponse()

