"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
import os
from django.conf import settings
from django.db import connection,connections
from django.core.cache import caches, cache
from NNCPortal.commonMethods import commonMethods
from django.template.context_processors import request
import datetime
from models.NrEmpDemographic import NrEmpDemographic
from pyexcel_xlsx import get_data
from _sqlite3 import Row
from dateutil.parser import parse
from copy import deepcopy
comObj = commonMethods()


class hrData():
    hrDataHeader = {0:'Emp ID',1:'Employee Name',2:'DOJ',3:'Prior Exp',4:'NE Exp',5:'Total Exp',
                    6:'Qualification', 7:'Grade',8:'Current Title',9:'Reporting Manager',
                    10:'Functional Owner',11:'Business Division',12:'Business Group',13:'Status',
                    14:'Type',15:'Contracting Company',16:'Geography',17:'Work Location',18:'Practice',
                    19:'Skill 1',20:'Skill 1 - Level',21:'Skill 2',22:'Skill 2 - Level',23:'Shared',
                    24:'Shared %',25:'Direct  1',26:'Direct1 %',27:'Direct 2',28:'Direct 2%',
                    29:'Date of Resignation',30:'Exit Date'}
    16,17
    #hrDataHeader = {'Emp No','Employee Name','DOJ','Grade','Current Title','Reporting Manager','Functional Owner','Work Location','Functional Unit','Skill 1','Skill 1 - Level','Skill 2','Skill 2 - Level','Shared','Shared %','Direct  1','Direct1 %','Direct 2','Direct 2%','Status','Type','Contracting Company','Date_of Resignation','Date_of Relieve'}
    
    def defaultConections(self,sql):
        cursor = connections['rosterWrite'].cursor()
        cursor.execute(sql)
        finResult = comObj.dictfetchall(cursor)
        cursor.close()
        return finResult
    
    def uploadFile(self, request):
        response = {}
        try:
            mediaPath = request.build_absolute_uri().replace(request.get_full_path(), '')+"/static/files/"
            uploadPath = os.path.join(settings.BASE_DIR, "static/files/")
            upfile = request.FILES['uploadFile']
            fileName = upfile.name
            ext = str(fileName).split(".")[1].lower()
            if ext in ['xls', 'xlsx']:
                absPath = uploadPath+fileName
                destination = open(absPath, 'wb+')
                for chunk in upfile.chunks():
                    destination.write(chunk)
                destination.close()            
                response['status'] = 'success'
                response['absPath'] = absPath
            else:
                response['status'] = 'fail'
                response['message'] = 'Invalid Format'
        except Exception as e:
            response['status'] = 'fail'
            response['message'] = e.message
        return response
    
    def updateExcelToDb(self, request, excelName):
        response = {}
        excelEmptyCell = [None,'','-']
        differencesFound = ''
        
        try:
            self.backupHrData(request)
            fileData = get_data(excelName)
            for sheetInfo in fileData:
                for row, data in enumerate(fileData[sheetInfo]):
                    if row == 0 :
                        excelHeader = data
                        excelHeaderLen = len(excelHeader)
                    else :
                        nullList = ['-'] * (excelHeaderLen - len(data))
                        data = data + nullList
                        
                        empId = data[1]
                        dataEmpName = data[2]
                        dataDOJ = data[3]
                        dataPriorExp = data[4]
                        dataQualification = data[7]
                        dataGrade = data[8]
                        dataCurrentTitle = data[9]
                        dataReportingManager = data[10]
                        dataFunctionalOwner = data[11]
                        dataBusinessDivision = data[12]
                        dataBusinessGroup = data[13]
                        dataEmpStatus = data[14]
                        dataEmpType = data[15]
                        dataContractingCompany = data[16]
                        
                        dataGeography = data[17]
                        dataWorkLocation = data[18]
                        dataPractice = data[19]
                        dataSkillOne = data[20]
                        dataSkillOneLevel = data[21]
                        dataSkillTwo = data[22]
                        dataSkillTwoLevel = data[23]
                        dataShared = data[24]
                        dataSharedPercent = data[25]
                        dataDirectOne = data[26]
                        dataDirectOnePercent = data[27]
                        dataDirectTwo = data[28]
                        dataDirectTwoPercent = data[29]
                        
                        dataDateOfResignation = data[30]
                        dataExitDate = data[31]
                        
                        
                        dataMissMatch = {}
                        if isinstance(dataDOJ, datetime.date):
                            doj = dataDOJ
                        else:
                            excelDoj = parse(dataDOJ)
                            doj = excelDoj.strftime('%Y-%m-%d')
                        #doj = str(doj)
                        
                        if isinstance(dataDateOfResignation, datetime.date):
                            date_of_resignation = dataDateOfResignation
                        else:
                            if dataDateOfResignation not in excelEmptyCell:
                                excelDoj = parse(dataDateOfResignation)
                                date_of_resignation = excelDoj.strftime('%Y-%m-%d')
                            else:
                                date_of_resignation = ''
                         
                        if isinstance(dataExitDate, datetime.date):
                            date_of_relieve = dataExitDate
                        else:
                            if dataExitDate not in excelEmptyCell:
                                excelDoj = parse(dataExitDate)
                                date_of_relieve = excelDoj.strftime('%Y-%m-%d')
                            else:
                                date_of_relieve = ''
                        
                        try:
                            staffObj = NrEmpDemographic.objects.using("rosterWrite").get(employee_id=empId)
                            staffObjCopy = deepcopy(staffObj)
                            flagFoundDiff = False
                            
                            #staffObj.employee_id = str(data[1])
                            staffObj.staff_name = str(dataEmpName)
                            if staffObj.staff_name != staffObjCopy.staff_name :
                                dataMissMatch['Employee Name'] = {'Old':staffObjCopy.staff_name, 'New': staffObj.staff_name}                                
                            
                            dojOld = staffObj.doj.strftime('%Y-%m-%d')
                            if dojOld != doj:
                                dataMissMatch['DOJ'] = {'Old':dojOld, 'New': doj}
                            staffObj.doj = doj if doj else None
                            
                            staffObj.prior_exp = int(dataPriorExp) if dataPriorExp not in excelEmptyCell else None
                            if staffObj.prior_exp != staffObjCopy.prior_exp:
                                dataMissMatch['Prior Exp'] = {'Old':staffObjCopy.prior_exp, 'New': staffObj.prior_exp}
                            
                            staffObj.qualification = str(dataQualification)
                            if staffObj.qualification != staffObjCopy.qualification :
                                dataMissMatch['Qualification'] = {'Old':staffObjCopy.qualification, 'New': staffObj.qualification}
                            
                            staffObj.grade = int(dataGrade) if dataGrade not in excelEmptyCell else None
                            if staffObj.grade != staffObjCopy.grade:
                                dataMissMatch['Grade'] = {'Old':staffObjCopy.grade, 'New': staffObj.grade}
                            
                            staffObj.current_title = str(dataCurrentTitle) if dataCurrentTitle not in excelEmptyCell else None
                            if staffObj.current_title != staffObjCopy.current_title:
                                dataMissMatch['Current Title'] = {'Old':staffObjCopy.current_title, 'New': staffObj.current_title}
                            
                            staffObj.reporting_manager = str(dataReportingManager) if dataReportingManager not in excelEmptyCell else None
                            if staffObj.reporting_manager != staffObjCopy.reporting_manager:
                                dataMissMatch['Reporting Manager'] = {'Old':staffObjCopy.reporting_manager, 'New': staffObj.reporting_manager}
                            
                            staffObj.functional_owner = str(dataFunctionalOwner) if dataFunctionalOwner not in excelEmptyCell else None
                            if staffObj.functional_owner != staffObjCopy.functional_owner:
                                dataMissMatch['Functional Owner'] = {'Old':staffObjCopy.functional_owner, 'New': staffObj.functional_owner}
                                
                            staffObj.business_divison = str(dataBusinessDivision) if dataBusinessDivision not in excelEmptyCell else None
                            if staffObj.business_divison != staffObjCopy.business_divison:
                                dataMissMatch['Business Division'] = {'Old':staffObjCopy.business_divison, 'New': staffObj.business_divison}
                                
                            staffObj.business_group = str(dataBusinessGroup) if dataBusinessGroup not in excelEmptyCell else None
                            if staffObj.business_group != staffObjCopy.business_group:
                                dataMissMatch['Business Group'] = {'Old':staffObjCopy.business_group, 'New': staffObj.business_group}
                                
                            
                            ##---------------
                            employeeStatus = 1 if str(dataEmpStatus).lower().strip() == 'active' else 0
                            staffObj.employee_status = employeeStatus
                            employeeStatusOld = 'Active' if staffObjCopy.employee_status == 1 else 'Inactive'
                            if staffObj.employee_status != staffObjCopy.employee_status:
                                dataMissMatch['Employee Status'] = {'Old':employeeStatusOld, 'New': dataEmpStatus}
                            
                            
                            employeeType = 0 if str(dataEmpType).lower().strip() == 'fte' else 1
                            staffObj.employee_type = employeeType
                            employeeTypeOld = 'FTE' if staffObjCopy.employee_type == 0 else 'Contractor'
                            if staffObj.employee_type != staffObjCopy.employee_type:
                                dataMissMatch['Employee Type'] = {'Old':employeeTypeOld, 'New': dataEmpType}
                            
                            staffObj.contracting_company = str(dataContractingCompany) if dataContractingCompany not in excelEmptyCell else None
                            if staffObj.contracting_company != staffObjCopy.contracting_company:
                                dataMissMatch['Contracting Company'] = {'Old':staffObjCopy.contracting_company, 'New': staffObj.contracting_company}
                            
                            
                            if isinstance(date_of_resignation, datetime.date):
                                date_of_resignation = date_of_resignation.strftime('%Y-%m-%d')
                            if staffObj.date_of_resignation :
                                dateOfResignationOld = staffObj.date_of_resignation.strftime('%Y-%m-%d')
                            else:
                                dateOfResignationOld = ''
                            if dateOfResignationOld != date_of_resignation:
                                dataMissMatch['Date of Resignation'] = {'Old':dateOfResignationOld, 'New': date_of_resignation}
                            staffObj.date_of_resignation = date_of_resignation if date_of_resignation else None
                            
                            if isinstance(date_of_relieve, datetime.date):
                                date_of_relieve = date_of_relieve.strftime('%Y-%m-%d')                                
                            if staffObj.date_of_relieve :
                                dateOfRelieveOld = staffObj.date_of_relieve.strftime('%Y-%m-%d')
                            else:
                                dateOfRelieveOld = ''
                            if dateOfRelieveOld != date_of_relieve:
                                dataMissMatch['Date of Relieve'] = {'Old':dateOfRelieveOld, 'New': date_of_relieve}
                            staffObj.date_of_relieve = date_of_relieve if date_of_relieve else None
                            
                            ##---------------
                            staffObj.geography = str(dataGeography) if dataGeography not in excelEmptyCell else None
                            if staffObj.geography != staffObjCopy.geography:
                                dataMissMatch['Geography'] = {'Old':staffObjCopy.geography, 'New': staffObj.geography}
                                
                            staffObj.work_localtion = str(dataWorkLocation) if dataWorkLocation not in excelEmptyCell else None
                            if staffObj.work_localtion != staffObjCopy.work_localtion:
                                dataMissMatch['Work Location'] = {'Old':staffObjCopy.work_localtion, 'New': staffObj.work_localtion}
                            
                            staffObj.functional_unit = str(dataPractice) if dataPractice not in excelEmptyCell else None
                            if staffObj.functional_unit != staffObjCopy.functional_unit:
                                dataMissMatch['Practice'] = {'Old':staffObjCopy.functional_unit, 'New': staffObj.functional_unit}
                            
                            staffObj.skill_one = str(dataSkillOne) if dataSkillOne not in excelEmptyCell else None
                            if staffObj.skill_one != staffObjCopy.skill_one:
                                dataMissMatch['Skill One'] = {'Old':staffObjCopy.skill_one, 'New': staffObj.skill_one}
                            
                            staffObj.skill_one_level = str(dataSkillOneLevel) if dataSkillOneLevel not in excelEmptyCell else None
                            if staffObj.skill_one_level != staffObjCopy.skill_one_level:
                                dataMissMatch['Skill One Level'] = {'Old':staffObjCopy.skill_one_level, 'New': staffObj.skill_one_level}
                            
                            staffObj.skill_two = str(dataSkillTwo) if dataSkillTwo not in excelEmptyCell else None
                            if staffObj.skill_two != staffObjCopy.skill_two:
                                dataMissMatch['Skill Two'] = {'Old':staffObjCopy.skill_two, 'New': staffObj.skill_two}
                            
                            staffObj.skill_two_level = str(dataSkillTwoLevel) if dataSkillTwoLevel not in excelEmptyCell else None
                            if staffObj.skill_two_level != staffObjCopy.skill_two_level:
                                dataMissMatch['Skill Two Level'] = {'Old':staffObjCopy.skill_two_level, 'New': staffObj.skill_two_level}
                            
                            staffObj.shared = str(dataShared) if dataShared not in excelEmptyCell else None
                            if staffObj.shared != staffObjCopy.shared:
                                dataMissMatch['Shared'] = {'Old':staffObjCopy.shared, 'New': staffObj.shared}
                            
                            staffObj.shared_percent = str(dataSharedPercent) if dataSharedPercent not in excelEmptyCell else None
                            if staffObj.shared_percent != staffObjCopy.shared_percent:
                                dataMissMatch['Shared Percent'] = {'Old':staffObjCopy.shared_percent, 'New': staffObj.shared_percent}
                            
                            staffObj.direct_one = str(dataDirectOne) if dataDirectOne not in excelEmptyCell else None
                            if staffObj.direct_one != staffObjCopy.direct_one:
                                dataMissMatch['Direct One'] = {'Old':staffObjCopy.direct_one, 'New': staffObj.direct_one}
                            
                            staffObj.direct_one_percent = str(dataDirectOnePercent) if dataDirectOnePercent not in excelEmptyCell else None
                            if staffObj.direct_one_percent != staffObjCopy.direct_one_percent:
                                dataMissMatch['Direct One%'] = {'Old':staffObjCopy.direct_one_percent, 'New': staffObj.direct_one_percent}
                            
                            staffObj.direct_two = str(dataDirectTwo) if dataDirectTwo not in excelEmptyCell else None
                            if staffObj.direct_two != staffObjCopy.direct_two:
                                dataMissMatch['Direct Two'] = {'Old':staffObjCopy.direct_two, 'New': staffObj.direct_two}
                            
                            staffObj.direct_two_percent = str(dataDirectTwoPercent) if dataDirectTwoPercent not in excelEmptyCell else None
                            if staffObj.direct_two_percent != staffObjCopy.direct_two_percent:
                                dataMissMatch['Direct Two%'] = {'Old':staffObjCopy.direct_two_percent, 'New': staffObj.direct_two_percent}
                            
                            
                            
                            
                            if len(dataMissMatch) > 0:
                                differencesFound += '<p style="font-family: arial;font-size:13px;">'
                                differencesFound += '<strong>'+str(staffObj.employee_id)+'</strong>';
                                differencesFound += '<table style="font-family: arial;font-size:13px;" width="50%" cellspacing="0" cellpadding="0" border="1">'
                                differencesFound += '<thead>'
                                differencesFound += '<tr>'
                                differencesFound += '<td>Field</td>'
                                differencesFound += '<td>Old</td>'
                                differencesFound += '<td>New</td>'
                                differencesFound += '</tr>'
                                differencesFound += '</thead>'
                                differencesFound += '<tbody>'
                                for key, data in dataMissMatch.items():
                                    differencesFound += '<tr>'
                                    differencesFound += '<td>'+key+'</td>'
                                    differencesFound += '<td>'+str(data['Old'])+'</td>'
                                    differencesFound += '<td>'+str(data['New'])+'</td>'
                                    differencesFound += '</tr>'
                                differencesFound += '</tbody>'
                                differencesFound += '</table>'
                                differencesFound += '</p>'
                                
                            
                        except NrEmpDemographic.DoesNotExist:
                            staffObj = NrEmpDemographic.objects.using('rosterWrite').create(
                                employee_id = str(empId),
                                staff_name = str(dataEmpName),
                                doj = doj if doj else None,
                                prior_exp = int(dataPriorExp) if dataPriorExp not in excelEmptyCell else 0,
                                qualification = str(dataQualification) if dataQualification not in excelEmptyCell else None,
                                grade = int(dataGrade) if dataGrade not in excelEmptyCell else 0,
                                current_title = str(dataCurrentTitle) if dataCurrentTitle not in excelEmptyCell else None,
                                reporting_manager = str(dataReportingManager) if dataReportingManager not in excelEmptyCell else None,
                                functional_owner = str(dataFunctionalOwner) if dataFunctionalOwner not in excelEmptyCell else None,
                                
                                business_divison = str(dataBusinessDivision) if dataBusinessDivision not in excelEmptyCell else None,
                                business_group = str(dataBusinessGroup) if dataBusinessGroup not in excelEmptyCell else None,
                                
                                employee_status = 1 if str(dataEmpStatus).lower().strip() == 'active' or dataEmpStatus not in excelEmptyCell else 0,
                                employee_type = 0 if str(dataEmpType).lower().strip() == 'fte' or dataEmpType not in excelEmptyCell else 1,
                                contracting_company = str(dataContractingCompany) if dataContractingCompany not in excelEmptyCell else None,
                                date_of_resignation = date_of_resignation if date_of_resignation else None,
                                date_of_relieve = date_of_relieve if date_of_relieve else None,
                                
                                geography = str(dataGeography) if dataGeography not in excelEmptyCell else None,
                                work_localtion = str(dataWorkLocation) if dataWorkLocation not in excelEmptyCell else None,
                                #practice
                                functional_unit = str(dataPractice) if dataPractice not in excelEmptyCell else None,
                                skill_one = str(dataSkillOne) if dataSkillOne not in excelEmptyCell else None,
                                skill_one_level = str(dataSkillOneLevel) if dataSkillOneLevel not in excelEmptyCell else None,
                                skill_two = str(dataSkillTwo) if dataSkillTwo not in excelEmptyCell else None,
                                skill_two_level = str(dataSkillTwoLevel) if dataSkillTwoLevel not in excelEmptyCell else None,
                                shared = str(dataShared) if dataShared not in excelEmptyCell else None,
                                shared_percent = str(dataSharedPercent) if dataSharedPercent not in excelEmptyCell else None,
                                direct_one = str(dataDirectOne) if dataDirectOne not in excelEmptyCell else None,
                                direct_one_percent = str(dataDirectOnePercent) if dataDirectOnePercent not in excelEmptyCell else None,
                                direct_two = str(dataDirectTwo) if dataDirectTwo not in excelEmptyCell else None,
                                direct_two_percent = str(dataDirectTwoPercent) if dataDirectTwoPercent not in excelEmptyCell else None
                                
                            )
                            
                        validationStatus = staffObj.validateData()
                        if validationStatus is True:
                            staffObj.save()
                            #pass
                        else:
                           response['status'] = "fail"
                           response['message'] = validationStatus
                           response['diffFound'] = differencesFound
                           #staffObj.delete()
                           return response                        
                       
            response['status'] = "success"
            response['message'] = "Data updated successfully!"
            response['diffFound'] = differencesFound
        except Exception as e:
            response['status'] = "fail"
            response['message'] = e.message
            response['diffFound'] = differencesFound
        
        return response
                    
    def getStaffInfoFromDB(self):
        #sql = "SELECT id,employee_id,staff_name,grade,UNIX_TIMESTAMP(doj) AS doj_unixtime, doj AS date_of_join,current_title,reporting_manager,functional_owner,work_localtion,functional_unit,skill_one,skill_one_level,skill_two,skill_two_level,shared,shared_percent,direct_one,direct_one_percent,direct_two,direct_two_percent FROM nr_emp_demographic ORDER BY LENGTH(employee_id), employee_id ASC"
        sql = "SELECT *, TIMESTAMPDIFF(MONTH, doj, NOW()) AS ne_exp, UNIX_TIMESTAMP(doj) AS doj_unixtime, doj AS date_of_join, UNIX_TIMESTAMP(date_of_resignation) AS doresig_unixtime, UNIX_TIMESTAMP(date_of_relieve) AS dorelieve_unixtime FROM nr_emp_demographic ORDER BY LENGTH(employee_id), employee_id ASC";
        cursor = connections['rosterWrite'].cursor()
        cursor.execute(sql)
        finResult = comObj.dictfetchall(cursor)
        cursor.close() 
        return finResult

    def date_handler(self, obj):
        return obj.strftime('%d-%b-%Y') if hasattr(obj, 'isoformat') else obj
    
    def deleteStaff(self, request):
        response = {}
        try:
            NrEmpDemographic.objects.using("rosterWrite").filter(pk__in=request.POST.getlist('staffid')).delete()
            response['status'] = 'success'
            response['message'] = "Selected records removed successfully"
        except Exception as e:
            response['status'] = "fail"
            response['message'] = "Error: Unable to delete records because "+e.message
        
        return response
    
    def backupHrData(self, request):
        global hrDataHeader
        response = {}
        try:
            staffInfo = self.getStaffInfoFromDB()
            
            import xlsxwriter
            row = 0
            col = 0
            nowTime = datetime.datetime.now().strftime('%Y%m%d_%H%M')
            fileName = "{0}_HrData_{1}.xlsx".format(str(request.session['uId']), str(nowTime))
            workbook = xlsxwriter.Workbook('static/files/'+fileName)
            worksheet = workbook.add_worksheet()
            worksheet.write(row, 0, '#')
            for key,value in self.hrDataHeader.iteritems():
                worksheet.write(row, key+1, value)
            
            row = 1
            date_format = workbook.add_format({'num_format': 'd-mmm-yyyy'})
            for key,value in enumerate(staffInfo):
                empStatus = 'Active' if value['employee_status'] else 'Inactive'
                empType = 'FTE' if value['employee_type'] == 0 else 'Contractor'
                worksheet.write_number(key+1, 0, key+1)
                worksheet.write(key+1, 1, value['employee_id'])
                worksheet.write(key+1, 2, value['staff_name'])
                worksheet.write_datetime(key+1, 3, value['doj'],date_format)
                worksheet.write_number(key+1, 4, value['prior_exp'])
                worksheet.write_number(key+1, 5, value['ne_exp'])
                worksheet.write_number(key+1, 6, int(value['ne_exp']) + int(value['prior_exp']))
                worksheet.write(key+1, 7, value['qualification'])
                worksheet.write_number(key+1, 8, int(value['grade']))
                worksheet.write(key+1, 9, value['current_title'])
                worksheet.write(key+1, 10, value['reporting_manager'])
                worksheet.write(key+1, 11, value['functional_owner'])
                worksheet.write(key+1, 12, value['business_divison'])
                worksheet.write(key+1, 13, value['business_group'])
                worksheet.write(key+1, 14, empStatus)
                worksheet.write(key+1, 15, empType)
                worksheet.write(key+1, 16, value['contracting_company'])
                worksheet.write(key+1, 17, value['geography'])
                worksheet.write(key+1, 18, value['work_localtion'])
                worksheet.write(key+1, 19, value['functional_unit'])
                worksheet.write(key+1, 20, value['skill_one'])
                worksheet.write(key+1, 21, value['skill_one_level'])
                worksheet.write(key+1, 22, value['skill_two'])
                worksheet.write(key+1, 23, value['skill_two_level'])
                worksheet.write(key+1, 24, value['shared'])
                worksheet.write_number(key+1, 25, int(value['shared_percent']) if value['shared_percent'] else 0)
                worksheet.write(key+1, 26, value['direct_one'])
                worksheet.write_number(key+1, 27, int(value['direct_one_percent']) if value['direct_one_percent'] else 0)
                worksheet.write(key+1, 28, value['direct_two'])
                worksheet.write_number(key+1, 29, int(value['direct_two_percent']) if value['direct_two_percent'] else 0)
                if value['doresig_unixtime']:
                    worksheet.write_datetime(key+1, 30, value['date_of_resignation'], date_format)
                else:
                    worksheet.write(key+1, 30, None)
                    
                if value['date_of_relieve']:
                    worksheet.write_datetime(key+1, 31, value['date_of_relieve'], date_format)
                else:
                    worksheet.write(key+1, 31, None)
                
            workbook.close()
            
            response['status'] = 'success'
            response['message'] = "Selected records removed successfully"
        except Exception as e:
            response['status'] = "fail"
            response['message'] = "Error: Unable to backup report because "+e.message
        
        return response