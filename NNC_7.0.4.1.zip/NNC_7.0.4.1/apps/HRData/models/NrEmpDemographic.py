"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import models
from django.core.exceptions import ValidationError
from django.utils.translation import ugettext_lazy as _
import re

def validate_even(self):
    print 'under validate even'
    '''
    if value % 2 != 0:
        print value
        raise ValidationError(
            _('%(value)s is not an even number'),
            params={'value': value},
        )
    '''
        
class NrEmpDemographic(models.Model):
    employee_id = models.CharField(unique=True, max_length=10)
    staff_name = models.CharField(max_length=255)
    doj = models.DateField(blank=True, null=True)
    grade = models.IntegerField(blank=True, null=True)
    current_title = models.CharField(max_length=50, blank=True, null=True)
    reporting_manager = models.CharField(max_length=75, blank=True, null=True)
    functional_owner = models.CharField(max_length=75, blank=True, null=True)
    work_localtion = models.CharField(max_length=30, blank=True, null=True)
    functional_unit = models.CharField(max_length=50, blank=True, null=True)
    skill_one = models.CharField(max_length=50, blank=True, null=True)
    skill_one_level = models.CharField(max_length=50, blank=True, null=True)
    skill_two = models.CharField(max_length=50, blank=True, null=True)
    skill_two_level = models.CharField(max_length=50, blank=True, null=True)
    shared = models.CharField(max_length=75, blank=True, null=True)
    shared_percent = models.CharField(max_length=6, blank=True, null=True)
    direct_one = models.CharField(max_length=75, blank=True, null=True)
    direct_one_percent = models.CharField(max_length=6, blank=True, null=True)
    direct_two = models.CharField(max_length=75, blank=True, null=True)
    direct_two_percent = models.CharField(max_length=6, blank=True, null=True)
    employee_status = models.IntegerField(blank=True, null=True)
    employee_type = models.IntegerField(blank=True, null=True)
    contracting_company = models.CharField(max_length=100, blank=True, null=True)
    date_of_resignation = models.DateField(blank=True, null=True)
    date_of_relieve = models.DateField(blank=True, null=True)
    business_divison = models.CharField(max_length=100, blank=True, null=True)
    business_group = models.CharField(max_length=100, blank=True, null=True)
    geography = models.CharField(max_length=75, blank=True, null=True)
    prior_exp = models.IntegerField(blank=True, null=True)
    qualification = models.CharField(max_length=20, blank=True, null=True)

    class Meta:
        #managed = False
        db_table = 'nr_emp_demographic'
        
    def validateData(self):
        exceptionMsg = ''
        flags = 0 | re.I
        regExName = r"""^[a-z. ]+$"""
        regExEmpNo = r"""^E [0-9]+$"""
        if not re.compile(regExName, flags).match(self.staff_name):
            #raise Exception('Invalid Employee name: '+self.staff_name)
            return 'Invalid employee name: '+self.staff_name            
        
        if not re.compile(regExEmpNo, flags).match(self.employee_id):
            return 'Invalid employee number: '+self.employee_id
        
        if int(self.employee_type) == 1  and self.contracting_company is None:
            return 'Contracting Company details missing for '+self.employee_id
        
        if int(self.employee_status) == 0:
            if self.date_of_resignation is None:  
                return 'Please provide resignation date for '+self.employee_id
            if self.date_of_relieve is None:
                return 'Please provide relieving date for '+self.employee_id
            
        return True