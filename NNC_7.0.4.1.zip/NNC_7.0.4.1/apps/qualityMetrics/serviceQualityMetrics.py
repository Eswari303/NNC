"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 * NetEnrich, Inc.
"""

import ast
from django.core.cache import caches
from NNCPortal.commonModels.Swticketpriorities import Swticketpriorities
from serviceManagement.models.commonModel import CommonServiceModel
from django.db import connections
from operator import itemgetter
from NNCPortal.commonMethods import commonMethods
from NNCPortal.configfile import ConfigManager
from NNCPortal.commonModels.NrStaff import NrStaff
nrstaff_obj = NrStaff()
configobj = ConfigManager()
comObj = commonMethods()
mem_cache = caches['memcached']
comMObj = CommonServiceModel()
env = configobj.getCommConfigValue(configobj.app_env)

''' class for quality metric services'''


class QualityMerics():
    # function to get the swatff and priorities
    def GetStaffandPriorities(self):
        # defined empty content dictionary to pass the data in response
        content = {}
        ''' try block to fetch the ticket priorities and swstaff data'''
        try:
            priorities = Swticketpriorities.objects.using('ticketRead').order_by('priorityid')
            #swStaff = mem_cache.get('swStaff')
            #if not swStaff:
            swStaff = nrstaff_obj.getSwStaffByRoster()
                #mem_cache.set('swStaff', swStaff, 86400)
            ''' assigning priorities and staff to content'''
            content['priorities'] = priorities
            content['staff'] = swStaff
            ''' returning the content '''
            return content
        # if something goes wrong exception will be thrown
        except Exception as e:
            return e

    # function is used to fetch the employees tickets data
    def getMetricData(self, data):
        #  converting unicode data to list
        staff = ast.literal_eval(data['staffdata'])
        priorities = ast.literal_eval(data['prioritydata'])
        # splitting date based on space delimiter
        fromdatetimelist = data['fromdate'].split(" ")
        todatetimelist = data['todate'].split(" ")
        #  again splitting 0th index value by / delimiter
        fdatelist = fromdatetimelist[0].split("/")
        tdatelist = todatetimelist[0].split("/")
        #  again reformatting date as per requirement
        formatted_fromdate = str(fdatelist[2]) + "-" + str(fdatelist[0] + "-" + str(fdatelist[1]))
        formatted_todate = str(tdatelist[2]) + "-" + str(tdatelist[0] + "-" + str(tdatelist[1]))
        #  if billable time is equal to on executes if block otherwise else will be executed
        if str(data['billabletime']) == "on":
            flag = 1
        else:
            flag = 0

        # if manage, aid, smartescalate is equal to on executes if block otherwise else will be executed
        # initializing package to empty list
        package = []
        if str(data['manage']) == "on":
            package.append("manage")
        if str(data['aid']) == "on":
            package.append("aid")
        if str(data['smartescalate']) == "on":
            package.append("smartescalate")
        # if length of package is 0 we are appending NA to package list and finalpackage will empty string
        if len(package) == 0:
            package.append("NA")
            finalpackage = ""
        # else  forming packages string by comma separated
        else:
            finalpackage = ",".join(package)
        # forming priorities string by comma separated
        priorities_str = ",".join(priorities)
        # calling getPackageBasedQMInfo to get employee number working mins, tickets closed count, touched count
        packageQMdata = comMObj.getPackageBasedQMInfo(data['fromdate'], data['todate'], staff, priorities, data['timeworked'], flag, data['manage'], data['aid'], data['smartescalate'])
        ''' calling getStaffTotalProductivityBySwStaffId to get employee
         working days, review time, kayako ticket time, and nr staffid, swstaff id'''
        productivitydata = comMObj.getStaffTotalProductivityBySwStaffId(staff, data['fromdate'], data['todate'])
        # initializing emppty dictionary
        finalResults = {}
        # creating dictionary for each employee to hold respective data of employee within final results dict
        for staffid in packageQMdata:
            finalResults[str(staffid[0])] = {}
        #  if packageQMdata exists try block will be executed
        try:
            '''here looping through each record to fetch each employee data
               and storing in employee respective dictionary'''
            for package in packageQMdata:
                # here we are creating the closed tickets url
                closedTktParams = "staffid={0}&priority={1}&timespent={2}&fromdate={3}" \
                                  "&todate={4}&closedflag=3&timeflag={5}&packages={6}".format(str(package[0]),
                                                                                              priorities_str,
                                                                                              str(data['timeworked']),
                                                                                              formatted_fromdate,
                                                                                              formatted_todate,
                                                                                              str(flag),
                                                                                              finalpackage)
                # here we are creating the touched tickets url
                touchedTktParams = "staffid={0}&priority={1}&timespent={2}&fromdate={3}" \
                                   "&todate={4}&closedflag=0&timeflag={5}&packages={6}".format(str(package[0]),
                                                                                               priorities_str,
                                                                                               str(data['timeworked']),
                                                                                               formatted_fromdate,
                                                                                               formatted_todate,
                                                                                               str(flag),
                                                                                               finalpackage)
                # we are creating respective data dictionary for each employee
                finalResults[str(package[0])]['staffid'] = str(package[0])
                finalResults[str(package[0])]['fullname'] = str(package[1])
                finalResults[str(package[0])]['tickets_closed'] = str(package[5])
                finalResults[str(package[0])]['tickets_touched'] = str(package[2])
                finalResults[str(package[0])]['time_spent'] = str(package[3])
                finalResults[str(package[0])]['time_billable'] = str(package[4])
                finalResults[str(package[0])]['working_days'] = productivitydata[str(package[0])]['working_days']
                finalResults[str(package[0])]['kyk_mins_worked'] = productivitydata[str(package[0])]['kyk_mins_worked']
                finalResults[str(package[0])]['review_time'] = productivitydata[str(package[0])]['review_time']
                finalResults[str(package[0])]['utilization'] = productivitydata[str(package[0])]['utilization']
                finalResults[str(package[0])]['closedTktParams'] = closedTktParams
                finalResults[str(package[0])]['touchedTktParams'] = touchedTktParams
            # returning the final data
            return finalResults
        #  except block will be executed if something goes wrong
        except Exception as e:
            return e

    #  common function for fetching closed and touched tickets based on given input
    def getQualityMetricTicketsInfo(self, staffid, priority, timespent, fromdate, todate, closedflag, timeflag,countflag, packages):
        #  formatting the given date to datetime format
        formatted_from_date = str(fromdate) + " 00:00:00"
        formatted_to_date = str(todate) + " 23:59:59"

        #  initializing package_condition to empty string
        package_condition = ""

        # creating priority condition based on its availability
        if priority:
            prioritiescondition = "AND id.priorityid IN (" + priority + ")"
        else:
            prioritiescondition = ""

        # creating packages condition based on its availability
        if packages != "":
            packagestr = ''
            glue = ''
            packages = packages.split(",")
            join = "INNER JOIN swstaff ss ON ss.staffid = swt.creatorstaffid"
            for package in packages:
                packagestr += glue + "'%" +package + "%'"
                glue = ' OR id.service_type like '
            package_condition += "AND (id.service_type like " + packagestr + ")"
        else:
            join = "INNER JOIN swstaff ss ON ss.staffid = swt.creatorstaffid"
            package_condition += ""

        # forming sql statement here
        sql = ""
        # if closed flag is zero we fetch touched tickets information based on given inputs
        if int(closedflag) == 0:
            ''' generationg the touched tickets query '''

            sql += "SELECT DISTINCT swt.ticketid,swt.creatorstaffid ,SUM(swt.timespent) timespent, " \
                   "from_unixtime(id.created_dt) dateline , " \
                   "id.priorityid,id.deptid,id.subject, ts.title as status," \
                   "FROM_UNIXTIME(id.lastactivity) lastactivity, SUM(swt.timebillable) timebillable," \
                   "count(swt.ticketid) replies FROM swtickettimetrack swt " \
                   "INNER JOIN incident_data id ON id.ticketid = swt.ticketid "+ str(join)+ \
                   " INNER JOIN swticketstatus ts ON ts.ticketstatusid = id.statusid " \
                   " WHERE CONVERT_TZ(FROM_UNIXTIME(swt.dateline),'+00:00','+05:30') <= '"+ str(formatted_to_date) +"' " \
                   " AND CONVERT_TZ(FROM_UNIXTIME(swt.dateline),'+00:00','+05:30') >= '" + str(formatted_from_date)+ "' " \
                   " AND swt.timespent>"+str(timespent)+" " + str(prioritiescondition) +" AND creatorstaffid IN (" + staffid + ") " \
                   "GROUP BY swt.creatorstaffid,swt.ticketid"

        #  if closed flag is not equal to zero then we fetch closed tickets info
        else:
            ''' generating the closed tickets query '''

            sql += "SELECT ta.ticketid ,ta.staffid as creatorstaffid,id.priorityid," \
                   "id.deptid,id.subject,ts.title as status, " \
                   "FROM_UNIXTIME(id.lastactivity) lastactivity,ifnull(SUM(swt.timespent),0) as timespent, " \
                   "ifnull(sum(swt.timebillable),0) as timebillable,COUNT(swt.ticketid) replies, " \
                   "from_unixtime(id.created_dt) dateline " \
                   "FROM swtickettimetrack swt INNER JOIN incident_data id ON id.ticketid = swt.ticketid " \
                   "INNER JOIN swticketstatus ts ON ts.ticketstatusid = id.statusid " \
                   "INNER JOIN neticketauditlog ta  ON ts.ticketstatusid=ta.to_id AND ts.statustype=3" + " " + \
                   str(join) + " WHERE CONVERT_TZ(FROM_UNIXTIME(swt.dateline),'+00:00','+05:30') <= '" + str(formatted_to_date) + "' " \
                   "AND CONVERT_TZ(FROM_UNIXTIME(swt.dateline),'+00:00','+05:30') >= '" + str(formatted_from_date) + "' " \
                   "AND id.deptid NOT IN (0,1,2) and swt.timespent>" + str(timespent) + " AND " \
                   "CONVERT_TZ(FROM_UNIXTIME(ta.dateline),'+00:00','+05:30') >= '" + str(formatted_from_date) + "' AND " \
                   "CONVERT_TZ(FROM_UNIXTIME(ta.dateline),'+00:00','+05:30') <= '" + str(formatted_to_date) + "' " \
                   "AND stsRpts = 1 "+ str(prioritiescondition)+" AND DATE(CONVERT_TZ(FROM_UNIXTIME" \
                   "(UNIX_TIMESTAMP(FROM_UNIXTIME(ta.dateline))),'+00:00', '+05:30'))" \
                   " = DATE(CONVERT_TZ(FROM_UNIXTIME(UNIX_TIMESTAMP(FROM_UNIXTIME(swt.dateline))), '+00:00', '+05:30')) " \
                   "AND ta.staffid = swt.creatorstaffid and swt.ticketid = ta.ticketid " +\
                   package_condition + " AND creatorstaffid IN(" + staffid + ") GROUP BY swt.creatorstaffid, swt.ticketid"

        #  here creating cursor object
        cursor = connections['ticketRead'].cursor()
        # using cursor object we are executing sql query formed based on conditions
        cursor.execute(sql)
        #  fetching all records returned from cursor object
        result = cursor.fetchall()
        #  closing cursor object
        cursor.close()
        # returning the final result set
        return result

    def prepareQualityMetricReport(self, data):
        staff = data.getlist('staff')
        partners = data.getlist('partners')
        clients = data.getlist('clients')
        reviewers = data.getlist('reviewers')
        reviewmetric = data.getlist('reviewmetric')
        qualityrating = data.getlist('qualityrating')

        if len(staff):
            staff_data = ",".join(staff)
        else:
            staff_data = ""

        if len(partners):
            partners_data = ",".join(partners)
        else:
            partners_data = ""

        if len(clients):
            clients_data = ",".join(clients)
        else:
            clients_data = ""

        if len(reviewers):
            reviewer_data = ",".join(reviewers)
        else:
            reviewer_data = ""

        finalquery = comMObj.prepareQualityMetricReportConditions(data['fromdate'],
                                                                  data['todate'],
                                                                  staff_data,
                                                                  partners_data,
                                                                  clients_data,
                                                                  reviewer_data,
                                                                  reviewmetric,
                                                                  qualityrating)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(finalquery)
        result = cursor.fetchall()
        return result

    def StaffDataBySwStaffId(self, swstaffid):
        try:
            if swstaffid == 0:
                return "Unknown"
            else:
                staff_data = mem_cache.get("staffdata"+env)
                if not staff_data:
                    cursor = connections['rosterRead'].cursor()
                    sql = "select swstaff_id, staff_fname, staff_lname from nr_staff"
                    cursor.execute(sql)
                    staff_data = comObj.dictfetchall(cursor)
                    mem_cache.set("staffdata"+env, staff_data, 86000)
                    cursor.close()

                index = map(itemgetter("swstaff_id"), staff_data).index(swstaffid)
                final_data = str(staff_data[index]['staff_fname']) + " " + str(staff_data[index]['staff_lname'])
                return final_data

        except Exception as e:
            print (e)
