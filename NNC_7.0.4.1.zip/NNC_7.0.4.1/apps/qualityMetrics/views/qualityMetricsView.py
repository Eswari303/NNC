"""
This computer program is the confidential information and proprietary trade
secret of NetEnrich, Inc. Possessions and use of this program must
conform strictly to the license agreement between the user and
NetEnrich, Inc., and receipt or possession does not convey any rights
to divulge, reproduce, or allow others to use this program without specific
written authorization of NetEnrich, Inc.
Copyright  2016 NetEnrich, Inc. All Rights Reserved.
NetEnrich, Inc.
"""

import json
from django.shortcuts import render_to_response
from django.template import RequestContext
from apps.qualityMetrics.serviceQualityMetrics import QualityMerics
from django.http import HttpResponse
from serviceManagement.models.serviceManagementQuerys import SlamResultQuerys
from NNCPortal.commonModels.Swticketpriorities import Swticketpriorities
from NNCPortal.commonModels.Swdepartments import Swdepartments
from NNCPortal.commonModels.Swticketstatus import Swticketstatus
from NNCPortal.commonModels.NtsMspDeviceData import NtsMspDeviceData
swpriorities_obj = Swticketpriorities()
from django.core.cache import caches
from NNCPortal.commonModels.NrStaff import NrStaff
nrstaff_obj = NrStaff()
from NNCPortal.commonModels.Ntsmsps import Ntsmsps
from managerDashboard.models.commonModel import CommonManagerDashboardModel
from serviceManagement.models.commonModel import CommonServiceModel
import unicodedata
import datetime
import pytz
import ast
from operator import itemgetter
from django.core.context_processors import csrf
from django.db.models import Q
from NNCPortal.configfile import ConfigManager
from django.db import connections
import json as simplejson
from NNCPortal.commonMethods import commonMethods
configobj = ConfigManager()
comMObj = CommonServiceModel()
mem_cache = caches['memcached']
slamobj = SlamResultQuerys()
swdept_obj = Swdepartments()
metricobj = QualityMerics()
com_method_obj = CommonManagerDashboardModel()
method_obj = commonMethods()
msp_obj = Ntsmsps()


''' function to convert utc datetime to pdt datetime
    Args:
    utcdate (str) : passing utc date in string format

    Returns:
    returns given input utc datetime into pdt datetime
'''

def utctopdt(utcdate):
    datetimelist = utcdate.split(" ")
    ''' here we are splitting utc datetime if length is > 1
        we split both time and date els only date'''
    if len(datetimelist) > 1:
        datelist = datetimelist[0].split("-")
        timelist = datetimelist[1].split(":")
    else:
        datelist = datetimelist[0].split("-")
        timelist = [0, 0, 0]
    ''' resetting timezone to America/Los_Angeles'''
    pdt_tz = pytz.timezone('America/Los_Angeles')
    ''' converting utc datetime to pdt time zone '''
    utc_dt = datetime.datetime(int(datelist[0]), int(datelist[1]), int(datelist[2]), int(timelist[0]), int(timelist[1]), int(timelist[2]), 0,pytz.UTC)
    local_dt = utc_dt.replace(tzinfo=pytz.utc).astimezone(pdt_tz)
    ''' returning the pdt time '''
    local_dt_list = str(local_dt).split(" ")
    local_dt_list1 = local_dt_list[1].split("-")
    finaldate = local_dt_list[0]+ " " + local_dt_list1[0]
    finaldate = datetime.datetime.strptime(finaldate,'%Y-%m-%d %H:%M:%S')
    finaldate = finaldate.strftime('%d %b %Y %H:%M')
    return finaldate


''' function is used to return the rating by input value given

    Args:
        rating (int) : rating

    Returns:
        matching rating will returned

'''


def ratingbyvalue(rating):
    if int(rating) == 1:
        return "Below Expectation"
    if int(rating) == 2:
        return "Meets Expectation"
    if int(rating) == 3:
        return "Exceeds Expectation"
    else:
        return False

'''
    Function is used to return the matching priority name.

    Args:
        priority id (int).

    Returns:
        returns display name for priority id.
'''


def PriorityById(pid):
    try:
        priority_data = mem_cache.get('priorities_data')
        if not priority_data:
            cursor = connections['ticketRead'].cursor()
            sql = "Select priorityid, display_text from swticketpriorities"
            cursor.execute(sql)
            priority_data = method_obj.dictfetchall(cursor)
            cursor.close()
            mem_cache.set('priorities_data', priority_data, 86400)
        try:
            index = map(itemgetter("priorityid"), priority_data).index(pid)
            priority = priority_data[index]['display_text']
            return priority
        except Exception as e:
            return None
    except Exception as e:
        print ("p error:", e.message)
        return "None"


'''function to get quality metric of employees
    if request.method == "GET"
        Args:
        request (object): request object serve all requests like get, post

        Returns:
        qualityMetrics.html with data

    if request.method == "POST:
        Args:
        Time spent, Billable Time, Service Type, Staff Id, From Date, To Date, Time Worked

        Returns:
        It returns matching results of above given inputs, which can be displayed in HTML
'''


def qualitymetricsinfo(request):
    # Get method is used to render the html page
    if request.method == "GET":
        # fetching staff and priorities from  GetStaffandPriorities function
        content = metricobj.GetStaffandPriorities()
        #  rendering fetched data to quality metric html
        return render_to_response('qualityMetrics.html', content, context_instance=RequestContext(request))
    # Processing the Post request
    if request.method == "POST":
        # handling the exception
        try:
            # calling getMetricData function to fetch the data based on the inputs given to it
            MetricData = metricobj.getMetricData(request.POST)
            # converting the data to json format
            FinalData = json.dumps(MetricData)
            # sending response data to ajax call and status
            return HttpResponse(FinalData, status=200)
        except Exception as e:
            # raising exception if anything goes wrong
            print "final error message:", e
            return HttpResponse(e, status=500)


''' function to get closed and touched tickets data don't get confused by the function name
    it is used for
    Args:
    Staff id, Priority, Time Spent, From Date, To Date, Time Flag, Packages

    Return:
    List of matching results of the above given input data

'''


def get_closed_tickets_info(request):
    # if requested method is get we execute this block
    if request.method == "GET":
        ''' here assigning request.GET object to data variable for easy acccessing '''
        data = request.GET

        ''' calling getQualityMetricTicketsInfo function and
        we are passing required parameters otherwise it throws error'''

        ticketsinfo = metricobj.getQualityMetricTicketsInfo(data['staffid'],
                                                            data['priority'],
                                                            data['timespent'],
                                                            data['fromdate'],
                                                            data['todate'],
                                                            data['closedflag'],
                                                            data['timeflag'],
                                                            0, data['packages'])
        ''' creating empty content object'''
        content = {}
        ''' fetching departments results from departments function'''
        departments = swdept_obj.departments()
        ''' creating empty priorities object'''
        priorities = {}

        ''' if priorities is in cache memory we fetch data from cache memory'''
        #priorities_query = mem_cache.get('priorities')
        priorities_query = swpriorities_obj.getPriority()
        ''' otherwise fetch the priorities from database and save it cache memory for further usage'''
        #if not priorities:
            #priorities_query = Swticketpriorities.objects.using('ticketRead').order_by('display_text')
            #mem_cache.set('priorities', priorities_query, 86400)

        ''' creating priorities key and value pair '''
        for priority in priorities_query:
            priorities[int(priority.priorityid)] = priority.title

        '''fetching employee data by staffid '''
        staffdata = NrStaff.objects.using('rosterRead').filter(swstaff_id=int(data['staffid']))
        ''' initializing the ticketdata, ticketcountinfo empty list'''
        ticketdata = []
        ticketscountinfo = []
        ''' initializing ticketscount, repliescount, timespentcount,
        timebillable to zero to find aggregated values of respective column'''
        ticketscount = 0
        repliescount = 0
        timespentcount = 0
        timebillable = 0
        ''' here looping through each ticket data to create respective ticket information '''
        for ticket in ticketsinfo:
            ''' initializing the dict_data object to store data '''
            dict_data = {}
            ''' adding 1 to ticketscount to calculate total number of tickets '''
            ticketscount += 1
            ''' if closed flag is zero we fetch data of toched tickets information '''
            if int(data['closedflag']) == 0:
                ''' here we are calculating total replies count, total time spent in mins, total billable time in mins '''
                repliescount += int(ticket[10])
                timespentcount += int(ticket[2])
                timebillable += int(ticket[9])
                dict_data['ticketid'] = str(ticket[0])
                dict_data['replies'] = str(ticket[10])
                dict_data['timespent'] = str(ticket[2])
                dict_data['billabletime'] = str(ticket[9])
                dict_data['createdon'] = utctopdt(str(ticket[3]))
                ''' here convering unicode data to normal string '''
                dict_data['subject'] = unicodedata.normalize('NFKD', ticket[6]).encode('ascii', 'ignore')
                dict_data['priority'] = str(priorities[int(ticket[4])])
                dict_data['department'] = str(departments[int(ticket[5])])
                dict_data['lastupdated'] = utctopdt(str(ticket[8]))
                dict_data['status'] = str(ticket[7])

            # if closed flag is not zero we fetch closed tickets information
            else:
                ''' here we are calculating total replies count,
                 total time spent in mins, total billable time in mins '''
                repliescount += int(ticket[9])
                timespentcount += int(ticket[7])
                timebillable += int(ticket[8])
                dict_data['ticketid'] = str(ticket[0])
                dict_data['replies'] = str(ticket[9])
                dict_data['timespent'] = str(ticket[7])
                dict_data['billabletime'] = str(ticket[8])
                dict_data['createdon'] = utctopdt(str(ticket[10]))
                ''' here convering unicode data to normal string '''
                dict_data['subject'] = unicodedata.normalize('NFKD', ticket[4]).encode('ascii', 'ignore')
                dict_data['priority'] = str(priorities[int(ticket[2])])
                dict_data['department'] = str(departments[int(ticket[3])])
                dict_data['lastupdated'] = utctopdt(str(ticket[6]))
                dict_data['status'] = str(ticket[5])
            ticketdata.append(dict_data)

        ''' finally appending total tickets count, total replies count, total time spent in mins,
        total billable time in mins to ticketscountinfo list '''
        ticketscountinfo.append(ticketscount)
        ticketscountinfo.append(timespentcount)
        ticketscountinfo.append(timebillable)
        ticketscountinfo.append(repliescount)

        ''' here we are defining what should be the title for the html page based on the closed flag value '''
        if int(data['closedflag']) == 3:
            content['title'] = "Closed Tickets Info"
        else:
            content['title'] = "Touched Tickets Info"
        ''' assigning staff data to staff key, tickets count information to ticketscount key,
         ticket data to ticketdata key '''
        content['staff'] = staffdata[0]
        content['ticketscount'] = ticketscountinfo
        content['ticketdata'] = ticketdata
        return render_to_response("getClosedTicketsInfo.html", content, context_instance=RequestContext(request))

    ''' post method is not allowed'''
    if request.method == "POST":
        return HttpResponse("Post Method is not allowed")


'''
    function is used to fetch the reports of the staff for particular date range

    if request.method == "GET":
    Args:
        request (object) :  it takes request object

    Returns:
        It returns qualityMetricFilter.html with the staff, partners, reviewers,
        clients, review metric, quality rating data.

    if request.method == "POST":

    Args:
        Staff, Partners, Reviewers, Clients, Review Metric, Quality Rating, From Date, To Date.

    Returns:
        matching results for the above given inputs.

'''


def quality_metric_reports(request):
    # GET method to render the html with some content
    if request.method == "GET":
        ''' Here initializing the empty content dictionary'''
        content = {}
        ''' updating the csrf token'''
        content.update(csrf(request))
        '''fetching staff data'''
        #swStaff = mem_cache.get('swStaff')
        swStaff = nrstaff_obj.getSwStaffByRoster()
        reviewers = NrStaff.objects.using('rosterRead').filter(Q(is_admin=1), Q(swstaff_id__isnull=False)).order_by("staff_fname")
        #if not swStaff:
            #swStaff = comMObj.getSwStaffByRoster()
            #mem_cache.set('swStaff', swStaff, 86400)
        ''' fetching partners data'''
        partners = comMObj.getpartners()
        ''' fetching clients '''
        clients = comMObj.getClients()
        ''' fetching review metric, and quality rating data'''
        review_metric = configobj.getCommConfigValue(configobj.ReviewMetric)
        quality_rating = configobj.getCommConfigValue(configobj.QualityRating)
        review_metric = ast.literal_eval(review_metric)
        quality_rating = ast.literal_eval(quality_rating)
        ''' assigning staff, partners, reviewer and clients to content dictionary '''
        content['staff'] = swStaff
        content['partners'] = partners
        content['reviewers'] = reviewers
        content['clients'] = clients
        content['review_metric'] = review_metric
        content['quality_rating'] = quality_rating
        ''' rendering html with content '''
        return render_to_response("qualityMetricFilter.html", content, context_instance=RequestContext(request))
'''
    function is used to fetch the reports of the staff for particular date range

    if request.method == "POST":

    Args:
        Staff, Partners, Reviewers, Clients, Review Metric, Quality Rating, From Date, To Date.

    Returns:
        matching results for the above given inputs.

'''


def qualityMetricTicketBrowser(request):
    if request.method == "POST":
        final_result = metricobj.prepareQualityMetricReport(request.POST)
        tickets_data = []
        content = {}
        nrstObj = NrStaff()
        stpObj = Swticketpriorities()
        swstatusObj = Swticketstatus()
        swdeptObj = Swdepartments()
        ntsDeviceDtObj = NtsMspDeviceData()
        ntsMspObj = Ntsmsps()
        staffDetails = nrstObj.staffDataByCache() #by id
        priorityDetails = stpObj.priorty() #by Id
        statusDeatils = swstatusObj.getNewStatus() #by Id
        deptDetails = swdeptObj.departments() #by Id
        mspDetails = ntsMspObj.getMsps() #by Id
        for result in final_result:
            if result[0]:
                data = dict()
                data['title'] = "Quality Metric Report"
                data['ticket_id'] = str(result[0])
                data['review_type'] = str(result[1])
                data['reviewer_id'] = ''
                if result[2] in staffDetails['swstaffId']:
                        data['reviewer_id'] = staffDetails['swstaffId'][int(result[2])]['fullname']#staffDetails[result[2]]
                psttime = method_obj.timeStampToPST(int(result[3])) 
                data['review_date'] = (psttime[0]['pstdate']).strftime('%d %b %Y %H:%M')          
                data['proc_rating'] = ratingbyvalue(result[4])
                data['tech_rating'] = ratingbyvalue(result[5])
                data['com_rating'] = ratingbyvalue(result[6])
                data['time_rating'] = ratingbyvalue(result[7])
                data['cus_rating'] = ratingbyvalue(result[8])
                data['reviewer_comments'] = str(result[9].encode('utf-8'))
                data['review_time'] = result[10]
                data['mail_sent'] = str(result[11])
                data['contents'] = result[12].encode('utf-8') if result[12] else ""
                if str(result[13]) == 'None':
                    data['swtp_dateline'] = ""
                else:
                    data['swtp_dateline'] = datetime.datetime.fromtimestamp(int(str(result[13]))).strftime('%Y-%m-%d %H:%M:%S')
                if result[14] in priorityDetails.keys():
                    data['priority'] = priorityDetails[result[14]]
                else:
                    data['priority'] = ''
                if result[15] in deptDetails.keys():
                    data['department'] = deptDetails[result[15]]
                else:
                    data['department'] = ''
                if result[16] in statusDeatils.keys():
                    data['status'] = statusDeatils[result[16]]
                else:
                    data['status'] = ''
                if result[17] in staffDetails['swstaffId']:
                    data['staff'] = staffDetails['swstaffId'][int(result[17])]['fullname']#staffDetails[result[17]]
                else:
                    data['staff'] = ''
                data['subject'] = result[18]
                if result[19] in mspDetails.keys():
                    data['partner'] = mspDetails[result[19]]
                else:
                    data['partner'] = ""
                data['client'] = result[20]
                try:
                    devicename = ntsDeviceDtObj.getDeviceById(int(result[21]),int(result[22]))
                    if devicename:
                        data['device_name'] = devicename
                    else:
                        data['device_name'] = "Not Found"
                except Exception as e:
                    data['device_name'] = "Unknown"
                tickets_data.append(data)
                content['ticketdata'] = tickets_data
        return render_to_response("qualityMetricReport.html", content, context_instance=RequestContext(request))
    
def getClientOfPat(request):
    if request.method == "POST":
        search = request.POST.getlist('res_cli[]', False)
        if search:
            search_text = ",".join(search)
        else:
            search_text = ''
    else:
        search_text = ''
    cli = comMObj.getClientsofPat(search_text)
    jsonData = simplejson.dumps({'clients': cli})
    return HttpResponse(jsonData, content_type="application/json")
