"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
'''
Created on Jan 2, 2016

@author: pradeep.thatavarthi
'''
"""NNCPortal URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Import the include() function: from django.conf.urls import url, include
    3. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import url,patterns
from views import qualityMetricsView


urlpatterns = patterns('',
                       url(r'^$', qualityMetricsView.qualitymetricsinfo),
                       url(r'^getClosedTicketsInfo$', qualityMetricsView.get_closed_tickets_info),
                       url(r'^Report', qualityMetricsView.quality_metric_reports),
                       url(r'^ticketBrowser', qualityMetricsView.qualityMetricTicketBrowser),
                       url(r'^getClientOfPat$', qualityMetricsView.getClientOfPat),
                       )




