"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.conf.urls import url,patterns
from views import escalationContaactsView


urlpatterns = patterns('',
url(r'^$', escalationContaactsView.indexPage),
url(r'^staffDetails/$', escalationContaactsView.staffContacts),
url(r'^escalationUI', escalationContaactsView.indexPage),
url(r'^service/$', escalationContaactsView.service),
url(r'^getServicelevels/(?P<departmentid>\d+)/$', escalationContaactsView.getServicelevels),
url(r'^addServiceLevelpopup/(?P<departmentid>\d+)/(?P<departmentname>\w+)/$', escalationContaactsView.addServiceLevelpopup),
url(r'^manipulateService_delete/$', escalationContaactsView.manipulateService_delete),
url(r'^serviceName_edit/', escalationContaactsView.serviceName_edit),
url(r'^servicelevel_add/', escalationContaactsView.servicelevel_add),
url(r'^edit_popup/(?P<departmentid>\d+)/(?P<departmentname>\w+)/(?P<servicelevelid>\d+)/(?P<servicename>\w+)$', escalationContaactsView.edit_popup),
url(r'^addContacts$', escalationContaactsView.addStaffDetails),
url(r'^saveStaffDetails', escalationContaactsView.SaveStaffDetails),
url(r'^savealertnum',escalationContaactsView.saveAlternativeNum),
url(r'^savepriortyorder',escalationContaactsView.savePriortyOrder),
url(r'^deleteEscContact',escalationContaactsView.deleteEscContact),                     
)
