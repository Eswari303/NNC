"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import connection,connections
from django.core.cache import caches, cache
from NNCPortal.commonMethods import commonMethods
comObj = commonMethods()
from models.escalationQuerys import escalationQuerys
obk = escalationQuerys()

class esclationData():
    def defaultConections(self,sql):
        cursor = connections['rosterWrite'].cursor()
        cursor.execute(sql)
        finResult = comObj.dictfetchall(cursor)
        cursor.close()
        return finResult
    
    """ To get service names based on department """
    def getsubDepartments(self,parentId):
        sql = 'select id,service_name from service_escalation where parent_id=%s ORDER BY service_name ASC' % (parentId)
        data = self.defaultConections(sql)
        result = data if len(data)>0  else []
        return result
    
    """ To get staff details to be displayed on internal escalation matrix"""
    def getstaffDetails(self, id,queryType=0):
        if queryType >0:
            sql = "select nr.id,(concat(nr.staff_fname,' ',nr.staff_lname))as staffname  from service_escalation_contact as sec  join nr_staff as nr on sec.staff_id =nr.id  where  sec.service_escalation_id =%s order by sec.priority ASC "% (id)    
        else:
            sql = "select sec.service_escalation_id,nr.id,(concat(nr.staff_fname,' ',nr.staff_lname))as staffame,nr.phone_number ,nr.alternate_number,nr.phone_priority,nr.skype_id,nr.staff_email , sec.priority from service_escalation_contact as sec  join nr_staff as nr on sec.staff_id =nr.id  where  sec.service_escalation_id =%s order by sec.priority ASC "% (id)
        data = self.defaultConections(sql)
        result = data if len(data)>0  else 0
        return result
    
    """ To decide the access for particular staff memeber 
       which decides whether internal escalation matrix should be shown or not"""    
    def getMangeServiceAccess(self,staffid):
        sql = "select count(*) as access  from nr_staff where escalation_adm = 1 and id =%s"% (staffid)
        data = self.defaultConections(sql)
        result = data[0]['access'] if len(data)>0  else 0
        return result
    
    def deletecontacts(self,contactid):
        sql = "delete from service_escalation_contact where staff_id=%s" % contactid
        print sql
        self.defaultConections(sql)
        