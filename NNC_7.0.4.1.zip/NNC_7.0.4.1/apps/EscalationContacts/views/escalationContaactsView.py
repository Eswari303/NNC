"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.shortcuts import render_to_response
from django.template import RequestContext
import json as simplejson
from django.http import HttpResponse
from NNCPortal.commonModels.commonModelMethods import CommonModelMethods
from apps.EscalationContacts.serviceEscalationContacts import esclationData
from apps.EscalationContacts.models.escalationQuerys import escalationQuerys
serviceEscalationObj = esclationData()
escalationObj =escalationQuerys()
import urlparse

# Index Html for  rendering Escalation ui  
def indexPage(request):
    departments = escalationObj.getDepartments()  # Departments
    userId = request.session['uId']
    access =serviceEscalationObj.getMangeServiceAccess(userId)
    return render_to_response('staffDetails.html', {'departments':departments,'access':access},context_instance=RequestContext(request))

""" To get the staff contacts 
    which are needs to be diplayed which are added to Internal Escalation Matrix .."""
def staffContacts(request):
    getData =request.GET
    parentId =getData.get('deptId')
    subDepartments =serviceEscalationObj.getsubDepartments(parentId)
    userId = request.session['uId']
    access =serviceEscalationObj.getMangeServiceAccess(userId)
    if len(subDepartments) >0:
        
        html = ''
        for i in subDepartments:
            html +='<hr><h4><span style="color:#006699;">'+i['service_name']+'</span> </h4>'
            if access >0:
                html += '<span style="position: absolute;right:100px;top"  class="escAddContact"><button id ="subDepartment"  data-id ="'+str(i['id'])+'"  class="btn btn-small btn-success">Edit</button></span>'
            html += '<div class="table-responsive"><table  class="table" ><thead><tr><th>Priority</th><th>Name</th><th>Primary Phone No</th><th>Alternate Phone No</th>'
            html +='<th></th></tr></thead><tbody id ="inShiftList">'
            
            subDepStaff = serviceEscalationObj.getstaffDetails(i['id'])            
            if (subDepStaff ==0):
                html +='<tr><td><p>No records found </p></td></tr>'
            else:
                for j in subDepStaff:
                    html += '<tr class="sortable ui-sortable"><td>Level '+str(j['priority'])+'</td><td><b>'
                    html += str(j['staffame'])+'</b>'
                    
                    html += '<div class="footable-row-detail-row"><a href="skype:'+str(j['skype_id'])+'?chat">'
                    if (j['skype_id'] is None):
                        pass
              
                    else:
                        html +='<i class="fa fa-skype text-primary"></i></a>'
                    html +='<a href="mailto:'+str(j['staff_email'])+'"><div class="email_active"><span class="email_active-mail">'+str(j['staff_email'])+'</div></a></div>'
                    html += '</td>'
                    if j['phone_priority'] >1 :
                        html += '<td>'
                        data1 = ' ' if j['alternate_number'] == None else str(j['alternate_number'])
                        html += data1+'</td><td>'
                        data2 = ' ' if j['phone_number'] == 'NULL' else str(j['phone_number'])
                        html += data2+'</td>'
                    else:
                        html += '<td>'
                        data2 = ' ' if j['phone_number'] == 'NULL' else str(j['phone_number'])
                        html += data2+'</td>'
                        data1 = ' ' if j['alternate_number'] == None else str(j['alternate_number'])
                        html += '<td >'+data1+'</td>'
                    
            html +='</tr></tbody>'
            html +='</table></div>'     
    else:
        
        html +='</tbody>'
        html +='</table></div>'     
        html += "<p>No record found </p>"
    jsonData = simplejson.dumps({'html': html,})
    return HttpResponse(jsonData, content_type="application/json")
    
    
    """ For 'manage service levels' popup 
    which is useful to edit or delete even to add other service levels in internal Escalation matrix."""
def service(request):    
    defaultdept = 2
    departments = escalationObj.getDepartments()    
    subdepartments = serviceEscalationObj.getsubDepartments(defaultdept)       
    return render_to_response('interEscalation2.html', {'departments':departments, 'subdepartments':subdepartments},context_instance=RequestContext(request))
    
    """ This is used for getting servicelevels under the particular department from DB"""
def getServicelevels(request, departmentid):
    subdepartments = serviceEscalationObj.getsubDepartments(departmentid)
    return render_to_response('Servicelevels.html', {'subdepartments':subdepartments},context_instance=RequestContext(request))

""" Add service Level 
    in internal Escalation matrix for specified department."""    
def addServiceLevelpopup(request, departmentid, departmentname):
    departments = {}
    departments['id'] = departmentid
    departments['name'] = departmentname
    return render_to_response('add_service_form.html', {'departments':departments},context_instance=RequestContext(request))

""" This is to delete the existed servicelevels under particular department """
def manipulateService_delete(request):
    post = request.POST
    servicelevelid = post.get('servicelevelid',False)
    escalationObj.deleteSubDept(servicelevelid)
    return HttpResponse("Deleted")

""" This is to get popup for edit the existed servicelevels under particular department """
def edit_popup(request, departmentid, departmentname, servicelevelid, servicename): 
    departments = {} 
    departments['servicelevelid'] = servicelevelid
    departments['servicename'] = servicename
    departments['name'] = departmentname  
    return render_to_response('add_service_form.html', {'departments':departments},context_instance=RequestContext(request))

"""  displaying staff  contact Detail  """  
def addStaffDetails(request):
    post = request.GET
    userId = request.session['uId']
    departmentId = post.get('deptId',False);
    staffDetails  = escalationObj.staffDetails()
    subDepStaff = serviceEscalationObj.getstaffDetails(departmentId)
    return render_to_response('addStaffDetails.html', {'staffDetails':staffDetails,'deptId':departmentId,'subDepStaff':subDepStaff,'userId':userId},context_instance=RequestContext(request))

"""  Adding staff contact  """
def SaveStaffDetails(request):
    post =  request.POST
    sdId = post.get('sdId',False)
    stId = post.get('stId',False)
    result = 0
    priortyStatus  = escalationObj.getPriortyCount(sdId)
    print priortyStatus
    if (int(priortyStatus['count']) < 3):
        
        if(int(priortyStatus['count']) <3):
            
            priortyStatus = int(priortyStatus['count']) +1
            saveSatffDetails = {}
            saveSatffDetails['service_escalation_id'] = str(sdId)
            saveSatffDetails['staff_id'] = str(stId)
            saveSatffDetails['priority'] = str(priortyStatus)
            commMM = CommonModelMethods()
            data= commMM.insertRecord(saveSatffDetails, 'service_escalation_contact', 'rosterWrite')
            result = 1
            
    jsonData = simplejson.dumps({'html': result,})
    return HttpResponse(jsonData, content_type="application/json")

""" saving alter number """

def saveAlternativeNum(request):
    post =  request.POST
    priorty = post.get('priorty',0)
    contactNum = post.get('contactNum',0)
    staffId = post.get('staffId',0)
    saveData ={}
    if priorty > 0:
        saveData['phone_priority'] = priorty
    saveData['alternate_number'] = contactNum
    commMM = CommonModelMethods()
    data = commMM.updateRecord(saveData, 'nr_staff', 'id='+staffId,'rosterWrite' ) 
    jsonData = simplejson.dumps({'html': data,})
    return HttpResponse(jsonData, content_type="application/json")

"""  saving priorty details  of staff  """
def savePriortyOrder(request):
    post = request.POST
    serilazaDatal= request.POST.get('datalist')
    data = urlparse.parse_qs(serilazaDatal)
    count = len(data['pirnum'])
    data2 = data['pirStaff']
    j = 1
    for i in range(0,count):
        saveData ={}
        saveData['priority'] = j
        j = j+1
        commMM = CommonModelMethods()
        data = commMM.updateRecord(saveData, 'service_escalation_contact', 'staff_id='+str(data2[i]),'rosterWrite' ) 
    jsonData = simplejson.dumps({'html': data,})
    return HttpResponse(jsonData, content_type="application/json")

""" This is to edit the existed servicelevels under particular department """
def serviceName_edit(request):  
    post = request.POST
    servicelevelid = post.get('servicelevelid',False)   
    servicename = post.get('servicename',False) 
    escalationObj.editSubDept(servicelevelid,servicename)
    return HttpResponse("updated")

""" This is to add the new servicelevel under particular department """
def servicelevel_add(request):
    post = request.POST
    servicename = post.get('servicename',False)
    parentid = post.get('departmentid',False)
    escalationObj.addsubdept(servicename,parentid);
    return HttpResponse("Added")

def deleteEscContact(request):
    contactid = ''
    contactid = request.POST.get('contactid',False)
    serviceEscalationObj.deletecontacts(contactid)
    serilazaDatal= request.POST.get('datalist')
    data = urlparse.parse_qs(serilazaDatal)
    
    data2 = data['pirStaff']
    data2.remove(contactid)
    count = len(data2)
    j = 1
    for i in range(0,count):
        saveData ={}
        saveData['priority'] = j
        j = j+1
        commMM = CommonModelMethods()
        data = commMM.updateRecord(saveData, 'service_escalation_contact', 'staff_id='+str(data2[i]),'rosterWrite' ) 
    return HttpResponse("deleted")


