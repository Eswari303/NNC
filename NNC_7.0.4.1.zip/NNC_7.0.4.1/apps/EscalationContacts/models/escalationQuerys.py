"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.db import connection,connections
from NNCPortal.commonMethods import commonMethods
from debug_toolbar.panels.sql.views import sql_explain
comObj = commonMethods()

class escalationQuerys(object):
    
    def defaultConections(self,sql):
        cursor = connections['rosterWrite'].cursor()
        cursor.execute(sql)
        finResult = comObj.dictfetchall(cursor)
        cursor.close()
        return finResult
    
    """ To get Departments which are in Internal escalation matrix"""  
    def getDepartments(self):
        sql = "select id,service_name from service_escalation where parent_id= 0" ;
        data = self.defaultConections(sql)
        resultSet ={}
        for  i in   data:
            resultSet[i['id']] =str(i['service_name'])
        return resultSet
    
    """ To get service names based on department """
    def getsubDepartments(self,parentId):
        sql = 'select id,service_name from service_escalation where parent_id=%s ORDER BY service_name ASC' % (parentId)
        data = self.defaultConections(sql)
        return data[0]

    def staffDetails(self):
        sql ="select id, concat(staff_fname, ' ',staff_lname) staffname from  nr_staff where is_active = 1 and is_found = 1 order by staff_fname asc"
        data = self.defaultConections(sql)
        return data
    def getPriortyCount(self,subdeptId):
        sql = "select count(*) as count from service_escalation_contact where service_escalation_id=%s" % (subdeptId)
        data = self.defaultConections(sql)
        return data[0]
    
    """ To delete the existed servicelevel from the table """
    def deleteSubDept(self, servicelevelid):
        sql = 'delete from service_escalation where id=%s' % (servicelevelid)
        self.defaultConections(sql)
    
    """ To edit the existed servicelevel from the table """    
    def editSubDept(self, servicelevelid, servicename):
        sql = "update service_escalation set service_name='"+ str(servicename)+"' where id= %s"  % servicelevelid
        self.defaultConections(sql)
    
    """ To add new servicelevel to the table """
    def addsubdept(self,servicename,parentid):
        sql ="insert into service_escalation(service_name,parent_id) values('"+ str(servicename)+"',%s)" % parentid
        self.defaultConections(sql)
            

        