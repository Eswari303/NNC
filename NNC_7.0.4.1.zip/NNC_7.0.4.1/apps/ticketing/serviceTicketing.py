"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
  
 """
from rest_framework.decorators import api_view
from rest_framework.response import Response
from datetime import datetime,timedelta
from django.shortcuts import render
from collections import OrderedDict
from rest_framework import status
import datetime as dt
import operator
from operator import itemgetter
import logging
import redis
import json
import os

from models.AutoAssignModel import AutoAssignMethods
AutoAssignObj = AutoAssignMethods()
autologger = logging.getLogger('AutoAssign')


class ServiceTicketing(object):
    
    def connectRedis(self):
        POOL = redis.ConnectionPool(host='172.22.3.152', port=6379, db=0, password='net!admin')
        r_server = redis.Redis(connection_pool=POOL)
        print "connecting to redis"
        #print r_server
        return r_server
    
    def getOnlinestaff(self, rediscon):
        staff = rediscon.smembers("OnlineStaff")    
        staffdata = list(staff)
        return staffdata    
   
    def getRedisData(self,rediscon,hashname):
        staffinfo = {}        
        if rediscon.exists(hashname):
            staffinfo = rediscon.hgetall(hashname)
        return staffinfo
    
    def getTotal_deptStaff(self,rediscon,deptId,onlinestaffids):
        Deptstafflist = {}        
        os.environ["TZ"]="Asia/Kolkata"
        today = dt.datetime.today()            
        date = today.strftime('%Y%m%d')
        for data in onlinestaffids:
            
            redisinfo = {} 
            hashname = "AutoAssignee_"+data+"_"+date            
            redisinfo = self.getRedisData(rediscon,hashname)   
            if redisinfo:
                autologger.debug("Employee Hash name: "+str(hashname)+" Total tickets: "+str(redisinfo['total_active'])) 
                              
                """ Check Staff Over all Active tickets if greater than 5 then ignore """
                if int(redisinfo['total_active']) <= 5 :
                    autologger.debug("lessthan 5 tickets")
                    tmpstr = redisinfo['deptIds'].replace('[','')
                    tmpstr = tmpstr.replace(']','')
                    if "," in tmpstr:
                        tmplist = tmpstr.split(',')
                    else:
                        tmplist = tmpstr
                    autologger.debug("tmlist"+str(tmplist))
                    for dept in list(tmplist):
                        if int(deptId) == int(dept) :
                            autologger.debug("departments for this staff: "+str(redisinfo['deptIds']))
                            autologger.debug("DeptId existed in depts and dept is: "+str(deptId))
                            dept_active = 0
                            dept_closed = 0
                            activeindex = "dept_"+deptId+"_active"
                            closedindex = "dept_"+deptId+"_closed"
                            if redisinfo.has_key(activeindex):
                                dept_active = redisinfo[activeindex]
                            if redisinfo.has_key(closedindex):
                                dept_closed = redisinfo[closedindex]                    
                            Deptstafflist[redisinfo['swstaffid']] = dept_active
                            autologger.debug("Department base staff: "+str(Deptstafflist))
        return Deptstafflist    
    
    def getStaffids_subjectbased(self,subject_short,filtered_staffidString):
        staffIds_countDescOrder = ''
        staffIds_countDescOrder=[]
        if filtered_staffidString:
            Final_subj_stafflist = AutoAssignObj.checkForSubjectLine(subject_short,filtered_staffidString)
            print Final_subj_stafflist
            print type(Final_subj_stafflist)
            if Final_subj_stafflist:
                result = sorted(Final_subj_stafflist, key=itemgetter('COUNT'),reverse=True)
                for data in result:
                    staffIds_countDescOrder.append(data['staffid'])
        return staffIds_countDescOrder

    
    def CurrentStaff_FinalResult(self, actCount):        
        finalRes = {}
        finalRes['Result'] = {}
        finalRes['Result']['priBasedCount'] = {}
        priCount = {}
        i = 0
        
        TicketsInfoFinal = []
        i=0
        
        for actK in actCount:            
            
            TicketsInfo = {'swstaffid':0,'deptIds':0,'total_active':0,'deptIds':[]}
            TicketsInfo['swstaffid'] = actK['swstaffId']
            totalActiveTktsCount=0         
            activecount,closedcount = AutoAssignObj.getDeptTktcounts(actK["swstaffId"])          
            
            deptIds=[]   
            if activecount:               
                for actTickets in activecount:
                    keyName='dept_'+str(actTickets['deptid'])+'_active'
                    TicketsInfo[keyName]=actTickets['activecount']
                    deptIds.append(actTickets['deptid'])
                    totalActiveTktsCount=totalActiveTktsCount+int(actTickets['activecount'])          
            
                print "total_active tickets count"
                print totalActiveTktsCount
                TicketsInfo['total_active']=totalActiveTktsCount
             
            if closedcount:
                for clsdTickets in closedcount:
                    keyName='dept_'+str(clsdTickets['deptid'])+'_closed'
                    TicketsInfo[keyName]=clsdTickets['closedcount']
                    deptIds.append(clsdTickets['deptid'])
            
            finalDeptIds=list(OrderedDict.fromkeys(deptIds))
            TicketsInfo['deptIds']=finalDeptIds
            
            
            TicketsInfoFinal.append(TicketsInfo)
                            
        print TicketsInfoFinal
        if not finalRes['Result']['priBasedCount']:
            finalRes['Result'] = "No records found"       
            
        return TicketsInfoFinal
    
    def mergingresults(self,l1, l2, key):
                merged = {}
                for item in l1+l2:
                    if item[key] in merged:
                        merged[item[key]].update(item)
                    else:
                      merged[item[key]] = item
                return [val for (_, val) in merged.items()]
    
    def checkStaffDepartment(self,FinalStaffId,deptId):
        exists = ''
        result = AutoAssignObj.checkStaffDepartmentMapping(FinalStaffId,deptId)
        for res in result:
            exists = res['count']
        return exists
        