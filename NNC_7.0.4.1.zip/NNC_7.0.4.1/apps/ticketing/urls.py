
"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
  
 """

"""NEOS URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.9/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Add an import:  from blog import urls as blog_urls
    2. Import the include() function: from django.conf.urls import url, include
    3. Add a URL to urlpatterns:  url(r'^blog/', include(blog_urls))
"""
from django.conf.urls import url
from views import TicketView
from views import TicketingView
from views import TicketMetricView
from views import SlaveStatusView
from views import AutoClosureView
from views import AutoAssignmentView
urlpatterns = [
    
    url(r'^client/(?P<clientId>[0-9A-Za-z]+)/opentickets/$', TicketView.openTicketsDetils, name='openTicketsDetils'),
    url(r'^client/(?P<clientId>[0-9A-Za-z]+)/closedtickets/$', TicketView.closedTicketsDetils, name='closedTicketsDetils'),
    url(r'^client/(?P<clientId>[0-9A-Za-z]+)/clientCurrentMonthTickets/$', TicketView.clientCurrMonthTkts, name='clientCurrMonthTkts'),
    url(r'^client/(?P<clientId>[0-9A-Za-z]+)/todayClientTickets/$', TicketView.clienttodayTkts, name='clienttodayTkts'),    
    url(r'^client/(?P<clientId>[0-9A-Za-z]+)/inventory/$', TicketView.patCliInventoryDetails, name='partner,client InventoryDetails'),
    url(r'^inventory/partner/(?P<partnerId>[0-9A-Za-z]+)/$', TicketView.patCliInventoryDetails, name='partner,client InventoryDetails'),
    url(r'^inventory/partner/(?P<partnerId>[0-9A-Za-z]+)/client/(?P<clientId>[0-9A-Za-z]+)/$', TicketView.patCliInventoryDetails, name='partner,client InventoryDetails'),
    url(r'^partner/(?P<partnerId>[0-9A-Za-z]+)/client/(?P<clientId>[0-9A-Za-z]+)/$', TicketView.clientTicketDetails, name='cient ticket details'),
    #url(r'^ticketdetails/partner/(?P<partnerId>[0-9A-Za-z]+)/client/(?P<clientId>[0-9A-Za-z]+)/priority/(?P<priorityId>[0-9]+)/status/(?P<status>[0-9A-Za-z]+)/$', ticketView.getTicketDetailsClientLevel, name='getTicketDetailsClientLevel'),
    #url(r'^ticketdetails/partner/(?P<partnerId>[0-9A-Za-z]+)/priority/(?P<priorityId>[0-9]+)/status/(?P<status>[0-9A-Za-z]+)/$', ticketView.getTicketDetailsPartnerLevel, name='getTicketDetailsPartnerLevel'),
    #url(r'^noisedata/partner/(?P<partnerId>[0-9A-Za-z]+)/$', ticketView.deviceNoiseData, name='deviceNoiseData'),
    #url(r'^noisedata/partner/(?P<partnerId>[0-9A-Za-z]+)/client/(?P<clientId>[0-9A-Za-z]+)/$', ticketView.deviceNoiseData, name='deviceNoiseData'),
    #url(r'^noisedevices/partner/(?P<partnerId>[0-9A-Za-z]+)/devgroup/(?P<devGroup>[0-9A-Za-z]+)/$', ticketView.noiseDevicePartnerLevel, name='deviceNoiseData'),
    #url(r'^noisedevices/partner/(?P<partnerId>[0-9A-Za-z]+)/client/(?P<clientId>[0-9A-Za-z]+)/devgroup/(?P<devGroup>[0-9A-Za-z]+)/$', ticketView.noiseDeviceClientLevel, name='deviceNoiseData'),
    #url(r'^ticketsynopsis/partner/(?P<partnerId>[0-9A-Za-z]+)/client/(?P<clientId>[0-9A-Za-z]+)/$', ticketView.partnerclienttickets, name='partnerclienttickets'),
    #url(r'^ticketsynopsis/partner/(?P<partnerId>[0-9A-Za-z]+)/$', ticketView.partnerclienttickets, name='partnerclienttickets'),
    #url(r'^ticketpost/(?P<ticketpostId>[0-9A-Za-z]+)/attachment/(?P<attachmentId>[0-9A-Za-z]+)$', ticketView.attachments, name='attachments'),
    url(r'^rbaupdates/$', TicketMetricView.ticketData, name='TicketMetricView'),    
    url(r'^rbametricstatus/$', AutoClosureView.rbaMetric, name='Rba metric status'),
    url(r'^currentstaff', AutoAssignmentView.currentStaffDetails, name= 'currentstaff'),
    url(r'^autoAssign',AutoAssignmentView.autoAssign, name= 'autoAssign'),
    url(r'^showslaveinfo',SlaveStatusView.showSlaveSatus, name= 'showSlaveSatus'),
    url(r'^ticketingdata',TicketingView.GetTicektingData, name= 'TicketingData'), 
    url(r'^showcurrenttime',TicketingView.GetCurrentTime, name= 'GetCurrentTime'),
    url(r'^ticketstaging/$',TicketingView.GetTicektingDataStaging, name= 'GetTicektingDataStg'),
    url(r'^rosterstaging/$',TicketingView.GetRosterStaging, name= 'GetRosterStaging'),
    url(r'^rosterdata/$',TicketingView.GetRoster, name= 'GetRosterData'),
    url(r'^cumulativedata/$',TicketingView.updateCumuletive, name= 'updateCumuletive'),
    url(r'^test$',TicketingView.GetRosterStaging, name= 'GetRosterStaging'),
    url(r'^p0active/client/(?P<cid>\d+)/status/(?P<tktstatusId>[0-9A-Za-z,_]+)/$',TicketView.demoView, name= 'demoView'),
    url(r'^p0TktDetails/client/(?P<cid>\d+)/status/(?P<statusId>[0-9A-Za-z,_]+)/$',TicketView.p0TitDetails, name= ''),
    url(r'^hmspWfciCountsByPriorty/client/(?P<cId>\d+)/$',TicketView.hmspwfcicounts, name= ''),
    url(r'^TicketDetails/$',TicketView.TicketDetails, name= ''),
    url(r'^tktCountByPriority/client/(?P<cid>\d+)/$',TicketView.ticketCountByPriority, name= ''),
    url(r'^top5Devices/client/(?P<cId>\d+)/$',TicketView.topFiveDevice, name= 'Top5Devices'),
    url(r'^genericAPI/$',TicketView.genericAPI, name= 'genericAPI'),
    url(r'^activeTicketsPriorty/client/(?P<cid>\d+)/$',TicketView.activeTicketsByPriorty, name= 'activeTicketPriorty'),
    url(r'^operationalTicketCount/client/(?P<cid>\d+)/$',TicketView.operationalMetricTicketsCount, name= 'scheduleTicketCount'),
    url(r'^getTicketsOfWeatherAPI/client/(?P<cid>\d+)/$',TicketView.ticketsOfWeatherAPI, name= 'TicketsOfWeatherAPI'),
]
