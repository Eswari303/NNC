"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
 
from __future__ import unicode_literals
from django.db import connection,connections
from calendar import monthrange
import calendar, time, datetime
from django.db import models
from _sqlite3 import Cursor
from datetime import date
import logging
import json

from NNCPortal.commonMethodsNEOS import CommonMethods

logger = logging.getLogger(__name__)
commMM = CommonMethods()

class AutoAssignMethods():

    def getCurrentTime(self):
        sql = "select convert_tz(now(),@@session.time_zone,'+05:30') as datetime"     
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        return result
    
    def getOnlineStaff(self, currDate,currTime):        
        sql="""SELECT nr.swstaff_id AS swstaffId,nr.id AS nrstaffid,nr.dept_id,cb.employee_number,cb.current_location 
        FROM cumulative_biometric_info cb JOIN nr_staff nr ON nr.id=cb.staffid WHERE 
        cb.first_punch_shift IN (SELECT shift_name FROM nr_shift WHERE first_punch_in_time >='"""+str(currDate)+"""' AND 
        '"""+str(currTime)+"""' BETWEEN shift_start_time AND shift_end_time) AND cb.in_building=0 AND nr.swstaff_id IS NOT NULL"""  
        
        print "sql query is ::",sql  
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        return result                                                                                                                                           
    
    def getKayakoDeptId(self,nrstaffid):
        sql="""select kayako_deptId as dept_id from staff_dept_mapping where nrstaffid="""+str(nrstaffid)
        cursor=connections['rosterRead'].cursor()
        cursor.execute(sql)
        result=commMM.dictfetchall(cursor)
        cursor.close()
        deptid=0
        for res in result:
            deptid= res['dept_id']
        return deptid
    
    def getDeptTktcounts(self, staffId):
        result = result1 = []
        sql="""select deptid,count(ticketid) as activecount from incident_data where  statusid not in (3,17,5,20,9,46) and staffId="""+str(staffId)+""" and priorityid in (8,9,10,11) and deptid !=1 GROUP BY deptid"""
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        sql1 ="""select count(ticketid) as closedcount, deptid from incident_data where convert_tz(from_unixtime(last_post_time),'+00:00','+05:30')>=date_sub(curdate(), interval 30 day) and convert_tz(from_unixtime(last_post_time),'+00:00','+05:30')<=curdate() and statusid in (3,5,17,20) and staffid="""+str(staffId)+""" and priorityid in (8,9,10,11) and deptid !=1 GROUP BY deptid;"""
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql1)
        result1 = commMM.dictfetchall(cursor)
        cursor.close()
        return result,result1
 

    def checkForSubjectLine(self,subject_short,stafflist):        
        sql = """SELECT COUNT(ticketid) AS COUNT,staffid FROM incident_data 
              WHERE 
              statusid IN(3,5,17,20) AND staffid IN ("""+str(stafflist)+""") AND
              SUBJECT LIKE '"""+str(subject_short)+"""' AND
              CONVERT_TZ(FROM_UNIXTIME(last_post_time),'+00:00','+05:30')>=DATE_SUB(CURDATE(), INTERVAL 30 DAY) 
              AND CONVERT_TZ(FROM_UNIXTIME(last_post_time),'+00:00','+05:30')<=convert_tz(now(),'+00:00','+05:30')  
             GROUP BY staffid"""
        print sql
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()        
        return result   
    
    def checkStaffDepartmentMapping(self,finalstaffid,deptid):
        sql = "select count(id) as count from staff_dept_mapping where swstaffid="+str(finalstaffid)+" and kayako_deptId="+str(deptid)
        cursor = connections['rosterRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()        
        return result 
    