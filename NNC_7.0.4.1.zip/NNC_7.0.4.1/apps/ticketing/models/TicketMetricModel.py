"""

 *
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc, and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 * 
 @author: ganisetti.raju
"""
from __future__ import unicode_literals
from django.db import connection,connections
from django.db import models
import json
from NNCPortal.commonMethodsNEOS import CommonMethods
from NNCPortal import AutoClosureConfig
import logging
logger = logging.getLogger(__name__)

#insert record into database
commMM = CommonMethods()
class CommonModelMethods(object):
   
    def ticketData(self,subject, deviceTypeId, statusIds,ticketids):
         logger.info('In selectRecord in NebotModels file')
         try :
                apndstrng = '  AND nct.sccalertid > 0 AND icd.created_dt >  UNIX_TIMESTAMP(NOW() - INTERVAL 1 WEEK) AND  icd.lastactivity > (SELECT (UNIX_TIMESTAMP() - '+str(AutoClosureConfig.lactivityTime)+'))'
                if ticketids:
                    apndstrng = ' AND icd.ticketid IN '+str(ticketids)
                if deviceTypeId == '':
                    #sql = "SELECT icd.ticketid AS ticketId, icd.created_dt AS createdDate, icd.cid AS clientId,icd.mid AS mspId, icd.did AS deviceId,nmdd.unique_id AS resourceUid FROM incident_data icd JOIN ntsmspdevicedata nmdd ON (icd.did = nmdd.id) WHERE icd.subject like '%"+str(subject)+"%' "+str(statusIds)+" AND icd.created_dt > (SELECT (UNIX_TIMESTAMP() - 1800))"
                    sql = "SELECT icd.ticketid AS ticketId,icd.statusid as statusid ,icd.subject as subject,icd.created_dt AS createdDate, icd.cid AS clientId,icd.mid AS mspId, icd.did AS deviceId,nmdd.unique_id AS resourceUid FROM incident_data icd JOIN ntsmspdevicedata nmdd ON (icd.did = nmdd.id) JOIN ntsclienttickets nct ON(icd.ticketid=nct.ticketid) WHERE icd.subject like '%"+str(subject)+"%' "+str(statusIds)+str(apndstrng)
                else:
                    sql = "SELECT icd.ticketid AS ticketId,icd.statusid as statusid,icd.subject as subject,icd.created_dt AS createdDate, icd.cid AS clientId,icd.mid AS mspId, icd.did AS deviceId, nmdd.unique_id AS resourceUid FROM incident_data icd JOIN ntsmspdevicedata nmdd ON (icd.did = nmdd.id) JOIN ntsclienttickets nct ON(icd.ticketid=nct.ticketid) WHERE icd.subject like '%"+str(subject)+"%'  AND devicetypeid in ("+str(deviceTypeId)+") "+str(statusIds)+str(apndstrng)
                logger.info('select query is '+str(sql))
                cur = connections["obvalidation"].cursor()
                cur.execute(sql)
                commMM = CommonMethods()
                res = commMM.dictfetchall(cur)
                #res = cur.fetchall() 
                cur.close()
                return res
         except Exception as e:
            # handle all your exceptions... this is just an example
            logger.error("Caught Exception:"+str(e))
            return "Exception raised"
    
    def postMetricData(self,preparePaylaod):
        logger.info('In postclientObCheck Method in models')
        cursor = connections['ticketWrite'].cursor()
        commMM.insertRecord(preparePaylaod,'nts_ticket_metric_rba_status',cursor)
        #commMM.insertRecord(preparePaylaod,'nts_ticket_metric_rba_status_staging',cursor)
        res = cursor.rowcount
        cursor.close()
        return res
    
 
    def checkTicketId(self,preparePaylaod):
        logger.info('In postclientObCheck Method in models')
        cursor = connections['obvalidation'].cursor()
        commMM.insertRecord(preparePaylaod,'nts_ticket_metric_rba_status',cursor)
        #commMM.insertRecord(preparePaylaod,'nts_ticket_metric_rba_status_staging',cursor)
        res = commMM.dictfetchall(cursor)
        cursor.close()
        return res
    
    def getTicketRbaStatus(self,queryString,extentionQuery):
         logger.info('In getTicketRbaStatus models file')
         try :
            sql = "select * from nts_ticket_metric_rba_status" +str(queryString)+ " AND exec_time <  UNIX_TIMESTAMP()-"+str(AutoClosureConfig.exec_time)+str(extentionQuery)
            #sql = "select * from nts_ticket_metric_rba_status_staging" +str(queryString)+ " AND exec_time <  UNIX_TIMESTAMP()-600 "
            #sql = "select * from nts_ticket_metric_rba_status_staging where status = 1  AND exec_time <  UNIX_TIMESTAMP()-600"
            #sql = "select ntmrs.ticketid,ntmrs.client_id,ntmrs.resource_uid, ntmrs.script_id, ntmrs.job_id, ntmrs.exec_time, ntmrs.created_time, ntmrs.status  from nts_ticket_metric_rba_status ntmrs JOIN incident_data id ON (id.ticketid = ntmrs.ticketid)  WHERE id.ticketid IN (1, 19) AND ntmrs.status = 1 AND ntmrs.exec_time <  UNIX_TIMESTAMP()"
            logger.info('select query is '+str(sql))
            cur = connections["obvalidation"].cursor()
            cur.execute(sql)
            commMM = CommonMethods()
            res = commMM.dictfetchall(cur)
            print sql
            #res = cur.fetchall() 
            cur.close()
            return res
         except Exception as e:
            # handle all your exceptions... this is just an example
            logger.error("Caught Exception:"+str(e))
            return "Exception raised"
        
    def checkClientId(self,clientId,subject):
        logger.info('In checkClientId Method in models')
        cursor = connections['ticketRead'].cursor()
        # '@@' is a delimitter in subject_line
        sql = "select * from nts_auto_ticket_ignore_clients where clientid = "+str(clientId)+" AND subject_line like '%@@"+str(subject)+"@@%'"
        logger.error(sql)
        cursor.execute(sql)
        res = cursor.rowcount
        cursor.close()
        return res
    
    def checkMspId(self,mspId,extQry):
        logger.info('In checkMspId Method in models')
        cursor = connections['ticketRead'].cursor()
        sql = "select * from nts_auto_ticket_ignore_clients where mspid = "+str(mspId)+" And clientid = '' And clientid = 0"+str(extQry)
        cursor.execute(sql)
        res = cursor.rowcount
        cursor.close()
        return res
    
    def checkTktId(self,ticketId):
        logger.info('In checkTktId Method in models')
        cursor = connections['ticketRead'].cursor()
        sql = "select ticketid from nts_ticket_metric_rba_status WHERE ticketid = "+str(ticketId)
        #sql = "select ticketid from nts_ticket_metric_rba_status_staging WHERE ticketid = "+str(ticketId)
        cursor.execute(sql)
        res = cursor.rowcount
        cursor.close()
        return res
    
    def tktstatus(self, ticketId, statusIds):
        logger.info('In tktstatus Method in models')
        cursor = connections['ticketRead'].cursor()
        sql = "select ticketid,statusid from incident_data where ticketid = "+str(ticketId)+" and statusid in ("+str(statusIds)+")"
        print sql
        cursor.execute(sql)
        res = commMM.dictfetchall(cursor)
        cursor.close()
        return res
    
    def checkTktPost(self,ticketId, postSt):
        logger.info('In checkTktPost Method in models')
        cursor = connections['ticketRead'].cursor()
        #sql = "SELECT count(*) FROM swticketposts where ticketid = '"+str(ticketId)+"' AND dateline > (SELECT (UNIX_TIMESTAMP() - 86400))  AND contents like '%"+str(postSt)+"%' order by dateline desc limit 1"
        sql = "SELECT count(*) AS count FROM swticketposts where ticketid = '"+str(ticketId)+"' AND dateline > (SELECT (UNIX_TIMESTAMP() - "+str(AutoClosureConfig.dateline)+"))  AND contents like '%"+str(postSt)+"%' order by dateline desc"       
        logger.info(sql)
        cursor.execute(sql)
        commMM = CommonMethods()
        res = commMM.dictfetchall(cursor)
        cursor.close()
        return res
      
    def getActStaId(self):
        sql = "SELECT group_concat(ticketstatusid) AS actstatus FROM swticketstatus WHERE title NOT IN (SELECT statusname FROM ntsignorablestates) ORDER BY displayorder"
        #sql = "select ntmrs.ticketid,ntmrs.client_id,ntmrs.resource_uid, ntmrs.script_id, ntmrs.job_id, ntmrs.exec_time, ntmrs.created_time, ntmrs.status  from nts_ticket_metric_rba_status ntmrs JOIN incident_data id ON (id.ticketid = ntmrs.ticketid)  WHERE id.ticketid IN (1, 19) AND ntmrs.status = 1 AND ntmrs.exec_time <  UNIX_TIMESTAMP()"
        logger.info('select query is '+str(sql))
        cur = connections["ticketRead"].cursor()
        cur.execute(sql)
        commMM = CommonMethods()
        res = commMM.dictfetchall(cur)
        #res = cur.fetchall() 
        cur.close()
        return res
    
    def getTicketRbaStatusCount(self,queryString):
        sql = "SELECT count(*) as count from nts_ticket_metric_rba_status "+str(queryString) +" AND exec_time <  UNIX_TIMESTAMP()-"+str(AutoClosureConfig.exec_time) 
        #sql = "SELECT count(*) as count from nts_ticket_metric_rba_status_staging "+str(queryString) +" AND exec_time <  UNIX_TIMESTAMP()-600 "
        #sql = "select ntmrs.ticketid,ntmrs.client_id,ntmrs.resource_uid, ntmrs.script_id, ntmrs.job_id, ntmrs.exec_time, ntmrs.created_time, ntmrs.status  from nts_ticket_metric_rba_status ntmrs JOIN incident_data id ON (id.ticketid = ntmrs.ticketid)  WHERE id.ticketid IN (1, 19) AND ntmrs.status = 1 AND ntmrs.exec_time <  UNIX_TIMESTAMP()"
        logger.info('select query is '+str(sql))
        cur = connections["ticketRead"].cursor()
        cur.execute(sql)
        commMM = CommonMethods()
        res = commMM.dictfetchall(cur)
        #res = cur.fetchall() 
        cur.close()
        return res
    

