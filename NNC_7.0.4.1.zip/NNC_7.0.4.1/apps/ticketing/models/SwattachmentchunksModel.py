"""

 *
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc, and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 * 
 
"""
from __future__ import unicode_literals
from django.db import connection,connections
from django.db import models
import json
#from cassandra.cluster import Cluster
import logging
import calendar, time, datetime
from datetime import date
from calendar import monthrange
logger = logging.getLogger(__name__)
dbHost="127.0.0.1"
dbPort="9042"
keyspace="apitest"
cf="sample1"
rowKey="value"

class SwattachmentchunkMehtods():
    
#     def testQryCluster(self):  
#         logger.info("In testQryCluster method")
#         cluster = Cluster(["127.0.0.1"], connect_timeout = 5)
#         session = cluster.connect('apitest')
#         #.execute("""insert into users (lastname, age, city, email, firstname) values ('Jones', 35, 'Austin', 'bob@example.com', 'Bob')""")
#         result = session.execute("SELECT chunkid,attachmentid,contents FROM swattachmentchunks LIMIT 1")
#         '''sql = "SELECT chunkid,attachmentid,contents FROM swattachmentchunks"     
#         cursor = connections['default'].cursor()
#         cursor.execute(sql)
#         #result = dict(cursor)
#         print type(cursor)
#         cursor.close()'''
#         cluster.shutdown()
#         return result[0].contents
    
    def testQry(self):  
        logger.info("In testQry method")
        #cursor = connections['cassandra'].connect()
        '''sql = 'SELECT chunkid,attachmentid,contents FROM swattachmentchunks LIMIT 1';
        cursor.all(sql)
        result = cursor'''
        cursor = connections['cassandra'].cursor()
        result = cursor.execute("select count(*) from swattachmentchunks")
        return result[0]
    
   
