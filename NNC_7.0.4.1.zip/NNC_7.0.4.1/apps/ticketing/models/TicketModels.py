from __future__ import unicode_literals
from django.db import connection,connections
from django.db import models
from NNCPortal.commonMethodsNEOS import CommonMethods
from NNCPortal import QueryConfig
import logging
logger = logging.getLogger(__name__)
commMM = CommonMethods()
from collections import OrderedDict
# Create your models here.
# Create your models here.
class TicketModel(object):
    def getTotalOpenTickets(self, clientId): 
        logger.info("in getTotalOpenTickets method in TicketModels ")
        sql = """SELECT p.display_text AS priority,IFNULL(c.opentickets,0) AS count FROM swticketpriorities p LEFT JOIN (SELECT priorityid, COUNT(ticketid) opentickets
            FROM incident_data id WHERE id.cid = '"""+str(clientId)+"""' and deptid NOT IN (0,1,2) AND statusid NOT IN (3,5,17,20,32,41) AND priorityid IN (8,9,10,11) GROUP BY priorityid) 
            c ON p.priorityid = c.priorityid WHERE p.priorityid IN (8,9,10,11)"""
        print sql
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close() 
        logger.info("Method Complted") 
        return result
    def getTotalClosedTickets(self, clientId):
        logger.info("in getTotalClosedTickets method in TicketModels ")
        sql = "SELECT p.display_text AS priority,IFNULL(c.Closed,0) AS count FROM swticketpriorities p LEFT JOIN (SELECT priorityid, COUNT(ticketid) Closed FROM incident_data id WHERE deptid NOT IN (0,1,2) and id.created_dt >  unix_timestamp(now()-interval 1 month) and id.cid = "+str(clientId)+" and statusid IN (3,5,17,20,32,41) AND priorityid IN (8,9,10,11) GROUP BY priorityid) c ON p.priorityid = c.priorityid WHERE p.priorityid IN (8,9,10,11) "
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def getInventoryDetails(self,clientId):  
        logger.info("in getInventoryDetails method in TicketModels ")
        sql = "SELECT dt.devicetype as type,COUNT(dt.id) count FROM msp.device_data dd JOIN device_type dt ON dt.id=dd.devicetype JOIN  msp.organizations org ON org.id=dd.client_id JOIN msp.noc_details nocs ON(nocs.id = org.noc_details_id) JOIN msp.organization_apps org_apps ON(((org.id = org_apps.org_id) AND (org_apps.app_id = 1))) WHERE (dd.state IS NULL OR dd.state = 'active') AND (org.class_code = 'client') and org.id = "+str(clientId)+" GROUP BY dt.devicetype"
        cursor = connections['mspDB'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def getInventoryByOs(self, clientId): 
        logger.info("in getInventoryByOs method in TicketModels ")
        sql = """SELECT dd.os,count(dd.id) osCount FROM msp.device_data dd  
        JOIN msp.organizations org ON org.id=dd.client_id  
        JOIN msp.noc_details nocs ON(nocs.id = org.noc_details_id)  
        JOIN msp.organization_apps org_apps ON(((org.id = org_apps.org_id) AND (org_apps.app_id = 1)))  
        WHERE org.id= """+str(clientId)+"""  and org.class_code='client' AND (dd.state IS NULL OR dd.state = 'active' OR dd.state='') GROUP BY dd.os"""
        #sql = """SELECT  dd.os,COUNT(dd.id) os_count FROM msp.device_data dd JOIN  msp.organizations org ON org.id=dd.msp_id JOIN msp.noc_details nocs ON(nocs.id = org.noc_details_id) JOIN msp.organization_apps org_apps ON(((org.id = org_apps.org_id) AND (org_apps.app_id = 1))) WHERE org.id=""" +str(clientId)+ """ AND (dd.state IS NULL OR dd.state = 'active' OR dd.state='') GROUP BY dd.os"""
   
        cursor = connections['mspDB'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def getCrtdTkts(self, mspId,clientId, dateTime):
        logger.info("in getCrtdTkts method in TicketModels ")
        if clientId :   
            sql = """SELECT count(ticketid) AS count, priority FROM incident_data WHERE mid = """+str(mspId)+""" AND cid = """+str(clientId)+""" AND priorityid IN (8,9,10,11) AND created_dt > """ +str(dateTime) + """ AND deptid not in (0,1) group by priorityid"""
        else :
            sql = """SELECT count(ticketid) AS count, priority FROM incident_data WHERE mid = """+str(mspId)+""" AND priorityid IN (8,9,10,11) AND created_dt > """ +str(dateTime) + """ AND deptid not in (0,1) group by priorityid"""
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getClosedTkts(self, mspId,clientId, dateTime):
        logger.info("in getClosedTkts method in TicketModels ")
        if clientId :
            sql = "SELECT count(ticketid) AS count, priority FROM incident_data WHERE mid = "+str(mspId)+" AND cid = "+str(clientId)+" AND priorityid IN (8,9,10,11) AND lastactivity > "+str(dateTime)+" AND deptid not in (0,1) and statusid in (3,5,17,20,32,41)  group by priorityid"
        else :
            sql = "SELECT count(ticketid) AS count, priority FROM incident_data WHERE mid = "+str(mspId)+" AND priorityid IN (8,9,10,11) AND lastactivity > "+str(dateTime)+" AND deptid not in (0,1) and statusid in (3,5,17,20,32,41)  group by priorityid"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def getPatCliTickets(self,mspId,priId,endDate,status,clientId=0):
        logger.info("in getPatCliTickets method in TicketModels ")
        cursor = connections['ticketRead'].cursor()
        if status == 'open' :
            sql = "select group_concat(ticketstatusid) as active_statuses from swticketstatus where title not in (select statusname from ntsignorablestates) order by displayorder"
            cursor.execute(sql)
            actStatus = commMM.dictfetchall(cursor)
            sql = 'select group_concat(statusid) as inactive_statuses from ntsignorablestates where statusname not in (select title from swticketstatus where statustype=3) order by statusname'
            cursor.execute(sql)
            inStatus = commMM.dictfetchall(cursor)
            finStatus = str(actStatus[0]['active_statuses'])+','+str(inStatus[0]['inactive_statuses'])
        elif status == 'closed' :
            sql = "select group_concat(ticketstatusid) as closed_statuses from swticketstatus where statustype=3 order by title"
            cursor.execute(sql)    
            status = commMM.dictfetchall(cursor)
            finStatus = status[0]['closed_statuses']
        print finStatus
        if clientId :
            sql = "select client,msp,status,priority,subject,device,ticketid from incident_data where statusid in ("+str(finStatus)+") and mid = %s and cid = %s and priorityId = %s and created_dt > %s"%(mspId,clientId,priId,endDate)
        else :
            sql = "select client,msp,status,priority,subject,device,ticketid from incident_data where statusid in ("+str(finStatus)+") and mid = %s and priorityId = %s and created_dt > %s"%(mspId,priId,endDate)
        print sql
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def getDeviceCounts(self, mspId, clientId):
        logger.info("in getDeviceCounts method in TicketModels ")
        if clientId:            
            sql = """select nmd.client_id AS clientId, nmc.clientname AS clientName, count(nmd.id) as count from ntsmspdevicedata nmd 
                    JOIN ntsmspclients nmc ON (nmc.mspclientid = nmd.client_id)
                    where nmd.msp_id = '"""+str(mspId)+"""' AND nmd.client_id = '"""+str(clientId)+"""'"""
        else:
            sql = """select nmd.client_id AS clientId, nmc.clientname AS clientName, count(nmd.id) as count from ntsmspdevicedata nmd 
                    JOIN ntsmspclients nmc ON (nmc.mspclientid = nmd.client_id)
                    where nmd.msp_id = '"""+str(mspId)+"""' group by nmd.client_id"""
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def getDeviceId(self, mspId, clientId):
        logger.info("in getDeviceId method in TicketModels ")
        if clientId:
            sql = "select group_concat(id) as deviceIdList from ntsmspdevicedata where msp_id = '"+str(mspId)+"' and client_id = '"+str(clientId)+"'"
        else:
            sql = "select group_concat(id) as deviceIdList from ntsmspdevicedata where msp_id = '"+str(mspId)+"'"
        print sql
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def topNoisedevice(self, mspId, clientId):
        logger.info("in topNoisedevice method in TicketModels ")
        if clientId:
            sql = "select did as deviceId,count(*) as count, cid as clientId,device as deviceName, client as clientName from incident_data where did != 0 and mid = "+str(mspId)+" and cid ='"+str(clientId)+"' group by did order by count desc limit 5"
        else:
            sql = "select did as deviceId,count(*) as count, cid as clientId,device as deviceName, client as clientName from incident_data where did != 0 and mid = "+str(mspId)+" group by did order by count desc limit 5"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def getNoiseDevices(self,mspId,devGroup,clientId = 0):
        logger.info("in getNoiseDevices method in TicketModels ")
        sql1 = 'select id from ntsdevice_type where devicetype = "'+str(devGroup)+'"'
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql1)
        result = commMM.dictfetchall(cursor)
        if clientId:
            sql = "select device_name as deviceName from ntsmspdevicedata where msp_id = %s and client_id = %s and devicetype = '%s'"%(mspId,clientId,result[0]['id'])
        else:
            sql = "select device_name as deviceName from ntsmspdevicedata where msp_id = %s and devicetype = '%s'"%(mspId,result[0]['id'])
        print sql
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def getActiveTickets(self, sdate, edate, clientId, mspId):  
        logger.info("in getActiveTickets method in TicketModels ")
        sql = "select group_concat(ticketstatusid) as active_statuses from swticketstatus where title not in (select statusname from ntsignorablestates) order by displayorder"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        status = commMM.dictfetchall(cursor)
        if(clientId != ''):
            sql = 'select priorityid, count(ticketid) as count,priority  from incident_data where priorityid in (8,9,10,11) and statusid in ('+status[0]['active_statuses']+') and created_dt <= '+str(sdate)+' and created_dt >= '+str(edate)+' and mid = '+str(mspId)+' and cid = '+str(clientId)+' and deptid not in (0,1,2) group by priorityid'
        else:
            sql = 'select priorityid, count(ticketid) as count,priority  from incident_data where priorityid in (8,9,10,11) and statusid in ('+status[0]['active_statuses']+') and created_dt <= '+str(sdate)+' and created_dt >= '+str(edate)+' and mid = '+str(mspId)+' and deptid not in (0,1,2) group by priorityid'
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def getClosedTickets(self, sdate, edate, clientId, mspId):  
        logger.info("in getClosedTickets method in TicketModels ")
        sql = "select group_concat(ticketstatusid) as closed_statuses from swticketstatus where statustype=3 order by title"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        status = commMM.dictfetchall(cursor)
        if(clientId != ''):
            sql = 'select priorityid, count(ticketid) as count,priority from incident_data where priorityid in (8,9,10,11) and statusid in ('+status[0]['closed_statuses']+') and created_dt <= '+str(sdate)+' and created_dt >= '+str(edate)+' and mid = '+str(mspId)+' and cid = '+str(clientId)+' and deptid not in (0,1,2) group by priorityid'
        else:
            sql = 'select priorityid, count(ticketid) as count,priority from incident_data where priorityid in (8,9,10,11) and statusid in ('+status[0]['closed_statuses']+') and created_dt <= '+str(sdate)+' and created_dt >= '+str(edate)+' and mid = '+str(mspId)+' and deptid not in (0,1,2) group by priorityid'
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def getScheduledTickets(self, sdate, edate, clientId, mspId):  
        logger.info("in getScheduledTickets method in TicketModels ")
        if(clientId != ''):
            sql = 'SELECT priorityid,group_concat(ticketid) as count,priority FROM incident_data WHERE statusid = 16 AND created_dt >= '+str(sdate)+' AND created_dt <= '+str(edate)+' and mid = '+str(mspId)+' and cid = '+str(clientId)+' group by priorityid'
        else:
            sql = 'SELECT priorityid,group_concat(ticketid) as count,priority FROM incident_data WHERE statusid = 16 AND created_dt >= '+str(sdate)+' AND created_dt <= '+str(edate)+' and mid = '+str(mspId)+' group by priorityid'
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def getPastOneMonthCreatedTickets(self, sdate,edate, clientId, mspId): 
        logger.info("in getPastOneMonthCreatedTickets method in TicketModels ")
        if(clientId != ''):
            sql = 'select priorityid,priority,count(ticketid) as count from incident_data where created_dt > '+str(edate)+' and mid = '+str(mspId)+' and cid = '+str(clientId)+' group by priorityid'
        else:
            sql = 'select priorityid,priority,count(ticketid) as count from incident_data where created_dt > '+str(edate)+' and mid = '+str(mspId)+' group by priorityid'
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        print "========================>"
        print sql
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def getTodayCreatedTickets(self,clientId): 
        logger.info("in getTodayCreatedTickets method in TicketModels ")
        sql = 'SELECT priority AS priority, count(*) AS count  from incident_data where cid = '+str(clientId)+' AND deptid NOT IN (0,1,2) AND created_dt > unix_timestamp(now()-interval 1 day) group by priorityid'
        print sql
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    """    def getClosedToday(self, clientId):  
        logger.info("in getClosedToday method in TicketModels ")
        sql = 'SELECT priority AS priority, count(*) AS count  from incident_data where cid = '+str(clientId)+' AND created_dt > unix_timestamp(now()-interval 1 day) and statusid in(3,5,17,20,32,41) group by priorityid'
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        status = commMM.dictfetchall(cursor)
        if(clientId != ''):
            sql = 'select count(ticketid) as count from incident_data where created_dt < '+str(sdate)+' and statusid in ('+status[0]['closed_statuses']+') and created_dt > '+str(edate)+' and mid = '+str(mspId)+' and cid = '+str(clientId)
        else:
            sql = 'select count(ticketid) as count from incident_data where created_dt < '+str(sdate)+' and statusid in ('+status[0]['closed_statuses']+') and created_dt > '+str(edate)+' and mid = '+str(mspId)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result"""
    def getHmspWfci(self, sdate, edate, clientId, mspId): 
        logger.info("in getHmspWfci method in TicketModels ")
        if(clientId != ''):
            sql = 'select priorityid,count(ticketid) as count,priority from incident_data where statusid  in (46,9) and created_dt > '+str(sdate)+' and created_dt < '+str(edate)+' and mid = '+str(mspId)+' and cid = '+str(clientId)+' group by priorityid'
        else:
            sql = 'select priorityid,count(ticketid) as count,priority from incident_data where statusid  in (46,9) and created_dt > '+str(sdate)+' and created_dt < '+str(edate)+' and mid = '+str(mspId)+' group by priorityid'
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getActiveServer(self,sdate, edate, clientId, mspId): 
        logger.info("in getActiveServer method in TicketModels ") 
        if(clientId != ''):
            sql = 'select priorityid,count(ticketid) as count,priority from incident_data where devicetypeid in (3,7,8,9,11,12,30,38,39,53,55,56,57,70,78,79,80,81,82,91,92) and statusid in (1,7,12,18,19,21,22,23) and mid = '+str(mspId)+' and cid = '+str(clientId)+' group by priorityid'
        else:
            sql = 'select priorityid,count(ticketid) as count,priority from incident_data where devicetypeid in (3,7,8,9,11,12,30,38,39,53,55,56,57,70,78,79,80,81,82,91,92) and statusid in (1,7,12,18,19,21,22,23) and mid = '+str(mspId)+' group by priorityid'
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
        
    
    def getDeviceCount(self, clientId, mspId):  
        logger.info("in getDeviceCount method in TicketModels ") 
        if(clientId != ''):
            sql = "select count(*) as count from ntsmspdevicedata where msp_id = 'msp_"+str(mspId)+"' and client_id = "+str(clientId)
        else:
            sql = "select count(*) as count from ntsmspdevicedata where msp_id = 'msp_"+str(mspId)+"'"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result    
    
    def getHmspWfciCount(self, sdate, edate, clientId, mspId):
        logger.info("in getHmspWfciCount method in TicketModels ") 
        if(clientId != ''):
            sql = 'select count(ticketid) as count from incident_data where statusid  in (46,9) and created_dt > '+str(sdate)+' and created_dt < '+str(edate)+' and mid = '+str(mspId)+ ' and cid = '+str(clientId)
        else:
            sql = 'select count(ticketid) as count from incident_data where statusid  in (46,9) and created_dt > '+str(sdate)+' and created_dt < '+str(edate)+' and mid = '+str(mspId)
        cursor = connections['ticketRead'].cursor() 
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getPriorityids(self,sdate, edate, clientId, mspId): 
        logger.info("in getPriorityids method in TicketModels ") 
        if(clientId != ''):
            sql = 'select id.priorityid,count(id.ticketid) as count,stp.title AS priority from incident_data id JOIN swticketpriorities stp ON (stp.priorityid = id.priorityid) where id.created_dt < '+str(sdate)+' and id.created_dt > '+str(edate)+' and id.statusid in (1,7,12,18,19,21,22,23) and id.cid = '+str(clientId)+' and mid = '+str(mspId)+' and stp.priorityid != 21 group by id.priorityid'
        else:
            sql = 'select id.priorityid,count(id.ticketid) as count,stp.title AS priority from incident_data id JOIN swticketpriorities stp ON (stp.priorityid = id.priorityid) where id.created_dt < '+str(sdate)+' and id.created_dt > '+str(edate)+' and id.statusid in (1,7,12,18,19,21,22,23) and mid = '+str(mspId)+' and stp.priorityid != 21 group by id.priorityid'
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def validatePartnerAndClient(self,clientId):
        logger.info("in validatePartnerAndClient method in TicketModels ") 
        if(clientId != ''):
            sql = "select count(*) as count from ntsmspclients where mspclientid = '"+str(clientId)+"'"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def executeQry(self,query):
        logger.info("in executeQry method in TicketModels ")
        cursor = connections['ticketRead'].cursor()
        cursor.execute(query)
        print query
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    def todayCtdTkts(self, clientId, mspId):
        logger.info("in todayCtdTkts method in TicketModels ")
        if(clientId != ''):
            sql = "SELECT count(ticketid) AS count, priority FROM incident_data WHERE mid = '"+str(mspId)+"' AND cid = '"+str(clientId)+"' AND priorityid IN (8,9,10,11) AND deptid not in (0,1) AND created_dt > unix_timestamp((now()) - interval 1 day) group by priorityid"
        else:
            sql = "SELECT count(ticketid) AS count, priority FROM incident_data WHERE mid = '"+str(mspId)+"' AND priorityid IN (8,9,10,11) AND deptid not in (0,1) AND created_dt > unix_timestamp((now()) - interval 1 day) group by priorityid"
        cursor = connections['ticketRead'].cursor() 
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getActTktCountByPriority(self, clientId):
        logger.info("in getActTktCountByPriority method in TicketModels ")
        priorities ={}
        cursor = connections['ticketRead'].cursor() 
        actStatusSql ="select group_concat(ticketstatusid) as status from swticketstatus where title not in (select statusname from ntsignorablestates) order by displayorder"
        cursor.execute(actStatusSql)
        actSataus = commMM.dictfetchall(cursor)
       
        cldStatusSql = "select group_concat(ticketstatusid) as status from swticketstatus where statustype=3 order by title"
        cursor.execute(cldStatusSql)
        cldSataus = commMM.dictfetchall(cursor)
        
        inactStatusSql = "select group_concat(statusid) as status from ntsignorablestates where statusname not in (select title from swticketstatus where statustype=3) order by statusname"
        cursor.execute(inactStatusSql)
        inactSataus = commMM.dictfetchall(cursor)
             
        sql = "select priority,count(*) as count from incident_data where created_dt> unix_timestamp((now()) - interval 1 month) and statusid in ("+str(actSataus[0]['status'])+") and cid = '"+str(clientId)+"' group by priority;"
        cursor.execute(sql)
        act = commMM.dictfetchall(cursor)
        
        sql = "select priority,count(*) as count from incident_data where created_dt> unix_timestamp((now()) - interval 1 month) and statusid in ("+str(cldSataus[0]['status'])+") and cid = '"+str(clientId)+"' group by priority;"
        cursor.execute(sql)
        closed = commMM.dictfetchall(cursor)
        
        
        sql = "select priority,count(*) as count from incident_data where created_dt> unix_timestamp((now()) - interval 1 month) and statusid in ("+str(inactSataus[0]['status'])+") and cid = '"+str(clientId)+"' group by priority;"
        cursor.execute(sql)
        inact = commMM.dictfetchall(cursor)
        
        
        
        sql = "select priority,count(*) as count from incident_data where created_dt> unix_timestamp((now()) - interval 1 month) and statusid in ("+str(QueryConfig.clientTickets["scheduledStatus"])+") and cid = '"+str(clientId)+"' group by priority;"
        cursor.execute(sql)
        sch = commMM.dictfetchall(cursor)
        
        sql = "select priority,count(*) as count from incident_data where created_dt> unix_timestamp((now()) - interval 1 month) and cid = '"+str(clientId)+"' group by priority;"
        cursor.execute(sql)
        created = commMM.dictfetchall(cursor)
        
        priorities['active']=act
        priorities['inactive'] =inact
        priorities['closed'] = closed
        priorities['scheduled'] = sch
        priorities['created']=created
        cursor.close()
        logger.info("Method Complted")
        return priorities
    
    
    def getopenTksList(self, clientId,prId):
        logger.info("in getopenTksList method in TicketModels ")
        sql = "SELECT ticketid AS ticketId,status AS status, priority AS priority, msp AS mspName, client AS clientName from incident_data where statusid NOT IN (3,5,17,20,32,41) AND deptid NOT IN (0,1,2) AND priorityid IN ("+str(prId)+") AND cid = "+str(clientId)
        cursor = connections['ticketRead'].cursor() 
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getopenTksListToday(self, clientId,prId):
        logger.info("in getopenTksListToday method in TicketModels ")
        sql = "SELECT ticketid AS ticketId,status AS status, priority AS priority, msp AS mspName, client AS clientName from incident_data where deptid NOT IN (0,1,2) AND priorityid IN ("+str(prId)+") AND cid = "+str(clientId)+" AND created_dt > unix_timestamp(now()-interval 1 day)"
        cursor = connections['ticketRead'].cursor() 
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    
    def getclosedTksList(self, clientId,prId):
        logger.info("in getclosedTksList method in TicketModels ")
        sql = " SELECT ticketid AS ticketId,status AS status, priority AS priority, msp AS mspName, client AS clientName from incident_data where statusid IN (3,5,17,20,32,41) AND deptid NOT IN (0,1,2) AND priorityid IN ("+str(prId)+") AND cid = '"+str(clientId)+"' AND created_dt >  unix_timestamp(now()-interval 1 month);"
        cursor = connections['ticketRead'].cursor() 
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getclosedTksListToday(self, clientId,prId):
        logger.info("in getclosedTksListToday method in TicketModels ")
        sql = "SELECT ticketid AS ticketId,status AS status, priority AS priority, msp AS mspName, client AS clientName from incident_data where statusid IN (3,5,17,20,32,41) AND deptid NOT IN (0,1,2) AND priorityid IN ("+str(prId)+") AND cid = "+str(clientId)+" AND created_dt > unix_timestamp(now()-interval 1 day)"
        cursor = connections['ticketRead'].cursor() 
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getDevicesInfo(self, clientId,devType):
        logger.info("in getDevicesInfo method in TicketModels ")
        sql = "SELECT dd.ipaddress as ipAddress,dd.os as os,dd.device_name as deviceName,dd.mac_address as macAddress,dd.osversion as osVersion FROM msp.device_data dd JOIN device_type dt ON dt.id=dd.devicetype JOIN  msp.organizations org ON org.id=dd.client_id JOIN msp.noc_details nocs ON(nocs.id = org.noc_details_id) JOIN msp.organization_apps org_apps ON(((org.id = org_apps.org_id) AND (org_apps.app_id = 1))) WHERE (dd.state IS NULL OR dd.state = 'active') AND (org.class_code = 'client') and org.id ='"+str(clientId)+"' and dt.devicetype = '"+str(devType)+"'"
        #sql = "select nmdd.device_name AS deviceName, nmdd.ipaddress AS ipAddress, nmdd.os AS operatingSystem from ntsmspdevicedata nmdd JOIN ntsdevice_type ndt ON (ndt.id = nmdd.devicetype) where nmdd.client_id = '"+str(clientId)+"' and nmdd.state = 'active' and ndt.devicetype = '"+str(devType)+"'"
        cursor = connections['mspDB'].cursor() 
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getTotalClosedTicketsCount(self, clientId):
        logger.info("in getTotalClosedTicketsCount method in TicketModels ")
        sql ="SELECT count(ticketid) AS count FROM incident_data WHERE cid = '"+str(clientId)+"' AND priorityid IN (8,9,10,11) AND deptid not in (0,1) AND created_dt > unix_timestamp((now()) - interval 1 day)" 
        #sql = "select nmdd.device_name AS deviceName, nmdd.ipaddress AS ipAddress, nmdd.os AS operatingSystem from ntsmspdevicedata nmdd JOIN ntsdevice_type ndt ON (ndt.id = nmdd.devicetype) where nmdd.client_id = '"+str(clientId)+"' and nmdd.state = 'active' and ndt.devicetype = '"+str(devType)+"'"
        cursor = connections['ticketRead'].cursor() 
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getCretdTodayTktsCount(self, clientId):
        logger.info("in getCretdTodayTktsCount method in TicketModels ")
        sql ="SELECT count(ticketid) AS count FROM incident_data WHERE cid = '"+str(clientId)+"' AND priorityid IN (8,9,10,11) AND deptid not in (0,1) AND created_dt > unix_timestamp((now()) - interval 1 day)" 
        #sql = "select nmdd.device_name AS deviceName, nmdd.ipaddress AS ipAddress, nmdd.os AS operatingSystem from ntsmspdevicedata nmdd JOIN ntsdevice_type ndt ON (ndt.id = nmdd.devicetype) where nmdd.client_id = '"+str(clientId)+"' and nmdd.state = 'active' and ndt.devicetype = '"+str(devType)+"'"
        cursor = connections['ticketRead'].cursor() 
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getClosedTodayTktsCount(self, clientId):
        logger.info("in getClosedTodayTktsCount method in TicketModels ")
        cursor = connections['ticketRead'].cursor() 
        cldStatusSql = "select group_concat(ticketstatusid) as status from swticketstatus where statustype=3 order by title"
        cursor.execute(cldStatusSql)
        cldSataus = commMM.dictfetchall(cursor)
        
        sql =" SELECT count(ticketid) AS count FROM incident_data WHERE cid = '106962' AND priorityid IN (8,9,10,11) AND deptid not in (0,1) AND statusid IN ("+str(cldSataus[0]['status'])+")  AND created_dt > unix_timestamp((now()) - interval 1 day);" 
        #sql = "select nmdd.device_name AS deviceName, nmdd.ipaddress AS ipAddress, nmdd.os AS operatingSystem from ntsmspdevicedata nmdd JOIN ntsdevice_type ndt ON (ndt.id = nmdd.devicetype) where nmdd.client_id = '"+str(clientId)+"' and nmdd.state = 'active' and ndt.devicetype = '"+str(devType)+"'"
        
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getHMSPWFCITodayTodayTktsCount(self, clientId):
        logger.info("in getHMSPWFCITodayTodayTktsCount method in TicketModels ")
        cursor = connections['ticketRead'].cursor() 
        hmspwfStatusSql = "select group_concat(ticketstatusid) as status from swticketstatus where statustype = 2"
        cursor.execute(hmspwfStatusSql)
        hmspSataus = commMM.dictfetchall(cursor)
        
        sql =" SELECT count(ticketid) AS count FROM incident_data WHERE cid = '106962' AND priorityid IN (8,9,10,11) AND deptid not in (0,1) AND statusid IN ("+str(hmspSataus[0]['status'])+")  AND created_dt > unix_timestamp((now()) - interval 1 day);" 
        #sql = "select nmdd.device_name AS deviceName, nmdd.ipaddress AS ipAddress, nmdd.os AS operatingSystem from ntsmspdevicedata nmdd JOIN ntsdevice_type ndt ON (ndt.id = nmdd.devicetype) where nmdd.client_id = '"+str(clientId)+"' and nmdd.state = 'active' and ndt.devicetype = '"+str(devType)+"'"
        
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getTodayTktsList(self,clientId):
        logger.info("in getTodayTktsList method in TicketModels ")
        Tktinfo ={}
        cursor = connections['ticketRead'].cursor() 
        cldStatusSql = "select group_concat(ticketstatusid) as status from swticketstatus where statustype=3 order by title"
        cursor.execute(cldStatusSql)
        cldSataus = commMM.dictfetchall(cursor)
        
        hmspwfStatusSql = "select group_concat(ticketstatusid) as status from swticketstatus where statustype = 2"
        cursor.execute(hmspwfStatusSql)
        hmspSataus = commMM.dictfetchall(cursor)
        
        crtdSql= "SELECT priority AS priority, status AS status, msp AS mspName, client AS clientName, ticketid AS ticketId FROM incident_data WHERE cid = '"+str(clientId)+"' AND priorityid IN (8,9,10,11) AND deptid not in (0,1) AND created_dt > unix_timestamp((now()) - interval 1 day)"
        hmspSql ="SELECT priority AS priority, status AS status, msp AS mspName, client AS clientName, ticketid AS ticketId FROM incident_data WHERE cid = '106962' AND priorityid IN (8,9,10,11) AND deptid not in (0,1) AND statusid IN ("+str(hmspSataus[0]['status'])+") AND created_dt > unix_timestamp((now()) - interval 1 day) "
        cldSql = "SELECT priority AS priority, status AS status, msp AS mspName, client AS clientName, ticketid AS ticketId FROM incident_data WHERE cid = '106962' AND priorityid IN (8,9,10,11) AND deptid not in (0,1) AND statusid IN ("+str(cldSataus[0]['status'])+") AND created_dt > unix_timestamp((now()) - interval 1 day) "
        
        cursor.execute(crtdSql)
        created = commMM.dictfetchall(cursor)
        
        cursor.execute(cldSql)
        closed = commMM.dictfetchall(cursor)
        
        cursor.execute(hmspSql)
        hmspWf = commMM.dictfetchall(cursor)
        cursor.close()
        Tktinfo['created']=created
        Tktinfo['closed'] =closed
        Tktinfo['hmsp'] =hmspWf
        logger.info("Method Complted")
        return Tktinfo
    
    
    def getP0Tickets(self,cid,statusId):
       logger.info("in getP0Tickets method in TicketModels ")
       sql = "SELECT s.ticketstatusid as statusid,s.title as status,COUNT(ticketid) as count   \
                FROM swticketstatus s left join incident_data id on s.ticketstatusid=id.statusid \
                WHERE s.ticketstatusid IN ("+str(statusId)+") AND id.deptid NOT IN (0,1,2) AND id.priorityid =8 and id.cid="+str(cid)+" GROUP BY s.ticketstatusid "; 
       cursor = connections['ticketRead'].cursor()
       cursor.execute(sql)
       result = commMM.orderDictFetchall(cursor)
       cursor.close()
       logger.info("Method Complted")
       return result
   
    def getP0TicketsInformation(self,cid,statusIds):
        logger.info("in getP0TicketsInformation method in TicketModels ")
        sql = "SELECT  ticketid, client, priority,subject,status,device,msp, created_dt,lastactivity from incident_data where statusid IN ("+str(statusIds)+") AND deptid NOT IN (0,1,2) AND priorityid IN (8) AND cid ="+str(cid)
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result

    def getTicketsInformation(self,post):
        result={}
        logger.info(" in getTicketsInformation method in TicketModels ")
        sql = "SELECT  ticketid as 'Ticket Id', priority as 'Priority',status as 'Status', created_dt as 'Created Date',  subject as 'Subject', lastactivity as 'Last Update' , msp as 'Partner Name',client as 'Client Name',device as 'Device Name' from incident_data WHERE 1=1 "
        try:
            if len(post.keys()) >0:
                deptFlag = 0
                dateFlag = 0
                for rec in post.keys():
                    if rec == 'deptid':
                        deptFlag = 1
                    if rec == 'created_dt' and dateFlag == 0:
                        dateFlag = 1
                        sql += " AND "+str(rec)+" >= "+ post.get(rec)[0] +" AND "+str(rec)+" <= "+ post.get(rec)[1] #("+",".join(str(e) for e in post.get(rec))+")"
                    else:
                        sql += " AND "+str(rec)+" in ("+",".join(str(e) for e in post.getlist(rec))+")"
                if deptFlag == 0:
                    sql += "  AND deptid NOT IN (0,1,2)  "
                print sql
                cursor = connections['ticketRead'].cursor()
                cursor.execute(sql)
                result = commMM.orderDictFetchall(cursor)
                cursor.close()
        except Exception as e:
            result = str(e)
        logger.info("getTicketsInformation Method Complted")
        return result

    def getHmspWfciTicketCount(self,cId,status):
        logger.info("in getHmspWfciTicketCount method in TicketModels ")
        
        sql = " SELECT p.display_text as 'Priority',COUNT(ticketid) as count \
                FROM incident_data id join  swticketpriorities p on p.priorityid=id.priorityid \
                WHERE deptid NOT IN (0,1,2)   AND id.cid="+str(cId)+" and id.statusid="+str(status)+" \
                and p.priorityid IN (8,9,10,11) group by p.priorityid;" 
        print sql
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
   
    def ticketCountByPriorityQuery(self,cid,statusIds):
        logger.info("in ticketCountByPriorityQuery method in TicketModels ")
        sql = " SELECT \
                ifnull(sum((case when (priorityid=8) then 1 else 0 end) ),0) Critical, \
                ifnull(sum((case when (priorityid=9) then 1 else 0 end) ),0) High, \
                ifnull(sum((case when (priorityid=10) then 1 else 0 end) ),0) Medium, \
                ifnull(sum((case when (priorityid=11) then 1 else 0 end) ),0) Low  \
                FROM incident_data \
                WHERE deptid NOT IN (0,1,2) \
                and statusid IN ("+statusIds+") \
                and priorityid IN (8,9,10,11) and cid = "+str(cid)
        print sql
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.orderDictFetchall(cursor)
        finalRes =[]
        final= OrderedDict()
        for k,v in result[0].iteritems():
            temp ={}
            temp['Priority'] = str(k)
            temp['Count']= int(v)
            finalRes.append(temp)
        cursor.close()
        final['Result'] = finalRes
        print final
        logger.info("ticketCountByPriorityQuery Method Complted")
        return finalRes
    
    def topFiveDeviceQuery(self,cId):
        sql = "select ntsd.device_name as device, count(ticketid) as count \
                from incident_data ind  JOIN ntsmspdevicedata ntsd on ind.did=ntsd.id \
                where cid="+str(cId)+" and created_dt>=unix_timestamp(date_sub(now(), interval 1 month)) \
                and deptid NOT IN (0,1,2) \
                and did>0 group by did order by count(ticketid) desc limit 5"
        print sql
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        print result
        logger.info("ticketCountByPriorityQuery Method Complted")
        return result

    def NEOSDivaMapping(self):
        from NNCPortal.configfile import ConfigManager
        configobj = ConfigManager()
        import ast
        NEOSDivaMapping = configobj.getCommConfigValue(configobj.NEOSDivaMapping)
        NEOSDivaMapping = ast.literal_eval(NEOSDivaMapping) 
        return NEOSDivaMapping
    
    def ticketStatuses(self):
        sql = "select ticketstatusid,display_text from swticketstatus"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        finalRes={}
        for r in result:
            finalRes[r['display_text']] = r['ticketstatusid']
        return finalRes
    
    def ticketPriority(self):
        sql = "select priorityid,display_text from swticketpriorities"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        finalRes={}
        for r in result:
            finalRes[r['display_text']] = r['priorityid']
        return finalRes
    
    def deviceDetails(self,cid):
        sql ="select id, device_name from ntsmspdevicedata where (state IS NULL OR state IN('','active','deleted-active')) AND client_id ="+str(cid)+" order by device_name"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        finalRes={}
        for r in result:
            finalRes[r['device_name']] = r['id']
        return finalRes
    
    
    def getSwticketstatus(self):
        sql = "select ticketstatusid,title,display_text,parent_id from swticketstatus order by displayorder"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        status = self.dictfetchall(cursor)
        cursor.close()
        print status
        return status
    
        """    def getActiveStatus(self,cId,status):
        logger.info("in getHmspWfciTicketCount method in TicketModels ")
        sql=    "SELECT COUNT(ticketid) total,ifnull(sum((case when (id.priorityid=8) then 1 else 0 end) ),0) Critical, ifnull(sum((case when (id.priorityid=9) then 1 else 0 end) ),0) High,ifnull(sum((case when (id.priorityid=10) then 1 else 0 end) ),0) Medium ,ifnull(sum((case when (id.priorityid=11) then 1 else 0 end) ),0) Low   FROM incident_data id join  swticketpriorities p on p.priorityid=id.priorityid WHERE deptid NOT IN (0,1,2)  and id.statusid in("+str(status)+") and id.priorityid IN (8,9,10,11) and cid ="+str(cId) 
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result"""
        
    def getActiveStatus(self,cId,status,condtions):
        logger.info("in getHmspWfciTicketCount method in TicketModels ")
        sql=    "SELECT COUNT(ticketid) total,ifnull(sum((case when (id.priorityid=8) then 1 else 0 end) ),0) Critical, ifnull(sum((case when (id.priorityid=9) then 1 else 0 end) ),0) High,ifnull(sum((case when (id.priorityid=10) then 1 else 0 end) ),0) Medium ,ifnull(sum((case when (id.priorityid=11) then 1 else 0 end) ),0) Low   FROM incident_data id join  swticketpriorities p on p.priorityid=id.priorityid WHERE deptid NOT IN (0,1,2)  and id.statusid in("+str(status)+") and id.priorityid IN (8,9,10,11) "+str(condtions)+" and cid ="+str(cId) 
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result

    def getTicketsByIsoTime(self,cId,status,formIsoDateTime,toIsoDateTime):
        logger.info("in getScheduledTicketcount method in TicketModels ")
        sql=    "SELECT COUNT(ticketid) total,   FROM incident_data id join  swticketpriorities p on p.priorityid=id.priorityid WHERE deptid NOT IN (0,1,2)  and id.statusid in("+str(status)+") and id.priorityid IN (8,9,10,11) and cid ="+str(cId) 
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def getTimeZone(self,timeZone): 
        logger.info("in getScheduledTicketcount method in TicketModels ")
        sql=    "select name as timeZone from nts_cfg_timezones where label_values ='"+str(timeZone)+"'"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result
    
    def operationalMetricCounts(self,status,priorty,cid,dates,tag,condtion):
        condtions = ''
        if status != False:
            condtions += " and statusid in ("+str(status)+")"
        if priorty != False:
            condtions += " and priorityid IN ("+str(priorty)+")"
        if len(dates) >1:
            if int(status) != 3:
                condtions +=" and created_dt >=unix_timestamp("+str(dates[0])+") and created_dt <= unix_timestamp("+str(dates[1])+")"
            else:
                condtions +=" and lastactivity >=unix_timestamp("+str(dates[0])+") and lastactivity <= unix_timestamp("+str(dates[1])+")"
        if cid != False:
            condtions += " and cid="+str(cid)
        if tag != False:
            condtions += " and tags like '"+str(tag)+"%'" 
        
        sql = "SELECT COUNT(ticketid) total,ifnull(sum((case when (priorityid=8) then 1 else 0 end) ),0) Critical, ifnull(sum((case when (priorityid=9) then 1 else 0 end) ),0) High,ifnull(sum((case when (priorityid=10) then 1 else 0 end) ),0) Medium ,ifnull(sum((case when (priorityid=11) then 1 else 0 end) ),0) Low    FROM incident_data where  deptid NOT IN (0,1,2)  "+str(condtions)+"  "+str(condtion)  
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        priortys ={}
        for i in result:
            for k, value in i.iteritems():
                priortys[k] = int(value)
        return priortys
    
    def getScheduledTicket(self,cid,status,dates,tag):
        sql = "SELECT COUNT(ticketid) total  FROM incident_data where  deptid NOT IN (0,1,2) AND  lastactivity >=unix_timestamp("+str(dates[0])+") and lastactivity <= unix_timestamp("+str(dates[1])+") and  statusid in("+str(status)+")  and cid ="+str(cid)+"  and tags like '"+str(tag)+"%'" 
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        return result
    
        
    def convertTz(self,dateTime,fromTz,toTz):
        sql = "SELECT CONVERT_TZ('"+str(dateTime)+"','"+str(fromTz)+"','"+str(toTz)+"') as pstdate FROM dual"
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        pstDate = commMM.dictfetchall(cursor)
        cursor.close()
        return pstDate[0]['pstdate']
    
        """def getScheduledTicket(self,cid,status,dates,tag):
        print 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'
        sql = "SELECT  COUNT(ticketid) total FROM incident_data as inc \
                    join swcustomfieldvalues as swc on inc.ticketid=swc.typeid  and customfieldid=12   \
                where   inc.deptid NOT IN (0,1,2)  \
                AND   inc.statusid =16  and inc.cid ="+str(cid)+"  and tags like '"+str(tag)+"%'        \
                and swc.fieldvalue >='"+str(dates[0])+"' and swc.fieldvalue<='"+str(dates[1])+"' "
        print sql+'--------------------------------------------------------------------------------0000000000000000scheduled'
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        return result"""
        
    def getWeatherAPI(self,cid):
        logger.info("in ticketsOfWeatherAPI method in TicketModels ")
        sql= "SELECT ticketid,subject FROM incident_data WHERE cid ="+str(cid)+" AND statusid != 3 AND subject LIKE '%Forecast of critical weather at%'"
        print sql
        cursor = connections['ticketRead'].cursor()
        cursor.execute(sql)
        result = commMM.dictfetchall(cursor)
        cursor.close()
        logger.info("Method Complted")
        return result