"""
 *
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc, and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 * 
 @author: ganisetti.raju
"""
from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from NNCPortal.commonMethodsNEOS import CommonMethods
#from apps.ticketing.models.nebotModels import NebotHistory
#from NEBOT.serializers import NebotHistorySerializer
from NNCPortal.CommonModel import CommonModelMethods
#from apps.ticketing.models.nebotModels import CommonModelMethods
import datetime as dt
from datetime import datetime,timedelta
from NNCPortal import nebotConfig
import math,time
import logging
import json
#from apps.authentication.models.TokenModel import TokenModel
logger = logging.getLogger(__name__)
commObj = CommonMethods() 
commMM = CommonModelMethods()
def createJsonData(queryString):
    ''' This method will convert the requested queryString into Json format'''
    logger.info('In createJsonData method in views.py')
    str = []
    str = queryString.split('+')
    querySting_json = {}
    for var in str:
        data = var.split(':',1)
        querySting_json[data[0]] = data[1]
   
    return querySting_json 

@api_view(['GET', 'POST', 'PUT'])
def GetTicektingData(request):
    """
    Getting the ticketing inforamtion
    """
    '''
    #token validation code
    token = request.META['HTTP_TOKEN']
    logger.info("Validating Token")
    tokObj=TokenModel()
    orgId = tokObj.getOrgId(token)
    orgId= orgId[0]['orgId']
    tokenInfo=tokObj.getTokenInfo(token)
    if len(tokenInfo) == 0:
         resp ={"Result" : "Please provide valid token"}
         return Response(resp,status=status.HTTP_401_UNAUTHORIZED)
    curtime = tokObj.currentTime()
    if int(curtime[0]['curr_time']) > int(tokenInfo[0]['expires']):
         resp ={"Result" : "Token Expired"}
         return Response(resp,status=status.HTTP_403_FORBIDDEN)
    '''
    print request.META
    finalResponse={}
    logger.info('In post ticketing data method in TicektingView.py')
    if request.method == 'POST':
        database = 'ticketWrite'
        commMM = CommonModelMethods()
        tableName = request.data['tableName']
        print "Table Name is :",tableName
        del request.data['tableName']
        postRvwId = commMM.insertRecord(request.data, tableName, database)
        if postRvwId:
            resp = {"Result" : "Record Saved successfully"}
            logger.info("Response is "+str(resp))
            return Response(resp, status=status.HTTP_200_OK)
            
        else:
            resp = {"Result" : "Failed to save record"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    logger.info('In Get ticket data method in TicektingView.py')
    if request.method == 'GET':
        database = "ticketRead"
        if('queryString' in request.query_params):
            queryString = request.query_params['queryString']
        else:
            resp ={"Result" : "Please Provide valid filter"}
            return Response(resp,status=status.HTTP_400_BAD_REQUEST)
        queryString = createJsonData(queryString)
        commonMthods = CommonMethods()
        tableName = queryString['tableName'].strip()
        
        logger.info("tableName is "+str(tableName))
            
        ''' preparing select Fields '''
        if 'selectFields' in queryString:
            selectFields = queryString['selectFields'].replace("(","")
            selectFields = selectFields.replace(")","")
            del queryString['selectFields']
        else:
            selectFields = commonMthods.prparingSelectFields(tableName,database)
        del queryString['tableName']
        
        ''' preparing filter Querystring  '''
        queryString = commonMthods.preparingQueryString(queryString)
        logger.info("query sting  is "+str(queryString))
        commMM = CommonModelMethods()
        
        '''getting records count'''
        totalRecordsCount = commMM.recordCount(tableName,queryString, database)
       
        if (str(totalRecordsCount) == 'Exception raised'):
            resp = {"Result" : "Internal error Occured"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            
        totalRecordsCount = totalRecordsCount[0]
        
        ''' Pagination code'''
        extentionQuery = ''
        
        if('orderBy' in request.query_params):
            finalResponse['orderBy']= request.query_params['orderBy']
            extentionQuery += " order by "+str(request.query_params['orderBy'])+" DESC "
        else:
            if(str(tableName) == "incident_data"):
                finalResponse['orderBy']= nebotConfig.incident_data_defaultOrderby
                extentionQuery += " order by "+str(nebotConfig.incident_data_defaultOrderby)+" DESC "
            

        if('pageSize' in request.query_params):
            finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(request.query_params['pageSize']))) + 1
            finalResponse['pageSize']= request.query_params['pageSize']
            extentionQuery += " LIMIT  "+str(request.query_params['pageSize'])
        else:
            finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(nebotConfig.defaultPageSize))) + 1
            finalResponse['pageSize']= nebotConfig.defaultPageSize
            extentionQuery += " LIMIT "+str(nebotConfig.defaultPageSize)
            
        if('pageNo' in request.query_params):
            pageNo = int(request.query_params['pageNo'])
            finalResponse["currentPageNo"] = str(pageNo)
            OFFSET = ((pageNo-1)*int(finalResponse['pageSize']))
            extentionQuery += " OFFSET "+str(OFFSET)
        else:
            pageNo = int(nebotConfig.defaultPageNo)
            finalResponse["currentPageNo"] = str(pageNo)
            OFFSET = (pageNo-1)*int(finalResponse['pageSize'])
            extentionQuery += " OFFSET "+str(OFFSET)
            
        queryString += extentionQuery
        
        ''' calling selectRecord method to get the requested data '''
        postRvwId = commMM.selectRecord(tableName,selectFields,queryString, database)
        
        if (str(postRvwId) == 'Exception raised'):
            resp = {"Result" : "Internal error Occured"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        if len(postRvwId) == 0 :
            postRvwId = {"Result" : "No Records Found"}
            finalResponse = postRvwId
        else :
            
            finalResponse['overAllRecordsCount'] = totalRecordsCount
            finalResponse['Result'] = postRvwId

        
        logger.info("exiting from getTicket data method in views ")
        
        return Response(finalResponse,status=status.HTTP_200_OK)


@api_view(['GET', 'POST', 'PUT'])
def GetTicektingDataStaging(request):
    """
    Getting the ticketing inforamtion
    """
    finalResponse={}
    logger.info('In GetTicektingDataStaging data method in TicektingView.py')
    print "..........................."
    if request.method == 'POST':
        print "++++++++++++++++++++++++++++++++++++++++++++++="
        database = 'ticketRead_staging'
        logger.info("database is : ",database)
        commMM = CommonModelMethods()
        tableName = request.data['tableName']
        print "Table Name is :",tableName
        del request.data['tableName']
        postRvwId = commMM.insertRecord(request.data, tableName, database)
        if postRvwId:
            resp = {"Result" : "Record Saved successfully"}
            logger.info("Response is "+str(resp))
            return Response(resp, status=status.HTTP_200_OK)
            
        else:
            resp = {"Result" : "Failed to save record"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    logger.error('In Get ticket data method in TicektingView.py')
    if request.method == 'GET':
        database = "ticketRead_staging"
        print "..............................."
        print "database is : ",database
        if('queryString' in request.query_params):
            queryString = request.query_params['queryString']
        else:
            resp ={"Result" : "Please Provide valid filter"}
            return Response(resp,status=status.HTTP_400_BAD_REQUEST)
        queryString = createJsonData(queryString)
        commonMthods = CommonMethods()
        tableName = queryString['tableName'].strip()
        
        logger.info("tableName is "+str(tableName))
            
        ''' preparing select Fields '''
        if 'selectFields' in queryString:
            selectFields = queryString['selectFields'].replace("(","")
            selectFields = selectFields.replace(")","")
            del queryString['selectFields']
        else:
            selectFields = commonMthods.prparingSelectFields(tableName,database)
        del queryString['tableName']
        
        ''' preparing filter Querystring  '''
        queryString = commonMthods.preparingQueryString(queryString)
        logger.info("query sting  is "+str(queryString))
        commMM = CommonModelMethods()
        
        '''getting records count'''
        totalRecordsCount = commMM.recordCount(tableName,queryString, database)
       
        if (str(totalRecordsCount) == 'Exception raised'):
            resp = {"Result" : "Internal error Occured"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            
        totalRecordsCount = totalRecordsCount[0]
        
        ''' Pagination code'''
        extentionQuery = ''
        
        if('orderBy' in request.query_params):
            finalResponse['orderBy']= request.query_params['orderBy']
            extentionQuery += " order by "+str(request.query_params['orderBy'])+" DESC "
        else:
            if(str(tableName) == "incident_data"):
                finalResponse['orderBy']= nebotConfig.incident_data_defaultOrderby
                extentionQuery += " order by "+str(nebotConfig.incident_data_defaultOrderby)+" DESC "
            

        if('pageSize' in request.query_params):
            finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(request.query_params['pageSize']))) + 1
            finalResponse['pageSize']= request.query_params['pageSize']
            extentionQuery += " LIMIT  "+str(request.query_params['pageSize'])
        else:
            finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(nebotConfig.defaultPageSize))) + 1
            finalResponse['pageSize']= nebotConfig.defaultPageSize
            extentionQuery += " LIMIT "+str(nebotConfig.defaultPageSize)
            
        if('pageNo' in request.query_params):
            pageNo = int(request.query_params['pageNo'])
            finalResponse["currentPageNo"] = str(pageNo)
            OFFSET = ((pageNo-1)*int(finalResponse['pageSize']))
            extentionQuery += " OFFSET "+str(OFFSET)
        else:
            pageNo = int(nebotConfig.defaultPageNo)
            finalResponse["currentPageNo"] = str(pageNo)
            OFFSET = (pageNo-1)*int(finalResponse['pageSize'])
            extentionQuery += " OFFSET "+str(OFFSET)
            
        queryString += extentionQuery
        
        ''' calling selectRecord method to get the requested data '''
        postRvwId = commMM.selectRecord(tableName,selectFields,queryString, database)
        
        if (str(postRvwId) == 'Exception raised'):
            resp = {"Result" : "Internal error Occured"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        if len(postRvwId) == 0 :
            postRvwId = {"Result" : "No Records Found"}
            finalResponse = postRvwId
        else :
            
            finalResponse['overAllRecordsCount'] = totalRecordsCount
            finalResponse['Result'] = postRvwId       
        logger.info("exiting from getTicket data method in views ")
        
        return Response(finalResponse,status=status.HTTP_200_OK)



@api_view(['GET', 'POST', 'PUT'])
def GetRosterStaging(request):
    """
    Getting the ticketing inforamtion
    """
    finalResponse={}
    logger.info('In roster data method in TicektingView.py')
    
    if request.method == 'POST':
        database = 'roster_staging'
        tableName = request.data['tableName']
        commMM = CommonModelMethods()
        del request.data['tableName']
        postRvwId = commMM.insertRecord(request.data, tableName, database)
        if postRvwId:
            resp = {"Result" : "Record Saved successfully"}
            logger.info("Response is "+str(resp))
            return Response(resp, status=status.HTTP_200_OK)
            
        else:
            resp = {"Result" : "Failed to save record"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    logger.info('In Get ticket data method in TicektingView.py')
    if request.method == 'GET':
        database = "roster_staging"
        
        if('queryString' in request.query_params):
            queryString = request.query_params['queryString']
        else:
            resp ={"Result" : "Please Provide valid filter"}
            return Response(resp,status=status.HTTP_400_BAD_REQUEST)
        queryString = createJsonData(queryString)
        commonMthods = CommonMethods()
        tableName = queryString['tableName'].strip()
        
        logger.info("tableName is "+str(tableName))
            
        ''' preparing select Fields '''
        if 'selectFields' in queryString:
            selectFields = queryString['selectFields'].replace("(","")
            selectFields = selectFields.replace(")","")
            del queryString['selectFields']
        else:
            selectFields = commonMthods.prparingSelectFields(tableName,database)
        del queryString['tableName']
        
        ''' preparing filter Querystring  '''
        queryString = commonMthods.preparingQueryString(queryString)
        logger.info("query sting  is "+str(queryString))
        commMM = CommonModelMethods()
        
        '''getting records count'''
        totalRecordsCount = commMM.recordCount(tableName,queryString, database)
       
        if (str(totalRecordsCount) == 'Exception raised'):
            resp = {"Result" : "Internal error Occured"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            
        totalRecordsCount = totalRecordsCount[0]
        
        ''' Pagination code'''
        extentionQuery = ''
        
        if('orderBy' in request.query_params):
            finalResponse['orderBy']= request.query_params['orderBy']
            extentionQuery += " order by "+str(request.query_params['orderBy'])+" DESC "
        else:
            if(str(tableName) == "incident_data"):
                finalResponse['orderBy']= nebotConfig.incident_data_defaultOrderby
                extentionQuery += " order by "+str(nebotConfig.incident_data_defaultOrderby)+" DESC "
            

        if('pageSize' in request.query_params):
            finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(request.query_params['pageSize']))) + 1
            finalResponse['pageSize']= request.query_params['pageSize']
            extentionQuery += " LIMIT  "+str(request.query_params['pageSize'])
        else:
            finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(nebotConfig.defaultPageSize))) + 1
            finalResponse['pageSize']= nebotConfig.defaultPageSize
            extentionQuery += " LIMIT "+str(nebotConfig.defaultPageSize)
            
        if('pageNo' in request.query_params):
            pageNo = int(request.query_params['pageNo'])
            finalResponse["currentPageNo"] = str(pageNo)
            OFFSET = ((pageNo-1)*int(finalResponse['pageSize']))
            extentionQuery += " OFFSET "+str(OFFSET)
        else:
            pageNo = int(nebotConfig.defaultPageNo)
            finalResponse["currentPageNo"] = str(pageNo)
            OFFSET = (pageNo-1)*int(finalResponse['pageSize'])
            extentionQuery += " OFFSET "+str(OFFSET)
            
        queryString += extentionQuery
        
        ''' calling selectRecord method to get the requested data '''
        postRvwId = commMM.selectRecord(tableName,selectFields,queryString, database)
        
        if (str(postRvwId) == 'Exception raised'):
            resp = {"Result" : "Internal error Occured"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        if len(postRvwId) == 0 :
            postRvwId = {"Result" : "No Records Found"}
            finalResponse = postRvwId
        else :
            
            finalResponse['overAllRecordsCount'] = totalRecordsCount
            finalResponse['Result'] = postRvwId

        
        logger.info("exiting from getTicket data method in views ")
        
        return Response(finalResponse,status=status.HTTP_200_OK)
    
    if request.method == 'PUT':
            logger.info(" In Put method in Tickeing View")
            postData = request.data
            dbname = 'roster_staging'
            if 'tableName' in postData:
                tableName = request.data['tableName']
                print "Table Name is :",tableName
                del request.data['tableName']
            else:
                resp = {"Result" : "Please Provide Table Name"}
                return Response(resp, status=status.HTTP_400_BAD_REQUEST)
            logger.info(str(postData))
            if postData['id']:
                query = " id = '"+str(postData['id'])+"' "
            else:
                resp = {"Result" : "Please Provide id name "}
                return Response(resp, status=status.HTTP_400_BAD_REQUEST)
                #return Response(resp)
            updateStauts = commObj.updateRecord(postData,tableName,query,dbname)
            logger.info('Method completed')
            if int(updateStauts) > 0:
                resp = {"Result" : "Record Updated Successfully"}
                return Response(resp, status=status.HTTP_200_OK)
            else:
                resp = {"Result" : "Zero Records Update"}
                return Response(resp, status=status.HTTP_200_OK)



@api_view(['GET', 'POST', 'PUT'])
def GetRoster(request):
    """
    Getting the ticketing inforamtion
    """
    finalResponse={}
    logger.info('In GetTicektingDataStaging data method in TicektingView.py')
    print "..........................."
    if request.method == 'POST':
        database = 'rosterWrite'
        logger.info("database is : ",database)
        commMM = CommonModelMethods()
        tableName = request.data['tableName']
        del request.data['tableName']
        postRvwId = commMM.insertRecord(request.data, tableName, database)
        if postRvwId:
            resp = {"Result" : "Record Saved successfully"}
            logger.info("Response is "+str(resp))
            return Response(resp, status=status.HTTP_200_OK)
            
        else:
            resp = {"Result" : "Failed to save record"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    logger.error('In Get ticket data method in TicektingView.py')
    if request.method == 'GET':
        database = "rosterRead"
        if('queryString' in request.query_params):
            queryString = request.query_params['queryString']
        else:
            resp ={"Result" : "Please Provide valid filter"}
            return Response(resp,status=status.HTTP_400_BAD_REQUEST)
        queryString = createJsonData(queryString)
        commonMthods = CommonMethods()
        tableName = queryString['tableName'].strip()
        logger.info("tableName is "+str(tableName))
            
        ''' preparing select Fields '''
        if 'selectFields' in queryString:
            selectFields = queryString['selectFields'].replace("(","")
            selectFields = selectFields.replace(")","")
            del queryString['selectFields']
        else:
            selectFields = commonMthods.prparingSelectFields(tableName,database)
        del queryString['tableName']
        
        ''' preparing filter Querystring  '''
        queryString = commonMthods.preparingQueryString(queryString)
        logger.info("query sting  is "+str(queryString))
        commMM = CommonModelMethods()
        
        '''getting records count'''
        totalRecordsCount = commMM.recordCount(tableName,queryString, database)
       
        if (str(totalRecordsCount) == 'Exception raised'):
            resp = {"Result" : "Internal error Occured"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            
        totalRecordsCount = totalRecordsCount[0]
        
        ''' Pagination code'''
        extentionQuery = ''
        
        if('orderBy' in request.query_params):
            finalResponse['orderBy']= request.query_params['orderBy']
            extentionQuery += " order by "+str(request.query_params['orderBy'])+" DESC "
        else:
            if(str(tableName) == "incident_data"):
                finalResponse['orderBy']= nebotConfig.incident_data_defaultOrderby
                extentionQuery += " order by "+str(nebotConfig.incident_data_defaultOrderby)+" DESC "
            

        if('pageSize' in request.query_params):
            finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(request.query_params['pageSize']))) + 1
            finalResponse['pageSize']= request.query_params['pageSize']
            extentionQuery += " LIMIT  "+str(request.query_params['pageSize'])
        else:
            finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(nebotConfig.defaultPageSize))) + 1
            finalResponse['pageSize']= nebotConfig.defaultPageSize
            extentionQuery += " LIMIT "+str(nebotConfig.defaultPageSize)
            
        if('pageNo' in request.query_params):
            pageNo = int(request.query_params['pageNo'])
            finalResponse["currentPageNo"] = str(pageNo)
            OFFSET = ((pageNo-1)*int(finalResponse['pageSize']))
            extentionQuery += " OFFSET "+str(OFFSET)
        else:
            pageNo = int(nebotConfig.defaultPageNo)
            finalResponse["currentPageNo"] = str(pageNo)
            OFFSET = (pageNo-1)*int(finalResponse['pageSize'])
            extentionQuery += " OFFSET "+str(OFFSET)
            
        queryString += extentionQuery
        
        ''' calling selectRecord method to get the requested data '''
        postRvwId = commMM.selectRecord(tableName,selectFields,queryString, database)
        
        if (str(postRvwId) == 'Exception raised'):
            resp = {"Result" : "Internal error Occured"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        if len(postRvwId) == 0 :
            postRvwId = {"Result" : "No Records Found"}
            finalResponse = postRvwId
        else :
            
            finalResponse['overAllRecordsCount'] = totalRecordsCount
            finalResponse['Result'] = postRvwId

        
        logger.info("exiting from getTicket data method in views ")
        
        return Response(finalResponse,status=status.HTTP_200_OK)
    
    if request.method == 'PUT':
            logger.info(" In Put method in Tickeing View")
            postData = request.data
            dbname = 'rosterWrite'
            if 'tableName' in postData:
                tableName = request.data['tableName']
                print "Table Name is :",tableName
                del request.data['tableName']
            else:
                resp = {"Result" : "Please Provide Table Name"}
                return Response(resp, status=status.HTTP_400_BAD_REQUEST)
            logger.info(str(postData))
            if postData['id']:
                query = " id = '"+str(postData['id'])+"' "
            else:
                resp = {"Result" : "Please Provide id name "}
                return Response(resp, status=status.HTTP_400_BAD_REQUEST)
                #return Response(resp)
            updateStauts = commObj.updateRecord(postData,tableName,query,dbname)
            logger.info('Method completed')
            if int(updateStauts) > 0:
                resp = {"Result" : "Record Updated Successfully"}
                return Response(resp, status=status.HTTP_200_OK)
            else:
                resp = {"Result" : "Zero Records Update"}
                return Response(resp, status=status.HTTP_200_OK)

@api_view(['GET', 'POST', 'PUT'])
def GetCurrentTime(request):
    """
    Getting the ticketing inforamtion
    """
    finalResponse={}
    logger.info('In GetCurrentTime method in TicektingView.py')
    try:
        logger.info("in try block")
        resp = commMM.currentTime()
        finalResponse['Result']=resp
        return Response(finalResponse,status=status.HTTP_200_OK)
    except Exception as e:
        finalResponse['Result']=str(e)
        return Response(finalResponse,status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
''' This method used to update updateCumuletive info'''   
@api_view(['GET', 'POST', 'PUT'])
def updateCumuletive(request):
    if request.method == 'PUT':
            postData = request.data
            logger.info(str(postData))
            if 'employee_number' in postData:
                pass
            else:
                resp = {"Result" : "Please Provide employee_number "}
                return Response(resp, status=status.HTTP_400_BAD_REQUEST)
            if 'first_punch_in_time' in postData:
                pass
            else:
                resp = {"Result" : "Please Provide first_punch_in_time "}
                return Response(resp, status=status.HTTP_400_BAD_REQUEST)
            query = " employee_number="+str(postData['employee_number'])+" AND first_punch_in_time='"+str(postData['first_punch_in_time'])+"'"
            
            updateStauts = commObj.updateRecord(postData,'cumulative_biometric_info',query,'roster_staging')
            logger.error('Method completed')
            if int(updateStauts) > 0:
                resp = {"Result" : "Record Updated Successfully"}
                return Response(resp, status=status.HTTP_200_OK)
            else:
                resp = {"Result" : "Zero Records Update"}
                return Response(resp, status=status.HTTP_200_OK)