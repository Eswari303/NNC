"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
  
 """
from rest_framework.decorators import api_view
from rest_framework.response import Response
from datetime import datetime,timedelta
from django.shortcuts import render
from collections import OrderedDict
from rest_framework import status
import datetime as dt
import operator
import logging
import redis
from rest_framework.decorators import api_view
from NNCPortal.commonMethodsNEOS import CommonMethods
from NNCPortal import AutoClosureConfig
from apps.ticketing.models.TicketMetricModel import CommonModelMethods
import datetime as dt
from datetime import datetime,timedelta
from NNCPortal import nebotConfig
import math,time
import logging
import json
logger = logging.getLogger(__name__)
commObj = CommonMethods()       

@api_view(['GET', 'POST','PUT'])       
def rbaMetric(request):
    try:
        logger.info('Post data is')
        finalResponse = {}
        preparePaylaod = {}
        finalResponse["Result"] = {}
        commMM = CommonModelMethods()
        if request.method == 'POST':
            postData = request.data
            logger.info(str(postData))
            metricStauts = commMM.postMetricData(postData)
            logger.error('Method completed')
            if int(metricStauts) > 0:
                resp = {"Result" : "Record Inserted Successfully"}
                return Response(resp, status=status.HTTP_200_OK)
                #return Response(resp)
            else:
                resp = {"Result" : "Failed To Insert Record"}
                return Response(resp, status=status.HTTP_204_NO_CONTENT)
                #return Response(resp)
           
        if request.method == 'GET':
            resp = []
            flag =0
            rbaQryStr = " where status ='1' "
            if('queryString' in request.query_params):
                    queryString = request.query_params['queryString']
                    queryString = commObj.createJsonData(queryString)
                    #statusValue = queryString['status']
                    flag = 1
                    rbaQryStr = commObj.preparingQueryString(queryString)
            ''' Pagination Code '''
            extentionQuery = ''
            totalRecordsCount = commMM.getTicketRbaStatusCount(rbaQryStr)
            totalRecordsCount = totalRecordsCount[0]['count']
            finalResponse['totalRecordsCount']= totalRecordsCount
            if('queryString' in request.query_params):
                if('orderBy' in request.query_params):
                    finalResponse['orderBy']= request.query_params['orderBy']
                    extentionQuery += " order by "+str(request.query_params['orderBy'])+" DESC "
                else:
                    finalResponse['orderBy']= 'ticketid'
                    extentionQuery += " order by "+str(finalResponse['orderBy'])+" DESC "
    
                if('pageSize' in request.query_params):
                    finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(request.query_params['pageSize']))) + 1
                    finalResponse['pageSize']= request.query_params['pageSize']
                    extentionQuery += " LIMIT  "+str(request.query_params['pageSize'])
                else:
                    finalResponse['pageSize']= 20
                    finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(finalResponse['pageSize']))) + 1
                    extentionQuery += " LIMIT "+str(finalResponse['pageSize'])
                    
                if('pageNo' in request.query_params):
                    pageNo = int(request.query_params['pageNo'])
                    finalResponse["currentPageNo"] = str(pageNo)
                    OFFSET = ((pageNo-1)*int(finalResponse['pageSize']))
                    extentionQuery += " OFFSET "+str(OFFSET)
                else:
                    pageNo =1
                    finalResponse["currentPageNo"] = str(pageNo)
                    OFFSET = (pageNo-1)*int(finalResponse['pageSize'])
                    extentionQuery += " OFFSET "+str(OFFSET)
            else:
                finalResponse['orderBy']= 'ticketid'
                extentionQuery += " order by "+str(finalResponse['orderBy'])+" DESC "

                finalResponse['pageSize']= 20
                finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(finalResponse['pageSize']))) + 1
                extentionQuery += " LIMIT "+str(finalResponse['pageSize'])
                
                pageNo =1
                finalResponse["currentPageNo"] = str(pageNo)
                OFFSET = (pageNo-1)*int(finalResponse['pageSize'])
                extentionQuery += " OFFSET "+str(OFFSET)
                
            ticketData = commMM.getTicketRbaStatus(rbaQryStr,extentionQuery)
            if len(ticketData) == 0:
                finalResponse = {"Result" : "No records found"}
            else:
                for tkData in ticketData:
                    actStatus = commMM.getActStaId()
                    actStatusList = actStatus[0]["actstatus"]
                    chkStatus = commMM.tktstatus(tkData['ticketid'], actStatusList)
                    if len(chkStatus) > 0 :
                        if int(chkStatus[0]['statusid']) == AutoClosureConfig.sHealStatus:
                           tkData['status'] = AutoClosureConfig.sHealStatus 
                           query = " ticketid = '"+str(tkData['ticketid'])+"' "
                           postData = {}
                           postData['status'] = AutoClosureConfig.sHealStatus
                           updateStauts = commObj.updateRecord(postData,'nts_ticket_metric_rba_status',query,'ticketWrite')
                           #updateStauts = commObj.updateRecord(postData,'nts_ticket_metric_rba_status',query,'ticketWrite')
                      
                        resp.append(tkData)
                    else:
                        query = " ticketid = '"+str(tkData['ticketid'])+"' "
                        postData = {}
                        postData['status'] = AutoClosureConfig.closedStatus
                        updateStauts = commObj.updateRecord(postData,'nts_ticket_metric_rba_status',query,'ticketWrite')
                        #updateStauts = commObj.updateRecord(postData,'nts_ticket_metric_rba_status_staging',query,'ticketWrite')
                if len(resp) == 0:
                    finalResponse = {"Result" : "No records found"}
                else:
                    finalResponse['Result'] = resp
            return Response(finalResponse, status=status.HTTP_200_OK)
        
        if request.method == 'PUT':
            postData = request.data
            logger.info(str(postData))
            if 'ticketid' in postData:
                query = " ticketid = '"+str(postData['ticketid'])+"' "
            elif 'resource_uid' in postData :
                query = " resource_uid = '"+str(postData['resource_uid'])+"' "
            else:
                resp = {"Result" : "Please Provide ticketid "}
                return Response(resp, status=status.HTTP_400_BAD_REQUEST)
                #return Response(resp)
            updateStauts = commObj.updateRecord(postData,'nts_ticket_metric_rba_status',query,'ticketWrite')
            #updateStauts = commObj.updateRecord(postData,'nts_ticket_metric_rba_status_staging',query,'ticketWrite')
            logger.info('Method completed')
            if int(updateStauts) > 0:
                resp = {"Result" : "Record Updated Successfully"}
                return Response(resp, status=status.HTTP_200_OK)
            else:
                resp = {"Result" : "No Records To Update"}
                return Response(resp, status=status.HTTP_200_OK)
                      
    except Exception as e:
        commonMethods = CommonMethods()
        resp = commonMethods.postRequest(str(e),"AutoClosureView.py and TicketMetricModel.py")
        return Response(str(e), status=status.HTTP_500_INTERNAL_SERVER_ERROR)              