"""
 *
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc, and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 * 
 @author: ganisetti.raju
"""
from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from NNCPortal.commonMethodsNEOS import CommonMethods
#from apps.ticketing.models.nebotModels import NebotHistory
#from NEBOT.serializers import NebotHistorySerializer
from apps.ticketing.models.nebotModels import CommonModelMethods
import datetime as dt
from datetime import datetime,timedelta
from NNCPortal import nebotConfig
import math,time
import logging
import json
logger = logging.getLogger(__name__)
commObj = CommonMethods() 

def createJsonData(queryString):
    ''' This method will convert the requested queryString into Json format'''
    logger.info('In createJsonData method in views.py')
    str = []
    str = queryString.split('+')
    querySting_json = {}
    for var in str:
        data = var.split(':')
        querySting_json[data[0]] = data[1]
   
    return querySting_json 

@api_view(['GET', 'POST', 'PUT'])
def GetNebotData(request):
    """
    List all tasks, or create a new task.
    """
    finalResponse={}
    logger.info('In Post Nebot Data method in nebot/views.py')
    if request.method == 'POST':
        database = 'nebot'
        commMM = CommonModelMethods()
        tableName = request.data['tableName']
        if(str(tableName) == "nebot_user_notification" or str(tableName) == 'nebot_history'):
            database = "roster_staging"
        print "Table Name is :",tableName
        del request.data['tableName']
        
        postRvwId = commMM.insertRecord(request.data, tableName, database)
        if postRvwId:
            resp = {"Result" : "Record Saved successfully"}
            logger.info("Response is "+str(resp))
            return Response(resp)
            
        else:
            resp = {"Result" : "Failed to save record"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    logger.info('In GetNebotData method in nebot/views.py')
    if request.method == 'GET':
        database = "nebot"
        if('queryString' in request.query_params):
            queryString = request.query_params['queryString']
        else:
            resp ={"Result" : "Please Provide valid filter"}
            return Response(resp)
        queryString = createJsonData(queryString)
        commonMthods = CommonMethods()
        tableName = queryString['tableName'].strip()
        print tableName
       
        ''' database selection for incident_data table'''
        if(str(tableName) == "incident_data" or str(tableName)=='swauditlogs' or str(tableName)=='nts_ticket_metric_rba_status' or str(tableName)=='nts_ticket_metric_rba_status_staging'):
            database = "ticketRead"
         
        if(str(tableName) == "nebot_user_notification" or str(tableName) == 'nebot_history'):
            database = "roster_staging"
       
       
        logger.error("tableName is "+str(tableName))
            
        ''' preparing select Fields '''
        selectFields = commonMthods.prparingSelectFields(tableName,database)
        del queryString['tableName']
        
        ''' preparing filter Querystring  '''
        queryString = commonMthods.preparingQueryString(queryString)
        logger.info("query sting  is "+str(queryString))
        commMM = CommonModelMethods()
        
        '''getting records count'''
        totalRecordsCount = commMM.recordCount(tableName,queryString, database)
       
        if (str(totalRecordsCount) == 'Exception raised'):
            resp = {"Result" : "Internal error Occured"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
            
        totalRecordsCount = totalRecordsCount[0]
        
        ''' Pagination code'''
        extentionQuery = ''
        
        if('orderBy' in request.query_params):
            finalResponse['orderBy']= request.query_params['orderBy']
            extentionQuery += " order by "+str(request.query_params['orderBy'])+" DESC "
        else:
            if(str(tableName) == "incident_data"):
                finalResponse['orderBy']= nebotConfig.incident_data_defaultOrderby
                extentionQuery += " order by "+str(nebotConfig.incident_data_defaultOrderby)+" DESC "
            else :
                finalResponse['orderBy']= nebotConfig.defaultOrderBy
                extentionQuery += " order by "+str(nebotConfig.defaultOrderBy)+" DESC "

        if('pageSize' in request.query_params):
            finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(request.query_params['pageSize'])))
            finalResponse['pageSize']= request.query_params['pageSize']
            extentionQuery += " LIMIT  "+str(request.query_params['pageSize'])
        else:
            finalResponse['totalPages']= int(math.ceil(totalRecordsCount/int(nebotConfig.defaultPageSize)))
            finalResponse['pageSize']= nebotConfig.defaultPageSize
            extentionQuery += " LIMIT "+str(nebotConfig.defaultPageSize)
            
        if('pageNo' in request.query_params):
            pageNo = int(request.query_params['pageNo'])
            finalResponse["currentPageNo"] = str(pageNo)
            OFFSET = ((pageNo-1)*int(finalResponse['pageSize']))
            extentionQuery += " OFFSET "+str(OFFSET)
        else:
            pageNo = int(nebotConfig.defaultPageNo)
            finalResponse["currentPageNo"] = str(pageNo)
            OFFSET = (pageNo-1)*int(finalResponse['pageSize'])
            extentionQuery += " OFFSET "+str(OFFSET)
            
        queryString += extentionQuery
        
        ''' calling selectRecord method to get the requested data '''
        postRvwId = commMM.selectRecord(tableName,selectFields,queryString, database)
        
        if (str(postRvwId) == 'Exception raised'):
            resp = {"Result" : "Internal error Occured"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        if len(postRvwId) == 0 :
            postRvwId = {"Result" : "No Records Found"}
            finalResponse = postRvwId
        else :
            
            finalResponse['overAllRecordsCount'] = totalRecordsCount
            finalResponse['Result'] = postRvwId

        
        logger.info("exiting from GetNebotData method in views ")
        
        return Response(finalResponse)

    if request.method == 'PUT':
            postData = request.data
            logger.info(str(postData))
            if postData['command']:
                query = " command = '"+str(postData['command'])+"' "
            else:
                resp = {"Result" : "Please Provide command name "}
                return Response(resp, status=status.HTTP_400_BAD_REQUEST)
                #return Response(resp)
            updateStauts = commObj.updateRecord(postData,'nebot_history',query,'roster_staging')
            logger.info('Method completed')
            if int(updateStauts) > 0:
                resp = {"Result" : "Record Updated Successfully"}
                return Response(resp, status=status.HTTP_200_OK)
            else:
                resp = {"Result" : "Zero Records Update"}
                return Response(resp, status=status.HTTP_200_OK)
    
def ProcessDictData(data):
    for index in data:
        if index["priorityid"] == 8 :
            index['priority'] = "critical"
            
        if index["priorityid"] == 9 :
            index['priority'] = "High"
            
        if index["priorityid"] == 10 :
            index['priority'] = "Medium"
                
        if index["priorityid"] == 11 :
            index['priority'] = "Low"
    return data
            

@api_view(['GET', 'POST'])
def PostNebotData(request):
    """
    List all tasks, or create a new task.
    """
    logger.info('In Post Nebot Data method in nebot/views.py')
    if request.method == 'POST':
       
        commMM = CommonModelMethods()
        tableName = request.data['tableName']
        print "Table Name is :",tableName
        del request.data['tableName']
        print request.data
        postRvwId = commMM.insertRecord(request.data, tableName, 'nebot')
        if postRvwId:
            resp = {"Result" : "Record Saved successfully"}
            logger.info("Response is "+str(resp))
            return Response(resp)
            
        else:
            resp = {"Result" : "Failed to save record"}
            logger.error("Response is ",resp)
            return Response(resp, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


@api_view(['GET', 'POST'])
def GetBrchTkts(request, staffId):
    neObj = CommonModelMethods()
    brchTkts = {}
    brchTkts['Result'] = {}
    resp = neObj.brchTkts(staffId)
    if len(resp) == 0 : 
        brchTkts = {"Result" : "No Records Found"}
    else:
        brchTkts = {"Result" : resp}
    return Response(brchTkts)

@api_view(['GET', 'POST'])
def ScheduledTkts(request):
    neObj = CommonModelMethods()
    schTkts = {}
    if 'HTTP_ACTION' in request.META and request.META.get('HTTP_ACTION') != None:
        if request.META.get('HTTP_ACTION') == 'ticketlist':
            schTkts['Result'] = {}
            resp = neObj.schTkts()
            if len(resp) == 0 : 
                schTkts = {"Result" : "No records found"}
            else:
                schTkts = {"Result" : resp}
            return Response(schTkts, status=status.HTTP_200_OK)
        elif request.META.get('HTTP_ACTION') == 'ticketcount':
            resp = neObj.schTktCount()
            if len(resp) == 0 : 
                schTkts = {"Result" : "No records found"}
            else:
                schTkts = {"Result" : resp[0]}
            return Response(schTkts, status=status.HTTP_200_OK)
        else:
            schTkts = {"Result" : "No action found"}
            return Response(schTkts, status=status.HTTP_200_OK)
    else:
        schTkts = {"Result" : "Please specify header action"}
        return Response(schTkts, status=status.HTTP_400_BAD_REQUEST)