"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
  
 """
 
from rest_framework.decorators import api_view
from rest_framework.response import Response
from datetime import datetime,timedelta
from django.shortcuts import render
from collections import OrderedDict
from rest_framework import status
import datetime as dt
import operator
import logging
import redis
import json
import os

from apps.ticketing.models.AutoAssignModel import AutoAssignMethods
from apps.ticketing.serviceTicketing import ServiceTicketing
from NNCPortal.commonMethodsNEOS import CommonMethods

AutoAssignObj = AutoAssignMethods()
autologger = logging.getLogger('AutoAssign')
serviceObj = ServiceTicketing()
commObj = CommonMethods()       

@api_view(['GET', 'POST'])       
def currentStaffDetails(request):
    try: 
        autologger.debug("In current staff details")
        finalRes = {}
        finalRes['Result'] = {}
        priBasedCount = []
        currentTime = AutoAssignObj.getCurrentTime()    
        os.environ["TZ"] = "Asia/Kolkata"
        currDateTime = datetime.now()
        
        currDate = currDateTime.strftime('%Y-%m-%d')
        currTime = currDateTime.strftime('%H:%M:%S')
        actCount = AutoAssignObj.getOnlineStaff(currDate,currTime)
        autologger.debug("Online staff information: "+str(actCount))   
        TicketsInfoFinal = []
        TicketsInfoFinal = serviceObj.CurrentStaff_FinalResult(actCount)
        #autologger.debug("Tickets info Final Reuslt: "+str(TicketsInfoFinal))
        return Response(TicketsInfoFinal)
    except Exception as e:
        print "Exception Raised[Current Staff Details]",str(e)
        

@api_view(['GET', 'POST'])       
def autoAssign(request):
    try:
        hashname = ''    
        FinalStaffId = ''
        post = {}
        if request.method=='GET':
            print "In GET Request"
            post = request.data
            ticketId = post['ticketid']
            deptId = post['deptid']    
            tkt_priority = post['priorityid']
            tkt_subject = post['subject']
            subject_short = tkt_subject[:20]
            subject_short = subject_short+'%'
        if request.method=='POST':        
            print "In POST Request"
            post = request.data
            ticketId = post['ticketid']
            deptId = post['deptid']    
            tkt_priority = post['priorityid']
            tkt_subject = post['subject']
            subject_short = tkt_subject[:20]
            subject_short = subject_short+'%'
        autologger.debug("Request details: TicketId="+str(ticketId)+" deptID: "+str(deptId)+" subject_short: "+str(subject_short))
               
        """ Redis connectivity """
        rediscon = serviceObj.connectRedis()
        
        """ Case 1: Get all the current available Staff who are in the Building """
        onlinestaffids = serviceObj.getOnlinestaff(rediscon)
        autologger.debug("Online staffIds: "+str(onlinestaffids))
        
        if len(onlinestaffids) > 0: 
            DeptstaffData = {}
            filtered_Staffid_list = [] 
            sorted_filtered_staffidlist = {}
            filtered_staffidString = ''
            
            """Case 2 : Check Staff Over all Active tickets if greater than 5 then ignore
               Case 3 : Get Staff Department details from Case 1 based on the Ticketed Department if not Ignore the Staff
               Case 4 : Check Staff Department active tickets 
               ###Only get filtered Info combined by case 2 & 3 & 4 using the below function### """           
            DeptstaffData = serviceObj.getTotal_deptStaff(rediscon,deptId,onlinestaffids) 
            autologger.debug("Department staff Data: "+str(DeptstaffData))
            print "Department staff data",DeptstaffData      
            
            """ Preparing staff id list and string contains only staffids to be used in Subject based Queries"""
            for key,value in DeptstaffData.iteritems():            
                filtered_Staffid_list.append(key)            
            autologger.debug("Filetered staff list: "+str(filtered_Staffid_list))
            filtered_staffidString = ",".join(filtered_Staffid_list)
            autologger.debug("Filetered staff string: "+str(filtered_staffidString))
            
            """Case 5 : Get lowest top 5 Staff other wise goes to case 9"""
            
            if len(DeptstaffData) > 5 and DeptstaffData != None:            
                Final_subj_stafflist = {}
                print "Befrore subject check"
                Final_subj_stafflist = serviceObj.getStaffids_subjectbased(subject_short,filtered_staffidString)
                autologger.debug("In If(a) case and subject based staff list: "+str(Final_subj_stafflist))
                print "final subject staff list",Final_subj_stafflist
                if Final_subj_stafflist:
                    autologger.debug("subject based staff existed: "+str(Final_subj_stafflist))
                    """ case 6 : Check the staff who have worked on the type of ticket which has Subject line if not found
                                 goes to case 6.5 """
                    print "In IF"
                    """ case 7 : Get the Lowest staffid count and get the staff id if found 
                                 and return the staffid for the ticket assign """                
                    FinalStaffId = Final_subj_stafflist[0]
                    autologger.debug("Final staff ID in subject case: "+str(FinalStaffId))
                    print "Final Staff id"
                    print FinalStaffId
                     
                else:
                    """ #case 6.5: Pick up the staff id who has less active tickets from the sorted list """
                    print "In else"
                    autologger.debug("In else(a) case: ")
                    sorted_filtered_staffidlist = []
                    sorted_filtered_staffidlist = sorted(DeptstaffData.items(), key=operator.itemgetter(1)) 
                    FinalStaffId = sorted_filtered_staffidlist[0]
                    print "Final Staff id"
                    FinalStaffId = FinalStaffId[0]
                    autologger.debug("Final staff ID in (a):"+str(FinalStaffId))
                    print FinalStaffId
                    
            elif len(DeptstaffData) <= 5 and len(DeptstaffData) !=0 :  
                """ Case 7 : Getting Staff Id using Subject line who worked earlier in the staff list"""   
                autologger.debug("In less than or equal case(b)") 
                Final_subj_stafflist = []   
                Final_subj_stafflist = serviceObj.getStaffids_subjectbased(subject_short,filtered_staffidString) 
                autologger.debug("in if case (b) subject based staff: "+str(Final_subj_stafflist))
                print "In exception case Final staff id"
                if Final_subj_stafflist: 
                    """ case 8 : Get the Lowest staffid with respect to count 
                                 and get the staff id if found and return the staffid for the ticket assign """    
                    print Final_subj_stafflist[0] 
                    FinalStaffId = Final_subj_stafflist[0]
                    autologger.debug("Final staff id in if case (b): "+str(FinalStaffId))
                    print FinalStaffId
                else:
                    autologger.debug("In else case(b)")
                    sorted_filtered_staffidlist = []
                    sorted_filtered_staffidlist = sorted(DeptstaffData.items(), key=operator.itemgetter(1)) 
                    FinalStaffId = sorted_filtered_staffidlist[0]
                    print "Final Staff id"
                    FinalStaffId = FinalStaffId[0]
                    autologger.debug("Finalstaff Id in else case (b): "+str(FinalStaffId))
                    print FinalStaffId 
            else:
                print "no dept staff data found"
                logging.debug("No staff data found in the dept:"+str(deptId))
        if FinalStaffId:
            staffexists = serviceObj.checkStaffDepartment(FinalStaffId,deptId)
            if staffexists == 0:
               FinalStaffId = '' 
        return Response({"StaffId":FinalStaffId})
    except Exception as e:
        print "Exception Raised[Auto Assign Method]",str(e)
                           