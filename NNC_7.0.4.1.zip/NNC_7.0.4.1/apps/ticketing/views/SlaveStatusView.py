"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
  
 """
 
from rest_framework.decorators import api_view
from rest_framework.response import Response
import logging
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from NNCPortal.commonMethodsNEOS import CommonMethods
from apps.ticketing.models.SlaveStatusModel import CommonModelMethods
logger = logging.getLogger(__name__)
commObj = CommonMethods()   
commMM = CommonModelMethods()  
  
@api_view(['GET', 'POST','PUT'])       
def showSlaveSatus(request):
    ''' This method will get the slave status(ticketing db)'''
    logger.info("in showSlaveSatus in SlaveStatusView")
    finalResponse = {}
    try:
        finalResponse["Result"] = {}
        slaveStatus = commMM.getSlaveStatus()
        finalResponse["Result"] = slaveStatus
        return Response(finalResponse, status=status.HTTP_200_OK)
    except Exception,e:
        finalResponse["Result"] = str(e)
        logger.error("Exeception Raisd "+str(e))
        return Response(finalResponse, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
        
        
        