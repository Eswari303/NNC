"""
 *
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc, and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 * 
 @author: ganisetti.raju
"""
from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from NNCPortal.commonMethodsNEOS import CommonMethods
#from apps.ticketing.models.nebotModels import NebotHistory
#from NEBOT.serializers import NebotHistorySerializer
from apps.ticketing.models.TicketMetricModel import CommonModelMethods
import datetime as dt
from datetime import datetime,timedelta
from NNCPortal import nebotConfig
import math,time
import logging
import json
from _ast import And
logger = logging.getLogger(__name__)

def createJsonData(queryString):
    ''' This method will convert the requested queryString into Json format'''
    logger.info('In createJsonData method in views.py')
    str = []
    str = queryString.split('+')
    querySting_json = {}
    for var in str:
        data = var.split(':',1)
        querySting_json[data[0]] = data[1]
   
    return querySting_json 

@api_view(['GET', 'POST', 'PUT'])
def ticketData(request):
    """
        getting ticket data 
    """
    try:
        logger.info('In ticketData Method')
        finalResponse={}
        commMM = CommonModelMethods()
        commonMethods = CommonMethods()
        if request.method == 'GET':
            extQry = ""
            queryString = request.query_params['queryString']
            queryString = createJsonData(queryString)
            deviceTypeId = ''
            ticketids = ''
            subject = queryString['subject']
            actStatusId = {}
            actStatusList = ""
            statusId = ""
            postsub = ""
            postFlag = 0
            actStatusId = commMM.getActStaId()
            actStatusList = actStatusId[0]["actstatus"]
            #checking swticket posts table 
            if 'posts' in  queryString:
                postsData = queryString['posts'].strip()
                postFlag = 1
                if str(postsData) != str('0') :
                    statusId = " AND icd.statusid IN ("+str(actStatusList)+")"
                    if 'searchpost' in  queryString:
                        postsub = queryString['searchpost'].strip()
                    else:
                        finalResponse["Result"] = "Please provide valid searchpost string"
                        return Response(finalResponse, status=status.HTTP_200_OK)
               
                else:
                    statusId = " AND icd.statusid IN ("+str(actStatusList)+")"
            if 'statusid' in queryString:
                stids = queryString['statusid'].replace("(","")
                stids = stids.replace(")","")
                statusId = " AND icd.statusid IN ("+str(stids)+")"
            if 'devicetypeid' in  queryString:
                deviceTypeId = queryString['devicetypeid'].strip()
            if 'ticketids' in  queryString:
                ticketids = queryString['ticketids'].strip()
            #checking autoClosureType
            if 'autoCloseType' in queryString:
                autoCloseType = queryString['autoCloseType']
                extQry = " AND "+str(autoCloseType)+" = 1 "
                
            ticketResp = commMM.ticketData(subject, deviceTypeId, statusId,ticketids)
            #ntsClientData = commMM.ntsClientData()
            finalResponse = {}
            finalResponse["Result"] = []
            uptimeDict = []
            temp = []
            count = 0
            checkPostCount = -1
            for tkData in ticketResp:
                count +=1
                clientId = str(tkData['clientId']).strip()
                mspId = str(tkData['mspId']).strip()
                tickeId = str(tkData['ticketId']).strip() 
                filterResp = ticketValidation(clientId)
                ##################
                validateC = -1
                validateM = -1
                #####################
                validateC = commMM.checkClientId(clientId,subject)
                #validateM = commMM.checkMspId(mspId,extQry)
                checkTkt = commMM.checkTktId(tickeId)
                checkPost = 0
                #if str(mspId) == '2589':
                if int(postFlag) != 0 :
                    checkPost = commMM.checkTktPost(tickeId, postsub)
                    checkPostCount = checkPost[0]['count']
                if checkPostCount == 0:
                    pass
                elif checkTkt > 0:
                    pass
                elif validateC > 0:
                    temp.append(tkData)
                '''
                elif validateM > 0:
                    pass
                else:
                    temp.append(tkData)
                '''
            if len(temp) > 0:
                finalResponse["Result"] = temp
            else :
                finalResponse["Result"] = "No Records Found"
            return Response(finalResponse, status=status.HTTP_200_OK)
            #return Response(finalResponse)
    except Exception as e:
        commonMethods = CommonMethods()
        resp = commonMethods.postRequest(str(e),"TicketMetricName.py and TicketMetricModel.py")
        return Response(str(e), status=status.HTTP_500_INTERNAL_SERVER_ERROR)
#filtering tickets for client 
def ticketValidation(clientId):
    logger.info("In ticketValidation  method in TicketMetric view")
    return clientId