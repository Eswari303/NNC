from django.shortcuts import render
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
import datetime as dt
from datetime import datetime
import time
import json
from django.http import HttpResponse
from apps.ticketing.models.TicketModels import TicketModel
from apps.ticketing.models.SwattachmentchunksModel import SwattachmentchunkMehtods
#from boto.ec2.autoscale.request import Request
from NNCPortal.commonMethodsNEOS import CommonMethods
from NNCPortal import QueryConfig
import logging
logger = logging.getLogger(__name__)
ticObj = TicketModel()
attchChunks = SwattachmentchunkMehtods()
commMM = CommonMethods()
# Create your views here.
@api_view(['GET', 'POST'])
def patCliInventoryDetails(request,clientId):
    logger.info("In patCliInventoryDetails method in TicketView")
    finalRes = {}
    count = 0
    startDate = datetime.now()
    endDate = startDate - dt.timedelta(days=30)
    sdate = time.mktime(startDate.timetuple())
    edate = time.mktime(endDate.timetuple())
    finalRes['response'] = {}
    try:
        #totalOpenTickets = ticObj.getTotalOpenTickets(partnerId,clientId)
        #finalRes['Result']['totalOpenTickets'] = totalOpenTickets
        #totalClosedTickets = ticObj.getTotalClosedTickets(partnerId,edate,clientId)
        #finalRes['Result']['totalClosedTickets'] = totalClosedTickets
        inventoryDetails = ticObj.getInventoryDetails(clientId)
        finalRes['response']['inventoryDetails'] = inventoryDetails
        ''' Gettin devices information by dev type'''
        for set in finalRes['response']['inventoryDetails']:
            set ['list']=ticObj.getDevicesInfo(clientId,set['type'].strip())
        inventoryByOs = ticObj.getInventoryByOs(clientId)
        for k,index in enumerate(inventoryByOs):
            if index["os"] == "" or index["os"] == None:
                count +=  1
        for k,index in enumerate(inventoryByOs):
            if index["os"] == "" or index["os"] == None:
                index.pop("os")
                index.pop("osCount")
        res = {}
        if count:
            res["os"] = "Others"
            res["osCount"] = count
        inventoryByOs = [x for x in inventoryByOs if x]
        inventoryByOs.append(res)
        finalRes['response']['inventoryByOs'] = inventoryByOs 
        
        """
        createdTickets = ticObj.getCrtdTkts(partnerId,clientId, edate)
        finalRes['Result']['lastMonthCreatedTickets'] = createdTickets
        closedTickets = ticObj.getClosedTkts(partnerId,clientId, edate)
        finalRes['Result']['lastMonthClosedTickets'] = closedTickets
        """
        ''' Getting Today created tickets '''
        endDateToday = startDate - dt.timedelta(days=1)
        edatetoday = time.mktime(endDateToday.timetuple())
        #todayCreatedTickets = ticObj.getTodayCreatedTickets(sdate,edatetoday,clientId,partnerId)
        #finalRes['Result']['createdToday'] = todayCreatedTickets[0]["count"]
        
        #res = np.asarray(finalRes)
        finalRes['status']="success"
        return Response(finalRes, status=status.HTTP_200_OK)
    except Exception as e:
        finalRes["status"] = "failed"
        finalRes["response"] = str(e)  
        return Response(finalRes, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
@api_view(['GET', 'POST'])
def openTicketsDetils(request,clientId):
    logger.info("In openTicketsDetils method in TicketView")
    finalRes = {}
    finalRes['response']={}
    try:
        totalOpenTickets = ticObj.getTotalOpenTickets(clientId)
        finalRes["status"] = "success"
        startDate = datetime.now()
        sdate = time.mktime(startDate.timetuple())
        endDateToday = startDate - dt.timedelta(days=1)
        edatetoday = time.mktime(endDateToday.timetuple())
        todayCreatedTickets = ticObj.getTodayCreatedTickets(clientId)
        finalRes['response']['createdToday'] = todayCreatedTickets
        finalRes['response']['totalOpenTickets'] = totalOpenTickets
        for set in finalRes['response']['totalOpenTickets']:
            if set['priority'] == 'Critical':
                set['tktList'] = ticObj.getopenTksList(clientId,8)
            if set['priority'] == 'High':
                set['tktList'] = ticObj.getopenTksList(clientId,9)
            if set['priority'] == 'Medium':
                set['tktList'] = ticObj.getopenTksList(clientId,10)
            if set['priority'] == 'Low':
                set['tktList'] = ticObj.getopenTksList(clientId,11)
        
        for set in finalRes['response']['createdToday']:
            if set['priority'] == 'Critical':
                set['tktList'] = ticObj.getopenTksListToday(clientId,8)
            if set['priority'] == 'High':
                set['tktList'] = ticObj.getopenTksListToday(clientId,9)
            if set['priority'] == 'Medium':
                set['tktList'] = ticObj.getopenTksListToday(clientId,10)
            if set['priority'] == 'Low':
                set['tktList'] = ticObj.getopenTksListToday(clientId,11)
        
        print finalRes
        return Response(finalRes, status=status.HTTP_200_OK)
    
    except Exception as e:
        finalRes["status"] = "failed"
        finalRes["response"] = str(e)  
        print str(e)
        return Response(finalRes, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    

@api_view(['GET', 'POST'])
def closedTicketsDetils(request,clientId):
    logger.info("In closedTicketsDetils method in TicketView")
    finalRes = {}
    finalRes['response']={}
    startDate = datetime.now()
    endDate = startDate - dt.timedelta(days=30)
    sdate = time.mktime(startDate.timetuple())
    edate = time.mktime(endDate.timetuple())
    try:
        totalClosedTickets = ticObj.getTotalClosedTickets(clientId)
        
        finalRes["status"] = "success"
        startDate = datetime.now()
        sdate = time.mktime(startDate.timetuple())
        endDateToday = startDate - dt.timedelta(days=1)
        edatetoday = time.mktime(endDateToday.timetuple())
        finalRes['response']['totalClosedTickets'] = totalClosedTickets
        for set in finalRes['response']['totalClosedTickets']:
            if set['priority'] == 'Critical':
                set['tktList'] = ticObj.getclosedTksList(clientId,8)
            if set['priority'] == 'High':
                set['tktList'] = ticObj.getclosedTksList(clientId,9)
            if set['priority'] == 'Medium':
                set['tktList'] = ticObj.getclosedTksList(clientId,10)
            if set['priority'] == 'Low':
                set['tktList'] = ticObj.getclosedTksList(clientId,11)
        return Response(finalRes, status=status.HTTP_200_OK)
    except Exception as e:
        finalRes["status"] = "failed"
        finalRes["response"] = str(e)  
        return Response(finalRes, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
@api_view(['GET', 'POST'])
def getTicketDetailsPartnerLevel(Request,partnerId,priorityId,status):
    logger.info("In getTicketDetailsPartnerLevel method in TicketView")
    startDate = datetime.now()
    endDate = startDate - dt.timedelta(days=30)
    edate = time.mktime(endDate.timetuple())
    finalResult = ticObj.getPatCliTickets(partnerId,priorityId,edate,status)
    return Response(finalResult)
@api_view(['GET', 'POST'])
def getTicketDetailsClientLevel(Request,partnerId,clientId,priorityId,status):
    logger.info("In getTicketDetailsClientLevel method in TicketView")
    startDate = datetime.now()
    endDate = startDate - dt.timedelta(days=30)
    edate = time.mktime(endDate.timetuple())
    finalResult = ticObj.getPatCliTickets(partnerId,priorityId,edate,status,clientId)
    return Response(finalResult)
@api_view(['GET', 'POST'])
def deviceNoiseData(Request,partnerId,clientId=0):
    logger.info("In deviceNoiseData method in TicketView")
    finalRes = {}
    finalRes['Result'] = {}
    print "client id is ::: ", clientId
    #deviceCount
    deviceCount = ticObj.getDeviceCounts(partnerId, clientId)
    if deviceCount:
        finalRes['Result']['deviceCount'] = deviceCount
    #deviceList
    deviceList = ticObj.getDeviceId(partnerId, clientId)
    if deviceList[0]['deviceIdList']:
        if deviceList[0]['deviceIdList'].endswith(","):
            deviceList[0]['deviceIdList'] = deviceList[0]['deviceIdList'][:-1] + ""
        noiseCount = ticObj.topNoisedevice(partnerId, clientId)
        finalRes['Result']['topNoiseDevices'] = noiseCount
    else:
        finalRes['Result'] = "No records found"
    return Response(finalRes)
@api_view(['GET', 'POST'])  
def noiseDevicePartnerLevel(Request,partnerId,devGroup):
    logger.info("In noiseDevicePartnerLevel method in TicketView")
    finalRes = ticObj.getNoiseDevices(partnerId,devGroup)
    return Response(finalRes)
@api_view(['GET', 'POST'])  
def noiseDeviceClientLevel(Request,partnerId,clientId,devGroup):
    logger.info("In noiseDeviceClientLevel method in TicketView")
    print partnerId,devGroup,clientId
    finalRes = ticObj.getNoiseDevices(partnerId,devGroup,clientId)
    return Response(finalRes)
@api_view(['GET', 'POST'])       
def partnerclienttickets(request,partnerId,clientId=''):
    logger.info("In partnerclienttickets method in TicketView")
    finalRes = {}
    finalRes['Result'] = {}
    startDate = datetime.now()
    endDate = startDate - dt.timedelta(days=30)
    sdate = time.mktime(startDate.timetuple())
    edate = time.mktime(endDate.timetuple())
    ''' Getting active tickets '''
    actTicekts = ticObj.getActiveTickets(sdate,edate,clientId,partnerId)
    actTicekts = commMM.processDictData(actTicekts)
    finalRes['Result']['active'] = actTicekts
    ''' Getting closed tickets '''
    closedTicekts = ticObj.getClosedTickets(sdate,edate,clientId,partnerId)
    closedTicekts = commMM.processDictData(closedTicekts)
    finalRes['Result']['closed'] = closedTicekts
    ''' Getting scheduled tickets '''
    schdTicekts = ticObj.getScheduledTickets(sdate,edate,clientId,partnerId)
    schdTicekts = commMM.processDictData(schdTicekts)
    finalRes['Result']['scheduled'] = schdTicekts
    ''' Getting last 30 days tickets '''
    pastOneMonthTickets = ticObj.getPastOneMonthCreatedTickets(sdate,edate,clientId,partnerId)
    finalRes['Result']['pastOneMonthTickets'] = pastOneMonthTickets
    ''' Getting Today created tickets '''
    endDateToday = startDate - dt.timedelta(days=1)
    edatetoday = time.mktime(endDateToday.timetuple())
    todayCreatedTickets = ticObj.getTodayCreatedTickets(sdate,edatetoday,clientId,partnerId)
    finalRes['Result']['createdToday'] = todayCreatedTickets[0]["count"]
    ''' Getting Today closed tickets '''
    todayClosedTickets = ticObj.getClosedToday(sdate,edatetoday,clientId,partnerId)
    finalRes['Result']['closedToday'] = todayClosedTickets[0]["count"]
    ''' Getting hmspWfci '''
    htmpWifi = ticObj.getHmspWfci(sdate,edate,clientId,partnerId)
    finalRes['Result']['hmspWfci'] = htmpWifi
    ''' Getting count of hmspWfci today'''
    htmpWifi = ticObj.getHmspWfciCount(sdate,edatetoday,clientId,partnerId)
    finalRes['Result']['hmspWfciCount'] = htmpWifi[0]["count"]
    ''' Getting Device count '''
    deviceCount = ticObj.getDeviceCount(clientId,partnerId)
    finalRes['Result']['deviceCount'] = deviceCount[0]["count"]
    ''' Getting Active server or network '''
    actSrvNetw = ticObj.getActiveServer(sdate,edate,clientId,partnerId)
    for index in actSrvNetw:
        if index["priorityid"] == 8 :
            index['priority'] = "Critical"
        if index["priorityid"] == 9 :
            index['priority'] = "High"   
        if index["priorityid"] == 10 :
            index['priority'] = "Medium"       
        if index["priorityid"] == 11 :
            index['priority'] = "Low"           
    finalRes['Result']['serverOrNetwork'] = actSrvNetw
    return Response(finalRes)
@api_view(['GET', 'POST'])       
def attachments(request, ticketpostId, attachmentId):
    logger.info("In attachments method in TicketView")
    print "Inside attachments APIcall"
    finalRes = {}
    res = attchChunks.testQryCluster()
    print "Res is isisisisisisis", res
    #finalResponse["Result"] =  res
    my_data = res
    response = HttpResponse(my_data, content_type='application/force-download')
    response['Content-Disposition'] = 'attachment; filename="foo.png"'
    return response
    #return Response(finalResponse)
@api_view(['GET', 'POST'])  
def clientTicketDetails(request, partnerId, clientId):
    logger.info("In clientTicketDetails method in TicketView")
    finalRes = {}
    res = {}
    option = ''
    print "Request Query params information is ::::",request.query_params
    try :
        if 'option' in request.query_params:
            queryOption = request.query_params["option"]
        '''validate partner and client '''
        validateMsp = ticObj.validatePartnerAndClient(clientId,partnerId)
        if validateMsp[0]["count"] == 0:
            finalRes["Result"] = "Please provide valid partner client details"
            return Response(finalRes,status=status.HTTP_400_BAD_REQUEST)
        if queryOption == 'clientCurrentMonthTickets' : 
            res = clientCurrentMonthTickets(queryOption,partnerId, clientId)
        if queryOption == 'todayClientTickets' :
            res = todayClientTickets(queryOption,partnerId, clientId)           
        finalRes["Result"] = res        
        return Response(finalRes, status=status.HTTP_200_OK)
    except Exception as e:
        finalRes["Result"] = str(e) 
        return Response(finalRes, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
@api_view(['GET', 'POST'])  
def clientCurrMonthTkts(request,clientId):
    logger.info("In clientCurrMonthTkts method in TicketView")
    finalRes = {}
    res = {}
    queryOption='clientCurrentMonthTickets'
    try:
        '''validate partner and client '''
        validateMsp = ticObj.validatePartnerAndClient(clientId)
        if validateMsp[0]["count"] == 0:
            finalRes["status"] = "failed"
            finalRes["response"] = "Please provide valid partner client details"
            return Response(finalRes,status=status.HTTP_400_BAD_REQUEST)
        res = clientCurrentMonthTickets(queryOption,clientId)
        prioritySet = ticObj.getActTktCountByPriority(clientId)
        ''' Preparing Priority set info'''
        prioritySet['active']= preparingPriorityData(prioritySet['active'])
        prioritySet['inactive'] =preparingPriorityData(prioritySet['inactive'])
        prioritySet['closed'] =preparingPriorityData(prioritySet['closed'])
        prioritySet['scheduled']= preparingPriorityData(prioritySet['scheduled'])
        prioritySet['created']= preparingPriorityData(prioritySet['created'])
        finalRes["response"] = res 
        finalRes["status"] = "success"
        finalRes["response"]['active']['priWise'] = prioritySet['active']
        finalRes["response"]['inactive']['priWise'] = prioritySet['inactive']
        finalRes["response"]['closed']['priWise'] = prioritySet['closed']
        finalRes["response"]['scheduled']['priWise'] = prioritySet['scheduled']
        finalRes["response"]['created']['priWise'] = prioritySet['created']
        #finalRes["priority"] = prioritySet
        return Response(finalRes, status=status.HTTP_200_OK)  
    except Exception as e:
        finalRes["status"] = "failed"
        finalRes["response"] = str(e) 
        return Response(finalRes, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
@api_view(['GET', 'POST'])  
def clienttodayTkts(request, clientId):
    logger.info("In clienttodayTkts method in TicketView")
    finalRes = {}
    res = {}
    queryOption='todayClientTickets'
    try:
        '''validate partner and client '''
        validateMsp = ticObj.validatePartnerAndClient(clientId)
        if validateMsp[0]["count"] == 0:
            finalRes["status"] = "failed"
            finalRes["response"] = "Please provide valid partner client details"
            return Response(finalRes,status=status.HTTP_400_BAD_REQUEST)
        res = todayClientTickets(queryOption,clientId)
        finalRes["status"] = "success"
        finalRes["response"] = res        
        return Response(finalRes, status=status.HTTP_200_OK)  
    except Exception as e:
        finalRes["status"] = "failed"
        finalRes["response"] = str(e)  
        return Response(finalRes, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
def createJsonData(queryString):
    ''' This method will convert the requested queryString into Json format'''
    logger.info("In createJsonData method in TicketView")
    str = []
    str = queryString.split('+')
    querySting_json = {}
    for var in str:
        data = var.split(':')
        querySting_json[data[0]] = data[1]
    return querySting_json 

def clientCurrentMonthTickets(queryOption,clientId):
    logger.info("In clientCurrentMonthTickets method in TicketView")
    query = QueryConfig.clientTickets[queryOption]
    res = {}
    finalRes={}
    if query == '':
        finalRes["Result"] = "Please provide valid option"
        return Response(finalRes,status=status.HTTP_400_BAD_REQUEST)
    query += str(clientId)
    resp = ticObj.executeQry(query) 
    if resp[0]["active"] != 0:
        res["active"] = {}
        res["active"]["count"] = int(resp[0]["active"])
        actQry = QueryConfig.clientTickets["activeCurrentMonthTickets"]
        actQry += str(clientId)
        actTkts = ticObj.executeQry(actQry)
        res["active"]["list"] = {}
        res["active"]["list"] = actTkts
    else:
        res["active"]={}
    if resp[0]["scheduled"] != 0:
        res["scheduled"] = {}
        res["scheduled"]["count"] = int(resp[0]["scheduled"])
        schQry = QueryConfig.clientTickets["scheduledCurrentMonthTickets"]
        schQry += str(clientId)
        schTkts = ticObj.executeQry(schQry)
        res["scheduled"]["list"] = {}
        res["scheduled"]["list"] = schTkts
    else:
        res["scheduled"]={}
        
    if resp[0]["inactive"] != 0:
        res["inactive"] = {}
        res["inactive"]["count"] = int(resp[0]["inactive"])
        inActQry = QueryConfig.clientTickets["inactiveCurrentMonthTickets"]
        inActQry += str(clientId)
        inActTkts = ticObj.executeQry(inActQry)
        res["inactive"]["list"] = {}
        res["inactive"]["list"] = inActTkts
    else:
        res["inactive"]={}
        
    if resp[0]["closed"] != 0:
        res["closed"] = {}
        res["closed"]["count"] = int(resp[0]["closed"])
        closedQry = QueryConfig.clientTickets["closedCurrentMonthTickets"]
        closedQry += str(clientId)
        clsTkts = ticObj.executeQry(closedQry)
        res["closed"]["list"] = {}
        res["closed"]["list"] = clsTkts
    else:
        res["closed"]={}
        
    if resp[0]["created"] != 0:
        res["created"] = {}
        res["created"]["count"] = int(resp[0]["created"])
        createdQry = QueryConfig.clientTickets["createdCurrentMonthTickets"]
        createdQry += str(clientId)
        createdTkts = ticObj.executeQry(createdQry)
        res["created"]["list"] = {}
        res["created"]["list"] = createdTkts
    else:
        res["created"]={}
    return res

def todayClientTickets(queryOption, clientId):
    logger.info("In todayClientTickets method in TicketView")
    res = {}
    res["ticketsClosedToday"]={}
    res["ticketsCreatedToday"]={}
    res["ticketsWithHMSP/WFCIToday"]={}
    #tickets created today
    createdQry = QueryConfig.clientTickets['todayCreatedTickets'] %clientId
    createdTodyTkts = ticObj.executeQry(createdQry)    
    #tickets closed today
    clsoedTodayQry = QueryConfig.clientTickets['todayClosedTickets'] %clientId
    closedTodyTkts = ticObj.executeQry(clsoedTodayQry)
    #ticket with HMSP/WFCI
    hmspQry = QueryConfig.clientTickets['todayhmspwfciTickets'] %clientId
    hmspTodyTkts = ticObj.executeQry(hmspQry)
    #device count
    deviceQry = QueryConfig.clientTickets['deviceCount'] %clientId
    deviceCount = ticObj.executeQry(deviceQry)
    closedTodyTkts=preparingPriorityData(closedTodyTkts)
    createdTodyTkts=preparingPriorityData(createdTodyTkts)
    hmspTodyTkts=preparingPriorityData(hmspTodyTkts)
    
    res["ticketsClosedToday"]['priWise'] = closedTodyTkts
    res["ticketsCreatedToday"]['priWise'] = createdTodyTkts
    res["ticketsWithHMSP/WFCIToday"]['priWise'] = hmspTodyTkts
    res["activeDeviceCount"] = deviceCount[0]['count']
    
    ''' getting tickets count and '''
    resp=ticObj.getCretdTodayTktsCount(clientId)
    res["ticketsCreatedToday"]['count']=resp[0]['count']
    resp=ticObj.getClosedTodayTktsCount(clientId)
    res["ticketsClosedToday"]['count']=resp[0]['count']
    resp=ticObj.getHMSPWFCITodayTodayTktsCount(clientId)
    res["ticketsWithHMSP/WFCIToday"]['count']=resp[0]['count']
    
    '''getting Tkt Info'''
    TktInfo = ticObj.getTodayTktsList(clientId)
    res["ticketsCreatedToday"]['list']=TktInfo['created']
    res["ticketsClosedToday"]['list']=TktInfo['closed']
    res["ticketsWithHMSP/WFCIToday"]['list']=TktInfo['hmsp']
    return res 

def preparingPriorityData(priorityset):
    logger.info("In preparingPriorityData method in TicketView")
    finalSet =[]
    hflag=0
    lflag=0
    cflag=0
    nflag=0
    mflag=0
    for set in priorityset:
        tmp ={}
        tmp[set['priority']] = set['count']
        finalSet.append(tmp)
    for set in finalSet:
        if 'High' in set:
            hflag = 1
        elif 'Critical' in set:
            cflag = 1
        elif 'Low' in set:
            lflag = 1
        elif 'Normal' in set:
            nflag = 1
        elif 'Medium' in set:
            mflag =1
    if nflag == 0:
         tmp = {'Normal': 0}
         finalSet.append(tmp)
    if cflag == 0:
         tmp = {'Critical': 0}
         finalSet.append(tmp)
    if lflag == 0:
         tmp = {'Low': 0}
         finalSet.append(tmp)
    if hflag == 0:
         tmp = {'High': 0}
         finalSet.append(tmp)
    if mflag == 0:
         tmp = {'Medium': 0}
         finalSet.append(tmp)
    return finalSet

@api_view(['GET', 'POST'])
def demoView(request,cid,tktstatusId):
    print cid,tktstatusId
    resData =ticObj.getP0Tickets(cid,tktstatusId)
    finalRes={}
    chartData=[]
    dataPoints=[]
    headderKeys=resData[0].keys()
    headderKeys.remove('statusid')
    chartData.append(headderKeys)
    for res in resData :
        statusId=''
        statusId=res['statusid']
        del res['statusid']
        eachList=res.values()
        orderRes=chartData.append(eachList)
        dataPoints.append(statusId)
    finalRes['chartData']=chartData
    finalRes['dataPoints']=dataPoints
    overFinalResult = {'Result':finalRes}
    
    return Response(overFinalResult, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
def p0TitDetails(request,cid,statusId):
    print ticObj.NEOSDivaMapping()
    data = ticObj.getP0TicketsInformation(cid,statusId)
    finalresults = {'Result':data}
    return Response(finalresults, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
def hmspwfcicounts(request,cId):

    statusNmae =  request.GET.get('statusname',False);
    
    statusList = ticObj.ticketStatuses();
    data = {}
    if statusNmae !=False:
        priortys ={}
        conditions = ''
        data = ticObj.getActiveStatus(cId,statusList[statusNmae],conditions)
        for i in data:
            #priortys[i['']] = i['']
            for k, value in i.iteritems():
              priortys[k] = int(value)
        
    finalresults = {'Result':priortys}
    return Response(finalresults, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
def TicketDetails(request):
    print ticObj.NEOSDivaMapping()
    data = ticObj.getTicketsInformation(request)
    finalresults = {'Result':data}
    return Response(finalresults, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
def ticketCountByPriority(request,cid):
    print ticObj.NEOSDivaMapping()
    data = ticObj.ticketCountByPriorityQuery(cid)
    finalresults = {'Result':data}
    return Response(finalresults, status=status.HTTP_200_OK)

@api_view(['GET', 'POST'])
def topFiveDevice(request,cId):
    print ticObj.NEOSDivaMapping()
    try:
        data = ticObj.topFiveDeviceQuery(cId)
        finalresults = {'Result':data}
        return Response(finalresults, status=status.HTTP_200_OK)
    except Exception as e:
        finalRes={}
        finalRes["status"] = "failed"
        finalRes["Result"] = str(e) 
        return Response(finalRes, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    
@api_view(['GET', 'POST'])
def genericAPI(request):
    post = request.GET
    mappingDict = ticObj.NEOSDivaMapping()
    resData=[]
    overFinalResult={}
    print mappingDict
    try:
        
        if  str(post['option'])=='CriticalActiveStatuses':
            tktstatusId =",".join(str(e) for e in mappingDict['ActiveStatuses']) 
            resData =ticObj.getP0Tickets(post['cid'],tktstatusId)
            if len(resData)>0:
                finalRes={}
                chartData=[]
                dataPoints=[]
                headderKeys=resData[0].keys()
                headderKeys.remove('statusid')
                chartData.append(headderKeys)
                for res in resData :
                    statusId=''
                    statusId=res['status']
                    del res['statusid']
                    eachList=res.values()
                    orderRes=chartData.append(eachList)
                    dataPoints.append(statusId)
                finalRes['chartData']=chartData
                finalRes['dataPoints']=dataPoints
                overFinalResult = {'Result':finalRes}
            else:
                finalRes={}
                finalRes['chartData']=[]
                finalRes['dataPoints']=[]
                overFinalResult = {'Result':finalRes}
        if  str(post['option'])=='TopFiveDevice':
            data = ticObj.topFiveDeviceQuery(post['cid'])
            overFinalResult = {'Result':data}
        if  str(post['option'])=='TicketCountByPriority':
            data = ticObj.ticketCountByPriorityQuery(post['cid'],','.join(str(e) for e in mappingDict['ActiveStatuses']))
            overFinalResult = {'Result':data}
        if  str(post['option'])=='TicketDetails':
            query = ''
            post1 = request.GET.copy() 
            del post1['option']
            if post.has_key('statuses'):
                del post1['statuses']
                if post['statuses'] == 'ActiveStatuses':
                    post1['statusid'] =",".join(str(e) for e in mappingDict['ActiveStatuses']) 
                else:
                    #dbStatuses = ticObj.ticketStatuses()
                    from NNCPortal.configfile import ConfigManager
                    configobj = ConfigManager()
                    import ast
                    dbStatuses = configobj.getCommConfigValue(configobj.Statuses)
                    dbStatuses = ast.literal_eval(dbStatuses) 
                    givenStusesIds=[]
                    statuses = post.getlist('statuses')
                    statuses = statuses[0].split(',')
                    for stats in statuses:
                        if stats !='' and stats != None:
                            if dbStatuses.has_key(str(stats)):
                                givenStusesIds.append(dbStatuses[str(stats)])  
                    if len(givenStusesIds)>0:
                        post1['statusid']= ",".join(str(e) for e in givenStusesIds)
                        query += ",".join(str(e) for e in givenStusesIds)                      
            if post.has_key('priorities'):
                del post1['priorities']
                #dbPriorities = ticObj.ticketPriority()
                from NNCPortal.configfile import ConfigManager
                configobj = ConfigManager()
                import ast
                dbPriorities = configobj.getCommConfigValue(configobj.Priorities)
                dbPriorities = ast.literal_eval(dbPriorities) 
                givenPriorityIds=[]
                priorities = post.getlist('priorities')
                priorities = priorities[0].split(',')
                for priority in priorities:
                    if priority !='' and priority != None:
                        if dbPriorities.has_key(str(priority)):
                            givenPriorityIds.append(dbPriorities[str(priority)]) 
                if len(givenPriorityIds)>0:
                    post1['priorityid']= ",".join(str(e) for e in givenPriorityIds)
                    
            if post.has_key('devices'):
                del post1['devices']
                dbDeviceNames=ticObj.deviceDetails(post['cid'])
                print dbDeviceNames
                givenDeviceIds=[]
                devices = post.getlist('devices')
                devices = devices[0].split(',')
                for device in devices:
                    if device !='' and device != None:
                        if dbDeviceNames.has_key(str(device)):
                            givenDeviceIds.append(dbDeviceNames[str(device)]) 
                if len(givenDeviceIds)>0:
                    post1['did']= ",".join(str(e) for e in givenDeviceIds)
                
            if post.has_key('fromDate') and post.has_key('toDate'):
                del post1['fromDate']
                del post1['toDate']
                post1['created_dt']=[str(post['fromDate']),str(post['toDate'])]
                
            data = ticObj.getTicketsInformation(post1)
            overFinalResult = {'Result':data}
            
        return Response(overFinalResult, status=status.HTTP_200_OK)
 
    except Exception as e:
        finalRes={}
        finalRes["status"] = "failed"
        finalRes["Result"] = str(e) 
        return Response(finalRes, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET', 'POST'])
def activeTicketsByPriorty(request,cid):
 
    mappDict = ticObj.NEOSDivaMapping()
    tktstatusId =",".join(str(e) for e in mappDict['ActiveStatuses'])
    try:
        conditions = " and sccalertid !=0 "
        ticketInformation = ticObj.getActiveStatus(cid,tktstatusId,conditions)
        priortys ={}
        for i in ticketInformation:
            for k, value in i.iteritems():
                priortys[k] = int(value)
        finalresults = {'Result':priortys}
        return Response(finalresults, status=status.HTTP_200_OK)
    except Exception as e:
        finalRes={}
        finalRes["status"] = "failed"
        finalRes["Result"] = str(e) 
        return Response(finalRes, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


def convertTimeZone(psttime):
    dateAndTime = psttime[0:-5]
    timeZone = psttime[-5:]
    convertTimeZone = timeZone[0:3] + str(':') + timeZone[-2:]
    timeZoneFromDb  = ticObj.getTimeZone(convertTimeZone)
    dateWOrk = timeZoneFromDb[0]['timeZone'] if len(timeZoneFromDb) >0  else 0
    convetedDateAndTime = dateAndTime.replace("T",' ');
    return "CONVERT_TZ('"+str(convetedDateAndTime)+"','"+str(dateWOrk )+"','UTC')"

def convertTimeZones(psttime):
    dateAndTime = psttime[0:-5]
    timeZone = psttime[-5:]
    convertTimeZone = timeZone[0:3] + str(':') + timeZone[-2:]
    timeZoneFromDb  = ticObj.getTimeZone(convertTimeZone)
    dateWOrk = timeZoneFromDb[0]['timeZone'] if len(timeZoneFromDb) >0  else 0
    convetedDateAndTime = dateAndTime.replace("T",' ');
    dates = {'convetedDateAndTime':convetedDateAndTime,'dateWOrk':dateWOrk}
    return dates

def scheduleConvertTimeZone(psttime):
    dateAndTime = psttime[0:-5]
    timeZone = psttime[-5:]
    convertTimeZone = timeZone[0:3] + str(':') + timeZone[-2:]
    timeZoneFromDb  = ticObj.getTimeZone(convertTimeZone)
    dateWOrk = timeZoneFromDb[0]['timeZone'] if len(timeZoneFromDb) >0  else 0
    convetedDateAndTime = dateAndTime.replace("T",' ');
    if convertTimeZone !='-08:00':
        return "CONVERT_TZ('"+str(convetedDateAndTime)+"','"+str(dateWOrk )+"','America/Los_Angeles')"
    else:
        return "'"+str(convetedDateAndTime)+"'"
    
@api_view(['GET', 'POST'])
def operationalMetricTicketsCount(request,cid):
 
    fromIsoDateTime =  convertTimeZone(request.GET.get('fromIsoDateTime',False))
    toIsoDateTime =  convertTimeZone(request.GET.get('toIsoDateTime',False))
    requestedApi  = request.GET.get('requestApi',False)
    print requestedApi
    dates =[]
    statusIds = priorty = tag  = False
    finalresults = {}
    queryCondtions = ''
    try:
        if requestedApi == 'scheduledTicketCount':
            statusIds = '16'
            fromIsoDateTime =  scheduleConvertTimeZone(request.GET.get('fromIsoDateTime',False))
            toIsoDateTime =  scheduleConvertTimeZone(request.GET.get('toIsoDateTime',False))
            dates = [fromIsoDateTime,toIsoDateTime]
            tag ="Scheduled - Task"
            data = ticObj.getScheduledTicket(cid,statusIds,dates,tag)
            finalresults = {'result':data[0]}
        
        if requestedApi == 'closedTicketCount':
            statusIds = '3'
            priorty = '8,9,10,11'
            dates = [fromIsoDateTime,toIsoDateTime]
            data = ticObj.operationalMetricCounts(statusIds,priorty,cid,dates,tag,queryCondtions)
            finalresults = {'result':data}
        
        if requestedApi == 'createdTicketCount':
            priorty = '8,9,10,11'
            dates = [fromIsoDateTime,toIsoDateTime]
            data = ticObj.operationalMetricCounts(statusIds,priorty,cid,dates,tag,queryCondtions)
            finalresults = {'result':data}
            
        if requestedApi == 'serviceRequest':
            priorty = '8,9,10,11'
            statusIds = '1,18,19'
            queryCondtions = ' and sccalertid =0 '
            data = ticObj.operationalMetricCounts(statusIds,priorty,cid,dates,tag,queryCondtions)
            finalresults = {'result':data}
        return Response(finalresults, status=status.HTTP_200_OK)        
    
    except Exception as e:
        finalRes={}
        finalRes["status"] = "failed"
        finalRes["Result"] = str(e) 
        return Response(finalRes, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET', 'POST'])
def ticketsOfWeatherAPI(request,cid):
    try:
        data = ticObj.getWeatherAPI(cid)
        finalresults = {"status":"success",'result':data}
        return Response(finalresults, status=status.HTTP_200_OK)
    except Exception as e:
        finalRes={}
        finalRes["status"] = "failed"
        finalRes["result"] = str(e) 
        return Response(finalRes, status=status.HTTP_500_INTERNAL_SERVER_ERROR)