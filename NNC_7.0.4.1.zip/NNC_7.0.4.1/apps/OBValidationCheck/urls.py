"""
 * This computer program is the confidential information and proprietary trade
 * secret of NetEnrich, Inc. Possessions and use of this program must
 * conform strictly to the license agreement between the user and
 * NetEnrich, Inc., and receipt or possession does not convey any rights
 * to divulge, reproduce, or allow others to use this program without specific
 * written authorization of NetEnrich, Inc.
 * 
 * Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.conf.urls import url
from views import OBValidationCheckView
urlpatterns = [
    url(r'^$',OBValidationCheckView.ALLPartnerClientsView),
    url(r'^report/', OBValidationCheckView.ClientsReportView),
    url(r'^partnerAjax$',OBValidationCheckView.getClientsForPartner),
    url(r'^checkList$',OBValidationCheckView.getGenerateReport),  
    url(r'^countsForm/$',OBValidationCheckView.getCountFormData),  
    url(r'^getTabs$',OBValidationCheckView.getTabs),
    url(r'^getDeviceTypeData$',OBValidationCheckView.getDeviceData),
    url(r'^excelDownload$',OBValidationCheckView.excelDownload),
    url(r'^saveToRepo$',OBValidationCheckView.saveToRepository),
    url(r'^repoExcelDownload$',OBValidationCheckView.repoExcelDownload),
    url(r'^clientCheckPointsExcelDownload$',OBValidationCheckView.clientCheckpointsExcelDownload),
    url(r'^validateCounts$',OBValidationCheckView.getAutoRefreshCount),
    url(r'^partnerReport/',OBValidationCheckView.partnerReport), 
]