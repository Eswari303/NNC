"""
  This computer program is the confidential information and proprietary trade
  secret of NetEnrich, Inc. Possessions and use of this program must
  conform strictly to the license agreement between the user and
  NetEnrich, Inc., and receipt or possession does not convey any rights
  to divulge, reproduce, or allow others to use this program without specific
  written authorization of NetEnrich, Inc.
  
  Copyright  2016 NetEnrich, Inc. All Rights Reserved.
 """
from django.db import connections
from django.core.cache import caches
import math
from NNCPortal.commonMethods import commonMethods
comObj = commonMethods()
mem_cache = caches['memcached']
from django.http import HttpResponseRedirect
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()

class CommonModel(object):
    
    deviceTypeDetails = []
    clientId = None
    
    def __init__(self):
        CommonModel.deviceTypeDetails = []
        
    
    def clientBasedDeviceTypeDetails(self,clientId):
        if CommonModel.clientId == None:
            CommonModel.deviceTypeDetails = []
            CommonModel.clientId = clientId
            #print 'first time'
        elif CommonModel.clientId != clientId:
            CommonModel.deviceTypeDetails = []
            CommonModel.clientId = clientId
            #print 'client changed'
        DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)  
        url = DjnagoApiUrl+'obvalidation/getdevicetypes/'+str(clientId)+'/'
        result = comObj.getAPIResponce(url, 'ticket')
        CommonModel.deviceTypeDetails = result['Result']
        return result['Result']
        
    def deviceTypeNameDetails(self,clientId):
        if CommonModel.clientId == None:
            CommonModel.deviceTypeDetails = []
            CommonModel.clientId = clientId
        elif CommonModel.clientId != clientId:
            CommonModel.deviceTypeDetails = []
            CommonModel.clientId = clientId

        if len(CommonModel.deviceTypeDetails) == 0:
            #print 'data previously not set'
            deviceDetails = self.clientBasedDeviceTypeDetails(clientId)
            CommonModel.deviceTypeDetails = deviceDetails
        else:
            #print 'data already set'
            deviceDetails = CommonModel.deviceTypeDetails
        deviceTypeDetails={}
        for DeviceDt in deviceDetails:
            deviceName = DeviceDt['name']
            tmp = str(DeviceDt['path'])
            if tmp.find('>>') > -1:
                tmp = tmp.split('>>')
                tmp = tmp[0]
                deviceName = deviceName+' ( '+str(tmp)+' )'
            temp = {}
            temp['parentPath'] = DeviceDt['path']
            temp['path'] = str(deviceName)
            temp['name'] = DeviceDt['name']
            temp['devicetype'] = int(DeviceDt['devicetype'])
            deviceTypeDetails[DeviceDt['devicetype']] = temp
        #CommonModel.deviceTypeDetails = deviceTypeDetails
        return deviceTypeDetails
    
    def prepareExcelData(self,titles,data,templateNameFlag,monitorNameFlag):
        countFormData={}
        for k in titles:
            if k == "Device Name":
                countFormData.setdefault('Device Name',str(data['deviceName']).encode('utf-8'))
            if k == "Partner Name":
                countFormData.setdefault('Partner Name',str(data['mspName']).encode('utf-8'))
            if k == "Device IP":
                countFormData.setdefault('Device IP',str(data['device_ip']).encode('utf-8'))
            if k == "Checklist Option":
                countFormData.setdefault('Checklist Option',str(data['checklistoption']).encode('utf-8'))
            if k == "Client Name":
                countFormData.setdefault('Client Name',str(data['clientName']).encode('utf-8'))
            if k == "OS":
                countFormData.setdefault('OS',str(data['os']).encode('utf-8'))
            if k == "Template Name" and templateNameFlag ==1 :
                countFormData.setdefault('Template Name',str(data['templatename']).encode('utf-8'))
            if k == "Monitor Name" and monitorNameFlag == 1:
                countFormData.setdefault('Monitor Name',str(data['monitorname']).encode('utf-8'))
        return countFormData
    
    def checkingAccess(self,request):
        if request.session.has_key('OBValidationCheck_access'):
            if request.session['OBValidationCheck_access'] == 1:
                return True
            else:
                return HttpResponseRedirect('/serviceManagement/')
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
        
    def preparePartnerRepoExcelData(self,titles,data):
        countFormData={}
        percent =  float(data['genteratedClientsCount']) / int(data['totalClientsCount'])
        percent = percent * 100  
        percent = math.floor(percent)
        for k in titles:
            if k == "Partner Name":
                countFormData.setdefault('Partner Name',str(data['mspName']).encode('utf-8'))
            if k == "Total Clients":
                countFormData.setdefault('Total Clients',str(data['totalClientsCount']).encode('utf-8'))
            if k == "Validated Clients":
                countFormData.setdefault('Validated Clients',str(data['genteratedClientsCount']).encode('utf-8'))
            if k == "% Done":
                countFormData.setdefault('% Done',int(percent))
            if k == "Last Client Validation":
                countFormData.setdefault('Last Client Validation',str(data['clientName']).encode('utf-8'))
            if k == "Timestamp (PST)":
                countFormData.setdefault('Timestamp (PST)',str(data['lastRepoSavedDate']).encode('utf-8'))
            
        return countFormData
