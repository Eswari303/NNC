"""
 This computer program is the confidential information and proprietary trade
 secret of NetEnrich, Inc. Possessions and use of this program must
 conform strictly to the license agreement between the user and
 NetEnrich, Inc., and receipt or possession does not convey any rights
 to divulge, reproduce, or allow others to use this program without specific
 written authorization of NetEnrich, Inc.
  
 Copyright  2016 NetEnrich, Inc. All Rights Reserved.
"""
from django.shortcuts import render_to_response,render
from NNCPortal.commonModels.NrStaff import NrStaff
from django.template import RequestContext
import json as simplejson
from django.http import HttpResponse
from django.core.cache import caches
mem_cache = caches['memcached']
from NNCPortal.commonMethods import commonMethods
comObj = commonMethods()
from datetime import datetime
from pytz import timezone
from json import dumps
import pytz
import ast,json
from NNCPortal.commonModels.NrStaff import NrStaff
from NNCPortal.commonModels.Ntsmsps import Ntsmsps
msps_obj = Ntsmsps()
from django.http import HttpResponseRedirect
from NNCPortal.configfile import ConfigManager
configobj = ConfigManager()
from serviceManagement.models.commonModel import CommonServiceModel
servicemodel_obj = CommonServiceModel()
from NNCPortal.commonModels.Ntsmspclients import Ntsmspclients
ntsmspclient_obj = Ntsmspclients()
from apps.OBValidationCheck.models.commonModel import CommonModel
from django.template.loader import render_to_string
obModel = CommonModel()
from django.core.cache import caches
mem_cache = caches['memcached']
import urllib
import xlsxwriter,StringIO
from NNCPortal.commonMethods import commonMethods
comObj = commonMethods()
from random import randint
randomNumber = randint(100, 1000)

def ALLPartnerClientsView(request):
    try:
        accessFlag = obModel.checkingAccess(request)
        if accessFlag == True:
            msps = msps_obj.getMSPSdata()
            #msps = mem_cache.get('msps')
            #if not msps:
                #msps = Ntsmsps.objects.using('ticketRead').only('mspname', 'mspid').filter(status=1).order_by('mspname')
                #mem_cache.set('msps', msps, 86400)
            clients = servicemodel_obj.showPartnerClient()
            #clients = mem_cache.get('clients')
            #if not clients:
                #clients = comMObj.showpatclient()
                #mem_cache.set('clients', clients, 86400)
            DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)
            url = DjnagoApiUrl+'obvalidation/msplevelinfo/'
            partnerDetails = comObj.getAPIResponce(url, 'ticket')
            TotalValidation = 0
            for v in partnerDetails['Result']:
                TotalValidation = v['checkPointsCount']
            return render_to_response('index.html', {'msps': msps,'clients':clients,'allPartnerDetails':partnerDetails['Result'],'randomNumber':randomNumber,'TotalValidation':TotalValidation},context_instance=RequestContext(request))
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in OBValidationCheck - ALLPartnerClientsView -> %s'%str(e))
        return HttpResponseRedirect('/OBValidationCheck/report/')

def ClientsReportView(request):
    try:
        accessFlag = obModel.checkingAccess(request)
        if accessFlag == True:
            msps = msps_obj.getMSPSdata()
            #msps = mem_cache.get('msps')
            #if not msps:
                #msps = Ntsmsps.objects.using('ticketRead').only('mspname', 'mspid').filter(status=1).order_by('mspname')
                #mem_cache.set('msps', msps, 86400)
            clients = {}
            selectedFlag= 0
            clients = servicemodel_obj.showPartnerClient()
            #clients = mem_cache.get('clients')
            #if not clients:
                #clients = comMObj.showpatclient()
                #mem_cache.set('clients', clients, 86400)
            if request.method == "GET":
                partnerId = request.GET.get('partnerId', '')
                clientId = request.GET.get('clientId', '')
                if partnerId and clientId:
                    selectedFlag = 1
            else:
                partnerId = clientId
            return render_to_response('clientReports.html', {'msps': msps,'clients':clients,'clientId':clientId,'partnerId':partnerId,'selectedFlag':selectedFlag,'randomNumber':randomNumber},context_instance=RequestContext(request))
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in OBValidationCheck - ClientsReportView -> %s'%str(e))
        return HttpResponseRedirect('/OBValidationCheck/report/')
    
def getClientsForPartner(request):
    if request.method == "POST":
        search_text = request.POST.getlist('partnerId', '')
        if len(search_text) > 1:
            search_text = ','.join(str(e) for e in search_text)
        else:
            search_text = search_text[0]
    else:
        search_text = ''
    cli = ntsmspclient_obj.getClientsOfPartner(search_text)
    jsonData = simplejson.dumps({'clients': cli})
    return HttpResponse(jsonData, content_type="application/json")
    
def getGenerateReport(request):
    try:
        accessFlag = obModel.checkingAccess(request)
        if accessFlag == True:
            if request.method == "POST":
                preparePaylaod = {}
                preparePaylaod["deviceTypeId"] = request.POST["deviceTypeId"]
                preparePaylaod["mspId"] = request.POST["partnerId"]
                preparePaylaod["clientId"] = request.POST["clientId"]
                preparePaylaod["lastexecutedBy"] = request.session['uId']
                configobj = ConfigManager()
                DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)
                url= DjnagoApiUrl+"obvalidation/obchecklist/"
                result = comObj.getPostResponce(url, preparePaylaod, 'ticket')
                data = json.dumps(result)
                return HttpResponse(data, content_type="application/json")
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in OBValidationCheck - getGenerateReport -> %s'%str(e))
        return HttpResponseRedirect('/OBValidationCheck/report/')

def getCountFormData(request):
    try:
        accessFlag = obModel.checkingAccess(request)
        if accessFlag == True:
            if request.method == "GET":
                post = request.GET
                tmpString = 'option:'+str(post['optionString'])
                queryString = urllib.quote(tmpString);
                DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)
                url= DjnagoApiUrl+"obvalidation/devicesinfo/partner/"+str(post['partnerId'])+"/client/"+str(post['clientId'])+"/checklistid/"+str(post['checklistId'])+"/clientchecklistid/"+str(post['clientCheckListId'])+"/?queryString="+str(queryString)
                result = comObj.getAPIResponce(url, 'ticket')
                print url
                deviceTypeId = int(post['deviceTypeId']);
                countFormData = {}
                count = 1
                title= ''
                templateNameFlag = 0
                monitorNameFlag = 0
                OBDeviceTypeDetails = mem_cache.get('OBDeviceTypeDetails_'+str(post['clientId']))
                if not OBDeviceTypeDetails:
                   OBDeviceTypeDetails =  obModel.deviceTypeNameDetails(post['clientId'])
                   mem_cache.set('OBDeviceTypeDetails_'+str(post['clientId']), OBDeviceTypeDetails, 86400)  
                tabHead = ['Partner Name','Client Name','Device Name','Device IP','OS','Checklist Option']
                if result['Result'] != 'No Records Found':
                    for k1,v1 in result.iteritems():
                        for k,v in v1.iteritems():
                            title= str(OBDeviceTypeDetails[deviceTypeId]['parentPath'])+' >> '+str(k).encode('utf-8')
                            count =1
                            for tmp in v:
                                countFormData[count]={}
                                countFormData[count].setdefault('deviceName',str(tmp['deviceName']).encode('utf-8'))
                                countFormData[count].setdefault('mspName',str(tmp['mspName']).encode('utf-8'))
                                countFormData[count].setdefault('device_ip',str(tmp['device_ip']).encode('utf-8'))
                                countFormData[count].setdefault('checklistoption',str(tmp['checklistoption']).encode('utf-8'))
                                countFormData[count].setdefault('clientName',str(tmp['clientName']).encode('utf-8'))
                                countFormData[count].setdefault('os',str(tmp['os']).encode('utf-8'))
                                countFormData[count].setdefault('mspid',str(tmp['mspid']).encode('utf-8'))
                                countFormData[count].setdefault('clientid',str(tmp['clientid']).encode('utf-8'))
                                countFormData[count].setdefault('deviceId',str(tmp['deviceId']).encode('utf-8'))
                                if 'templatename' in tmp.keys():
                                    if templateNameFlag != 1:
                                        templateNameFlag = 1
                                        tabHead.append('Template Name')
                                    countFormData[count].setdefault('templateName',str(tmp['templatename']).encode('utf-8'))
                                if 'monitorname' in tmp.keys():
                                    if monitorNameFlag != 1:
                                        monitorNameFlag = 1
                                        tabHead.append('Monitor Name')
                                    countFormData[count].setdefault('monitorName',str(tmp['monitorname']).encode('utf-8'))
                                count = count +1
                else:
                    countFormData['result']='No Records Found'
                return render_to_response('countsForm.html',{'countFormData':countFormData,'title':title,'tabHead':tabHead,'templateNameFlag':templateNameFlag,'monitorNameFlag':monitorNameFlag},context_instance=RequestContext(request))
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in OBValidationCheck - getCountFormData -> %s'%str(e))
        
def getTabs(request):
    try: 
        accessFlag = obModel.checkingAccess(request)
        if accessFlag == True:
            data = {}
            if request.method == "POST":
                client_text = request.POST.getlist('clientId', '')
                partner_text = request.POST.getlist('partnerId', '')
                clientId = client_text[0]
                partnerId = partner_text[0]
            deviceTypeDetails=[]
            deviceDetails = obModel.clientBasedDeviceTypeDetails(clientId)
            staffData = comObj.staffDataByCache()
            for DeviceDt in deviceDetails:
                deviceName = DeviceDt['name']
                tmp = str(DeviceDt['path'])
                if tmp.find('>>') > -1:
                    tmp = tmp.split('>>')
                    tmp = tmp[0]
                    deviceName = deviceName+' ( '+str(tmp)+' )'
                temp = {}
                temp['parentPath'] = DeviceDt['path']
                temp['path'] = str(deviceName)
                temp['name'] = DeviceDt['name']
                temp['devicetype'] = int(DeviceDt['devicetype'])
                deviceTypeDetails.append(temp)
            DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)  
            url = DjnagoApiUrl+'obvalidation/savetorepoinfo/partner/'+str(partnerId)+'/client/'+str(clientId)+'/'
            saveToRepoResult = comObj.getAPIResponce(url, 'ticket')
            repoFlag = 0
            tabFlag = 0
            if len(deviceTypeDetails)>0:
                tabFlag = 1
                if saveToRepoResult['Result']['rptGenFlag'] == 1:
                    repoFlag = 1    
            data['tabs'] = render_to_string('clientTabs.html', {'deviceTypes':deviceTypeDetails,'tabFlag':tabFlag})
            swstaffid =  saveToRepoResult['Result']['lastSavedBy']
            lastupdatedby = ''
            if swstaffid:
                lastupdatedby = staffData['swstaffId'][int(swstaffid)]['fullname']
            data['tabFlag'] = tabFlag
            data['repoFlag']= repoFlag
            data['lastRepo'] = 'Last saved on '+str(saveToRepoResult['Result']['lastRepoSavedDate'])
            if lastupdatedby !='':
                data['lastRepo'] += str(' by '+str(lastupdatedby))
            data = json.dumps(data)
            return HttpResponse(data, content_type="application/json")
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in OBValidationCheck - getTabs -> %s'%str(e))
        return HttpResponseRedirect('/OBValidationCheck/report/')
    
def getDeviceData(request):
    if request.method == "POST":
        client_text = request.POST.getlist('clientId', '')
        partner_text = request.POST.getlist('partnerId', '')
        deviceTypeId_text = request.POST.getlist('devicetypeId', '')
        clientId = client_text[0]
        deviceTypeId = deviceTypeId_text[0]
        partnerId = partner_text[0]
        OBDeviceTypeDetails = mem_cache.get('OBDeviceTypeDetails_'+str(clientId))
        if not OBDeviceTypeDetails:
            OBDeviceTypeDetails = obModel.deviceTypeNameDetails(clientId)
            mem_cache.set('OBDeviceTypeDetails_'+str(clientId), OBDeviceTypeDetails, 86400)   
        tempString = 'devicetype:'+str(deviceTypeId)
        queryString = urllib.quote(str(tempString))
        DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)  
        url = DjnagoApiUrl+'obvalidation/partner/'+str(partnerId)+'/client/'+str(clientId)+'/?queryString='+str(queryString)
        deviceAPIDetails = comObj.getAPIResponce(url, 'ticket')
        data ={}
        lastExecutedBy = ''
        onHoldSet = {}
        checkPointsSet = {}
        checkPointsSet[1]={}
        checkPointsSet[0]={}
        generateReportStopFlag = 0
        for k,v in deviceAPIDetails['Result'].iteritems():
            for k1,v1 in v.iteritems():
                if k1 == 'generalInfo':
                    if v1.has_key('lastexecutedby'):
                        if v1['lastexecutedby'] !='' and v1['lastexecutedby'] != None and v1['lastexecutedby'] !='null':
                            try:
                                nrInfo = NrStaff.objects.using('rosterRead').get(id = v1['lastexecutedby'])
                                lastExecutedBy = str(nrInfo.staff_fname)+' '+str(nrInfo.staff_lname)
                            except Exception as e:
                                import logging
                                log  = logging.getLogger('NNCPortal')
                                log.info('')
                                log.exception(' Exception in OBValidationCheck - getDeviceData -> %s'%str(e))
                elif k1 == 'titlesList':
                    for k2,v2 in v1.iteritems():
                        if v2.has_key('status') and v2['status'] == 1:
                            checkPointsSet[0][k2] = {}
                            checkPointsSet[0][k2]=v2
                        else:
                            checkPointsSet[1][k2] = {}
                            checkPointsSet[1][k2]=v2
                            
                        if v2.has_key('executionStatus'):
                            if v2['executionStatus'] == 'inqueue':
                                generateReportStopFlag = 1                   
        context = { 'deviceAPIDetails' : deviceAPIDetails,'devicetypeId': str(deviceTypeId),'parentPath':OBDeviceTypeDetails[int(deviceTypeId)],'apiKeys':deviceAPIDetails['Result'].keys(),'lastExecutedBy':str(lastExecutedBy),'generateReportStopFlag':int(generateReportStopFlag),'checkPointsSet':checkPointsSet }
        data[deviceTypeId] = render_to_string('_deviceTypeTabs.html', context)
        data['obvc'] = OBDeviceTypeDetails
        data = json.dumps(data)
        return HttpResponse(data, content_type="application/json")  
    
def excelDownload(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.method == "GET":
                post = request.GET
                pId = request.GET.getlist('partnerId','')
                clientId = request.GET.getlist('clientId','')
                chcklist =  request.GET.getlist('checklistId','')
                clientChckList = request.GET.getlist('clientCheckListId','')
                deviceTypeId = request.GET.getlist('deviceTypeId','')
                deviceTypeId = int(deviceTypeId[0])
                DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)
                url= DjnagoApiUrl+"obvalidation/devicesinfo/partner/"+str(pId[0])+"/client/"+str(clientId[0])+"/checklistid/"+str(chcklist[0])+"/clientchecklistid/"+str(clientChckList[0])
                result = comObj.getAPIResponce(url, 'ticket')
                countFormData = {}
                title= ''
                OBDeviceTypeDetails = mem_cache.get('OBDeviceTypeDetails_'+str(clientId))
                if not OBDeviceTypeDetails:
                   OBDeviceTypeDetails =  obModel.deviceTypeNameDetails(request.GET.get('clientId'))
                   mem_cache.set('OBDeviceTypeDetails_'+str(clientId), OBDeviceTypeDetails, 86400)
                tabHead = ['Partner Name','Client Name','Device Name','Device IP','OS','Checklist Option']
                output = StringIO.StringIO()
                workbook = xlsxwriter.Workbook(output)
                worksheet = workbook.add_worksheet()
                row = 0
                mainHeading = 0
                templateNameFlag = 0
                monitorNameFlag = 0
                format1 = workbook.add_format({'bold': True, 'bg_color': 'gray','align':'center'})
                format1.set_text_wrap()
                format2 = workbook.add_format({'bold': True, 'bg_color': 'gray','font_color':'white','align':'center'})
                if result['Result'] != 'No Records Found':
                        # tabHead
                    for k1,v1 in result['Result'].iteritems():
                        worksheet.write(row, mainHeading, k1)
                        mainHeading +=1
                        row += 2
                        tj = 0
                        for k,v in v1.iteritems():
                            if v:
                                worksheet.set_column(row, tj, 30)
                                worksheet.write(row, tj, k,format1)
                                row += 1
                                ti = 0
                                for record in v:
                                    if 'templatename' in record.keys():
                                        tabHead.append('Template Name')
                                        break
                                    if 'monitorname' in record.keys():
                                        tabHead.append('Monitor Name')
                                        break
                                for th in tabHead:
                                    worksheet.set_column(row, ti, 30)
                                    worksheet.write(row, ti, th,format2)
                                    ti +=1
                                row += 1
                                for tmp1 in v:
                                    if 'templatename' in tmp1.keys():
                                        if templateNameFlag != 1:
                                            templateNameFlag = 1
                                    if 'monitorname' in tmp1.keys():
                                        if monitorNameFlag != 1:
                                            monitorNameFlag = 1
                                            #tabHead.append('Template Name')
                                    preparedDict = obModel.prepareExcelData(tabHead,tmp1,templateNameFlag,monitorNameFlag)
                                    trc = 0
                                    for th in tabHead:
                                        worksheet.set_column(row, trc, 30)
                                        worksheet.write(row, trc, str(preparedDict[th]))
                                        trc +=1
                                    row += 1
                                row += 1
                else:
                    worksheet.write(0, 0, 'No Records Found')
                
                workbook.close()
                xlsx_data = output.getvalue()
                response = HttpResponse(content_type='application/vnd.ms-excel')
                response['Content-Disposition'] = 'attachment; filename='+'statusCountDeviceData.xlsx'
                response.write(xlsx_data)
                return response
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in OBValidationCheck - excelDownload -> %s'%str(e))
        return HttpResponseRedirect('/OBValidationCheck/') 

def saveToRepository(request):
    try:
        accessFlag = obModel.checkingAccess(request)
        if accessFlag == True:
            if request.method == "POST":
                preparePaylaod = {}
                preparePaylaod["mspid"] = request.POST["partnerId"]
                preparePaylaod["clientid"] = request.POST["clientId"]
                preparePaylaod["lastexecutedby"] = request.session['swstaffId']
                configobj = ConfigManager()
                DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)
                url= DjnagoApiUrl+"obvalidation/savetorepo/"
                result = comObj.getPostResponce(url, preparePaylaod, 'ticket')
                DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)  
                url = DjnagoApiUrl+'obvalidation/savetorepoinfo/partner/'+str(request.POST["partnerId"])+'/client/'+str(request.POST["clientId"])+'/'
                saveToRepoResult = comObj.getAPIResponce(url, 'ticket')
                staffData = comObj.staffDataByCache()
                swstaffid =  saveToRepoResult['Result']['lastSavedBy']
                data={}
                lastupdatedby = ''
                data['lastRepo']  = ''
                if swstaffid:
                    lastupdatedby = staffData['swstaffId'][int(swstaffid)]['fullname']
                if lastupdatedby !='':
                    data['lastRepo'] = 'Last saved on '+str(saveToRepoResult['Result']['lastRepoSavedDate'])
                    data['lastRepo'] += str(' by '+str(lastupdatedby))
                data = json.dumps(data)
                return HttpResponse(data, content_type="application/json")
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in OBValidationCheck - saveToRepository -> %s'%str(e))
        return HttpResponseRedirect('/OBValidationCheck/')

def repoExcelDownload(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.method == "GET":
                post = request.GET
                pIds = request.GET.get('partnerIds','')
                import urlparse
                pIds = urlparse.parse_qs(pIds)
                DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)
                url = DjnagoApiUrl+'obvalidation/msplevelinfo/'
                partnerDetails = comObj.getAPIResponce(url, 'ticket')
                tabHead = ['Partner Name','Total Clients','Validated Clients','% Done','Last Client Validation','Timestamp (PST)']
                output = StringIO.StringIO()
                workbook = xlsxwriter.Workbook(output)
                worksheet = workbook.add_worksheet()
                row = 0
                mainHeading = 0
                if partnerDetails['Result']:
                    format1 = workbook.add_format({'bold': True, 'font_color': 'brown','align':'center'})
                    format1.set_text_wrap()
                    worksheet.set_column(row, mainHeading, format1)
                    worksheet.merge_range(row,mainHeading,row,mainHeading+1,'Total Validated Checks Done Till Date:')
                    worksheet.write(row, mainHeading, 'Total Validated Checks Done Till Date:',format1)
                    mainHeading +=1
                    format2 = workbook.add_format({'bold': True, 'bg_color': 'gray','font_color': 'white','align':'center'})
                    worksheet.write(row, mainHeading+1,len(partnerDetails['Result']),format1)
                    row += 2
                    ti = 0
                    for th in tabHead:
                        worksheet.set_column(row, mainHeading, format2)
                        worksheet.write(row, ti, th,format2)
                        ti +=1
                    row += 1
                    for v1 in partnerDetails['Result']:
                        if pIds:
                            for mspId in pIds['partnerId']:
                                if int(mspId) in v1.values():
                                    preparedDict = obModel.preparePartnerRepoExcelData(tabHead,v1)
                                    trc = 0
                                    for th in tabHead:
                                        worksheet.set_column(row, trc, 30)
                                        worksheet.write(row, trc, str(preparedDict[th]))
                                        trc +=1
                                    row += 1
                        else:
                            preparedDict = obModel.preparePartnerRepoExcelData(tabHead,v1)
                            trc = 0
                            for th in tabHead:
                                worksheet.set_column(row, trc, 30)
                                worksheet.write(row, trc, str(preparedDict[th]))
                                trc +=1
                            row += 1
                else:
                    worksheet.write(0, 0, 'No Records Found')
                
                workbook.close()
                xlsx_data = output.getvalue()
                response = HttpResponse(content_type='application/vnd.ms-excel')
                response['Content-Disposition'] = 'attachment; filename='+'ValidatedParnersReports.xlsx'
                response.write(xlsx_data)
                return response
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in OBValidationCheck - getTabs -> %s'%str(e))
        return HttpResponseRedirect('/OBValidationCheck/') 
    
def clientCheckpointsExcelDownload(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.method == "GET":
                post = request.GET
                partnerId = request.GET.get('partnerId','')
                clientId = request.GET.get('clientId','')
                OBDeviceTypeDetails = mem_cache.get('OBDeviceTypeDetails_'+str(clientId))
                if not OBDeviceTypeDetails:
                    OBDeviceTypeDetails = obModel.deviceTypeNameDetails(clientId)
                    mem_cache.set('OBDeviceTypeDetails_'+str(clientId), OBDeviceTypeDetails, 86400)   
                DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)  
                url = DjnagoApiUrl+'obvalidation/partner/'+str(partnerId)+'/client/'+str(clientId)+"/"
                clientCheckPointsAPIDetails = comObj.getAPIResponce(url, 'ticket')
                finalData = {}
                staffData = comObj.staffDataByCache()
                for deviceTypeId,Details in clientCheckPointsAPIDetails['Result'].iteritems():
                    if Details:
                        if len(Details['generalInfo']) > 1:
                            nrstaffid =  Details['generalInfo']['lastexecutedby']
                            lastupdatedby = ''
                            if nrstaffid and nrstaffid !='':
                                lastupdatedby = staffData['nrstaffId'][int(nrstaffid)]['fullname']
                            tmp = OBDeviceTypeDetails[int(deviceTypeId)]
                            deviceTypeName = str(tmp['parentPath'])
                            deviceTypeName += '['+str(Details['generalInfo']['devicesCount'])+'] ( Last executed on '+str(Details['generalInfo']['lastReportGenDate'])+' by '+lastupdatedby +')'
                            finalData[deviceTypeId] = {}
                            finalData[deviceTypeId]['lastUpdate']= str(deviceTypeName)
                            count =0
                            for k,v in Details['titlesList'].iteritems():
                                if v['status'] != 0:
                                    finalData[deviceTypeId][count]={}
                                    finalData[deviceTypeId][count]['checkPointTitle']={}
                                    finalData[deviceTypeId][count]['checkPointTitle']['checkpoint']=str(k)
                                    if v.has_key('checkListOpt'):
                                        if v['checkListOpt'].has_key('firstSet'):
                                            finalData[deviceTypeId][count]['checkPointTitle']['firstSet']={}
                                            if v['checkListOpt']['firstSet']['count'] != -1:
                                                finalData[deviceTypeId][count]['checkPointTitle']['firstSet']['count']=v['checkListOpt']['firstSet']['count']
                                                finalData[deviceTypeId][count]['checkPointTitle']['firstSet']['checklistoption']=v['checkListOpt']['firstSet']['checklistoption']
                                            else:
                                                finalData[deviceTypeId][count]['checkPointTitle']['firstSet']['count'] = -1
                                                finalData[deviceTypeId][count]['checkPointTitle']['firstSet']['checklistoption']=v['checkListOpt']['firstSet']['checklistoption']
                                        if v['checkListOpt'].has_key('secondSet'):
                                            finalData[deviceTypeId][count]['checkPointTitle']['secondSet']={}
                                            if v['checkListOpt']['secondSet']['count'] != -1:
                                                finalData[deviceTypeId][count]['checkPointTitle']['secondSet']['count']=v['checkListOpt']['secondSet']['count']
                                                finalData[deviceTypeId][count]['checkPointTitle']['secondSet']['checklistoption']=v['checkListOpt']['secondSet']['checklistoption']
                                            else:
                                                finalData[deviceTypeId][count]['checkPointTitle']['secondSet']['count'] = -1
                                                finalData[deviceTypeId][count]['checkPointTitle']['secondSet']['checklistoption']=v['checkListOpt']['secondSet']['checklistoption']
                                        
                                        count = count +1
                tabHead = ['Check Points','1-Status','2-Status']
                output = StringIO.StringIO()
                workbook = xlsxwriter.Workbook(output)
                worksheet = workbook.add_worksheet()
                row = 0
                if finalData:
                    format1 = workbook.add_format({'bold': True, 'font_color': 'brown','align':'center'})
                    format2 = workbook.add_format({'bold': True, 'bg_color': 'gray','font_color': 'white','align':'center'})
                    format1.set_text_wrap()
                    format2.set_text_wrap()
                    
                    for devicetypeID,vv in finalData.iteritems():
                       
                        worksheet.write_string(row, 0,str(vv['lastUpdate']),format2)
                        row += 1
                        ti = 0
                        for th in tabHead:
                            #worksheet.set_column(row, 20, format2)
                            worksheet.set_column('A:A', 75)
                            worksheet.set_column('B:B', 40)
                            worksheet.set_column('C:C', 40)
                            worksheet.write(row, ti, str(th),format1)
                            ti +=1
                        row += 1
                        for chpc, diviceDetails in vv.iteritems():
                            if chpc != 'lastUpdate':
                                mainHeading = 0
                                tmp=''
                                tmp1=''
                                #worksheet.set_column(row, mainHeading, format1)
                                #worksheet.merge_range(row,mainHeading,row,mainHeading,str(diviceDetails['checkPointTitle']['checkpoint']))
                                worksheet.write(row, mainHeading,str(diviceDetails['checkPointTitle']['checkpoint']))
                                mainHeading += 1
                                if diviceDetails['checkPointTitle'].has_key('firstSet'):
                                    if diviceDetails['checkPointTitle']['firstSet'].has_key('count'):
                                        if int(diviceDetails['checkPointTitle']['firstSet']['count'])  != -1:
                                            tmp = '('+str(diviceDetails['checkPointTitle']['firstSet']['count'])+') '+str(diviceDetails['checkPointTitle']['firstSet']['checklistoption'])
                                            worksheet.write(row, mainHeading,str(tmp))
                                            mainHeading += 1
                                        else:
                                            worksheet.write(row, mainHeading,str(diviceDetails['checkPointTitle']['firstSet']['checklistoption']))
                                            mainHeading += 1
                                if diviceDetails['checkPointTitle'].has_key('secondSet'):
                                    if diviceDetails['checkPointTitle']['secondSet'].has_key('count'):
                                        if int(diviceDetails['checkPointTitle']['secondSet']['count'])  != -1:
                                            tmp1 = '('+str(diviceDetails['checkPointTitle']['secondSet']['count'])+') '+str(diviceDetails['checkPointTitle']['secondSet']['checklistoption'])
                                            worksheet.write(row, mainHeading,str(tmp1))
                                            mainHeading += 1
                                        else:
                                            worksheet.write(row, mainHeading,str(diviceDetails['checkPointTitle']['secondSet']['checklistoption']))
                                            mainHeading += 1
                                row += 1
                else:
                    worksheet.write(0, 0, 'No Records Found')
                workbook.close()
                xlsx_data = output.getvalue()
                response = HttpResponse(content_type='application/vnd.ms-excel')
                response['Content-Disposition'] = 'attachment; filename='+'ClientCheckPointsReports.xlsx'
                response.write(xlsx_data)
                return response
        else:
            return HttpResponseRedirect('/NNCPortal/Login/')
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in OBValidationCheck - clientCheckpointsExcelDownload -> %s'%str(e))
        return HttpResponseRedirect('/OBValidationCheck/') 
    
def getAutoRefreshCount(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.method == "GET":
                DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)  
                url = DjnagoApiUrl+'obvalidation/checklistcount/'
                validateCounts = comObj.getAPIResponce(url, 'ticket')
                data = json.dumps(validateCounts['checkPointsCount'])
                return HttpResponse(data, content_type="application/json")
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in OBValidationCheck - getAutoRefreshCount -> %s'%str(e))
        return HttpResponseRedirect('/OBValidationCheck/')  
      
def partnerReport(request):
    try:
        authRes = comObj.checkAuthentication(request)
        if authRes == True :
            if request.method == "GET":
                partnerId = request.GET.get('partnerId','')
                mspName = request.GET.get('partnerName','')
                DjnagoApiUrl = configobj.getCommConfigValue(configobj.DjnagoAppsApiUrl)  
                url = DjnagoApiUrl+'obvalidation/partnerlevelrpt/'+str(partnerId)+'/'
                clientsInfo = comObj.getAPIResponce(url, 'ticket')
                return render_to_response('partnerReports.html', {'clientsInfo':clientsInfo["Result"],'mspName':mspName},context_instance=RequestContext(request))
    except Exception as e:
        import logging
        log  = logging.getLogger('NNCPortal')
        log.info('')
        log.exception(' Exception in OBValidationCheck - partnerReport -> %s'%str(e))
        return HttpResponseRedirect('/OBValidationCheck/')    
                      
